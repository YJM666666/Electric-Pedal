#ifndef CONFIG_PROTOCOL_PROFILE_H
#define CONFIG_PROTOCOL_PROFILE_H

/*
 * 协议默认配置：定义事件上报、重试和超时等通信策略的默认参数。
 */
#define APP_PROTO_ACTIVE_VERSION      0x20U
#define APP_PROTO_ENABLE_V2           1U
#define APP_PROTO_ENABLE_V1_COMPAT    0U
#define APP_PROTO_UART_BAUDRATE       115200UL
#define APP_PROTO_REQ_TIMEOUT_MS      300U
#define APP_PROTO_MAX_RETRY           3U

#endif
