#ifndef CONFIG_BOARD_PROFILE_U17_GD32F130_H
#define CONFIG_BOARD_PROFILE_U17_GD32F130_H

/*
 * 文件: config/board/board_profile_u17_gd32f130.h
 * 描述: U17 (GD32F130) 板级配置：灯带与语音执行侧的引脚与功能开关。
 * 责任: 定义 U17 目标板的外设存在性、引脚映射与默认总线策略。
 */

#include "board_profile_common.h"

#define BSP_BOARD_NAME                "u17-gd32f130-light-voice-v103"
#define BSP_MCU_NAME                  "GD32F130C8T6"
#define BSP_MCU_FLASH_KB              64U
#define BSP_MCU_SRAM_KB               8U
#define BSP_HAS_FLASH                 0U
#define BSP_HAS_EEPROM                0U
#define BSP_HAS_CURRENT_ADC           0U
#define BSP_HAS_VOICE_I2C             0U
#define BSP_HAS_BUZZER               0U
#define BSP_CAN_BOARD_HAS_HS_PHY      0U
#define BSP_CAN_BOARD_HAS_FT_PHY      0U
#define BSP_MOTOR_DRIVE_BACKEND       0U  /* 无本地电机后端 */
#define BSP_HAS_MOTOR_HALL_INPUT      0U
#define BSP_MOTOR_FEEDBACK_FLAGS      0U

#define BSP_HAS_LOCAL_MOTOR_GPIO      0U
#define BSP_HAS_LOCAL_LIGHT_GPIO      1U
#define BSP_HAS_LIGHT_PWR_GPIO        1U
#define BSP_HAS_LIMIT_SWITCH_INPUTS   0U
#define BSP_HAS_MAIN_SWITCH_GPIO      0U
#define BSP_HAS_DRIVER_EN_OUTPUT      1U   /* WS-EN */
#define BSP_HAS_DRIVER_PWM_OUTPUT     0U
#define BSP_HAS_VOICE_RESET_GPIO      0U

/* U17 负责灯带供电/数据和 MX5008F 语音芯片，不负责有刷电机功率级。 */
#define BSP_HAS_LOCAL_MOTOR_GPIO      0U
#define BSP_HAS_LOCAL_LIGHT_GPIO      1U
#define BSP_HAS_LIGHT_PWR_GPIO        1U
#define BSP_HAS_LIMIT_SWITCH_INPUTS   0U
#define BSP_HAS_MAIN_SWITCH_GPIO      0U
#define BSP_HAS_DRIVER_EN_OUTPUT      1U   /* WS-EN */
#define BSP_HAS_DRIVER_PWM_OUTPUT     0U
#define BSP_HAS_VOICE_RESET_GPIO      0U

#define BSP_UART_BLE_PERIPH           USART1
#define BSP_UART_BLE_RCU              RCU_USART1
#define BSP_UART_BLE_IRQN             USART1_IRQn
#define BSP_UART_BLE_GPIO_RCU_TX      RCU_GPIOA
#define BSP_UART_BLE_GPIO_RCU_RX      RCU_GPIOA
#define BSP_UART_BLE_TX_PORT          GPIOA
#define BSP_UART_BLE_TX_PIN           GPIO_PIN_2
#define BSP_UART_BLE_RX_PORT          GPIOA
#define BSP_UART_BLE_RX_PIN           GPIO_PIN_3
#define BSP_UART_BLE_AF               GPIO_AF_1

/* 未使用的本地 UART（PA2/PA3）保留为将来工厂/调试使用。 */
#define BSP_UART_BLE_PERIPH           USART1
#define BSP_UART_BLE_RCU              RCU_USART1
#define BSP_UART_BLE_IRQN             USART1_IRQn
#define BSP_UART_BLE_GPIO_RCU_TX      RCU_GPIOA
#define BSP_UART_BLE_GPIO_RCU_RX      RCU_GPIOA
#define BSP_UART_BLE_TX_PORT          GPIOA
#define BSP_UART_BLE_TX_PIN           GPIO_PIN_2
#define BSP_UART_BLE_RX_PORT          GPIOA
#define BSP_UART_BLE_RX_PIN           GPIO_PIN_3
#define BSP_UART_BLE_AF               GPIO_AF_1

#define BSP_UART_LINK_IS_SOFT         0U
#define BSP_UART_LINK_PERIPH          USART0
#define BSP_UART_LINK_RCU             RCU_USART0
#define BSP_UART_LINK_IRQN            USART0_IRQn
#define BSP_UART_LINK_AF              GPIO_AF_1
#define BSP_UART_LINK_GPIO_RCU_TX     RCU_GPIOA
#define BSP_UART_LINK_GPIO_RCU_RX     RCU_GPIOA
#define BSP_UART_LINK_TX_PORT         GPIOA
#define BSP_UART_LINK_TX_PIN          GPIO_PIN_9
#define BSP_UART_LINK_RX_PORT         GPIOA
#define BSP_UART_LINK_RX_PIN          GPIO_PIN_10

/* U12 <-> U17 链接：U17 PA9 CONNECT_TXD, PA10 CONNECT_RXD。 */
#define BSP_UART_LINK_IS_SOFT         0U
#define BSP_UART_LINK_PERIPH          USART0
#define BSP_UART_LINK_RCU             RCU_USART0
#define BSP_UART_LINK_IRQN            USART0_IRQn
#define BSP_UART_LINK_AF              GPIO_AF_1
#define BSP_UART_LINK_GPIO_RCU_TX     RCU_GPIOA
#define BSP_UART_LINK_GPIO_RCU_RX     RCU_GPIOA
#define BSP_UART_LINK_TX_PORT         GPIOA
#define BSP_UART_LINK_TX_PIN          GPIO_PIN_9
#define BSP_UART_LINK_RX_PORT         GPIOA
#define BSP_UART_LINK_RX_PIN          GPIO_PIN_10

#define BSP_SPI_FLASH_SW_ONLY         0U
#define BSP_SPI_FLASH_CS_GPIO_RCU     ((rcu_periph_enum)0)
#define BSP_SPI_FLASH_SCK_GPIO_RCU    ((rcu_periph_enum)0)
#define BSP_SPI_FLASH_MISO_GPIO_RCU   ((rcu_periph_enum)0)
#define BSP_SPI_FLASH_MOSI_GPIO_RCU   ((rcu_periph_enum)0)
#define BSP_SPI_FLASH_CS_PORT         ((uint32_t)0U)
#define BSP_SPI_FLASH_CS_PIN          ((uint32_t)0U)
#define BSP_SPI_FLASH_SCK_PORT        ((uint32_t)0U)
#define BSP_SPI_FLASH_SCK_PIN         ((uint32_t)0U)
#define BSP_SPI_FLASH_MISO_PORT       ((uint32_t)0U)
#define BSP_SPI_FLASH_MISO_PIN        ((uint32_t)0U)
#define BSP_SPI_FLASH_MOSI_PORT       ((uint32_t)0U)
#define BSP_SPI_FLASH_MOSI_PIN        ((uint32_t)0U)

#define BSP_I2C_EE_PERIPH             ((uint32_t)0U)
#define BSP_I2C_EE_RCU                ((rcu_periph_enum)0)
#define BSP_I2C_EE_GPIO_RCU           ((rcu_periph_enum)0)
#define BSP_I2C_EE_SCL_PORT           ((uint32_t)0U)
#define BSP_I2C_EE_SCL_PIN            ((uint32_t)0U)
#define BSP_I2C_EE_SDA_PORT           ((uint32_t)0U)
#define BSP_I2C_EE_SDA_PIN            ((uint32_t)0U)
#define BSP_I2C_EE_AF                 ((uint32_t)0U)

#define BSP_I2C_EE_PERIPH             ((uint32_t)0U)
#define BSP_I2C_EE_RCU                ((rcu_periph_enum)0)
#define BSP_I2C_EE_GPIO_RCU           ((rcu_periph_enum)0)
#define BSP_I2C_EE_SCL_PORT           ((uint32_t)0U)
#define BSP_I2C_EE_SCL_PIN            ((uint32_t)0U)
#define BSP_I2C_EE_SDA_PORT           ((uint32_t)0U)
#define BSP_I2C_EE_SDA_PIN            ((uint32_t)0U)
#define BSP_I2C_EE_AF                 ((uint32_t)0U)

/* 电机引脚故意设为占位，因为 U17 不负责有刷继电器级。 */
#define BSP_GPIO_L_MOTOR_A_RCU        RCU_GPIOA
#define BSP_GPIO_L_MOTOR_A_PORT       GPIOA
#define BSP_GPIO_L_MOTOR_A_PIN        GPIO_PIN_0
#define BSP_GPIO_L_MOTOR_B_RCU        RCU_GPIOA
#define BSP_GPIO_L_MOTOR_B_PORT       GPIOA
#define BSP_GPIO_L_MOTOR_B_PIN        GPIO_PIN_0
#define BSP_GPIO_R_MOTOR_A_RCU        RCU_GPIOA
#define BSP_GPIO_R_MOTOR_A_PORT       GPIOA
#define BSP_GPIO_R_MOTOR_A_PIN        GPIO_PIN_0
#define BSP_GPIO_R_MOTOR_B_RCU        RCU_GPIOA
#define BSP_GPIO_R_MOTOR_B_PORT       GPIOA
#define BSP_GPIO_R_MOTOR_B_PIN        GPIO_PIN_0

#define BSP_GPIO_LIGHT_L_RCU          RCU_GPIOB
#define BSP_GPIO_LIGHT_L_PORT         GPIOB
#define BSP_GPIO_LIGHT_L_PIN          GPIO_PIN_10   /* LED_DATA_L1 */
#define BSP_GPIO_LIGHT_R_RCU          RCU_GPIOB
#define BSP_GPIO_LIGHT_R_PORT         GPIOB
#define BSP_GPIO_LIGHT_R_PIN          GPIO_PIN_11   /* LED_DATA_R1 */
#define BSP_GPIO_LIGHT_DATA_L2_RCU    RCU_GPIOB
#define BSP_GPIO_LIGHT_DATA_L2_PORT   GPIOB
#define BSP_GPIO_LIGHT_DATA_L2_PIN    GPIO_PIN_1
#define BSP_GPIO_LIGHT_DATA_R2_RCU    RCU_GPIOB
#define BSP_GPIO_LIGHT_DATA_R2_PORT   GPIOB
#define BSP_GPIO_LIGHT_DATA_R2_PIN    GPIO_PIN_2

/* 灯带数据引脚。 */
#define BSP_GPIO_LIGHT_L_RCU          RCU_GPIOB
#define BSP_GPIO_LIGHT_L_PORT         GPIOB
#define BSP_GPIO_LIGHT_L_PIN          GPIO_PIN_10   /* LED_DATA_L1 */
#define BSP_GPIO_LIGHT_R_RCU          RCU_GPIOB
#define BSP_GPIO_LIGHT_R_PORT         GPIOB
#define BSP_GPIO_LIGHT_R_PIN          GPIO_PIN_11   /* LED_DATA_R1 */
#define BSP_GPIO_LIGHT_DATA_L2_RCU    RCU_GPIOB
#define BSP_GPIO_LIGHT_DATA_L2_PORT   GPIOB
#define BSP_GPIO_LIGHT_DATA_L2_PIN    GPIO_PIN_1
#define BSP_GPIO_LIGHT_DATA_R2_RCU    RCU_GPIOB
#define BSP_GPIO_LIGHT_DATA_R2_PORT   GPIOB
#define BSP_GPIO_LIGHT_DATA_R2_PIN    GPIO_PIN_2

#define BSP_GPIO_LIGHT_PWR_L1_RCU     RCU_GPIOA
#define BSP_GPIO_LIGHT_PWR_L1_PORT    GPIOA
#define BSP_GPIO_LIGHT_PWR_L1_PIN     GPIO_PIN_5
#define BSP_GPIO_LIGHT_PWR_R1_RCU     RCU_GPIOA
#define BSP_GPIO_LIGHT_PWR_R1_PORT    GPIOA
#define BSP_GPIO_LIGHT_PWR_R1_PIN     GPIO_PIN_4
#define BSP_GPIO_LIGHT_PWR_L2_RCU     RCU_GPIOA
#define BSP_GPIO_LIGHT_PWR_L2_PORT    GPIOA
#define BSP_GPIO_LIGHT_PWR_L2_PIN     GPIO_PIN_1
#define BSP_GPIO_LIGHT_PWR_R2_RCU     RCU_GPIOA
#define BSP_GPIO_LIGHT_PWR_R2_PORT    GPIOA
#define BSP_GPIO_LIGHT_PWR_R2_PIN     GPIO_PIN_0

/* 灯带电源使能引脚。 */
#define BSP_GPIO_LIGHT_PWR_L1_RCU     RCU_GPIOA
#define BSP_GPIO_LIGHT_PWR_L1_PORT    GPIOA
#define BSP_GPIO_LIGHT_PWR_L1_PIN     GPIO_PIN_5
#define BSP_GPIO_LIGHT_PWR_R1_RCU     RCU_GPIOA
#define BSP_GPIO_LIGHT_PWR_R1_PORT    GPIOA
#define BSP_GPIO_LIGHT_PWR_R1_PIN     GPIO_PIN_4
#define BSP_GPIO_LIGHT_PWR_L2_RCU     RCU_GPIOA
#define BSP_GPIO_LIGHT_PWR_L2_PORT    GPIOA
#define BSP_GPIO_LIGHT_PWR_L2_PIN     GPIO_PIN_1
#define BSP_GPIO_LIGHT_PWR_R2_RCU     RCU_GPIOA
#define BSP_GPIO_LIGHT_PWR_R2_PORT    GPIOA
#define BSP_GPIO_LIGHT_PWR_R2_PIN     GPIO_PIN_0

#define BSP_GPIO_BUZZER_RCU           RCU_GPIOA
#define BSP_GPIO_BUZZER_PORT          GPIOA
#define BSP_GPIO_BUZZER_PIN           GPIO_PIN_0
#define BSP_GPIO_DRIVER_EN_RCU        RCU_GPIOB
#define BSP_GPIO_DRIVER_EN_PORT       GPIOB
#define BSP_GPIO_DRIVER_EN_PIN        GPIO_PIN_12   /* WS-EN */
#define BSP_GPIO_DRIVER_PWM_RCU       RCU_GPIOA
#define BSP_GPIO_DRIVER_PWM_PORT      GPIOA
#define BSP_GPIO_DRIVER_PWM_PIN       GPIO_PIN_6    /* PWM 线路，不由固件驱动 */
#define BSP_GPIO_VOICE_RST_RCU        RCU_GPIOA
#define BSP_GPIO_VOICE_RST_PORT       GPIOA
#define BSP_GPIO_VOICE_RST_PIN        GPIO_PIN_0
#define BSP_GPIO_VOICE_DATA_RCU       RCU_GPIOB
#define BSP_GPIO_VOICE_DATA_PORT      GPIOB
#define BSP_GPIO_VOICE_DATA_PIN       GPIO_PIN_5    /* DATA_SPK */
#define BSP_GPIO_VOICE_BUSY_RCU       RCU_GPIOB
#define BSP_GPIO_VOICE_BUSY_PORT      GPIOB
#define BSP_GPIO_VOICE_BUSY_PIN       GPIO_PIN_4    /* BUSY */
#define BSP_VOICE_BUSY_WIRED          1U
#define BSP_VOICE_BUSY_ACTIVE_LOW     1U

#define BSP_GPIO_BUZZER_RCU           RCU_GPIOA
#define BSP_GPIO_BUZZER_PORT          GPIOA
#define BSP_GPIO_BUZZER_PIN           GPIO_PIN_0
#define BSP_GPIO_DRIVER_EN_RCU        RCU_GPIOB
#define BSP_GPIO_DRIVER_EN_PORT       GPIOB
#define BSP_GPIO_DRIVER_EN_PIN        GPIO_PIN_12   /* WS-EN */
#define BSP_GPIO_DRIVER_PWM_RCU       RCU_GPIOA
#define BSP_GPIO_DRIVER_PWM_PORT      GPIOA
#define BSP_GPIO_DRIVER_PWM_PIN       GPIO_PIN_6    /* PWM 线路，不由固件驱动 */
#define BSP_GPIO_VOICE_RST_RCU        RCU_GPIOA
#define BSP_GPIO_VOICE_RST_PORT       GPIOA
#define BSP_GPIO_VOICE_RST_PIN        GPIO_PIN_0
#define BSP_GPIO_VOICE_DATA_RCU       RCU_GPIOB
#define BSP_GPIO_VOICE_DATA_PORT      GPIOB
#define BSP_GPIO_VOICE_DATA_PIN       GPIO_PIN_5    /* DATA_SPK */
#define BSP_GPIO_VOICE_BUSY_RCU       RCU_GPIOB
#define BSP_GPIO_VOICE_BUSY_PORT      GPIOB
#define BSP_GPIO_VOICE_BUSY_PIN       GPIO_PIN_4    /* BUSY */
#define BSP_VOICE_BUSY_WIRED          1U
#define BSP_VOICE_BUSY_ACTIVE_LOW     1U

/* U17 V1.03 无本地限位/主开关输入。 */
#define BSP_GPIO_L_EXT_RCU            RCU_GPIOA
#define BSP_GPIO_L_EXT_PORT           GPIOA
#define BSP_GPIO_L_EXT_PIN            GPIO_PIN_0
#define BSP_GPIO_L_RET_RCU            RCU_GPIOA
#define BSP_GPIO_L_RET_PORT           GPIOA
#define BSP_GPIO_L_RET_PIN            GPIO_PIN_0
#define BSP_GPIO_R_EXT_RCU            RCU_GPIOA
#define BSP_GPIO_R_EXT_PORT           GPIOA
#define BSP_GPIO_R_EXT_PIN            GPIO_PIN_0
#define BSP_GPIO_R_RET_RCU            RCU_GPIOA
#define BSP_GPIO_R_RET_PORT           GPIOA
#define BSP_GPIO_R_RET_PIN            GPIO_PIN_0
#define BSP_GPIO_MAIN_SW_RCU          RCU_GPIOA
#define BSP_GPIO_MAIN_SW_PORT         GPIOA
#define BSP_GPIO_MAIN_SW_PIN          GPIO_PIN_0

#define BSP_ADC_GPIO_RCU              RCU_GPIOA
#define BSP_ADC_LEFT_PORT             GPIOA
#define BSP_ADC_LEFT_PIN              GPIO_PIN_0
#define BSP_ADC_RIGHT_PORT            GPIOA
#define BSP_ADC_RIGHT_PIN             GPIO_PIN_1
#define BSP_ADC_LEFT_CHANNEL          ADC_CHANNEL_0
#define BSP_ADC_RIGHT_CHANNEL         ADC_CHANNEL_1
#define BSP_CAN0_DEFAULT_NOMINAL      500000UL
#define BSP_CAN0_DEFAULT_DATA_2M      2000000UL
#define BSP_CAN0_DEFAULT_DATA_5M      5000000UL
#define BSP_CAN1_DEFAULT_NOMINAL      125000UL
#define BSP_CAN0_DEFAULT_LISTEN_ONLY  1U
#define BSP_CAN1_DEFAULT_LISTEN_ONLY  1U
#define BSP_CAN0_RCU                  ((rcu_periph_enum)0)
#define BSP_CAN1_RCU                  ((rcu_periph_enum)0)
#define BSP_CAN_GPIOA_RCU             RCU_GPIOA
#define BSP_CAN_GPIOB_RCU             RCU_GPIOB
#define BSP_CAN_AF_RCU                RCU_AF
#define BSP_CAN0_RX_PORT              GPIOA
#define BSP_CAN0_RX_PIN               GPIO_PIN_11
#define BSP_CAN0_TX_PORT              GPIOA
#define BSP_CAN0_TX_PIN               GPIO_PIN_12
#define BSP_CAN1_RX_PORT              GPIOB
#define BSP_CAN1_RX_PIN               GPIO_PIN_12
#define BSP_CAN1_TX_PORT              GPIOB
#define BSP_CAN1_TX_PIN               GPIO_PIN_13
#define BSP_CAN_GPIO_INPUT_MODE       GPIO_MODE_IPU
#define BSP_CAN_GPIO_OUTPUT_MODE      GPIO_MODE_AF_PP

#endif
