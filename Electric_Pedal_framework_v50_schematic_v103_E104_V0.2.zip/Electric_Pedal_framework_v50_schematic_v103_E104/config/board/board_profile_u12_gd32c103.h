#ifndef CONFIG_BOARD_PROFILE_U12_GD32C103_H
#define CONFIG_BOARD_PROFILE_U12_GD32C103_H

/*
 * 鏂囦欢: config/board/board_profile_u12_gd32c103.h
 * 鎻忚堪: U12 (GD32C103) 鏉跨骇閰嶇疆锛欸PIO銆佸璁句笌鎬荤嚎绛栫暐銆? * 璐ｄ换: 涓虹紪璇戞湡閫夋嫨涓?BSP 鎻愪緵鏉跨骇寮曡剼/澶栬鏄犲皠鍙婂姛鑳藉紑鍏炽€? */

#include "board_profile_common.h"

#define BSP_BOARD_NAME                "u12-gd32c103-main-v103"
#define BSP_MCU_NAME                  "GD32C103CBT6"
#define BSP_MCU_FLASH_KB              128U
#define BSP_MCU_SRAM_KB               32U
#define BSP_HAS_FLASH                 1U
#define BSP_HAS_EEPROM                1U
#define BSP_HAS_CURRENT_ADC           1U
#define BSP_HAS_VOICE_I2C             0U
#define BSP_HAS_BUZZER               0U
#define BSP_CAN_BOARD_HAS_HS_PHY      1U
#define BSP_CAN_BOARD_HAS_FT_PHY      1U
#define BSP_MOTOR_DRIVE_BACKEND       1U  /* 缁х數鍣?GPIO 鍚庣 */
#define BSP_HAS_MOTOR_HALL_INPUT      1U
#define BSP_MOTOR_FEEDBACK_FLAGS      3U  /* 鐢垫祦 + 闇嶅皵锛沄1.03 鏃犵嫭绔嬮檺浣嶅紑鍏宠緭鍏?*/

#define BSP_HAS_LOCAL_MOTOR_GPIO      1U
#define BSP_HAS_LOCAL_LIGHT_GPIO      0U
#define BSP_HAS_LIGHT_PWR_GPIO        0U
#define BSP_HAS_LIMIT_SWITCH_INPUTS   0U
#define BSP_HAS_MAIN_SWITCH_GPIO      1U
#define BSP_HAS_DRIVER_EN_OUTPUT      0U
#define BSP_HAS_DRIVER_PWM_OUTPUT     0U
#define BSP_HAS_VOICE_RESET_GPIO      0U

/* 鍘熺悊鍥?An'ersi V1.03 (2026-05-08) 涓婄殑 GPIO 褰掑睘銆?*/
#define BSP_HAS_LOCAL_MOTOR_GPIO      1U
#define BSP_HAS_LOCAL_LIGHT_GPIO      0U
#define BSP_HAS_LIGHT_PWR_GPIO        0U
#define BSP_HAS_LIMIT_SWITCH_INPUTS   0U
#define BSP_HAS_MAIN_SWITCH_GPIO      1U
#define BSP_HAS_DRIVER_EN_OUTPUT      0U
#define BSP_HAS_DRIVER_PWM_OUTPUT     0U
#define BSP_HAS_VOICE_RESET_GPIO      0U

/* E104-BT52 钃濈墮妯″潡锛氶€氳繃浣庣數骞?PMOS 闂ㄤ緵鐢碉紝WKP 鎷変綆淇濇寔妯″潡鍞ら啋銆?*/
#define BSP_BLE_MODULE_E104_BT52      1U
#define BSP_BLE_E104_AUTOCONFIG       1U
#define BSP_BLE_E104_PWR_EN_N_RCU     RCU_GPIOA
#define BSP_BLE_E104_PWR_EN_N_PORT    GPIOA
#define BSP_BLE_E104_PWR_EN_N_PIN     GPIO_PIN_8
#define BSP_BLE_E104_WKP_RCU          RCU_GPIOC
#define BSP_BLE_E104_WKP_PORT         GPIOC
#define BSP_BLE_E104_WKP_PIN          GPIO_PIN_13

/* 搴旂敤 / BLE UART锛歎12 PA9=USART0_TX -> E104 RXD锛孭A10=USART0_RX <- E104 TXD銆?*/
#define BSP_UART_BLE_PERIPH           USART0
#define BSP_UART_BLE_RCU              RCU_USART0
#define BSP_UART_BLE_IRQN             USART0_IRQn
#define BSP_UART_BLE_GPIO_RCU_TX      RCU_GPIOA
#define BSP_UART_BLE_GPIO_RCU_RX      RCU_GPIOA
#define BSP_UART_BLE_TX_PORT          GPIOA
#define BSP_UART_BLE_TX_PIN           GPIO_PIN_9
#define BSP_UART_BLE_RX_PORT          GPIOA
#define BSP_UART_BLE_RX_PIN           GPIO_PIN_10
#define BSP_UART_BLE_AF               ((uint32_t)0U)


/* U12 <-> U17 涓婚摼璺細U12 PB10 USART2_TX -> CONNECT_RXD锛孭B11 USART2_RX <- CONNECT_TXD銆?*/
#define BSP_UART_LINK_IS_SOFT         0U
#define BSP_UART_LINK_TX_PORT         GPIOB
#define BSP_UART_LINK_TX_PIN          GPIO_PIN_10
#define BSP_UART_LINK_RX_PORT         GPIOB
#define BSP_UART_LINK_RX_PIN          GPIO_PIN_11
#define BSP_UART_LINK_GPIO_RCU_TX     RCU_GPIOB
#define BSP_UART_LINK_GPIO_RCU_RX     RCU_GPIOB
#define BSP_UART_LINK_PERIPH          USART2
#define BSP_UART_LINK_RCU             RCU_USART2
#define BSP_UART_LINK_IRQN            USART2_IRQn
#define BSP_UART_LINK_AF              ((uint32_t)0U)


/* W25Q128 浣嶄簬 U12 PB3/PB4/PB5/PB6銆俠sp_platform 绂佺敤 JTAG锛孲WD 淇濈暀鍦?PA13/PA14銆?*/
#define BSP_SPI_FLASH_SW_ONLY         1U
#define BSP_SPI_FLASH_CS_GPIO_RCU     RCU_GPIOB
#define BSP_SPI_FLASH_SCK_GPIO_RCU    RCU_GPIOB
#define BSP_SPI_FLASH_MISO_GPIO_RCU   RCU_GPIOB
#define BSP_SPI_FLASH_MOSI_GPIO_RCU   RCU_GPIOB
#define BSP_SPI_FLASH_CS_PORT         GPIOB
#define BSP_SPI_FLASH_CS_PIN          GPIO_PIN_6
#define BSP_SPI_FLASH_SCK_PORT        GPIOB
#define BSP_SPI_FLASH_SCK_PIN         GPIO_PIN_3
#define BSP_SPI_FLASH_MISO_PORT       GPIOB
#define BSP_SPI_FLASH_MISO_PIN        GPIO_PIN_4
#define BSP_SPI_FLASH_MOSI_PORT       GPIOB
#define BSP_SPI_FLASH_MOSI_PIN        GPIO_PIN_5


/* AT24C04C EEPROM 鍦?I2C0锛堥噸鏄犲皠 PB8/PB9锛夈€?*/
#define BSP_I2C_EE_PERIPH             I2C0
#define BSP_I2C_EE_RCU                RCU_I2C0
#define BSP_I2C_EE_GPIO_RCU           RCU_GPIOB
#define BSP_I2C_EE_SCL_PORT           GPIOB
#define BSP_I2C_EE_SCL_PIN            GPIO_PIN_8
#define BSP_I2C_EE_SDA_PORT           GPIOB
#define BSP_I2C_EE_SDA_PIN            GPIO_PIN_9
#define BSP_I2C_EE_AF                 ((uint32_t)0U)
#define BSP_I2C_EE_REMAP              GPIO_I2C0_REMAP


/* CAN 鎶借薄锛欳AN0 = SIT1044T/3锛圕AN-FD PHY锛夛紝CAN1 = TJA1055锛堝閿欎綆閫?PHY锛夈€?*/
#define BSP_CAN0_RCU                  RCU_CAN0
#define BSP_CAN1_RCU                  RCU_CAN1
#define BSP_CAN_GPIOA_RCU             RCU_GPIOA
#define BSP_CAN_GPIOB_RCU             RCU_GPIOB
#define BSP_CAN_AF_RCU                RCU_AF
#define BSP_CAN0_RX_PORT              GPIOA
#define BSP_CAN0_RX_PIN               GPIO_PIN_11
#define BSP_CAN0_TX_PORT              GPIOA
#define BSP_CAN0_TX_PIN               GPIO_PIN_12
#define BSP_CAN1_RX_PORT              GPIOB
#define BSP_CAN1_RX_PIN               GPIO_PIN_12
#define BSP_CAN1_TX_PORT              GPIOB
#define BSP_CAN1_TX_PIN               GPIO_PIN_13
#define BSP_CAN_GPIO_INPUT_MODE       GPIO_MODE_IPU
#define BSP_CAN_GPIO_OUTPUT_MODE      GPIO_MODE_AF_PP
#define BSP_CAN0_STB_WIRED            1U
#define BSP_CAN0_STB_RCU              RCU_GPIOB
#define BSP_CAN0_STB_PORT             GPIOB
#define BSP_CAN0_STB_PIN              GPIO_PIN_15
#define BSP_CAN1_STB_WIRED            1U
#define BSP_CAN1_STB_RCU              RCU_GPIOB
#define BSP_CAN1_STB_PORT             GPIOB
#define BSP_CAN1_STB_PIN              GPIO_PIN_14


/* 榛樿鎬荤嚎绛栫暐锛欳AN0=FD 500k 浠茶 + 2M/5M 鏁版嵁锛孋AN1=缁忓吀 125k銆?*/
#define BSP_CAN0_DEFAULT_NOMINAL      500000UL
#define BSP_CAN0_DEFAULT_DATA_2M      2000000UL
#define BSP_CAN0_DEFAULT_DATA_5M      5000000UL
#define BSP_CAN1_DEFAULT_NOMINAL      125000UL
#define BSP_CAN0_DEFAULT_LISTEN_ONLY  1U
#define BSP_CAN1_DEFAULT_LISTEN_ONLY  1U


/* 鏈夊埛缁х數鍣ㄨ緭鍑猴細MOTOR1A/B 鍦?PB0/PB1锛孧OTOR2A/B 鍦?PB2/PA15銆?*/
#define BSP_GPIO_L_MOTOR_A_RCU        RCU_GPIOB
#define BSP_GPIO_L_MOTOR_A_PORT       GPIOB
#define BSP_GPIO_L_MOTOR_A_PIN        GPIO_PIN_0
#define BSP_GPIO_L_MOTOR_B_RCU        RCU_GPIOB
#define BSP_GPIO_L_MOTOR_B_PORT       GPIOB
#define BSP_GPIO_L_MOTOR_B_PIN        GPIO_PIN_1
#define BSP_GPIO_R_MOTOR_A_RCU        RCU_GPIOB
#define BSP_GPIO_R_MOTOR_A_PORT       GPIOB
#define BSP_GPIO_R_MOTOR_A_PIN        GPIO_PIN_2
#define BSP_GPIO_R_MOTOR_B_RCU        RCU_GPIOA
#define BSP_GPIO_R_MOTOR_B_PORT       GPIOA
#define BSP_GPIO_R_MOTOR_B_PIN        GPIO_PIN_15


/* U12 鍦?V1.03 涓嶉┍鍔ㄧ伅/璇煶锛涜繖浜涘湪缂栬瘧鏈熶负鍗犱綅锛屼細琚?bsp_gpio 璺宠繃銆?*/
#define BSP_GPIO_LIGHT_L_RCU          RCU_GPIOA
#define BSP_GPIO_LIGHT_L_PORT         GPIOA
#define BSP_GPIO_LIGHT_L_PIN          GPIO_PIN_0
#define BSP_GPIO_LIGHT_R_RCU          RCU_GPIOA
#define BSP_GPIO_LIGHT_R_PORT         GPIOA
#define BSP_GPIO_LIGHT_R_PIN          GPIO_PIN_0
#define BSP_GPIO_LIGHT_DATA_L2_RCU    RCU_GPIOA
#define BSP_GPIO_LIGHT_DATA_L2_PORT   GPIOA
#define BSP_GPIO_LIGHT_DATA_L2_PIN    GPIO_PIN_0
#define BSP_GPIO_LIGHT_DATA_R2_RCU    RCU_GPIOA
#define BSP_GPIO_LIGHT_DATA_R2_PORT   GPIOA
#define BSP_GPIO_LIGHT_DATA_R2_PIN    GPIO_PIN_0
#define BSP_GPIO_LIGHT_PWR_L1_RCU     RCU_GPIOA
#define BSP_GPIO_LIGHT_PWR_L1_PORT    GPIOA
#define BSP_GPIO_LIGHT_PWR_L1_PIN     GPIO_PIN_0
#define BSP_GPIO_LIGHT_PWR_R1_RCU     RCU_GPIOA
#define BSP_GPIO_LIGHT_PWR_R1_PORT    GPIOA
#define BSP_GPIO_LIGHT_PWR_R1_PIN     GPIO_PIN_0
#define BSP_GPIO_LIGHT_PWR_L2_RCU     RCU_GPIOA
#define BSP_GPIO_LIGHT_PWR_L2_PORT    GPIOA
#define BSP_GPIO_LIGHT_PWR_L2_PIN     GPIO_PIN_0
#define BSP_GPIO_LIGHT_PWR_R2_RCU     RCU_GPIOA
#define BSP_GPIO_LIGHT_PWR_R2_PORT    GPIOA
#define BSP_GPIO_LIGHT_PWR_R2_PIN     GPIO_PIN_0
#define BSP_GPIO_BUZZER_RCU           RCU_GPIOA
#define BSP_GPIO_BUZZER_PORT          GPIOA
#define BSP_GPIO_BUZZER_PIN           GPIO_PIN_0
#define BSP_GPIO_DRIVER_EN_RCU        RCU_GPIOA
#define BSP_GPIO_DRIVER_EN_PORT       GPIOA
#define BSP_GPIO_DRIVER_EN_PIN        GPIO_PIN_0
#define BSP_GPIO_DRIVER_PWM_RCU       RCU_GPIOA
#define BSP_GPIO_DRIVER_PWM_PORT      GPIOA
#define BSP_GPIO_DRIVER_PWM_PIN       GPIO_PIN_0
#define BSP_GPIO_VOICE_RST_RCU        RCU_GPIOA
#define BSP_GPIO_VOICE_RST_PORT       GPIOA
#define BSP_GPIO_VOICE_RST_PIN        GPIO_PIN_0
#define BSP_GPIO_VOICE_DATA_RCU       RCU_GPIOA
#define BSP_GPIO_VOICE_DATA_PORT      GPIOA
#define BSP_GPIO_VOICE_DATA_PIN       GPIO_PIN_0
#define BSP_GPIO_VOICE_BUSY_RCU       RCU_GPIOA
#define BSP_GPIO_VOICE_BUSY_PORT      GPIOA
#define BSP_GPIO_VOICE_BUSY_PIN       GPIO_PIN_0
#define BSP_VOICE_BUSY_WIRED          0U
#define BSP_VOICE_BUSY_ACTIVE_LOW     1U


/* V1.03 鏃犵鏁ｉ檺浣嶅紑鍏炽€備富寮€鍏充唬鐞嗕娇鐢?PA5 鐨?INT-CHECK銆?*/
#define BSP_GPIO_L_EXT_RCU            RCU_GPIOA
#define BSP_GPIO_L_EXT_PORT           GPIOA
#define BSP_GPIO_L_EXT_PIN            GPIO_PIN_0
#define BSP_GPIO_L_RET_RCU            RCU_GPIOA
#define BSP_GPIO_L_RET_PORT           GPIOA
#define BSP_GPIO_L_RET_PIN            GPIO_PIN_0
#define BSP_GPIO_R_EXT_RCU            RCU_GPIOA
#define BSP_GPIO_R_EXT_PORT           GPIOA
#define BSP_GPIO_R_EXT_PIN            GPIO_PIN_0
#define BSP_GPIO_R_RET_RCU            RCU_GPIOA
#define BSP_GPIO_R_RET_PORT           GPIOA
#define BSP_GPIO_R_RET_PIN            GPIO_PIN_0
#define BSP_GPIO_MAIN_SW_RCU          RCU_GPIOA
#define BSP_GPIO_MAIN_SW_PORT         GPIOA
#define BSP_GPIO_MAIN_SW_PIN          GPIO_PIN_5


/* ADC 杈撳叆锛氱數娴侀噰鏍峰湪 PA0/PA1銆?*/
#define BSP_ADC_GPIO_RCU              RCU_GPIOA
#define BSP_ADC_LEFT_PORT             GPIOA
#define BSP_ADC_LEFT_PIN              GPIO_PIN_0
#define BSP_ADC_RIGHT_PORT            GPIOA
#define BSP_ADC_RIGHT_PIN             GPIO_PIN_1
#define BSP_ADC_LEFT_CHANNEL          ADC_CHANNEL_0
#define BSP_ADC_RIGHT_CHANNEL         ADC_CHANNEL_1

/* 闇嶅皵鍙嶉杈撳叆銆?*/
#define BSP_GPIO_L_HALL_RCU           RCU_GPIOA
#define BSP_GPIO_L_HALL_PORT          GPIOA
#define BSP_GPIO_L_HALL_PIN           GPIO_PIN_6
#define BSP_GPIO_L_HALL_PORT_SRC      GPIO_PORT_SOURCE_GPIOA
#define BSP_GPIO_L_HALL_PIN_SRC       GPIO_PIN_SOURCE_6
#define BSP_GPIO_L_HALL_EXTI_LINE     EXTI_6
#define BSP_GPIO_L_HALL_IRQN          EXTI5_9_IRQn
#define BSP_GPIO_R_HALL_RCU           RCU_GPIOA
#define BSP_GPIO_R_HALL_PORT          GPIOA
#define BSP_GPIO_R_HALL_PIN           GPIO_PIN_7
#define BSP_GPIO_R_HALL_PORT_SRC      GPIO_PORT_SOURCE_GPIOA
#define BSP_GPIO_R_HALL_PIN_SRC       GPIO_PIN_SOURCE_7
#define BSP_GPIO_R_HALL_EXTI_LINE     EXTI_7
#define BSP_GPIO_R_HALL_IRQN          EXTI5_9_IRQn

#endif

