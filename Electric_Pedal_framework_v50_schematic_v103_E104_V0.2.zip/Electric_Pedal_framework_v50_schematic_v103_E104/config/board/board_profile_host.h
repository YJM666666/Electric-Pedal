#ifndef CONFIG_BOARD_PROFILE_HOST_H
#define CONFIG_BOARD_PROFILE_HOST_H

/*
 * 文件: config/board/board_profile_host.h
 * 描述: Host 模拟/测试板配置（用于桌面/主机端模拟环境）。
 * 责任: 在主机测试/模拟构建中提供占位的外设宏和默认设置。
 */

#include "board_profile_common.h"
#define BSP_BOARD_NAME                "host-mock"
#define BSP_MCU_NAME                  "host"
#define BSP_MCU_FLASH_KB              512U
#define BSP_MCU_SRAM_KB               64U
#define BSP_HAS_FLASH                 1U
#define BSP_HAS_EEPROM                1U
#define BSP_HAS_CURRENT_ADC           1U
#define BSP_HAS_VOICE_I2C             0U
#define BSP_HAS_BUZZER               0U
#define BSP_CAN_BOARD_HAS_HS_PHY      1U
#define BSP_HAS_MOTOR_HALL_INPUT      1U
#define BSP_CAN_BOARD_HAS_FT_PHY      1U
#define BSP_MOTOR_DRIVE_BACKEND       1U  /* 继电器 GPIO 后端 */
#define BSP_MOTOR_FEEDBACK_FLAGS      7U  /* 电流 + 霍尔 + 限位开关：用于主机测试 */
#define BSP_SPI_FLASH_SW_ONLY         1U
#define BSP_VOICE_BUSY_WIRED          0U
#define BSP_VOICE_BUSY_ACTIVE_LOW     1U
#define BSP_GPIO_VOICE_DATA_RCU       0U
#define BSP_GPIO_VOICE_DATA_PORT      0U
#define BSP_GPIO_VOICE_DATA_PIN       0U
#define BSP_GPIO_VOICE_BUSY_RCU       0U
#define BSP_GPIO_VOICE_BUSY_PORT      0U
#define BSP_GPIO_VOICE_BUSY_PIN       0U
#define BSP_I2C_EE_PERIPH             0U
#define BSP_I2C_EE_RCU                0U
#define BSP_I2C_EE_GPIO_RCU           0U
#define BSP_I2C_EE_SCL_PORT           0U
#define BSP_I2C_EE_SCL_PIN            0U
#define BSP_I2C_EE_SDA_PORT           0U
#define BSP_I2C_EE_SDA_PIN            0U
#define BSP_I2C_EE_AF                 0U

#define BSP_CAN0_DEFAULT_NOMINAL      500000UL
#define BSP_CAN0_DEFAULT_DATA_2M      2000000UL
#define BSP_CAN0_DEFAULT_DATA_5M      5000000UL
#define BSP_CAN1_DEFAULT_NOMINAL      125000UL
#define BSP_CAN0_DEFAULT_LISTEN_ONLY  1U
#define BSP_CAN1_DEFAULT_LISTEN_ONLY  1U

/* GPIO ID 枚举定义在 board_profile_common.h 中共享使用 */

#endif
