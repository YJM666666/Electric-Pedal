#ifndef CONFIG_BOARD_PROFILE_COMMON_H
#define CONFIG_BOARD_PROFILE_COMMON_H

/*
 * 文件: config/board/board_profile_common.h
 * 描述: 板级通用配置与外设映射的共享定义。
 * 责任: 提供各型号板文件共享的 GPIO 枚举、时钟与闪存参数等公共宏。
 */

#include "bsp/bsp_build.h"

#if BSP_PLATFORM_GD32
#if defined(BSP_TARGET_GD32C103)
#include "gd32c10x.h"
#include "gd32c10x_rcu.h"
#include "gd32c10x_gpio.h"
#include "gd32c10x_usart.h"
#include "gd32c10x_spi.h"
#include "gd32c10x_i2c.h"
#include "gd32c10x_can.h"
#else
#include "gd32f1x0.h"
#include "gd32f1x0_rcu.h"
#include "gd32f1x0_gpio.h"
#include "gd32f1x0_usart.h"
#include "gd32f1x0_spi.h"
#include "gd32f1x0_i2c.h"
#endif
#endif

typedef enum
{
    BSP_GPIO_OUT_L_MOTOR_A = 0,
    BSP_GPIO_OUT_L_MOTOR_B,
    BSP_GPIO_OUT_R_MOTOR_A,
    BSP_GPIO_OUT_R_MOTOR_B,
    BSP_GPIO_OUT_LIGHT_L,          /* 左侧 LED 数据线 L1 */
    BSP_GPIO_OUT_LIGHT_R,          /* 右侧 LED 数据线 R1 */
    BSP_GPIO_OUT_LIGHT_DATA_L2,
    BSP_GPIO_OUT_LIGHT_DATA_R2,
    BSP_GPIO_OUT_LIGHT_PWR_L1,
    BSP_GPIO_OUT_LIGHT_PWR_R1,
    BSP_GPIO_OUT_LIGHT_PWR_L2,
    BSP_GPIO_OUT_LIGHT_PWR_R2,
    BSP_GPIO_OUT_BUZZER,
    BSP_GPIO_OUT_DRIVER_EN,        /* U17 V1.03 的灯带驱动使能 */
    BSP_GPIO_OUT_DRIVER_PWM,
    BSP_GPIO_OUT_VOICE_RESET,
    BSP_GPIO_OUT_MAX
} bsp_gpio_out_id_t;

typedef enum
{
    BSP_GPIO_IN_L_EXT_LIMIT = 0,
    BSP_GPIO_IN_L_RET_LIMIT,
    BSP_GPIO_IN_R_EXT_LIMIT,
    BSP_GPIO_IN_R_RET_LIMIT,
    BSP_GPIO_IN_MAIN_SWITCH,
    BSP_GPIO_IN_MAX
} bsp_gpio_in_id_t;

#if defined(APP_ROLE_U17_SLAVE)
#define BSP_APP_IS_U17                1
#else
#define BSP_APP_IS_U17                0
#endif
#define BSP_HARDWARE_ABSTRACTION_V2   1U
#define BSP_UART_LINK_BAUDRATE        38400UL
#define BSP_UART_LINK_RETRY_TMO_10MS  5U
#define BSP_UART_LINK_MAX_RETRY       3U

#if defined(BSP_TARGET_GD32C103)
#define BSP_SYSCLK_TARGET_HZ          120000000UL
#define BSP_FLASH_SECTOR_SIZE         4096UL
#define BSP_FLASH_PAGE_SIZE           256UL
#else
#define BSP_SYSCLK_TARGET_HZ          48000000UL
#define BSP_FLASH_SECTOR_SIZE         1024UL
#define BSP_FLASH_PAGE_SIZE           1024UL
#endif

#define BSP_FLASH_PARAM_SLOT_A_ADDR   0x00010000UL
#define BSP_FLASH_PARAM_SLOT_B_ADDR   0x00011000UL
#define BSP_FLASH_FACTORY_SHADOW_ADDR 0x00012000UL
#define BSP_FLASH_OTA_META_ADDR       0x00013000UL
#define BSP_FLASH_OTA_IMAGE_ADDR      0x00014000UL
#define BSP_FLASH_OTA_IMAGE_MAX_BYTES (BSP_MCU_FLASH_KB * 1024UL)
#define BSP_EEPROM_DEV_ADDR           0x50U
#define BSP_EEPROM_PAGE_SIZE          16U
#define BSP_EEPROM_TOTAL_BYTES        512U

#endif
