#ifndef CONFIG_FLASH_LAYOUT_H
#define CONFIG_FLASH_LAYOUT_H

/*
 * 文件: config/flash_layout.h
 * 描述: U12 / U17 内部 Flash 与 EEPROM 的统一地址布局。
 * 责任: bootloader、应用、OTA 服务都引用这份定义，避免地址散落。
 *
 * U12 (GD32C103, 128KB internal flash)
 *   0x08000000  Bootloader            16KB
 *   0x08004000  App Slot A            56KB  (--> 当前应用)
 *   0x08012000  App Slot B            56KB  (--> OTA 下载落地区)
 *
 * U17 (GD32F1x0, 64KB internal flash)
 *   0x08000000  Bootloader             8KB
 *   0x08002000  App                   56KB  (--> 当前应用)
 *   外部 W25 SPI Flash 0x000000~0x00E000 用作 OTA 下载暂存区，
 *   bootloader 启动时校验通过后再搬入内部 Flash。
 *
 * 引导信息 boot_info 存放在 I2C EEPROM 的高地址区（不与 power_recovery 重叠）。
 */

#include <stdint.h>

#define FLASH_BASE_ADDR             0x08000000UL

/* ---------- U12 主控布局 ---------- */
#define FL_U12_BL_BASE              0x08000000UL
#define FL_U12_BL_SIZE              0x00004000UL  /* 16 KB */

#define FL_U12_APP_A_BASE           0x08004000UL
#define FL_U12_APP_A_SIZE           0x0000E000UL  /* 56 KB */

#define FL_U12_APP_B_BASE           0x08012000UL
#define FL_U12_APP_B_SIZE           0x0000E000UL  /* 56 KB */

#define FL_U12_APP_MAX_SIZE         FL_U12_APP_A_SIZE
#define FL_U12_SECTOR_SIZE          0x00000800UL  /* 2KB sector for GD32C10x */

/* ---------- U17 从控布局 ---------- */
#define FL_U17_BL_BASE              0x08000000UL
#define FL_U17_BL_SIZE              0x00002000UL  /* 8 KB */

#define FL_U17_APP_BASE             0x08002000UL
#define FL_U17_APP_SIZE             0x0000E000UL  /* 56 KB */

#define FL_U17_SECTOR_SIZE          0x00000400UL  /* 1KB sector for GD32F1x0 */

/* U17 OTA 暂存区在外部 SPI Flash 上 */
#define FL_U17_OTA_STAGE_SPI_BASE   0x00000000UL
#define FL_U17_OTA_STAGE_SPI_SIZE   FL_U17_APP_SIZE

/* ---------- 启动槽位枚举 ---------- */
typedef enum
{
    BOOT_SLOT_A = 0,
    BOOT_SLOT_B = 1,
    BOOT_SLOT_INVALID = 0xFFU
} boot_slot_t;

/* 取槽位的 Flash 起始地址（仅 U12 双 Bank 使用） */
static inline uint32_t flash_layout_u12_slot_base(boot_slot_t slot)
{
    return (slot == BOOT_SLOT_B) ? FL_U12_APP_B_BASE : FL_U12_APP_A_BASE;
}

#endif /* CONFIG_FLASH_LAYOUT_H */
