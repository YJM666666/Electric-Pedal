﻿# U12 一体化构建说明

现在 `PowerStep_Controller_U12.uvprojx` 内包含两个 target：

1. `U12_Bootloader`
   - 链接脚本：`Electric_Pedal_U12_boot.sct`
   - 输出：`Objects/Boot/Electric_Pedal_U12_Bootloader.hex/bin`

2. `U12_Brushed_Master`
   - 链接脚本：`Electric_Pedal_U12_app.sct`
   - 输出：`Objects/U12/Electric_Pedal_U12.bin`
   - After Build 会自动运行：
     `python .\tools\make_u12_factory_image.py --version 1.0.0`
   - 自动生成整片烧录文件：
     `Objects/U12/Electric_Pedal_U12_factory.hex`

推荐操作：

1. 打开 `PowerStep_Controller_U12.uvprojx`。
2. 使用 Batch Build，勾选并编译：
   - `U12_Bootloader`
   - `U12_Brushed_Master`
3. 烧录时选择/下载：
   `Objects/U12/Electric_Pedal_U12_factory.hex`

注意：

- 不要再单独烧 `Objects/U12/Electric_Pedal_U12.hex`，它只是应用区 hex。
- `factory.hex` 已包含：
  - 0x08000000 bootloader
  - 0x08004000 带 64 字节镜像头的应用 slot A
- 如果要改固件版本号，请修改 `U12_Brushed_Master` target 的 After Build 第二条命令里的 `--version 1.0.0`。
