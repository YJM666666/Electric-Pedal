# Scheduler / Event Collector refactor (v31)

This update tightens the framework toward the target layered architecture:

- `service/event_collector.c`
  - centralizes external input polling and event collection.
- `control/scheduler.c`
  - centralizes service maintenance, health monitoring, system FSM dispatch,
    and policy dispatch order.
- `service/event.c`
  - ring queue operations are now protected by an IRQ critical section,
    so ISR and main-loop access no longer race on `head/tail`.

Expected main-loop order:

1. `scheduler_poll_inputs()`
2. `scheduler_run_all()`
3. feed watchdog

This keeps ISR logic light while making dispatch order explicit and reusable.
