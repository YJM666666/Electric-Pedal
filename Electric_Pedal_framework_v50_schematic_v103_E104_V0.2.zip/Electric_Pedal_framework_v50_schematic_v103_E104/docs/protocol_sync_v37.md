# V38 协议对齐说明

本次更新按《汽车踏板控制器 APP–ECU 通信协议 V2.0-2026.04.22》对代码进行了同步，重点包括：

- `0xB1~0xB9` 工厂配置命令正式按最新协议实现。
- `0xB1 / 0xB2 / 0xB5 / 0xB6 / 0xB7` 中 `module_id` 改为 `uint16, LE`，不再兼容旧工厂工具的大端字节序。
- `0xB8` 中 `anti_pinch_level` 调整为 `0=关闭，1~8=1~8档`。
- `0xB9` 改为 8 档防夹阈值 + LE 时间策略参数的整包写入。
- `0x30` 主动事件上报补齐独立 `event_seq`、APP ACK、300ms 超时与最多 3 次重发。
- `0xC1~0xC5` OTA 首版流程接入应用层：开始、分块写入、CRC16 块校验、CRC32 整包校验、切换标记与进度查询。
- `0x16` 状态查询补齐 `door_bits / pedal_bits / system_bits / 左右踏板状态码`。
- `0x18 / 0x19 / 0x1A` 查询补齐设备、扩展与 OTA 状态字段。
- `can_if.c` 按工厂模板信号表解析门信号、转向 / 双闪 / 刹车 / 开锁 / 速度信号。
- `drv_motor.c` 已接入电机反向参数。
- host regression 新增工厂配置、事件 ACK 重发与 OTA 流程覆盖并通过。

优先关注文件：

- `service/ble_if.c`
- `service/can_if.c`
- `service/ota_service.c`
- `service/param.h`
- `service/param.c`
- `config/protocol/app_proto_v2_ids.h`

- v39: 同步 2026-04-23 协议：B1/B2/B5 长度改为 10 字节，B6 改为 13 字节，B8 改为 12 字节，删除 B1/B2/B5/B6 尾部 reserved，B8 删除 install_manual_switch / wash_function_switch。
