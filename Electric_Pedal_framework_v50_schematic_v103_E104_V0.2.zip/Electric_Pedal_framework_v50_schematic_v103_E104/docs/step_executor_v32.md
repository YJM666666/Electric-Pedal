# v32 step_sm 进一步解耦说明

本次调整的目标：让 `step_sm.c` 不再直接调用 `drv_motor_exec()`，而是只产生命令请求，
再由统一执行层 `service/step_executor.c` 负责真正落地到电机驱动。

## 调整点

- `control/step_sm.c`
  - 删除对 `drv_motor.h` 的直接依赖
  - 改为调用 `step_executor_request(side, action)`
  - 限位检测通过 `step_executor_is_limit_reached()` 获取执行反馈

- `service/step_executor.c`
  - 维护左右两侧“请求动作”和“已执行动作”
  - 合并同一调度周期内的重复动作
  - 统一调用 `drv_motor_exec()` 落地

- `control/scheduler.c`
  - 在 `policy_dispatch()` 之后调用 `step_executor_apply_pending()`
  - 形成“事件 -> 状态机 -> 动作请求 -> 执行层落地”的完整闭环

## 这样做的好处

1. `step_sm` 只关心状态迁移，不再关心底层如何驱动 H 桥/继电器
2. 后面如果要把执行层扩展成：
   - 本地有刷电机
   - U17 远端执行
   - 动作仲裁 / 安全钳制 / 诊断记录
   都可以继续在 `step_executor` 里做，而不用再动状态机主体
3. 更符合“状态机负责决策，执行层负责落地”的设计边界
