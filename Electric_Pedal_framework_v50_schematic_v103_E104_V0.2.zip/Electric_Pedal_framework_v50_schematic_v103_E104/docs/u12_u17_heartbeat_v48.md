# v48 U12/U17 心跳监测说明

本版在 v47 的 U12-U17 命名清理基础上，补齐 U12/U17 主从链路心跳监测。

## 范围

- 启用 U12 主控到 U17 灯光/语音从机的心跳请求/应答。
- 不增加第二路软 UART 备用链路。
- U12 当前只做单链路健康监测、故障置位和恢复清除。

## U12 主控侧

文件：`service/u17_link.c/.h`

- 每 200ms 发送一次 `U17_CMD_HEARTBEAT`。
- 心跳帧走现有 U17 内部协议，并要求 ACK。
- 心跳超时后按现有链路重试参数重发。
- 连续 3 次心跳失败后：
  - `u17_link_is_online()` 返回 false
  - `u17_link_get_state()` 返回 `U17_LINK_STATE_OFFLINE`
  - 置位 `FAULT_U17_LINK`
- 任意有效 U17 帧到达时恢复在线状态并清除 `FAULT_U17_LINK`。
- `u17_link_diag_t` 增加心跳 miss/recover 统计和链路状态。

## U17 从机侧

文件：`u17_slave/service/u12_u17_slave_link.c/.h`

- U17 收到 U12 任意有效请求帧后刷新主控在线计时。
- 1s 内未收到 U12 有效帧，则认为主控离线。
- 提供：
  - `u12_u17_slave_link_is_master_online()`
  - `u12_u17_slave_link_master_timeout_count()`

## UART 策略

本版不新增备用软 UART。

U12/U17 主链路仍走 `BSP_UART_PORT_U17`。根据当前 U12 原理图命名，PB10/PB11 是 `CONNECT_TXD/RXD`，配置为 USART2 主链路，不再作为新增软 UART 备用链路使用。

## 分层关系

```text
Layer 1: bsp_uart.c
Layer 2: UART RX flag / frame latch
Layer 5b: u17_link / u12_u17_slave_link heartbeat service
Layer 4: U12 link fault arbitration via FAULT_U17_LINK
```
