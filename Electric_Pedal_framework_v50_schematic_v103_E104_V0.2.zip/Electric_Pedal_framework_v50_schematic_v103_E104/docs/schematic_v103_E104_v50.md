# Electric Pedal Controller v50 - Schematic V1.03 / E104-BT52

This package is updated against the An'ersi electric pedal schematic V1.03 dated 2026-05-08.

## Main changes

### U12 / MCU2 / GD32C103CBT6 main controller

- Remapped brushed motor relay outputs to V1.03:
  - MOTOR1A-IO: PB0
  - MOTOR1B-IO: PB1
  - MOTOR2A-IO: PB2
  - MOTOR2B-IO: PA15
- Enabled local LM258 motor current sampling:
  - MT1-CUR-AD1: PA1 / ADC channel 1
  - MT1-CUR-AD2: PA2 / ADC channel 2
- Enabled Hall feedback:
  - M1-HALL: PA6 / EXTI6
  - M2-HALL: PA7 / EXTI7
- Removed discrete limit-switch dependency for V1.03; motion protection is current + Hall based.
- Remapped EEPROM to I2C0 PB8/PB9 with I2C0 remap enabled.
- Remapped W25Q128 software SPI to PB3/PB4/PB5/PB6 and disabled JTAG while keeping SWD enabled.
- CAN0 is mapped to SIT1044T/3 high-speed CAN-FD PHY; CAN1 is mapped to TJA1055T/3 low-speed fault-tolerant PHY.
- CAN0_STB and CAN1_STB are driven low during CAN init for normal operating mode.

### E104-BT52 BLE module

- BLE UART remains USART0: PA9 TX to E104 RXD, PA10 RX from E104 TXD.
- BLE power is controlled by PA8 as BLE-PWR-EN-N, active low.
- BLE-WKP is driven by PC13 and held low to keep E104 awake.
- Added E104-BT52 startup configuration sequence:
  - `AT+BAUD=7`
  - `AT+PARI=0`
  - `AT+DATABITS=3`
  - `AT+ROLE=0`
  - `AT+ADV=1`
  - `AT+TRANMD=1`
  - `AT+LOGMSG=0`
  - `AT+MTU=247`
  - `AT+UUIDSVR=FFF0`
  - `AT+UUIDSLAVE=FFF1`
  - `AT+UUIDMAST=FFF2`
  - `AT+NAME=ElectricPedal`
  - `AT+RESET`
- Actual UART RX bytes from the BLE port now trigger BLE parser service via `EVENT_FLAG_BLE_RX_PENDING`.

For production, after the E104 module has been configured in fixture programming, `BSP_BLE_E104_AUTOCONFIG` can be set to `0U` in `config/board/board_profile_u12_gd32c103.h` to reduce repeated writes to module NVM.

### U17 / MCU1 / GD32F130C8T6 light and voice executor

- U17 no longer owns brushed motor relay outputs.
- Light strip data pins:
  - LED_DATA_L1: PB10
  - LED_DATA_R1: PB11
  - LED_DATA_L2: PB1
  - LED_DATA_R2: PB2
- Light strip power enables:
  - LED-L1-PW-IO: PA5
  - LED-R1-PW-IO: PA4
  - LED-L2-PW-IO: PA1
  - LED-R2-PW-IO: PA0
- WS-EN is PB12.
- Voice interface:
  - DATA_SPK: PB5
  - BUSY: PB4
- U12/U17 link is USART0 on PA9/PA10.

## Verification run in this workspace

- Host regression: passed.
- Dual-MCU protocol regression: passed.

## Still required on hardware

- Keil/ARM target compilation for U12 and U17.
- Burn-in and bench validation on the V1.03 PCB.
- Confirm motor direction mapping for M1/M2 relay outputs.
- Confirm current thresholds after LM258 gain and shunt tolerance measurement.
- Confirm Hall polarity and pulse count per travel.
- Confirm E104 BLE app writes to UUID FFF2 and receives notify/read data from UUID FFF1.
- Confirm light-strip waveform timing if WS2812/SK6812-style addressable lamps are used; current firmware performs minimum on/off and power/data gating.

## Bootloader 与 OTA 双 Bank 集成 (2026-05-19)

本次更新为 U12 增加了独立的 bootloader 与双 Bank 应用布局，使 BLE OTA（协议命令 `0x1A` 与 `0xC1`~`0xC5`）能够安全升级并在新固件失效时自动回滚。U17 仍保持单 Bank 应用；在 U17 增加外部 SPI Flash 与对应 bootloader 之前，OTA 在 U17 上会上报为不支持。

### U12 内部 Flash 布局 (128KB)

```
0x08000000 +-- Bootloader        16KB
0x08004000 +-- App Slot A        56KB     <- 出厂镜像，默认 active
0x08012000 +-- App Slot B        56KB     <- bootloader OTA 拷贝目的地
0x08020000 +
```

每个应用槽起始为 64 字节的 `boot_image_header_t`，紧随其后是中断向量表与代码。链接脚本 `Electric_Pedal_U12_app.sct` 把代码段放到 `0x08004040`。原有的 `Electric_Pedal_U12_final.sct` 保留给单镜像构建；bootloader 本身使用 `Electric_Pedal_U12_boot.sct`。

### EEPROM 布局（与既有字段不重叠）

```
448 +-- boot_info_t    (active_slot / pending_slot / pending_state / pending_size /
                        pending_crc32 / pending_version / boot_count / boot_fail_count / crc32)
480 +-- drv_nvm_power_recovery   (已有，保持不变)
```

### 外部 W25 SPI Flash

`ota_service` 仍按原方式写入 `BSP_FLASH_OTA_META_ADDR` 与 `BSP_FLASH_OTA_IMAGE_ADDR`。bootloader 在执行 pending 切换时只读这两块区域，不会写。

### 新增模块

- `boot/boot_info.{h,c}` —— EEPROM 中的启动信息块，魔数 `'BOO1'`，CRC32 保护。
- `boot/boot_image.{h,c}` —— 64 字节镜像头（`'APP:'` 魔数、version、target_mcu、image_size、image_crc32、fw_version、header_crc32），以及包含 SP / Reset_Handler 合理性的槽内镜像有效性检查。
- `boot/boot_crc32.{h,c}` —— 共享的 IEEE 802.3 CRC32，与协议 `0xC3` 中 `image_crc32` 字段使用同一种算法。
- `boot/boot_jump.{h,c}` —— bootloader 跳应用所需的 VTOR / MSP / Reset_Handler 重定位。
- `boot/boot_extflash.{h,c}` —— bootloader 专用的 W25 SPI Flash 只读路径。bootloader 不写外部 Flash，写入仍由 `ota_service` 负责。
- `boot/boot_main_u12.c` —— bootloader 入口。校验 `boot_info`，处理 pending 切换；从 W25 把镜像拷到非激活的内部 Flash 槽，跑 CRC 与向量表合理性检查；最后跳应用，或在没有可用槽时停在 bootloader。
- `bsp/bsp_iflash.{h,c}` —— GD32 内部 Flash 擦除 / 编程 / 比对的统一封装，bootloader 使用。
- `config/flash_layout.h` —— U12 与 U17 共享的地址常量（槽位、boot info、sector 大小）。
- `tools/boot_image_pack.py` —— 把 Keil 输出的裸 `.bin` 包上一份合法的 `boot_image_header_t`，生成可用于 OTA 下发或出厂烧录的镜像。

### 修改的应用侧文件

- `service/ota_service.{h,c}` —— 沿用原有基于 W25 的 OTA 状态机；当镜像 CRC 校验通过后，`ota_service_activate()` 额外调用 `boot_info_request_pending(target_slot, fw_size, image_crc32, target_ver)`，让 bootloader 在下次启动时执行真正的槽位切换。
- `app/main.c` —— 应用启动时通过 `Image$$ER_IROM1$$Base` 重定位中断向量表；进入主循环后立即调 `boot_info_mark_healthy()` 清启动计数，避免新镜像被误判为不健康。

### 启动流程

```
                        +--------------------------+
                        |     bootloader 入口      |
                        +-----------+--------------+
                                    |
                                    v
                            读取 boot_info
                                    |
                +-------------------+-------------------+
                |                                       |
   pending_state == PROMOTE                  pending_state == NONE
                |                                       |
                v                                       v
   先写 pending_state = PROMOTING            校验 active_slot 镜像
   把 W25 镜像拷到内部 Flash 槽                       |
   边拷边对 pending_crc32 累计 CRC32                   |
                |                                      |
   通过？                                            通过？
    是 -> active = pending,                           是 -> 跳应用
          pending = NONE,                             否 -> 尝试备份槽
          boot_count = 0                                  -> 若也不行，停在 bootloader
    否 -> pending_state = FAILED,
          last_error = 0x10/0x11/0x12,
          pending = INVALID,
          仍跳老 active
```

bootloader 在第一次擦内部 Flash 之前先把 `pending_state` 写为 `PROMOTING`。即使拷贝中途断电，下次启动会识别这个状态、走同一条路径再尝试一次；要么成功，要么标记为 FAILED，但绝不会破坏老的 active 槽。

### 启动健康与自动回滚

- bootloader 每次跳应用前都把 `boot_info.boot_count` 累加 1。
- 应用进主循环立刻调用 `boot_info_mark_healthy()`，清零 `boot_count` 与 `boot_fail_count`。
- 当 bootloader 看到 `boot_count >= 3`，意味着应用连续 3 次都没能跑到健康点，bootloader 会把 `active_slot` 切到备份槽（前提是备份槽镜像仍然合法）。

### 协议层状态对外暴露

`ota_service` 继续负责协议字段 `ota_stage`（`0x1A` 字节 6 与 `0xC5` 字节 0）的取值，编号沿用 V2.0 协议第 9.13 节：0 空闲、1 准备、2 接收、3 校验、4 切换、5 失败。bootloader 使用的 `boot_pending_state_t`（PROMOTE / PROMOTING / FAILED / NONE）只存活在 EEPROM 里，不对应用暴露。bootloader 在拷贝或 CRC 校验阶段发现的失败会写到 `boot_info.last_error`，应用如有需要可读取后通过 `0xC5` 字节 5 上送。

### 构建与烧录说明

- bootloader 工程：链接脚本切 `Electric_Pedal_U12_boot.sct`，预定义 `BSP_TARGET_GD32C103`，**不**定义 `APP_ROLE_U17_SLAVE`。仅加入 `boot/` 和最小 BSP 文件（platform、wdg、i2c、spi、gpio、iflash）以及 GD32C10x 厂商源码，**不**引入应用层 `control/`、`service/`、`driver/`。
- 应用工程（`PowerStep_Controller_U12.uvprojx`）：链接脚本切 `Electric_Pedal_U12_app.sct`，把 `boot/boot_info.c`、`boot/boot_image.c`、`boot/boot_crc32.c`、`bsp/bsp_iflash.c` 加进工程。
- 应用编译完成后用 `python tools/boot_image_pack.py app.bin app_v1.0.0.bin --target u12 --version 1.0.0` 包上镜像头，再下发或烧录到 slot A。
- 出厂烧录：bootloader.hex 烧到 `0x08000000`，包好头的应用烧到 `0x08004000`。EEPROM 与 W25 的 OTA 区可留空；CRC 校验失败时 bootloader 安全回退到默认值（active=A）。

### 仍需在硬件上验证

- 在 PCB 上空跑 bootloader 工程，确认量产芯片上的 SPI / I2C / FMC 行为。
- 在样机上做 BLE OTA 端到端验证，包含 bootloader 拷贝阶段强制断电的恢复测试。
- 确认 V1.03 PCB 实际焊接的 W25 型号下，`BSP_FLASH_OTA_IMAGE_ADDR` 没有与其他持久化区域重叠。
- 决定 bootloader 的救援通道（UART / CAN）：当两个内部槽都损坏时，目前 bootloader 只能停机喂狗。
