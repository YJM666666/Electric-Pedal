# v49 U17 vendor restore fix

本版在 v48 心跳监测版基础上修复 U17 Keil 工程编译失败问题。

## 修复内容

U17 build log 中出现大量 `gd32f1x0_xxx.h file not found` 和 `vendor/.../gd32f1x0_xxx.c no such file or directory`，同时 `startup_gd32f1x0_ac6.c` 缺失。

根因是 v48 打包时遗漏了 `vendor/GD32F1x0_Firmware_Library_V3.8.0` 目录以及 `startup_gd32f1x0_ac6.c`。

本版已恢复：

- `vendor/GD32F1x0_Firmware_Library_V3.8.0/`
- `vendor/GD32C10x_Firmware_Library_V1.7.0/`
- `startup_gd32f1x0_ac6.c`

本次不改业务逻辑，不改 U12/U17 心跳代码。
