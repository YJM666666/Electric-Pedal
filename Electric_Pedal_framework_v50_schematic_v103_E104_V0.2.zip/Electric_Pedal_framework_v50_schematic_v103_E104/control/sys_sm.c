#include "sys_sm.h"
#include "policy.h"
#include "fault.h"

/*
 * 系统状态机：维护 INIT/NORMAL/FAULT 等整机模式，并把模式变化同步给策略层。
 * 严重故障会强制进入故障态，清故障事件只在故障条件解除后恢复正常模式。
 */
static sys_state_t s_state = SYS_INIT;

static void set_state(sys_state_t state)
{
    if (s_state != state) {
        s_state = state;
        policy_update_mode(state);
    }
}

void sys_sm_init(void)
{
    s_state = SYS_INIT;
    policy_update_mode(s_state);
}

void sys_sm_handle_event(const event_t *ev)
{
    if (ev == 0) {
        return;
    }

    if (ev->id == EV_FAULT_CLEAR) {
        fault_clear_all();
        if (s_state == SYS_FAULT) {
            set_state(SYS_NORMAL);
        }
        return;
    }

    if (fault_has_critical()) {
        set_state(SYS_FAULT);
        return;
    }

    switch (s_state)
    {
        case SYS_INIT:
            if (ev->id == EV_BOOT) {
                set_state(SYS_STANDBY);
            }
            break;

        case SYS_STANDBY:
            if (ev->id == EV_ENTER_WASH) {
                set_state(SYS_WASH);
            } else if (ev->id == EV_ENTER_INSTALL_TEST) {
                set_state(SYS_INSTALL_TEST);
            } else if (ev->id == EV_ENTER_OTA) {
                set_state(SYS_OTA);
            } else if ((ev->id == EV_TICK_100MS) || (ev->id == EV_TICK_1S)) {
                set_state(SYS_NORMAL);
            }
            break;

        case SYS_NORMAL:
            if (ev->id == EV_ENTER_WASH) {
                set_state(SYS_WASH);
            } else if (ev->id == EV_ENTER_INSTALL_TEST) {
                set_state(SYS_INSTALL_TEST);
            } else if (ev->id == EV_ENTER_OTA) {
                set_state(SYS_OTA);
            }
            break;

        case SYS_WASH:
            if ((ev->id == EV_WASH_TIMEOUT) ||
                (ev->id == EV_KEY_LOCK) ||
                (ev->id == EV_MAIN_SWITCH_OFF)) {
                set_state(SYS_NORMAL);
            } else if (ev->id == EV_ENTER_OTA) {
                set_state(SYS_OTA);
            }
            break;

        case SYS_INSTALL_TEST:
            if ((ev->id == EV_EXIT_INSTALL_TEST) ||
                (ev->id == EV_KEY_LOCK) ||
                (ev->id == EV_MAIN_SWITCH_OFF)) {
                set_state(SYS_NORMAL);
            } else if (ev->id == EV_ENTER_OTA) {
                set_state(SYS_OTA);
            }
            break;

        case SYS_OTA:
            if (ev->id == EV_OTA_FINISH) {
                set_state(SYS_NORMAL);
            }
            break;

        case SYS_FAULT:
        default:
            break;
    }
}

sys_state_t sys_sm_get_state(void)
{
    return s_state;
}
