#ifndef CONTROL_POLICY_H
#define CONTROL_POLICY_H

/*
 * 策略层接口：根据整车信号、模式和故障状态，决定左右踏板应该保持、伸出或收回。
 */
#include "project_bool.h"
#include <stdint.h>
#include "sys_sm.h"
#include "step_sm.h"
#include "param.h"

typedef struct
{
    sys_state_t  mode;
    bool         can_signal_valid;
    bool         button_signal_valid;
    bool         speed_above_8;
    bool         key_unlocked;
    bool         door_open[DOOR_POS_MAX];
    step_state_t left_state;
    step_state_t right_state;
    step_owner_t left_owner;
    step_owner_t right_owner;
    uint32_t     left_run_count;
    uint32_t     right_run_count;
    uint32_t     left_antipinch_count;
    uint32_t     right_antipinch_count;
} policy_status_t;

void policy_init(void);
void policy_update_mode(sys_state_t state);
void policy_dispatch(const event_t *ev);
policy_status_t policy_get_status(void);
uint8_t policy_get_step_status_code(step_side_t side);

#endif
