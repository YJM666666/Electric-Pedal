#ifndef CONTROL_STEP_SM_H
#define CONTROL_STEP_SM_H

/*
 * 单侧踏板状态机接口：管理伸出、收回、防夹回退、掉电恢复收回和停止。
 */
#include "project_bool.h"
#include <stdint.h>
#include "event.h"
#include "pedal_types.h"

typedef enum
{
    STEP_OWNER_NONE = 0,
    STEP_OWNER_DOOR,
    STEP_OWNER_WELCOME,
    STEP_OWNER_WASH,
    STEP_OWNER_INSTALL,
    STEP_OWNER_MANUAL,
    STEP_OWNER_SPEED_SAFETY,
    STEP_OWNER_POWER_RECOVERY,
    STEP_OWNER_FAULT
} step_owner_t;

typedef enum
{
    STEP_STATE_INIT = 0,
    STEP_STATE_RETRACTED,
    STEP_STATE_EXTENDING,
    STEP_STATE_EXTENDED,
    STEP_STATE_RETRACTING,
    STEP_STATE_ANTI_PINCH_BACKOFF,
    STEP_STATE_ERROR
} step_state_t;

typedef struct
{
    step_side_t   side;
    step_state_t  state;
    step_owner_t  owner;
    uint32_t      action_start_ms;
    uint32_t      action_deadline_ms;
    uint32_t      backoff_deadline_ms;
    uint32_t      run_counter;
    uint32_t      anti_pinch_counter;
    bool          fault_latched;
} step_sm_t;

void step_sm_init(step_sm_t *sm, step_side_t side);
void step_sm_handle_event(step_sm_t *sm, const event_t *ev);
void step_sm_tick_1ms(step_sm_t *sm);
step_state_t step_sm_get_state(const step_sm_t *sm);
step_owner_t step_sm_get_owner(const step_sm_t *sm);
bool step_sm_is_open(const step_sm_t *sm);
uint32_t step_sm_get_run_counter(const step_sm_t *sm);
uint32_t step_sm_get_antipinch_counter(const step_sm_t *sm);

#endif
