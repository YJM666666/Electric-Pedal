#include "scheduler.h"
#include "sys_sm.h"
#include "policy.h"
#include "param.h"
#include "fault.h"
#include "current_guard.h"
#include "can_if.h"
#include "ble_if.h"
#include "u17_link.h"
#include "bsp_adc.h"
#include "bsp_board.h"
#include "step_executor.h"
#include "voice_announce_service.h"
#include "motor_feedback.h"
#include "service/event_collector.h"

volatile uint32_t g_u12_tick_1ms_count = 0U;
volatile uint32_t g_u12_tick_10ms_count = 0U;
volatile uint32_t g_u12_u17_tick_10ms_count = 0U;

/*
 * 主调度器：按固定节拍收集输入、推进状态机、执行保护检测，并统一刷新外设输出�? * 业务层尽量通过这里串行推进，避免多个模块直接抢占硬件控制权�? */
static uint16_t scheduler_current_raw(step_side_t side)
{
#if (BSP_HAS_CURRENT_ADC != 0U)
    return (side == STEP_SIDE_LEFT) ? bsp_adc_get_left_current_raw() : bsp_adc_get_right_current_raw();
#else
    return u17_link_is_online() ? u17_link_remote_current(side) : 0U;
#endif
}

static void scheduler_monitor_health(void)
{
    if (event_has_overflowed()) {
        fault_set(FAULT_EVENT_QUEUE);
    }

    if (ble_if_has_rx_overflowed()) {
        fault_set(FAULT_BLE_RX_OVERFLOW);
    }

    if (u17_link_has_timeout_latched()) {
        fault_set(FAULT_U17_LINK);
    }
}

static void scheduler_service_event(const event_t *ev)
{
    if (ev == 0) {
        return;
    }

    switch (ev->id)
    {
        case EV_TICK_1MS:
            g_u12_tick_1ms_count++;
            current_guard_update_1ms(scheduler_current_raw(STEP_SIDE_LEFT),
                                     scheduler_current_raw(STEP_SIDE_RIGHT));
            scheduler_monitor_health();
            break;

        case EV_TICK_10MS:
            g_u12_tick_10ms_count++;
            u17_link_tick_10ms();
            g_u12_u17_tick_10ms_count++;
            voice_announce_service_tick_10ms();
            break;

        case EV_TICK_100MS:
            can_if_tick_100ms();
            ble_if_tick_100ms();
            scheduler_monitor_health();
            break;

        case EV_TICK_1S:
            param_periodic_1s();
            break;

        case EV_FAULT_CLEAR:
            event_clear_overflow();
            ble_if_clear_rx_overflow();
            u17_link_clear_timeout_latch();
            break;

        default:
            break;
    }
}

void scheduler_init(void)
{
    event_collector_init();
    step_executor_init();
    motor_feedback_init();
    voice_announce_service_init();
    scheduler_monitor_health();
}

void scheduler_poll_inputs(void)
{
    event_collector_poll();
    scheduler_monitor_health();
}

void scheduler_dispatch_event(const event_t *ev)
{
    if (ev == 0) {
        return;
    }

    scheduler_service_event(ev);
    sys_sm_handle_event(ev);
    policy_dispatch(ev);
    step_executor_apply_pending();
    motor_feedback_on_event(ev);
    ble_if_on_event(ev);
    voice_announce_service_on_event(ev);
}

bool scheduler_run_next(void)
{
    event_t ev;

    if (!event_pop(&ev)) {
        return false;
    }

    scheduler_dispatch_event(&ev);
    return true;
}

void scheduler_run_all(void)
{
    while (scheduler_run_next()) {
    }
}



