#ifndef CONTROL_SYS_SM_H
#define CONTROL_SYS_SM_H

/*
 * 整机状态机接口：维护初始化、正常和故障模式，并向策略层同步当前模式。
 */
#include "event.h"

typedef enum
{
    SYS_INIT = 0,
    SYS_STANDBY,
    SYS_NORMAL,
    SYS_WASH,
    SYS_INSTALL_TEST,
    SYS_OTA,
    SYS_FAULT
} sys_state_t;

void sys_sm_init(void);
void sys_sm_handle_event(const event_t *ev);
sys_state_t sys_sm_get_state(void);

#endif
