#ifndef CONTROL_SCHEDULER_H
#define CONTROL_SCHEDULER_H

/*
 * 调度器接口：初始化所有周期任务，并在主循环/定时节拍中推进业务处理。
 */
#include "project_bool.h"
#include "event.h"

void scheduler_init(void);
void scheduler_poll_inputs(void);
void scheduler_dispatch_event(const event_t *ev);
bool scheduler_run_next(void);
void scheduler_run_all(void);

#endif
