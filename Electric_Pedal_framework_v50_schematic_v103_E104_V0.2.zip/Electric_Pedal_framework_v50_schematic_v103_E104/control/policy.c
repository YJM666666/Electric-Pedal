#include "policy.h"
#include "fault.h"
#include "drv_light.h"
#include "can_if.h"
#include "sw_timer.h"

/*
 * 策略层负责把整车状态翻译为左右踏板动作。
 * 这里不直接驱动电机，只向左右踏板状态机投递伸出/收回命令。
 */
#define POWER_RECOVERY_CAN_STABLE_TICKS 2U

static sys_state_t s_mode = SYS_INIT;
static step_sm_t s_left;
static step_sm_t s_right;
static bool s_door_open[DOOR_POS_MAX];
static bool s_key_unlocked = false;
static bool s_speed_above_8 = false;
static bool s_turn_left = false;
static bool s_turn_right = false;
static bool s_brake = false;
static bool s_headlamp = false;
static bool s_auto_drive = false;
static bool s_welcome_active[STEP_SIDE_MAX];
static uint32_t s_welcome_deadline_ms[STEP_SIDE_MAX];
static uint32_t s_wash_deadline_ms = 0U;
static bool s_power_recovery_pending = false;
static uint8_t s_power_recovery_can_stable_ticks = 0U;

static step_side_t opposite_side(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? STEP_SIDE_RIGHT : STEP_SIDE_LEFT;
}

static step_side_t logical_to_hw_side(step_side_t logical_side)
{
    const system_param_t *param = param_get();
    if (param->left_right_swap) {
        return opposite_side(logical_side);
    }
    return logical_side;
}

static step_side_t door_pos_to_hw_side(door_pos_t pos)
{
    const system_param_t *param = param_get();
    step_side_t logical_side;

    switch (pos)
    {
        case DOOR_POS_FL:
            logical_side = STEP_SIDE_LEFT;
            break;

        case DOOR_POS_FR:
            logical_side = STEP_SIDE_RIGHT;
            break;

        case DOOR_POS_RL:
            logical_side = param->rear_door_reverse ? STEP_SIDE_RIGHT : STEP_SIDE_LEFT;
            break;

        case DOOR_POS_RR:
            logical_side = param->rear_door_reverse ? STEP_SIDE_LEFT : STEP_SIDE_RIGHT;
            break;

        default:
            logical_side = STEP_SIDE_LEFT;
            break;
    }

    return logical_to_hw_side(logical_side);
}

static bool side_has_any_open_door(step_side_t hw_side)
{
    uint32_t i;

    for (i = 0U; i < (uint32_t)DOOR_POS_MAX; ++i) {
        if (s_door_open[i] && (door_pos_to_hw_side((door_pos_t)i) == hw_side)) {
            return true;
        }
    }

    return false;
}

static void post_cmd(event_id_t id, step_owner_t owner, event_source_t source)
{
    event_t ev;

    ev.id = id;
    ev.source = source;
    ev.param_u32 = (uint32_t)owner;
    ev.param_ptr = 0;
    (void)event_push(&ev);
}

static void command_side(step_side_t side, bool extend, step_owner_t owner, event_source_t source)
{
    if (extend) {
        post_cmd((side == STEP_SIDE_LEFT) ? EV_L_EXT_CMD : EV_R_EXT_CMD, owner, source);
    } else {
        post_cmd((side == STEP_SIDE_LEFT) ? EV_L_RET_CMD : EV_R_RET_CMD, owner, source);
    }
}

static void command_both(bool extend, step_owner_t owner, event_source_t source)
{
    command_side(STEP_SIDE_LEFT, extend, owner, source);
    command_side(STEP_SIDE_RIGHT, extend, owner, source);
}

static void clear_welcome(step_side_t side);

static void service_power_recovery(void)
{
    const system_param_t *param = param_get();
    bool left_open;
    bool right_open;

    if (!s_power_recovery_pending) {
        return;
    }

    if (!can_if_signal_valid()) {
        s_power_recovery_can_stable_ticks = 0U;
        return;
    }

    if (s_power_recovery_can_stable_ticks < POWER_RECOVERY_CAN_STABLE_TICKS) {
        s_power_recovery_can_stable_ticks++;
        return;
    }

    s_power_recovery_pending = false;
    s_power_recovery_can_stable_ticks = 0U;
    clear_welcome(STEP_SIDE_LEFT);
    clear_welcome(STEP_SIDE_RIGHT);

    if (!param->main_switch_enable || s_speed_above_8) {
        command_both(false, STEP_OWNER_POWER_RECOVERY, EV_SRC_SYSTEM);
        return;
    }

    left_open = side_has_any_open_door(STEP_SIDE_LEFT);
    right_open = side_has_any_open_door(STEP_SIDE_RIGHT);

    /*
     * 掉电恢复期间，车门打开代表乘员可能正在上下车。
     * 该侧不允许展开，也不盲目收回；只有车门关闭侧才允许保守收回并重新建立基准。
     */
    if (left_open || right_open) {
        if (!left_open) {
            command_side(STEP_SIDE_LEFT, false, STEP_OWNER_POWER_RECOVERY, EV_SRC_SYSTEM);
        }
        if (!right_open) {
            command_side(STEP_SIDE_RIGHT, false, STEP_OWNER_POWER_RECOVERY, EV_SRC_SYSTEM);
        }
        return;
    }

    command_both(false, STEP_OWNER_POWER_RECOVERY, EV_SRC_SYSTEM);
}

static void clear_welcome(step_side_t side)
{
    if (side >= STEP_SIDE_MAX) {
        return;
    }

    s_welcome_active[side] = false;
    s_welcome_deadline_ms[side] = 0U;
}

static void start_welcome(step_side_t side)
{
    const system_param_t *param = param_get();

    s_welcome_active[side] = true;
    s_welcome_deadline_ms[side] = sw_timer_now_ms() + ((uint32_t)param->welcome_hold_seconds * 1000UL);
    command_side(side, true, STEP_OWNER_WELCOME, EV_SRC_SYSTEM);
}

static void refresh_lighting(void)
{
    bool any_welcome_or_open;

    any_welcome_or_open = s_welcome_active[STEP_SIDE_LEFT] ||
                          s_welcome_active[STEP_SIDE_RIGHT] ||
                          side_has_any_open_door(STEP_SIDE_LEFT) ||
                          side_has_any_open_door(STEP_SIDE_RIGHT);

    if (s_mode == SYS_FAULT) {
        drv_light_apply_scene(LIGHT_SCENE_FAULT);
    } else if (s_mode == SYS_WASH) {
        drv_light_apply_scene(LIGHT_SCENE_WASH);
    } else if (s_auto_drive) {
        drv_light_apply_scene(LIGHT_SCENE_AUTO_BLUE);
    } else if (s_brake) {
        drv_light_apply_scene(LIGHT_SCENE_BRAKE);
    } else if (s_turn_left || s_turn_right) {
        drv_light_apply_scene(LIGHT_SCENE_TURN);
    } else if (any_welcome_or_open) {
        drv_light_apply_scene(LIGHT_SCENE_WELCOME);
    } else if (s_headlamp || s_speed_above_8) {
        drv_light_apply_scene(LIGHT_SCENE_DRIVE);
    } else {
        drv_light_apply_scene(LIGHT_SCENE_OFF);
    }
}

static void handle_manual_cmd(const event_t *ev)
{
    const system_param_t *param = param_get();
    bool allow;

    allow = ((s_mode == SYS_INSTALL_TEST) || (!param->main_switch_enable)) ? true : false;
    if (!allow || (s_mode == SYS_OTA) || fault_has_critical()) {
        return;
    }

    switch (ev->id)
    {
        case EV_L_EXT_CMD:
        case EV_L_RET_CMD:
            step_sm_handle_event(&s_left, ev);
            break;

        case EV_R_EXT_CMD:
        case EV_R_RET_CMD:
            step_sm_handle_event(&s_right, ev);
            break;

        default:
            break;
    }
}

static void handle_auto_policy_event(const event_t *ev)
{
    const system_param_t *param = param_get();
    step_side_t side;
    step_side_t welcome_logical;

    if (ev == 0) {
        return;
    }

    switch (ev->id)
    {
        case EV_POWER_RECOVERED:
            s_power_recovery_pending = true;
            s_power_recovery_can_stable_ticks = 0U;
            service_power_recovery();
            break;

        case EV_KEY_UNLOCK:
            s_key_unlocked = true;
            if (param->main_switch_enable && param->welcome_enable && !s_speed_above_8 &&
                (s_mode == SYS_NORMAL || s_mode == SYS_STANDBY)) {
                if (param->welcome_mode == WELCOME_BOTH_SIDES) {
                    start_welcome(STEP_SIDE_LEFT);
                    start_welcome(STEP_SIDE_RIGHT);
                } else {
                    welcome_logical = (param->hand_drive == HAND_DRIVE_RIGHT) ? STEP_SIDE_RIGHT : STEP_SIDE_LEFT;
                    start_welcome(logical_to_hw_side(welcome_logical));
                }
            }
            break;

        case EV_KEY_LOCK:
            s_key_unlocked = false;
            clear_welcome(STEP_SIDE_LEFT);
            clear_welcome(STEP_SIDE_RIGHT);
            command_both(false, STEP_OWNER_WELCOME, EV_SRC_SYSTEM);
            break;

        case EV_SPEED_ABOVE_8:
            s_speed_above_8 = true;
            clear_welcome(STEP_SIDE_LEFT);
            clear_welcome(STEP_SIDE_RIGHT);
            command_both(false, STEP_OWNER_SPEED_SAFETY, EV_SRC_SYSTEM);
            break;

        case EV_SPEED_BELOW_8:
            s_speed_above_8 = false;
            break;

        case EV_DOOR_FL_OPEN:
            s_door_open[DOOR_POS_FL] = true;
            clear_welcome(door_pos_to_hw_side(DOOR_POS_FL));
            if (!s_power_recovery_pending &&
                param->main_switch_enable && !s_speed_above_8 &&
                (s_mode == SYS_NORMAL || s_mode == SYS_STANDBY)) {
                side = door_pos_to_hw_side(DOOR_POS_FL);
                command_side(side, true, STEP_OWNER_DOOR, EV_SRC_SYSTEM);
            }
            break;

        case EV_DOOR_FL_CLOSE:
            s_door_open[DOOR_POS_FL] = false;
            side = door_pos_to_hw_side(DOOR_POS_FL);
            if (!side_has_any_open_door(side) && (s_mode != SYS_WASH) && (s_mode != SYS_INSTALL_TEST)) {
                command_side(side, false, STEP_OWNER_DOOR, EV_SRC_SYSTEM);
            }
            break;

        case EV_DOOR_FR_OPEN:
            s_door_open[DOOR_POS_FR] = true;
            clear_welcome(door_pos_to_hw_side(DOOR_POS_FR));
            if (!s_power_recovery_pending &&
                param->main_switch_enable && !s_speed_above_8 &&
                (s_mode == SYS_NORMAL || s_mode == SYS_STANDBY)) {
                side = door_pos_to_hw_side(DOOR_POS_FR);
                command_side(side, true, STEP_OWNER_DOOR, EV_SRC_SYSTEM);
            }
            break;

        case EV_DOOR_FR_CLOSE:
            s_door_open[DOOR_POS_FR] = false;
            side = door_pos_to_hw_side(DOOR_POS_FR);
            if (!side_has_any_open_door(side) && (s_mode != SYS_WASH) && (s_mode != SYS_INSTALL_TEST)) {
                command_side(side, false, STEP_OWNER_DOOR, EV_SRC_SYSTEM);
            }
            break;

        case EV_DOOR_RL_OPEN:
            s_door_open[DOOR_POS_RL] = true;
            clear_welcome(door_pos_to_hw_side(DOOR_POS_RL));
            if (!s_power_recovery_pending &&
                param->main_switch_enable && !s_speed_above_8 &&
                (s_mode == SYS_NORMAL || s_mode == SYS_STANDBY)) {
                side = door_pos_to_hw_side(DOOR_POS_RL);
                command_side(side, true, STEP_OWNER_DOOR, EV_SRC_SYSTEM);
            }
            break;

        case EV_DOOR_RL_CLOSE:
            s_door_open[DOOR_POS_RL] = false;
            side = door_pos_to_hw_side(DOOR_POS_RL);
            if (!side_has_any_open_door(side) && (s_mode != SYS_WASH) && (s_mode != SYS_INSTALL_TEST)) {
                command_side(side, false, STEP_OWNER_DOOR, EV_SRC_SYSTEM);
            }
            break;

        case EV_DOOR_RR_OPEN:
            s_door_open[DOOR_POS_RR] = true;
            clear_welcome(door_pos_to_hw_side(DOOR_POS_RR));
            if (!s_power_recovery_pending &&
                param->main_switch_enable && !s_speed_above_8 &&
                (s_mode == SYS_NORMAL || s_mode == SYS_STANDBY)) {
                side = door_pos_to_hw_side(DOOR_POS_RR);
                command_side(side, true, STEP_OWNER_DOOR, EV_SRC_SYSTEM);
            }
            break;

        case EV_DOOR_RR_CLOSE:
            s_door_open[DOOR_POS_RR] = false;
            side = door_pos_to_hw_side(DOOR_POS_RR);
            if (!side_has_any_open_door(side) && (s_mode != SYS_WASH) && (s_mode != SYS_INSTALL_TEST)) {
                command_side(side, false, STEP_OWNER_DOOR, EV_SRC_SYSTEM);
            }
            break;

        case EV_TURN_LEFT_ON:
            s_turn_left = true;
            break;

        case EV_TURN_LEFT_OFF:
            s_turn_left = false;
            break;

        case EV_TURN_RIGHT_ON:
            s_turn_right = true;
            break;

        case EV_TURN_RIGHT_OFF:
            s_turn_right = false;
            break;

        case EV_BRAKE_ON:
            s_brake = true;
            break;

        case EV_BRAKE_OFF:
            s_brake = false;
            break;

        case EV_HEADLAMP_ON:
            s_headlamp = true;
            break;

        case EV_HEADLAMP_OFF:
            s_headlamp = false;
            break;

        case EV_AUTO_DRIVE_ON:
            s_auto_drive = true;
            break;

        case EV_AUTO_DRIVE_OFF:
            s_auto_drive = false;
            break;

        case EV_CAN_RECOVER:
            service_power_recovery();
            break;

        case EV_CAN_TIMEOUT:
            s_power_recovery_can_stable_ticks = 0U;
            break;

        default:
            break;
    }
}

void policy_init(void)
{
    uint32_t i;

    s_mode = SYS_INIT;
    step_sm_init(&s_left, STEP_SIDE_LEFT);
    step_sm_init(&s_right, STEP_SIDE_RIGHT);

    s_key_unlocked = false;
    s_speed_above_8 = false;
    s_turn_left = false;
    s_turn_right = false;
    s_brake = false;
    s_headlamp = false;
    s_auto_drive = false;
    s_wash_deadline_ms = 0U;
    s_power_recovery_pending = false;
    s_power_recovery_can_stable_ticks = 0U;

    for (i = 0U; i < (uint32_t)DOOR_POS_MAX; ++i) {
        s_door_open[i] = false;
    }

    for (i = 0U; i < (uint32_t)STEP_SIDE_MAX; ++i) {
        s_welcome_active[i] = false;
        s_welcome_deadline_ms[i] = 0U;
    }

    refresh_lighting();
}

void policy_update_mode(sys_state_t state)
{
    s_mode = state;
    refresh_lighting();
}


void policy_dispatch(const event_t *ev)
{
    uint32_t now_ms;
    const system_param_t *param;
    bool forwarded_to_sm = false;

    if (ev == 0) {
        return;
    }

    param = param_get();

    if (ev->id == EV_TICK_1MS) {
        step_sm_handle_event(&s_left, ev);
        step_sm_handle_event(&s_right, ev);
        forwarded_to_sm = true;
    }

    switch (ev->id)
    {
        case EV_FAULT_CLEAR:
            step_sm_handle_event(&s_left, ev);
            step_sm_handle_event(&s_right, ev);
            forwarded_to_sm = true;
            break;

        case EV_MAIN_SWITCH_OFF:
            command_both(false, STEP_OWNER_MANUAL, EV_SRC_SYSTEM);
            break;

        case EV_ENTER_WASH:
            s_wash_deadline_ms = sw_timer_now_ms() + ((uint32_t)param->wash_hold_seconds * 1000UL);
            command_both(true, STEP_OWNER_WASH, EV_SRC_SYSTEM);
            break;

        case EV_WASH_TIMEOUT:
            s_wash_deadline_ms = 0U;
            command_both(false, STEP_OWNER_WASH, EV_SRC_SYSTEM);
            break;

        case EV_ENTER_INSTALL_TEST:
            break;

        case EV_EXIT_INSTALL_TEST:
            command_both(false, STEP_OWNER_INSTALL, EV_SRC_SYSTEM);
            break;

        case EV_ENTER_OTA:
            command_both(false, STEP_OWNER_FAULT, EV_SRC_SYSTEM);
            break;

        case EV_CAN_TIMEOUT:
            command_both(false, STEP_OWNER_SPEED_SAFETY, EV_SRC_SYSTEM);
            break;

        default:
            break;
    }

    handle_auto_policy_event(ev);

    if (!forwarded_to_sm) {
        if ((ev->source == EV_SRC_APP) &&
            ((ev->id == EV_L_EXT_CMD) || (ev->id == EV_L_RET_CMD) ||
             (ev->id == EV_R_EXT_CMD) || (ev->id == EV_R_RET_CMD))) {
            handle_manual_cmd(ev);
        } else {
            step_sm_handle_event(&s_left, ev);
            step_sm_handle_event(&s_right, ev);
        }
    }

    if ((ev->id == EV_TICK_100MS) || (ev->id == EV_TICK_1MS)) {
        now_ms = sw_timer_now_ms();

        if (s_welcome_active[STEP_SIDE_LEFT] &&
            !side_has_any_open_door(STEP_SIDE_LEFT) &&
            sw_timer_is_expired(now_ms, s_welcome_deadline_ms[STEP_SIDE_LEFT])) {
            clear_welcome(STEP_SIDE_LEFT);
            command_side(STEP_SIDE_LEFT, false, STEP_OWNER_WELCOME, EV_SRC_SYSTEM);
        }

        if (s_welcome_active[STEP_SIDE_RIGHT] &&
            !side_has_any_open_door(STEP_SIDE_RIGHT) &&
            sw_timer_is_expired(now_ms, s_welcome_deadline_ms[STEP_SIDE_RIGHT])) {
            clear_welcome(STEP_SIDE_RIGHT);
            command_side(STEP_SIDE_RIGHT, false, STEP_OWNER_WELCOME, EV_SRC_SYSTEM);
        }

        if ((s_mode == SYS_WASH) &&
            (s_wash_deadline_ms != 0U) &&
            sw_timer_is_expired(now_ms, s_wash_deadline_ms)) {
            post_cmd(EV_WASH_TIMEOUT, STEP_OWNER_WASH, EV_SRC_TIMER);
        }
    }

    if (ev->id == EV_TICK_100MS) {
        service_power_recovery();
    }

    refresh_lighting();
}

policy_status_t policy_get_status(void)
{
    policy_status_t st;
    uint32_t i;

    st.mode = s_mode;
    st.can_signal_valid = can_if_signal_valid();
    st.button_signal_valid = true;
    st.speed_above_8 = s_speed_above_8;
    st.key_unlocked = s_key_unlocked;

    for (i = 0U; i < (uint32_t)DOOR_POS_MAX; ++i) {
        st.door_open[i] = s_door_open[i];
    }

    st.left_state = step_sm_get_state(&s_left);
    st.right_state = step_sm_get_state(&s_right);
    st.left_owner = step_sm_get_owner(&s_left);
    st.right_owner = step_sm_get_owner(&s_right);
    st.left_run_count = step_sm_get_run_counter(&s_left);
    st.right_run_count = step_sm_get_run_counter(&s_right);
    st.left_antipinch_count = step_sm_get_antipinch_counter(&s_left);
    st.right_antipinch_count = step_sm_get_antipinch_counter(&s_right);

    return st;
}

uint8_t policy_get_step_status_code(step_side_t side)
{
    const system_param_t *param;
    const step_sm_t *sm;
    step_state_t state;
    step_owner_t owner;

    param = param_get();
    sm = (side == STEP_SIDE_LEFT) ? &s_left : &s_right;
    state = step_sm_get_state(sm);
    owner = step_sm_get_owner(sm);

    if ((s_mode != SYS_INSTALL_TEST) && !param->main_switch_enable) {
        return 80U;
    }

    switch (state)
    {
        case STEP_STATE_RETRACTED:
            if (s_mode == SYS_INSTALL_TEST) {
                return 78U;
            }
            return 0U;

        case STEP_STATE_EXTENDED:
            if (s_mode == SYS_WASH || owner == STEP_OWNER_WASH) {
                return 72U;
            }
            if (s_mode == SYS_INSTALL_TEST || owner == STEP_OWNER_INSTALL) {
                return 76U;
            }
            if (owner == STEP_OWNER_WELCOME) {
                return 62U;
            }
            return 1U;

        case STEP_STATE_EXTENDING:
            if (owner == STEP_OWNER_WELCOME) {
                return 62U;
            }
            if (owner == STEP_OWNER_WASH) {
                return 72U;
            }
            if (owner == STEP_OWNER_INSTALL) {
                return 76U;
            }
            return 3U;

        case STEP_STATE_RETRACTING:
            if (s_mode == SYS_INSTALL_TEST || owner == STEP_OWNER_INSTALL) {
                return 78U;
            }
            return 4U;

        case STEP_STATE_ANTI_PINCH_BACKOFF:
            return 5U;

        case STEP_STATE_INIT:
        case STEP_STATE_ERROR:
        default:
            return 9U;
    }
}
