#ifndef CONTROL_MOTOR_FEEDBACK_H
#define CONTROL_MOTOR_FEEDBACK_H

/*
 * 电机反馈接口：统一霍尔、位置估算和收回端校准状态，供状态机和保护逻辑查询。
 */
#include "project_bool.h"
#include "pedal_types.h"
#include "event.h"
#include <stdint.h>

typedef struct
{
    uint32_t total_pulses;
    uint32_t motion_pulses;
    uint32_t last_pulse_ms;
    int32_t  position_pulses;
    uint16_t rpm_x10;
    bool     pulse_seen_in_motion;
    bool     no_pulse_fault_latched;
    bool     position_calibrated;
} motor_feedback_side_status_t;

void motor_feedback_init(void);
void motor_feedback_on_event(const event_t *ev);
void motor_feedback_get_status(step_side_t side, motor_feedback_side_status_t *out);
void motor_feedback_mark_retracted_calibrated(step_side_t side);

#endif
