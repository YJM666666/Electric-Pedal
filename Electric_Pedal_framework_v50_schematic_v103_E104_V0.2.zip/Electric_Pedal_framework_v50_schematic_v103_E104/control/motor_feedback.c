#include "motor_feedback.h"
#include "step_executor.h"
#include "motor_profile.h"
#include "param.h"
#include "sw_timer.h"
#include <string.h>

/*
 * 电机反馈服务。
 * 当前使用霍尔脉冲做运动存在性检测、转速估算和相对位置估算；收回完成后将当前位置校准为 0。
 */
typedef struct
{
    motor_feedback_side_status_t status;
    step_action_t last_action;
    uint32_t action_start_ms;
    uint32_t last_period_ms;
} motor_feedback_side_t;

static motor_feedback_side_t s_side[STEP_SIDE_MAX];

static event_id_t hall_pulse_evt(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? EV_L_HALL_PULSE : EV_R_HALL_PULSE;
}

static event_id_t timeout_evt(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? EV_L_TIMEOUT : EV_R_TIMEOUT;
}

static void post_feedback_event(step_side_t side, event_id_t id)
{
    event_t ev;

    ev.id = id;
    ev.source = EV_SRC_HALL;
    ev.param_u32 = (uint32_t)side;
    ev.param_ptr = 0;
    (void)event_push(&ev);
}

static bool action_is_motion(step_action_t action)
{
    return ((action == STEP_ACT_EXTEND) ||
            (action == STEP_ACT_RETRACT) ||
            (action == STEP_ACT_RETRACT_SLOW));
}

static bool action_is_retract(step_action_t action)
{
    return ((action == STEP_ACT_RETRACT) || (action == STEP_ACT_RETRACT_SLOW));
}

static uint16_t no_pulse_start_grace_ms(step_action_t action)
{
    const motor_profile_t *profile = motor_profile_get();

    if (action == STEP_ACT_RETRACT_SLOW) {
        return param_get()->recovery_no_pulse_start_grace_ms;
    }

    return (profile != 0) ? profile->no_pulse_start_grace_ms : 0U;
}

static uint16_t no_pulse_timeout_ms(step_action_t action)
{
    const motor_profile_t *profile = motor_profile_get();

    if (action == STEP_ACT_RETRACT_SLOW) {
        return param_get()->recovery_no_pulse_timeout_ms;
    }

    return (profile != 0) ? profile->no_pulse_timeout_ms : 0U;
}

static uint16_t rpm_x10_from_period(uint32_t period_ms)
{
    const motor_profile_t *profile = motor_profile_get();
    uint32_t denom;
    uint32_t rpm_x10;

    if ((profile == 0) || (profile->hall_pulses_per_rev == 0U) || (period_ms == 0U)) {
        return 0U;
    }

    denom = period_ms * (uint32_t)profile->hall_pulses_per_rev;
    if (denom == 0U) {
        return 0U;
    }

    rpm_x10 = 600000UL / denom;
    return (rpm_x10 > 0xFFFFUL) ? 0xFFFFU : (uint16_t)rpm_x10;
}

static void reset_motion_window(step_side_t side, step_action_t action, uint32_t now_ms)
{
    s_side[side].last_action = action;
    s_side[side].action_start_ms = now_ms;
    s_side[side].last_period_ms = 0U;
    s_side[side].status.motion_pulses = 0U;
    s_side[side].status.last_pulse_ms = 0U;
    s_side[side].status.rpm_x10 = 0U;
    s_side[side].status.pulse_seen_in_motion = false;
    s_side[side].status.no_pulse_fault_latched = false;
}

static void service_side(step_side_t side, uint32_t now_ms)
{
    step_action_t action = step_executor_get_applied_action(side);

    if (s_side[side].last_action != action) {
        reset_motion_window(side, action, now_ms);
    }

    if (!action_is_motion(action)) {
        return;
    }

    if (s_side[side].status.no_pulse_fault_latched) {
        return;
    }

    if (!motor_profile_has_feedback(MOTOR_FEEDBACK_HALL)) {
        return;
    }

    if (!s_side[side].status.pulse_seen_in_motion) {
        if (sw_timer_is_expired(now_ms, s_side[side].action_start_ms + (uint32_t)no_pulse_start_grace_ms(action))) {
            s_side[side].status.no_pulse_fault_latched = true;
            post_feedback_event(side, timeout_evt(side));
        }
        return;
    }

    if (sw_timer_is_expired(now_ms, s_side[side].status.last_pulse_ms + (uint32_t)no_pulse_timeout_ms(action))) {
        s_side[side].status.no_pulse_fault_latched = true;
        post_feedback_event(side, timeout_evt(side));
    }
}

static void on_hall_pulse(step_side_t side, uint16_t pulses)
{
    uint32_t now_ms;
    uint32_t previous_ms;

    if ((side >= STEP_SIDE_MAX) || (pulses == 0U)) {
        return;
    }

    now_ms = sw_timer_now_ms();
    previous_ms = s_side[side].status.last_pulse_ms;
    s_side[side].status.total_pulses += pulses;
    s_side[side].status.motion_pulses += pulses;
    s_side[side].status.last_pulse_ms = now_ms;
    s_side[side].status.pulse_seen_in_motion = true;
    s_side[side].last_action = step_executor_get_applied_action(side);

    if (s_side[side].last_action == STEP_ACT_EXTEND) {
        s_side[side].status.position_pulses += (int32_t)pulses;
    } else if (action_is_retract(s_side[side].last_action)) {
        s_side[side].status.position_pulses -= (int32_t)pulses;
        if (s_side[side].status.position_pulses < 0) {
            s_side[side].status.position_pulses = 0;
        }
    }

    if (previous_ms != 0U) {
        s_side[side].last_period_ms = now_ms - previous_ms;
        s_side[side].status.rpm_x10 = rpm_x10_from_period(s_side[side].last_period_ms);
    }
}

void motor_feedback_init(void)
{
    uint32_t i;

    (void)memset(s_side, 0, sizeof(s_side));
    for (i = 0U; i < (uint32_t)STEP_SIDE_MAX; ++i) {
        s_side[i].last_action = STEP_ACT_STOP;
    }
}

void motor_feedback_on_event(const event_t *ev)
{
    uint32_t now_ms;

    if (ev == 0) {
        return;
    }

    if (ev->id == hall_pulse_evt(STEP_SIDE_LEFT)) {
        on_hall_pulse(STEP_SIDE_LEFT, (uint16_t)ev->param_u32);
        return;
    }

    if (ev->id == hall_pulse_evt(STEP_SIDE_RIGHT)) {
        on_hall_pulse(STEP_SIDE_RIGHT, (uint16_t)ev->param_u32);
        return;
    }

    if (ev->id != EV_TICK_10MS) {
        return;
    }

    now_ms = sw_timer_now_ms();
    service_side(STEP_SIDE_LEFT, now_ms);
    service_side(STEP_SIDE_RIGHT, now_ms);
}

void motor_feedback_get_status(step_side_t side, motor_feedback_side_status_t *out)
{
    if ((side >= STEP_SIDE_MAX) || (out == 0)) {
        return;
    }

    *out = s_side[side].status;
}

void motor_feedback_mark_retracted_calibrated(step_side_t side)
{
    if (side >= STEP_SIDE_MAX) {
        return;
    }

    s_side[side].status.position_pulses = 0;
    s_side[side].status.position_calibrated = true;
}
