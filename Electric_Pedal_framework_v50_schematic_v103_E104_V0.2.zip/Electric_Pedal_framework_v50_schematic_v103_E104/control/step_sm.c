#include "step_sm.h"
#include "step_executor.h"
#include "fault.h"
#include "param.h"
#include "sw_timer.h"
#include "drv_nvm.h"
#include "drv_motor.h"
#include "motor_feedback.h"

/*
 * 单侧踏板状态机。
 * 上层策略只发“伸出/收回”意图，本模块负责动作切换、超时、防夹回退和 NVM 恢复记录。
 */
static event_id_t ext_evt(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? EV_L_EXT_CMD : EV_R_EXT_CMD;
}

static event_id_t ret_evt(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? EV_L_RET_CMD : EV_R_RET_CMD;
}

static event_id_t done_evt(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? EV_L_DONE : EV_R_DONE;
}

static event_id_t timeout_evt(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? EV_L_TIMEOUT : EV_R_TIMEOUT;
}

static event_id_t antipinch_evt(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? EV_L_ANTI_PINCH : EV_R_ANTI_PINCH;
}

static event_id_t overcurrent_evt(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? EV_L_OVERCURRENT : EV_R_OVERCURRENT;
}

static uint32_t timeout_fault_mask(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? FAULT_L_TIMEOUT : FAULT_R_TIMEOUT;
}

static uint32_t overcurrent_fault_mask(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? FAULT_L_OVERCURRENT : FAULT_R_OVERCURRENT;
}

static uint32_t antipinch_fault_mask(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? FAULT_L_ANTI_PINCH : FAULT_R_ANTI_PINCH;
}

static void post_local(step_side_t side, event_id_t id)
{
    event_t ev;

    (void)side;

    ev.id = id;
    ev.source = EV_SRC_TIMER; 
    ev.param_u32 = 0U;
    ev.param_ptr = 0;
    (void)event_push(&ev);
}

static step_owner_t owner_from_event(const event_t *ev)
{
    uint32_t raw;

    if (ev == 0) {
        return STEP_OWNER_NONE;
    }

    raw = ev->param_u32;
    if (raw > (uint32_t)STEP_OWNER_FAULT) {
        return STEP_OWNER_NONE;
    }

    return (step_owner_t)raw;
}

static bool state_is_valid(uint8_t state)
{
    return (state <= (uint8_t)STEP_STATE_ERROR) ? true : false;
}

static void save_recovery_record(const step_sm_t *sm, step_action_t action)
{
    drv_nvm_power_recovery_t rec;

    if (sm == 0) {
        return;
    }

    rec.last_side = sm->side;
    rec.last_state = (uint8_t)sm->state;
    rec.last_action = action;
    (void)drv_nvm_write_power_recovery(&rec);
}

static void start_extend(step_sm_t *sm, step_owner_t owner)
{
    const system_param_t *param = param_get();

    sm->owner = owner;
    sm->state = STEP_STATE_EXTENDING;
    sm->action_start_ms = sw_timer_now_ms();
    sm->action_deadline_ms = sm->action_start_ms + param->extend_timeout_ms;
    step_executor_request(sm->side, STEP_ACT_EXTEND);
    save_recovery_record(sm, STEP_ACT_EXTEND);
}

static void start_retract_action(step_sm_t *sm, step_owner_t owner, step_action_t action)
{
    const system_param_t *param = param_get();

    sm->owner = owner;
    sm->state = STEP_STATE_RETRACTING;
    sm->action_start_ms = sw_timer_now_ms();
    if (action == STEP_ACT_RETRACT_SLOW) {
        sm->action_deadline_ms = sm->action_start_ms + param->recovery_retract_timeout_ms;
    } else {
        sm->action_deadline_ms = sm->action_start_ms + param->retract_timeout_ms;
    }
    step_executor_request(sm->side, action);
    save_recovery_record(sm, action);
}

static void start_retract(step_sm_t *sm, step_owner_t owner)
{
    start_retract_action(sm, owner, STEP_ACT_RETRACT);
}

static void start_retract_slow(step_sm_t *sm, step_owner_t owner)
{
    start_retract_action(sm, owner, STEP_ACT_RETRACT_SLOW);
}

static void finish_stop(step_sm_t *sm, step_state_t final_state)
{
    step_executor_request(sm->side, STEP_ACT_STOP);
    sm->state = final_state;
    save_recovery_record(sm, STEP_ACT_STOP);
}

void step_sm_init(step_sm_t *sm, step_side_t side)
{
    drv_nvm_power_recovery_t rec;

    if (sm == 0) {
        return;
    }

    sm->side = side;
    sm->state = STEP_STATE_RETRACTED;
    sm->owner = STEP_OWNER_NONE;
    sm->action_start_ms = 0U;
    sm->action_deadline_ms = 0U;
    sm->backoff_deadline_ms = 0U;
    sm->run_counter = 0U;
    sm->anti_pinch_counter = 0U;
    sm->fault_latched = false;

    if (drv_nvm_read_power_recovery(&rec) &&
        (rec.last_side == side) &&
        state_is_valid(rec.last_state)) {
        sm->state = (step_state_t)rec.last_state;
        if ((sm->state == STEP_STATE_EXTENDING) ||
            (sm->state == STEP_STATE_RETRACTING) ||
            (rec.last_action != STEP_ACT_STOP)) {
            drv_motor_exec(sm->side, STEP_ACT_STOP);
            step_executor_request(sm->side, STEP_ACT_STOP);
            sm->state = STEP_STATE_INIT;
        }
    }
}

void step_sm_tick_1ms(step_sm_t *sm)
{
    uint32_t now_ms;

    if (sm == 0) {
        return;
    }

    now_ms = sw_timer_now_ms();

    if ((sm->state == STEP_STATE_EXTENDING) &&
        step_executor_is_limit_reached(sm->side, STEP_ACT_EXTEND)) {
        post_local(sm->side, done_evt(sm->side));
        return;
    }

    if (((sm->state == STEP_STATE_RETRACTING) ||
         (sm->state == STEP_STATE_ANTI_PINCH_BACKOFF)) &&
        step_executor_is_limit_reached(sm->side, STEP_ACT_RETRACT)) {
        post_local(sm->side, done_evt(sm->side));
        return;
    }

    if (((sm->state == STEP_STATE_EXTENDING) ||
         (sm->state == STEP_STATE_RETRACTING)) &&
        sw_timer_is_expired(now_ms, sm->action_deadline_ms)) {
        post_local(sm->side, timeout_evt(sm->side));
        return;
    }

    if ((sm->state == STEP_STATE_ANTI_PINCH_BACKOFF) &&
        sw_timer_is_expired(now_ms, sm->backoff_deadline_ms)) {
        post_local(sm->side, done_evt(sm->side));
    }
}

void step_sm_handle_event(step_sm_t *sm, const event_t *ev)
{
    step_owner_t owner;
    const system_param_t *param;

    if ((sm == 0) || (ev == 0)) {
        return;
    }

    if (ev->id == EV_TICK_1MS) {
        step_sm_tick_1ms(sm);
        return;
    }

    param = param_get();
    owner = owner_from_event(ev);

    if (ev->id == EV_FAULT_CLEAR) {
        sm->fault_latched = false;
        if (sm->state == STEP_STATE_ERROR) {
            finish_stop(sm, STEP_STATE_RETRACTED);
            sm->owner = STEP_OWNER_NONE;
        }
        return;
    }

    if (sm->fault_latched) {
        return;
    }

    switch (sm->state)
    {
        case STEP_STATE_RETRACTED:
            if (ev->id == ext_evt(sm->side)) {
                start_extend(sm, owner);
            }
            break;

        case STEP_STATE_INIT:
            if (ev->id == ext_evt(sm->side)) {
                start_extend(sm, owner);
            } else if (ev->id == ret_evt(sm->side)) {
                if (owner == STEP_OWNER_POWER_RECOVERY) {
                    start_retract_slow(sm, owner);
                } else {
                    start_retract(sm, owner);
                }
            }
            break;

        case STEP_STATE_EXTENDING:
            if (ev->id == done_evt(sm->side)) {
                finish_stop(sm, STEP_STATE_EXTENDED);
                sm->run_counter++;
            } else if (ev->id == ret_evt(sm->side)) {
                if (owner == STEP_OWNER_POWER_RECOVERY) {
                    start_retract_slow(sm, owner);
                } else {
                    start_retract(sm, owner);
                }
            } else if (ev->id == antipinch_evt(sm->side)) {
                fault_set(antipinch_fault_mask(sm->side));
                sm->anti_pinch_counter++;
                sm->owner = STEP_OWNER_FAULT;
                sm->state = STEP_STATE_ANTI_PINCH_BACKOFF;
                sm->backoff_deadline_ms = sw_timer_now_ms() + param->anti_pinch_backoff_ms;
                step_executor_request(sm->side, STEP_ACT_RETRACT);
                save_recovery_record(sm, STEP_ACT_RETRACT);
            } else if (ev->id == overcurrent_evt(sm->side)) {
                fault_set(overcurrent_fault_mask(sm->side));
                sm->fault_latched = true;
                finish_stop(sm, STEP_STATE_ERROR);
            } else if (ev->id == timeout_evt(sm->side)) {
                fault_set(timeout_fault_mask(sm->side));
                sm->fault_latched = true;
                finish_stop(sm, STEP_STATE_ERROR);
            }
            break;

        case STEP_STATE_EXTENDED:
            if (ev->id == ret_evt(sm->side)) {
                if (owner == STEP_OWNER_POWER_RECOVERY) {
                    start_retract_slow(sm, owner);
                } else {
                    start_retract(sm, owner);
                }
            }
            break;

        case STEP_STATE_RETRACTING:
            if (ev->id == done_evt(sm->side)) {
                finish_stop(sm, STEP_STATE_RETRACTED);
                motor_feedback_mark_retracted_calibrated(sm->side);
                sm->run_counter++;
                sm->owner = STEP_OWNER_NONE;
            } else if (ev->id == ext_evt(sm->side)) {
                start_extend(sm, owner);
            } else if (ev->id == overcurrent_evt(sm->side)) {
                fault_set(overcurrent_fault_mask(sm->side));
                sm->fault_latched = true;
                finish_stop(sm, STEP_STATE_ERROR);
            } else if (ev->id == timeout_evt(sm->side)) {
                fault_set(timeout_fault_mask(sm->side));
                sm->fault_latched = true;
                finish_stop(sm, STEP_STATE_ERROR);
            }
            break;

        case STEP_STATE_ANTI_PINCH_BACKOFF:
            if (ev->id == done_evt(sm->side)) {
                finish_stop(sm, STEP_STATE_RETRACTED);
                motor_feedback_mark_retracted_calibrated(sm->side);
                sm->owner = STEP_OWNER_NONE;
            } else if (ev->id == overcurrent_evt(sm->side)) {
                fault_set(overcurrent_fault_mask(sm->side));
                sm->fault_latched = true;
                finish_stop(sm, STEP_STATE_ERROR);
            }
            break;

        case STEP_STATE_ERROR:
        default:
            break;
    }
}

step_state_t step_sm_get_state(const step_sm_t *sm)
{
    return (sm != 0) ? sm->state : STEP_STATE_ERROR;
}

step_owner_t step_sm_get_owner(const step_sm_t *sm)
{
    return (sm != 0) ? sm->owner : STEP_OWNER_NONE;
}

bool step_sm_is_open(const step_sm_t *sm)
{
    if (sm == 0) {
        return false;
    }

    return ((sm->state == STEP_STATE_EXTENDING) ||
            (sm->state == STEP_STATE_EXTENDED) ||
            (sm->state == STEP_STATE_ANTI_PINCH_BACKOFF)) ? true : false;
}

uint32_t step_sm_get_run_counter(const step_sm_t *sm)
{
    return (sm != 0) ? sm->run_counter : 0U;
}

uint32_t step_sm_get_antipinch_counter(const step_sm_t *sm)
{
    return (sm != 0) ? sm->anti_pinch_counter : 0U;
}
