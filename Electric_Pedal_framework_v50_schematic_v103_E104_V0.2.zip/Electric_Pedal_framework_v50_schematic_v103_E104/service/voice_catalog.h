#ifndef SERVICE_VOICE_CATALOG_H
#define SERVICE_VOICE_CATALOG_H

#include "project_bool.h"
#include <stdint.h>
#include "bsp/bsp_voice.h"

/*
 * 业务层语音 ID。
 *
 * 这里定义的是“业务语义”，不是语音芯片里的物理槽位。
 * 真正的槽位号由 voice_catalog_resolve() 根据语言去查表。
 */
typedef enum
{
    VOICE_ID_NONE = 0,
    VOICE_ID_ECU_POWER_ON = 1,
    VOICE_ID_BLE_CONNECTED,
    VOICE_ID_BLE_DISCONNECTED,
    VOICE_ID_LF_DOOR_OPEN,
    VOICE_ID_LR_DOOR_OPEN,
    VOICE_ID_RF_DOOR_OPEN,
    VOICE_ID_RR_DOOR_OPEN,
    VOICE_ID_STEP_EXTENDING,
    VOICE_ID_STEP_RETRACTING,
    VOICE_ID_STEP_DISABLED,
    VOICE_ID_LEFT_MOTOR_ERROR,
    VOICE_ID_RIGHT_MOTOR_ERROR,
    VOICE_ID_LEFT_CURRENT_OVER,
    VOICE_ID_RIGHT_CURRENT_OVER,
    VOICE_ID_ANTI_PINCH_ACTIVE,
    VOICE_ID_CAN_SIGNAL_LOST,
    VOICE_ID_MATCH_SUCCESS,
    VOICE_ID_MATCH_FAILED,
    VOICE_ID_MAX
} voice_id_t;

typedef struct
{
    uint16_t slot_zh;
    uint16_t slot_en;
    uint16_t duration_ms;
} voice_catalog_entry_t;

const voice_catalog_entry_t *voice_catalog_get(voice_id_t id);

/*
 * 按语言把业务 ID 解析成语音芯片实际曲目槽位和预计时长。
 * 这是联调阶段最常改的地方之一：如果烧录顺序变了，只改表，不改驱动。
 */
bool voice_catalog_resolve(voice_id_t id,
                           bsp_voice_lang_t lang,
                           uint16_t *slot,
                           uint16_t *duration_ms);

#endif
