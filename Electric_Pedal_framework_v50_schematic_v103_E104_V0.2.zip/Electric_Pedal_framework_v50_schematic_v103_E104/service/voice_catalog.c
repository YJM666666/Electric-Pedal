﻿#include "service/voice_catalog.h"

/*
 * MX5008F 当前采用“连续曲目号”假设：
 * - 中文槽位：1..18
 * - 英文槽位：19..36
 *
 * 如果你后面实际烧录顺序不一样，只需要改下面这张表，
 * 不需要去动 bsp_voice / u17_exec / 协议层代码。
 */
static const voice_catalog_entry_t s_voice_catalog[VOICE_ID_MAX] = {
    [VOICE_ID_NONE]               = {0U, 0U, 0U},
    [VOICE_ID_ECU_POWER_ON]       = {1U, 19U, 1400U},
    [VOICE_ID_BLE_CONNECTED]      = {2U, 20U, 1200U},
    [VOICE_ID_BLE_DISCONNECTED]   = {3U, 21U, 1200U},
    [VOICE_ID_LF_DOOR_OPEN]       = {4U, 22U, 1300U},
    [VOICE_ID_LR_DOOR_OPEN]       = {5U, 23U, 1300U},
    [VOICE_ID_RF_DOOR_OPEN]       = {6U, 24U, 1300U},
    [VOICE_ID_RR_DOOR_OPEN]       = {7U, 25U, 1300U},
    [VOICE_ID_STEP_EXTENDING]     = {8U, 26U, 1100U},
    [VOICE_ID_STEP_RETRACTING]    = {9U, 27U, 1100U},
    [VOICE_ID_STEP_DISABLED]      = {10U, 28U, 1200U},
    [VOICE_ID_LEFT_MOTOR_ERROR]   = {11U, 29U, 1500U},
    [VOICE_ID_RIGHT_MOTOR_ERROR]  = {12U, 30U, 1500U},
    [VOICE_ID_LEFT_CURRENT_OVER]  = {13U, 31U, 1600U},
    [VOICE_ID_RIGHT_CURRENT_OVER] = {14U, 32U, 1600U},
    [VOICE_ID_ANTI_PINCH_ACTIVE]  = {15U, 33U, 1500U},
    [VOICE_ID_CAN_SIGNAL_LOST]    = {16U, 34U, 1500U},
    [VOICE_ID_MATCH_SUCCESS]      = {17U, 35U, 1300U},
    [VOICE_ID_MATCH_FAILED]       = {18U, 36U, 1300U}
};

const voice_catalog_entry_t *voice_catalog_get(voice_id_t id)
{
    if ((id <= VOICE_ID_NONE) || (id >= VOICE_ID_MAX)) {
        return 0;
    }
    return &s_voice_catalog[id];
}

bool voice_catalog_resolve(voice_id_t id,
                           bsp_voice_lang_t lang,
                           uint16_t *slot,
                           uint16_t *duration_ms)
{
    const voice_catalog_entry_t *entry = voice_catalog_get(id);

    if ((entry == 0) || (slot == 0) || (duration_ms == 0)) {
        return false;
    }

    *slot = (lang == BSP_VOICE_LANG_EN) ? entry->slot_en : entry->slot_zh;
    *duration_ms = entry->duration_ms;
    return (*slot != 0U);
}
