/*
 * 事件标志服务：保存来自中断或底层轮询的轻量标志，供事件采集器统一转换为事件。
 */
#include "event_flags.h"

typedef struct
{
    volatile uint16_t tick_1ms;
    volatile uint16_t tick_10ms;
    volatile uint16_t tick_100ms;
    volatile uint16_t tick_1s;
    volatile uint32_t flags;
} event_flag_bank_t;

static event_flag_bank_t s_bank;

#if defined(__arm__) || defined(__thumb__) || defined(__ARM_ARCH)
static uint32_t event_flags_irq_save(void)
{
    uint32_t primask;

    __asm volatile("MRS %0, primask" : "=r"(primask) :: "memory");
    __asm volatile("cpsid i" ::: "memory");
    return primask;
}

static void event_flags_irq_restore(uint32_t primask)
{
    __asm volatile("MSR primask, %0" :: "r"(primask) : "memory");
}
#else
static uint32_t event_flags_irq_save(void)
{
    return 0U;
}

static void event_flags_irq_restore(uint32_t primask)
{
    (void)primask;
}
#endif

static void saturating_inc(volatile uint16_t *value)
{
    if ((value != 0) && (*value < 0xFFFFU)) {
        (*value)++;
    }
}

void event_flags_init(void)
{
    uint32_t key = event_flags_irq_save();

    s_bank.tick_1ms = 0U;
    s_bank.tick_10ms = 0U;
    s_bank.tick_100ms = 0U;
    s_bank.tick_1s = 0U;
    s_bank.flags = 0U;
    event_flags_irq_restore(key);
}

void event_flags_mark(uint32_t flags)
{
    uint32_t key = event_flags_irq_save();

    s_bank.flags |= flags;
    event_flags_irq_restore(key);
}

void event_flags_mark_isr(uint32_t flags)
{
    uint32_t key = event_flags_irq_save();

    s_bank.flags |= flags;
    event_flags_irq_restore(key);
}

void event_flags_raise_tick_isr(event_id_t tick_id)
{
    uint32_t key = event_flags_irq_save();

    switch (tick_id)
    {
        case EV_TICK_1MS:
            saturating_inc(&s_bank.tick_1ms);
            break;

        case EV_TICK_10MS:
            saturating_inc(&s_bank.tick_10ms);
            break;

        case EV_TICK_100MS:
            saturating_inc(&s_bank.tick_100ms);
            break;

        case EV_TICK_1S:
            saturating_inc(&s_bank.tick_1s);
            break;

        default:
            break;
    }

    event_flags_irq_restore(key);
}

void event_flags_take_snapshot(event_flag_snapshot_t *out)
{
    uint32_t key;

    if (out == 0) {
        return;
    }

    key = event_flags_irq_save();
    out->tick_1ms = s_bank.tick_1ms;
    out->tick_10ms = s_bank.tick_10ms;
    out->tick_100ms = s_bank.tick_100ms;
    out->tick_1s = s_bank.tick_1s;
    out->flags = s_bank.flags;
    s_bank.tick_1ms = 0U;
    s_bank.tick_10ms = 0U;
    s_bank.tick_100ms = 0U;
    s_bank.tick_1s = 0U;
    s_bank.flags = 0U;
    event_flags_irq_restore(key);
}
