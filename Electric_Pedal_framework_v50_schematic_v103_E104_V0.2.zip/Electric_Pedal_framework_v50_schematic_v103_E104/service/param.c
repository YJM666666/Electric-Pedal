#include "param.h"
#include "drv_nvm.h"
#include "event.h"
#include "fault.h"
#include "u17_link.h"
#include "motor_profile.h"
#include <string.h>

/*
 * 系统参数服务：维护出厂/用户参数、边界校验、延迟保存和参数变更通知。
 * 掉电恢复相关的慢速收回、电流阈值和霍尔超时参数也在这里集中默认化。
 */
#define PARAM_LIGHT_MODE_MAX          0x0BU
#define PARAM_MIN_TIMEOUT_MS          100U
#define PARAM_MAX_TIMEOUT_MS          10000U
#define PARAM_MIN_BACKOFF_MS          50U
#define PARAM_MAX_BACKOFF_MS          2000U
#define PARAM_MIN_STALL_DEBOUNCE_MS   10U
#define PARAM_MAX_STALL_DEBOUNCE_MS   500U
#define PARAM_MIN_RECOVERY_PULSE_MS    50U
#define PARAM_MAX_RECOVERY_PULSE_MS    2000U
#define PARAM_MIN_CAN_TIMEOUT_MS      100U
#define PARAM_MAX_CAN_TIMEOUT_MS      5000U
#define PARAM_MIN_ADC_THRESHOLD       100U
#define PARAM_MAX_ADC_THRESHOLD       4095U

static system_param_t s_param;
static bool s_dirty = false;
static uint8_t s_save_defer_s = 0U;

static void param_post_updated(void)
{
    event_t ev;

    ev.id = EV_PARAM_UPDATED;
    ev.source = EV_SRC_SYSTEM;
    ev.param_u32 = 0U;
    ev.param_ptr = 0;
    (void)event_push(&ev);
}

static void param_mark_dirty(void)
{
    s_dirty = true;
    s_save_defer_s = 1U;
    u17_link_mark_param_dirty();
    param_post_updated();
}

static void fill_serial_default(char serial_ascii[13])
{
    static const char serial_default[13] = "000000000000";
    (void)memcpy(serial_ascii, serial_default, sizeof(serial_default));
}

static void fill_password_default(char password_ascii[7])
{
    static const char password_default[7] = "123456";
    (void)memcpy(password_ascii, password_default, sizeof(password_default));
}

static bool valid_password_ascii(const char password_ascii[7])
{
    uint32_t i;

    if ((password_ascii == 0) || (password_ascii[6] != '\0')) {
        return false;
    }

    for (i = 0U; i < 6U; ++i) {
        if ((password_ascii[i] < '0') || (password_ascii[i] > '9')) {
            return false;
        }
    }

    return true;
}

static bool valid_enum_hand_drive(hand_drive_t mode)
{
    return ((mode == HAND_DRIVE_LEFT) || (mode == HAND_DRIVE_RIGHT));
}

static bool valid_enum_voice_language(voice_language_t lang)
{
    return ((lang == VOICE_LANG_CHINESE) || (lang == VOICE_LANG_ENGLISH));
}

static bool valid_enum_welcome_mode(welcome_mode_t mode)
{
    return ((mode == WELCOME_DRIVER_ONLY) || (mode == WELCOME_BOTH_SIDES));
}

static bool valid_light_scene(const light_scene_cfg_t *scene)
{
    if (scene == 0) {
        return false;
    }

    return (scene->mode <= PARAM_LIGHT_MODE_MAX);
}

static bool valid_threshold(uint16_t value)
{
    return ((value >= PARAM_MIN_ADC_THRESHOLD) && (value <= PARAM_MAX_ADC_THRESHOLD));
}

static bool valid_signal_trigger(const signal_trigger_t *sig)
{
    if (sig == 0) {
        return false;
    }

    if (sig->module_id == 0U) {
        return true;
    }

    return ((sig->module_id <= 0x7FFU) &&
            (sig->group_no < 8U) &&
            (sig->bit_no < 8U) &&
            (sig->active_value <= 1U));
}

static bool valid_speed_signal(const speed_signal_cfg_t *sig)
{
    if (sig == 0) {
        return false;
    }

    if (sig->module_id == 0U) {
        return true;
    }

    return ((sig->module_id <= 0x7FFU) &&
            (sig->hi_group_no < 8U) &&
            (sig->lo_group_no < 8U));
}

bool param_validate(const system_param_t *candidate)
{
    uint32_t i;

    if (candidate == 0) {
        return false;
    }

    if ((candidate->magic != PARAM_MAGIC_VALUE) ||
        (candidate->format_version != PARAM_FORMAT_VERSION)) {
        return false;
    }

    if (candidate->anti_pinch_level > 8U) {
        return false;
    }

    if (!valid_enum_hand_drive(candidate->hand_drive) ||
        !valid_enum_voice_language(candidate->voice_language) ||
        !valid_enum_welcome_mode(candidate->welcome_mode)) {
        return false;
    }

    if ((candidate->welcome_hold_seconds == 0U) || (candidate->welcome_hold_seconds > 255U) ||
        (candidate->wash_hold_seconds > 1800U) ||
        (candidate->extend_timeout_ms < PARAM_MIN_TIMEOUT_MS) ||
        (candidate->extend_timeout_ms > PARAM_MAX_TIMEOUT_MS) ||
        (candidate->retract_timeout_ms < PARAM_MIN_TIMEOUT_MS) ||
        (candidate->retract_timeout_ms > PARAM_MAX_TIMEOUT_MS) ||
        (candidate->recovery_retract_timeout_ms < PARAM_MIN_TIMEOUT_MS) ||
        (candidate->recovery_retract_timeout_ms > PARAM_MAX_TIMEOUT_MS) ||
        (candidate->anti_pinch_backoff_ms < PARAM_MIN_BACKOFF_MS) ||
        (candidate->anti_pinch_backoff_ms > PARAM_MAX_BACKOFF_MS) ||
        (candidate->stall_debounce_ms < PARAM_MIN_STALL_DEBOUNCE_MS) ||
        (candidate->stall_debounce_ms > PARAM_MAX_STALL_DEBOUNCE_MS) ||
        (candidate->recovery_stall_debounce_ms < PARAM_MIN_STALL_DEBOUNCE_MS) ||
        (candidate->recovery_stall_debounce_ms > PARAM_MAX_STALL_DEBOUNCE_MS) ||
        (candidate->recovery_no_pulse_start_grace_ms < PARAM_MIN_RECOVERY_PULSE_MS) ||
        (candidate->recovery_no_pulse_start_grace_ms > PARAM_MAX_RECOVERY_PULSE_MS) ||
        (candidate->recovery_no_pulse_timeout_ms < PARAM_MIN_RECOVERY_PULSE_MS) ||
        (candidate->recovery_no_pulse_timeout_ms > PARAM_MAX_RECOVERY_PULSE_MS) ||
        (candidate->can_timeout_ms < PARAM_MIN_CAN_TIMEOUT_MS) ||
        (candidate->can_timeout_ms > PARAM_MAX_CAN_TIMEOUT_MS)) {
        return false;
    }

    if (!valid_light_scene(&candidate->light_welcome) ||
        !valid_light_scene(&candidate->light_drive) ||
        !valid_light_scene(&candidate->light_turn) ||
        !valid_light_scene(&candidate->light_brake) ||
        !valid_light_scene(&candidate->light_alert)) {
        return false;
    }

    if ((candidate->light_brightness > 100U) ||
        (candidate->light_strip_type > 2U) ||
        (candidate->physical_switch_state > 1U) ||
        (candidate->install_manual_switch > 1U) ||
        (candidate->wash_function_switch > 1U)) {
        return false;
    }

    if ((candidate->serial_ascii[12] != '\0') ||
        (candidate->vehicle_code_ascii[16] != '\0') ||
        !valid_password_ascii(candidate->password_ascii) ||
        (candidate->area_code[0] == 0xFFU && candidate->area_code[1] == 0xFFU)) {
        return false;
    }

    for (i = 0U; i < 12U; ++i) {
        if (candidate->serial_ascii[i] == '\0') {
            return false;
        }
    }

    for (i = 0U; i < (uint32_t)DOOR_POS_MAX; ++i) {
        if (candidate->door_can_id[i] > 0x7FFU) {
            return false;
        }
        if (!valid_signal_trigger(&candidate->door_signal[i])) {
            return false;
        }
    }

    if (!valid_signal_trigger(&candidate->headlamp_signal) ||
        !valid_signal_trigger(&candidate->ignition_signal) ||
        !valid_signal_trigger(&candidate->left_turn_signal) ||
        !valid_signal_trigger(&candidate->right_turn_signal) ||
        !valid_signal_trigger(&candidate->hazard_signal) ||
        !valid_signal_trigger(&candidate->brake_signal) ||
        !valid_signal_trigger(&candidate->unlock_signal) ||
        !valid_speed_signal(&candidate->speed_signal)) {
        return false;
    }

    if ((candidate->canfd_data_rate_sel > 1U) || (candidate->can_monitor_sel > 2U)) {
        return false;
    }

    if (!valid_threshold(candidate->adc_left_overcurrent_th) ||
        !valid_threshold(candidate->adc_right_overcurrent_th) ||
        !valid_threshold(candidate->adc_left_antipinch_th_lv1) ||
        !valid_threshold(candidate->adc_left_antipinch_th_lv2) ||
        !valid_threshold(candidate->adc_left_antipinch_th_lv3) ||
        !valid_threshold(candidate->adc_left_antipinch_th_lv4) ||
        !valid_threshold(candidate->adc_left_antipinch_th_lv5) ||
        !valid_threshold(candidate->adc_left_antipinch_th_lv6) ||
        !valid_threshold(candidate->adc_left_antipinch_th_lv7) ||
        !valid_threshold(candidate->adc_left_antipinch_th_lv8) ||
        !valid_threshold(candidate->adc_right_antipinch_th_lv1) ||
        !valid_threshold(candidate->adc_right_antipinch_th_lv2) ||
        !valid_threshold(candidate->adc_right_antipinch_th_lv3) ||
        !valid_threshold(candidate->adc_right_antipinch_th_lv4) ||
        !valid_threshold(candidate->adc_right_antipinch_th_lv5) ||
        !valid_threshold(candidate->adc_right_antipinch_th_lv6) ||
        !valid_threshold(candidate->adc_right_antipinch_th_lv7) ||
        !valid_threshold(candidate->adc_right_antipinch_th_lv8) ||
        !valid_threshold(candidate->adc_left_recovery_overcurrent_th) ||
        !valid_threshold(candidate->adc_right_recovery_overcurrent_th)) {
        return false;
    }

    if ((candidate->adc_left_antipinch_th_lv1 >= candidate->adc_left_antipinch_th_lv2) ||
        (candidate->adc_left_antipinch_th_lv2 >= candidate->adc_left_antipinch_th_lv3) ||
        (candidate->adc_left_antipinch_th_lv3 >= candidate->adc_left_antipinch_th_lv4) ||
        (candidate->adc_left_antipinch_th_lv4 >= candidate->adc_left_antipinch_th_lv5) ||
        (candidate->adc_left_antipinch_th_lv5 >= candidate->adc_left_antipinch_th_lv6) ||
        (candidate->adc_left_antipinch_th_lv6 >= candidate->adc_left_antipinch_th_lv7) ||
        (candidate->adc_left_antipinch_th_lv7 >= candidate->adc_left_antipinch_th_lv8) ||
        (candidate->adc_right_antipinch_th_lv1 >= candidate->adc_right_antipinch_th_lv2) ||
        (candidate->adc_right_antipinch_th_lv2 >= candidate->adc_right_antipinch_th_lv3) ||
        (candidate->adc_right_antipinch_th_lv3 >= candidate->adc_right_antipinch_th_lv4) ||
        (candidate->adc_right_antipinch_th_lv4 >= candidate->adc_right_antipinch_th_lv5) ||
        (candidate->adc_right_antipinch_th_lv5 >= candidate->adc_right_antipinch_th_lv6) ||
        (candidate->adc_right_antipinch_th_lv6 >= candidate->adc_right_antipinch_th_lv7) ||
        (candidate->adc_right_antipinch_th_lv7 >= candidate->adc_right_antipinch_th_lv8) ||
        (candidate->adc_left_recovery_overcurrent_th >= candidate->adc_left_overcurrent_th) ||
        (candidate->adc_right_recovery_overcurrent_th >= candidate->adc_right_overcurrent_th) ||
        (candidate->adc_left_antipinch_th_lv8 >= candidate->adc_left_overcurrent_th) ||
        (candidate->adc_right_antipinch_th_lv8 >= candidate->adc_right_overcurrent_th)) {
        return false;
    }

    return true;
}

bool param_commit(const system_param_t *candidate)
{
    if (!param_validate(candidate)) {
        fault_set(FAULT_PARAM_INVALID);
        return false;
    }

    s_param = *candidate;
    fault_clear(FAULT_PARAM_INVALID);
    param_mark_dirty();
    return true;
}

void param_load_default(system_param_t *p)
{
    if (p == 0) {
        return;
    }

    (void)memset(p, 0, sizeof(*p));

    p->magic = PARAM_MAGIC_VALUE;
    p->format_version = PARAM_FORMAT_VERSION;

    p->activated = false;
    p->area_code[0] = 0x00U;
    p->area_code[1] = 0x02U;
    p->area_code[2] = 0x00U;

    p->main_switch_enable = true;
    p->welcome_enable = true;
    p->anti_pinch_enable = true;
    p->anti_pinch_level = 4U;
    p->hand_drive = HAND_DRIVE_LEFT;
    p->sound_enable = true;
    p->voice_language = VOICE_LANG_CHINESE;
    p->light_enable = true;
    p->welcome_mode = WELCOME_BOTH_SIDES;
    p->rear_door_reverse = false;
    p->left_right_swap = false;
    p->motor_left_reverse = false;
    p->motor_right_reverse = false;
    p->ota_enable = false;
    p->magnetic_mode = false;
    p->password_enable = true;

    p->welcome_hold_seconds = 15U;
    p->wash_hold_seconds = 480U;
    p->extend_timeout_ms = 3000U;
    p->retract_timeout_ms = 3000U;
    p->recovery_retract_timeout_ms = 2200U;
    p->anti_pinch_backoff_ms = motor_profile_get()->anti_pinch_backoff_ms;
    p->stall_debounce_ms = motor_profile_get()->stall_debounce_ms;
    p->recovery_stall_debounce_ms = 40U;
    p->can_timeout_ms = 1000U;

    p->door_can_id[DOOR_POS_FL] = 0x101U;
    p->door_can_id[DOOR_POS_FR] = 0x102U;
    p->door_can_id[DOOR_POS_RL] = 0x103U;
    p->door_can_id[DOOR_POS_RR] = 0x104U;

    p->vehicle_type = 0U;
    p->vehicle_config_ver = 0U;
    p->customer_id = 0U;
    p->vehicle_id = 0U;
    p->vehicle_code = 0U;
    (void)memset(p->vehicle_code_ascii, 0, sizeof(p->vehicle_code_ascii));
    fill_serial_default(p->serial_ascii);
    fill_password_default(p->password_ascii);
    p->logo_id = 0U;
    p->feature_flags = 0x01U;
    p->canfd_data_rate_sel = 0U;
    p->can_monitor_sel = 0U;
    p->can_baud_code = 0x05U;
    p->led_count = 25U;
    p->unactivated_use_count = 30U;
    p->physical_switch_state = 1U;
    p->install_manual_switch = 0U;
    p->wash_function_switch = 0U;
    p->sw_version_major = 0U;
    p->sw_version_minor = 2U;
    p->sw_version_patch = 0U;

    p->light_welcome.r = 0xFFU;
    p->light_welcome.g = 0xFFU;
    p->light_welcome.b = 0xFFU;
    p->light_welcome.mode = 0x01U;

    p->light_drive.r = 0xFFU;
    p->light_drive.g = 0xFFU;
    p->light_drive.b = 0xFFU;
    p->light_drive.mode = 0x01U;

    p->light_turn.r = 0xFFU;
    p->light_turn.g = 0x80U;
    p->light_turn.b = 0x00U;
    p->light_turn.mode = 0x01U;

    p->light_brake.r = 0xFFU;
    p->light_brake.g = 0x00U;
    p->light_brake.b = 0x00U;
    p->light_brake.mode = 0x01U;

    p->light_alert = p->light_brake;
    p->light_brightness = 100U;
    p->light_strip_type = 2U;
    p->auto_drive_blue = true;

    p->door_signal[DOOR_POS_FL].module_id = p->door_can_id[DOOR_POS_FL];
    p->door_signal[DOOR_POS_FL].group_no = 0U;
    p->door_signal[DOOR_POS_FL].bit_no = 0U;
    p->door_signal[DOOR_POS_FL].active_value = 1U;
    p->door_signal[DOOR_POS_FR].module_id = p->door_can_id[DOOR_POS_FR];
    p->door_signal[DOOR_POS_FR].group_no = 0U;
    p->door_signal[DOOR_POS_FR].bit_no = 0U;
    p->door_signal[DOOR_POS_FR].active_value = 1U;
    p->door_signal[DOOR_POS_RL].module_id = p->door_can_id[DOOR_POS_RL];
    p->door_signal[DOOR_POS_RL].group_no = 0U;
    p->door_signal[DOOR_POS_RL].bit_no = 0U;
    p->door_signal[DOOR_POS_RL].active_value = 1U;
    p->door_signal[DOOR_POS_RR].module_id = p->door_can_id[DOOR_POS_RR];
    p->door_signal[DOOR_POS_RR].group_no = 0U;
    p->door_signal[DOOR_POS_RR].bit_no = 0U;
    p->door_signal[DOOR_POS_RR].active_value = 1U;

    p->headlamp_signal.module_id = 0x122U;
    p->headlamp_signal.group_no = 0U;
    p->headlamp_signal.bit_no = 3U;
    p->headlamp_signal.active_value = 1U;
    p->ignition_signal.module_id = 0U;
    p->left_turn_signal.module_id = 0x122U;
    p->left_turn_signal.group_no = 0U;
    p->left_turn_signal.bit_no = 0U;
    p->left_turn_signal.active_value = 1U;
    p->right_turn_signal.module_id = 0x122U;
    p->right_turn_signal.group_no = 0U;
    p->right_turn_signal.bit_no = 1U;
    p->right_turn_signal.active_value = 1U;
    p->hazard_signal.module_id = 0U;
    p->brake_signal.module_id = 0x122U;
    p->brake_signal.group_no = 0U;
    p->brake_signal.bit_no = 2U;
    p->brake_signal.active_value = 1U;
    p->unlock_signal.module_id = 0x121U;
    p->unlock_signal.group_no = 0U;
    p->unlock_signal.bit_no = 0U;
    p->unlock_signal.active_value = 1U;
    p->speed_signal.module_id = 0x120U;
    p->speed_signal.hi_group_no = 0U;
    p->speed_signal.lo_group_no = 0U;

    p->adc_left_overcurrent_th = motor_profile_get()->default_overcurrent_adc;
    p->adc_right_overcurrent_th = motor_profile_get()->default_overcurrent_adc;
    p->adc_left_antipinch_th_lv1 = motor_profile_get()->default_anti_pinch_adc[0];
    p->adc_left_antipinch_th_lv2 = motor_profile_get()->default_anti_pinch_adc[1];
    p->adc_left_antipinch_th_lv3 = motor_profile_get()->default_anti_pinch_adc[2];
    p->adc_left_antipinch_th_lv4 = motor_profile_get()->default_anti_pinch_adc[3];
    p->adc_left_antipinch_th_lv5 = motor_profile_get()->default_anti_pinch_adc[4];
    p->adc_left_antipinch_th_lv6 = motor_profile_get()->default_anti_pinch_adc[5];
    p->adc_left_antipinch_th_lv7 = motor_profile_get()->default_anti_pinch_adc[6];
    p->adc_left_antipinch_th_lv8 = motor_profile_get()->default_anti_pinch_adc[7];
    p->adc_right_antipinch_th_lv1 = motor_profile_get()->default_anti_pinch_adc[0];
    p->adc_right_antipinch_th_lv2 = motor_profile_get()->default_anti_pinch_adc[1];
    p->adc_right_antipinch_th_lv3 = motor_profile_get()->default_anti_pinch_adc[2];
    p->adc_right_antipinch_th_lv4 = motor_profile_get()->default_anti_pinch_adc[3];
    p->adc_right_antipinch_th_lv5 = motor_profile_get()->default_anti_pinch_adc[4];
    p->adc_right_antipinch_th_lv6 = motor_profile_get()->default_anti_pinch_adc[5];
    p->adc_right_antipinch_th_lv7 = motor_profile_get()->default_anti_pinch_adc[6];
    p->adc_right_antipinch_th_lv8 = motor_profile_get()->default_anti_pinch_adc[7];
    p->adc_left_recovery_overcurrent_th = motor_profile_get()->default_anti_pinch_adc[4];
    p->adc_right_recovery_overcurrent_th = motor_profile_get()->default_anti_pinch_adc[4];
    p->recovery_no_pulse_start_grace_ms = 300U;
    p->recovery_no_pulse_timeout_ms = 450U;
    p->welcome_start_interval_s = 60U;
}

bool param_load_from_nvm(system_param_t *p)
{
    if (p == 0) {
        return false;
    }

    if (!drv_nvm_read_params((uint8_t *)p, (uint32_t)sizeof(*p))) {
        return false;
    }

    return param_validate(p);
}

bool param_save_to_nvm(const system_param_t *p)
{
    if (p == 0) {
        return false;
    }

    return drv_nvm_write_params((const uint8_t *)p, (uint32_t)sizeof(*p));
}

void param_init(void)
{
    param_load_default(&s_param);

    if (!param_load_from_nvm(&s_param)) {
        fault_set(FAULT_NVM | FAULT_PARAM_INVALID);
        param_load_default(&s_param);
        if (param_save_to_nvm(&s_param)) {
            fault_clear(FAULT_NVM | FAULT_PARAM_INVALID);
        }
    } else {
        fault_clear(FAULT_NVM | FAULT_PARAM_INVALID);
    }

    s_dirty = false;
    s_save_defer_s = 0U;
}

void param_periodic_1s(void)
{
    if (!s_dirty) {
        return;
    }

    if (s_save_defer_s > 0U) {
        s_save_defer_s--;
        return;
    }

    if (param_save_to_nvm(&s_param)) {
        s_dirty = false;
        fault_clear(FAULT_NVM);
    } else {
        fault_set(FAULT_NVM);
    }
}

const system_param_t *param_get(void)
{
    return &s_param;
}

system_param_t *param_get_mutable(void)
{
    return &s_param;
}

bool param_set_activated(bool activated)
{
    system_param_t candidate = s_param;
    candidate.activated = activated;
    return param_commit(&candidate);
}

bool param_set_area_code(const uint8_t area[3])
{
    system_param_t candidate = s_param;

    if (area == 0) {
        return false;
    }

    candidate.area_code[0] = area[0];
    candidate.area_code[1] = area[1];
    candidate.area_code[2] = area[2];
    return param_commit(&candidate);
}

bool param_set_main_switch_enable(bool en)
{
    system_param_t candidate = s_param;
    candidate.main_switch_enable = en;
    return param_commit(&candidate);
}

bool param_set_welcome_enable(bool en)
{
    system_param_t candidate = s_param;
    candidate.welcome_enable = en;
    return param_commit(&candidate);
}

bool param_set_welcome_mode(welcome_mode_t mode)
{
    system_param_t candidate = s_param;
    candidate.welcome_mode = mode;
    return param_commit(&candidate);
}

bool param_set_welcome_hold_seconds(uint16_t sec)
{
    system_param_t candidate = s_param;
    candidate.welcome_hold_seconds = sec;
    return param_commit(&candidate);
}

bool param_set_anti_pinch_enable(bool en)
{
    system_param_t candidate = s_param;
    candidate.anti_pinch_enable = en;
    return param_commit(&candidate);
}

bool param_set_anti_pinch_level(uint8_t level)
{
    system_param_t candidate = s_param;
    candidate.anti_pinch_level = level;
    return param_commit(&candidate);
}

bool param_set_wash_hold_seconds(uint16_t sec)
{
    system_param_t candidate = s_param;
    candidate.wash_hold_seconds = sec;
    return param_commit(&candidate);
}

bool param_set_hand_drive(hand_drive_t mode)
{
    system_param_t candidate = s_param;
    candidate.hand_drive = mode;
    return param_commit(&candidate);
}

bool param_set_sound_enable(bool en)
{
    system_param_t candidate = s_param;
    candidate.sound_enable = en;
    return param_commit(&candidate);
}

bool param_set_voice_language(voice_language_t lang)
{
    system_param_t candidate = s_param;
    candidate.voice_language = lang;
    return param_commit(&candidate);
}

bool param_set_light_enable(bool en)
{
    system_param_t candidate = s_param;
    candidate.light_enable = en;
    return param_commit(&candidate);
}

bool param_set_motor_reverse(bool left_rev, bool right_rev)
{
    system_param_t candidate = s_param;
    candidate.motor_left_reverse = left_rev;
    candidate.motor_right_reverse = right_rev;
    return param_commit(&candidate);
}

bool param_set_swap(bool rear_reverse, bool lr_swap)
{
    system_param_t candidate = s_param;
    candidate.rear_door_reverse = rear_reverse;
    candidate.left_right_swap = lr_swap;
    return param_commit(&candidate);
}

bool param_set_door_can_id(door_pos_t pos, uint16_t can_id)
{
    system_param_t candidate = s_param;

    if (pos >= DOOR_POS_MAX) {
        return false;
    }

    candidate.door_can_id[pos] = can_id;
    return param_commit(&candidate);
}

bool param_set_serial_ascii(const char *serial12)
{
    system_param_t candidate = s_param;
    size_t i;

    if (serial12 == 0) {
        return false;
    }

    for (i = 0U; i < 12U; ++i) {
        char ch = serial12[i];
        if (ch == '\0') {
            return false;
        }
        candidate.serial_ascii[i] = ch;
    }
    candidate.serial_ascii[12] = '\0';
    return param_commit(&candidate);
}

bool param_set_light_scenes(const light_scene_cfg_t *welcome_scene,
                            const light_scene_cfg_t *alert_scene,
                            const light_scene_cfg_t *drive_scene)
{
    system_param_t candidate = s_param;

    if ((welcome_scene == 0) || (alert_scene == 0) || (drive_scene == 0)) {
        return false;
    }

    candidate.light_welcome = *welcome_scene;
    candidate.light_turn = *alert_scene;
    candidate.light_brake = *alert_scene;
    candidate.light_alert = *alert_scene;
    candidate.light_drive = *drive_scene;
    return param_commit(&candidate);
}

bool param_store_factory_cmd(uint8_t slot, const uint8_t *payload, uint8_t len)
{
    system_param_t candidate = s_param;

    if ((slot >= PARAM_FACTORY_CMD_COUNT) || (payload == 0) || (len > PARAM_FACTORY_CMD_MAX_SIZE)) {
        return false;
    }

    (void)memset(candidate.factory_cmd[slot], 0, PARAM_FACTORY_CMD_MAX_SIZE);
    (void)memcpy(candidate.factory_cmd[slot], payload, len);
    candidate.factory_cmd_len[slot] = len;
    return param_commit(&candidate);
}


bool param_set_vehicle_id(uint32_t id)
{
    system_param_t candidate = s_param;
    candidate.vehicle_id = id;
    return param_commit(&candidate);
}

bool param_set_vehicle_code(uint32_t code)
{
    system_param_t candidate = s_param;
    candidate.vehicle_code = code;
    return param_commit(&candidate);
}

bool param_set_vehicle_code_ascii(const char *code16)
{
    system_param_t candidate = s_param;
    if (code16 == 0) {
        return false;
    }
    candidate = s_param;
    (void)memset(candidate.vehicle_code_ascii, 0, sizeof(candidate.vehicle_code_ascii));
    (void)memcpy(candidate.vehicle_code_ascii, code16, 16U);
    candidate.vehicle_code_ascii[16] = '\0';
    return param_commit(&candidate);
}

bool param_set_can_monitor(uint8_t monitor_sel, uint8_t canfd_rate_sel)
{
    system_param_t candidate = s_param;
    candidate.can_monitor_sel = monitor_sel;
    candidate.canfd_data_rate_sel = canfd_rate_sel;
    return param_commit(&candidate);
}

uint16_t param_get_left_antipinch_threshold(void)
{
    switch (s_param.anti_pinch_level)
    {
        case 0U:
        case 1U: return s_param.adc_left_antipinch_th_lv1;
        case 2U: return s_param.adc_left_antipinch_th_lv2;
        case 3U: return s_param.adc_left_antipinch_th_lv3;
        case 4U: return s_param.adc_left_antipinch_th_lv4;
        case 5U: return s_param.adc_left_antipinch_th_lv5;
        case 6U: return s_param.adc_left_antipinch_th_lv6;
        case 7U: return s_param.adc_left_antipinch_th_lv7;
        case 8U: return s_param.adc_left_antipinch_th_lv8;
        default: return s_param.adc_left_antipinch_th_lv4;
    }
}

uint16_t param_get_right_antipinch_threshold(void)
{
    switch (s_param.anti_pinch_level)
    {
        case 0U:
        case 1U: return s_param.adc_right_antipinch_th_lv1;
        case 2U: return s_param.adc_right_antipinch_th_lv2;
        case 3U: return s_param.adc_right_antipinch_th_lv3;
        case 4U: return s_param.adc_right_antipinch_th_lv4;
        case 5U: return s_param.adc_right_antipinch_th_lv5;
        case 6U: return s_param.adc_right_antipinch_th_lv6;
        case 7U: return s_param.adc_right_antipinch_th_lv7;
        case 8U: return s_param.adc_right_antipinch_th_lv8;
        default: return s_param.adc_right_antipinch_th_lv4;
    }
}

uint16_t param_get_recovery_overcurrent_threshold(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? s_param.adc_left_recovery_overcurrent_th
                                    : s_param.adc_right_recovery_overcurrent_th;
}

uint8_t param_get_antipinch_proto_level(void)
{
    if (!s_param.anti_pinch_enable) {
        return 0U;
    }

    return s_param.anti_pinch_level;
}

bool param_is_dirty(void)
{
    return s_dirty;
}
