#ifndef SERVICE_BLE_IF_H
#define SERVICE_BLE_IF_H

/*
 * 文件: service/ble_if.h
 * 描述: BLE 链路抽象接口（UART 传输层到上层协议的桥接）。
 * 责任: 提供初始化、接收中断处理、轮询与诊断接口，供上层事件与协议模块使用。
 */

#include <stddef.h>
#include <stdint.h>
#include "project_bool.h"
#include "event.h"

typedef struct
{
    uint32_t rx_overflow_count;
    uint32_t frame_error_count;
    uint32_t unsupported_cmd_count;
    uint32_t event_drop_count;
    uint32_t event_ack_timeout_count;
    bool     rx_overflow_latched;
} ble_if_diag_t;

void ble_if_init(void);
void ble_if_on_event(const event_t *ev);
void ble_if_tick_100ms(void);
void ble_if_rx_byte_isr(uint8_t byte);
void ble_if_rx_buf_isr(const uint8_t *data, size_t len);
void ble_if_poll(void);
void ble_if_get_diag(ble_if_diag_t *diag);
bool ble_if_has_rx_overflowed(void);
void ble_if_clear_rx_overflow(void);

#endif
