#ifndef SERVICE_APP_CMD_DISPATCH_H
#define SERVICE_APP_CMD_DISPATCH_H

/*
 * 文件: service/app_cmd_dispatch.h
 * 描述: 应用命令分发接口声明。
 * 责任: 接收解析后的协议帧，将命令路由到对应处理器并生成应答。
 */

#include <stdint.h>
#include "project_bool.h"
#include "app_proto_v2.h"

typedef struct
{
    uint8_t status;
    uint8_t payload[64];
    uint8_t len;
    bool    send_reply;
    bool    reboot_after_reply;
} app_cmd_reply_t;

void app_cmd_dispatch_init(void);
void app_cmd_dispatch_set_link_active(bool active);
void app_cmd_dispatch_process(const app_proto_v2_frame_t *frame, app_cmd_reply_t *reply);
uint32_t app_cmd_dispatch_get_unsupported_count(void);

#endif
