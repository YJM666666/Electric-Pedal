#include "current_guard.h"
#include "param.h"
#include "event_flags.h"

/*
 * 电流保护服务。
 * 1ms 周期滤波左右电机电流，并按当前运动模式触发过流/防夹事件。
 * 掉电恢复收回使用独立阈值和防抖时间，避免恢复过程长时间硬顶机械端点。
 */
typedef struct
{
    current_guard_motion_t motion;
    uint16_t raw;
    uint16_t filt;
    uint16_t over_cnt_ms;
    uint16_t pinch_cnt_ms;
} current_guard_ch_t;

static current_guard_ch_t s_ch[STEP_SIDE_MAX];
static uint32_t s_alert_flags = 0U;

static uint32_t over_alert_bit(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? CURRENT_GUARD_ALERT_L_OVERCURRENT
                                    : CURRENT_GUARD_ALERT_R_OVERCURRENT;
}

static uint32_t pinch_alert_bit(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? CURRENT_GUARD_ALERT_L_ANTI_PINCH
                                    : CURRENT_GUARD_ALERT_R_ANTI_PINCH;
}

static uint16_t get_overcurrent_th(step_side_t side)
{
    const system_param_t *param = param_get();

    if (s_ch[side].motion == CG_MOTION_RECOVERY_RETRACT) {
        return param_get_recovery_overcurrent_threshold(side);
    }

    return (side == STEP_SIDE_LEFT) ? param->adc_left_overcurrent_th
                                    : param->adc_right_overcurrent_th;
}

static uint16_t get_antipinch_th(step_side_t side)
{
    return (side == STEP_SIDE_LEFT) ? param_get_left_antipinch_threshold()
                                    : param_get_right_antipinch_threshold();
}

static void note_alert(uint32_t bit)
{
    s_alert_flags |= bit;
    event_flags_mark(EVENT_FLAG_PROTECT_ALERT_PENDING);
}

static void update_one(step_side_t side, uint16_t raw)
{
    current_guard_ch_t *ch;
    const system_param_t *param;
    uint16_t debounce_ms;
    uint16_t over_th;
    uint16_t pinch_th;

    ch = &s_ch[side];
    param = param_get();
    ch->raw = raw;
    ch->filt = (uint16_t)(((uint32_t)ch->filt * 3U + raw) / 4U);

    if (ch->motion == CG_MOTION_IDLE) {
        ch->over_cnt_ms = 0U;
        ch->pinch_cnt_ms = 0U;
        return;
    }

    if (ch->motion == CG_MOTION_RECOVERY_RETRACT) {
        debounce_ms = (param->recovery_stall_debounce_ms == 0U) ? 1U : param->recovery_stall_debounce_ms;
    } else {
        debounce_ms = (param->stall_debounce_ms == 0U) ? 1U : param->stall_debounce_ms;
    }
    over_th = get_overcurrent_th(side);
    pinch_th = get_antipinch_th(side);

    if (ch->filt >= over_th) {
        if (ch->over_cnt_ms < 0xFFFFU) {
            ch->over_cnt_ms++;
        }
    } else {
        ch->over_cnt_ms = 0U;
    }

    if ((ch->motion == CG_MOTION_EXTEND) &&
        param->anti_pinch_enable &&
        (ch->filt >= pinch_th) &&
        (ch->filt < over_th)) {
        if (ch->pinch_cnt_ms < 0xFFFFU) {
            ch->pinch_cnt_ms++;
        }
    } else {
        ch->pinch_cnt_ms = 0U;
    }

    if (ch->pinch_cnt_ms >= debounce_ms) {
        ch->motion = CG_MOTION_IDLE;
        ch->pinch_cnt_ms = 0U;
        ch->over_cnt_ms = 0U;
        note_alert(pinch_alert_bit(side));
        return;
    }

    if (ch->over_cnt_ms >= debounce_ms) {
        ch->motion = CG_MOTION_IDLE;
        ch->pinch_cnt_ms = 0U;
        ch->over_cnt_ms = 0U;
        note_alert(over_alert_bit(side));
    }
}

void current_guard_init(void)
{
    uint32_t i;

    for (i = 0U; i < (uint32_t)STEP_SIDE_MAX; ++i) {
        s_ch[i].motion = CG_MOTION_IDLE;
        s_ch[i].raw = 0U;
        s_ch[i].filt = 0U;
        s_ch[i].over_cnt_ms = 0U;
        s_ch[i].pinch_cnt_ms = 0U;
    }
    s_alert_flags = 0U;
}

void current_guard_set_motion(step_side_t side, current_guard_motion_t motion)
{
    if (side >= STEP_SIDE_MAX) {
        return;
    }

    s_ch[side].motion = motion;
    s_ch[side].over_cnt_ms = 0U;
    s_ch[side].pinch_cnt_ms = 0U;
}

void current_guard_update_1ms(uint16_t left_raw, uint16_t right_raw)
{
    update_one(STEP_SIDE_LEFT, left_raw);
    update_one(STEP_SIDE_RIGHT, right_raw);
}

uint16_t current_guard_get_filtered(step_side_t side)
{
    if (side >= STEP_SIDE_MAX) {
        return 0U;
    }

    return s_ch[side].filt;
}

uint32_t current_guard_take_alert_flags(void)
{
    uint32_t flags = s_alert_flags;
    s_alert_flags = 0U;
    return flags;
}
