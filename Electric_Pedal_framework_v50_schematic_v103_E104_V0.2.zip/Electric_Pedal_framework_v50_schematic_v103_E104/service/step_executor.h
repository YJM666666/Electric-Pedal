#ifndef SERVICE_STEP_EXECUTOR_H
#define SERVICE_STEP_EXECUTOR_H

/*
 * 踏板动作执行接口：缓存状态机动作请求，并由调度器统一提交给底层电机驱动。
 */
#include "project_bool.h"
#include <stdint.h>
#include "pedal_types.h"

typedef struct
{
    step_side_t   side;
    step_action_t action;
    uint32_t      sequence;
} step_exec_cmd_t;

void step_executor_init(void);
void step_executor_request(step_side_t side, step_action_t action);
bool step_executor_take_pending(step_side_t side, step_exec_cmd_t *out);
void step_executor_apply_pending(void);
step_action_t step_executor_get_requested_action(step_side_t side);
step_action_t step_executor_get_applied_action(step_side_t side);
bool step_executor_is_limit_reached(step_side_t side, step_action_t action);

#endif
