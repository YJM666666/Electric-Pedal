#include "app_cmd_dispatch.h"
#include "event_report_service.h"
#include "param.h"
#include "policy.h"
#include "event.h"
#include "fault.h"
#include "ota_service.h"
#include "drv_light.h"
#include <string.h>

/*
 * 上位机/蓝牙命令分发：解析 APP 协议帧，写入参数、查询状态，并触发模式或 OTA 操作。
 * 这里只负责协议翻译，实际踏板安全决策仍由 policy 和 step_sm 执行。
 */
#define APP_OTA_C2_DATA_MAX       (APP_PROTO_V2_MAX_PAYLOAD - 10U) /* 预留协议头、命令字等占用，确保 OTA 数据能完整传输 */

typedef struct
{
    uint8_t scene_select;
    light_scene_cfg_t *scene;
} light_scene_ref_t;

enum {
    FACTORY_SLOT_B1 = 0,
    FACTORY_SLOT_B2,
    FACTORY_SLOT_B3,
    FACTORY_SLOT_B4,
    FACTORY_SLOT_B5,
    FACTORY_SLOT_B6,
    FACTORY_SLOT_B7,
    FACTORY_SLOT_B8,
    FACTORY_SLOT_B9
};

static bool s_link_active = false; 
static uint32_t s_unsupported_cmd_count = 0U;

static void post_event_simple(event_id_t id)
{
    event_t ev = {id, EV_SRC_APP, 0U, 0};
    (void)event_push(&ev);
}

static uint16_t le16(const uint8_t *p)
{
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static uint32_t le32(const uint8_t *p) 
{
    return (uint32_t)p[0] |
           ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}

static void put_le16(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)v;
    p[1] = (uint8_t)(v >> 8);
}

static void put_le32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)v;
    p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16);
    p[3] = (uint8_t)(v >> 24);
}

static uint16_t scale_factory_threshold_u16(uint16_t raw)
{
    uint32_t scaled = (uint32_t)raw * 10U;
    if (scaled < 100U) {
        scaled = 100U;
    }
    if (scaled > 4000U) {
        scaled = 4000U;
    }
    return (uint16_t)scaled;
}

static voice_language_t voice_lang_from_proto(uint8_t value)
{
    return (value != 0U) ? VOICE_LANG_ENGLISH : VOICE_LANG_CHINESE;
}

static uint8_t voice_lang_to_proto(voice_language_t lang)
{
    return (lang == VOICE_LANG_ENGLISH) ? 1U : 0U;
}

static bool pwd_is_digits6(const uint8_t *buf)
{
    uint32_t i;

    if (buf == 0) {
        return false;
    }

    for (i = 0U; i < 6U; ++i) {
        if ((buf[i] < (uint8_t)'0') || (buf[i] > (uint8_t)'9')) {
            return false;
        }
    }
    return true;
}

static uint8_t pwd_check(const uint8_t *buf, uint8_t len)
{
    const system_param_t *p = param_get();

    if (len != 6U) {
        return APP_ST_PWD_FMT_ERR;
    }
    if (!pwd_is_digits6(buf)) {
        return APP_ST_PWD_FMT_ERR;
    }
    if (memcmp(buf, p->password_ascii, 6U) != 0) {
        return APP_ST_PWD_ERR;
    }
    return APP_ST_OK;
}

static uint8_t build_feature_flags(const system_param_t *p)
{
    uint8_t flags = p->feature_flags;
    if (p->light_enable) {
        flags |= 0x01U;
    }
    if (p->sound_enable) {
        flags |= 0x02U;
    }
    if (p->ota_enable) {
        flags |= 0x04U;
    }
    return flags;
}

static bool vehicle_profile_loaded(const system_param_t *p)
{
    uint32_t i;

    if (p->vehicle_id != 0U) {
        return true;
    }
    for (i = 0U; i < PARAM_FACTORY_CMD_COUNT; ++i) {
        if (p->factory_cmd_len[i] != 0U) {
            return true;
        }
    }
    return false;
}

static uint32_t build_version_u32(uint16_t major, uint16_t minor, uint16_t patch)
{
    return (((uint32_t)(major & 0xFFU)) << 16) |
           (((uint32_t)(minor & 0xFFU)) << 8) |
           ((uint32_t)(patch & 0xFFU));
}

static light_scene_ref_t resolve_scene_ref(system_param_t *candidate, uint8_t scene_select)
{
    light_scene_ref_t ref;

    ref.scene_select = scene_select;
    ref.scene = 0;
    switch (scene_select)
    {
        case 0U: ref.scene = &candidate->light_welcome; break;
        case 1U: ref.scene = &candidate->light_drive; break;
        case 2U: ref.scene = &candidate->light_turn; break;
        case 3U: ref.scene = &candidate->light_brake; break;
        default: break;
    }
    return ref;
}

static const light_scene_cfg_t *resolve_scene_cfg_const(const system_param_t *p, uint8_t scene_select)
{
    switch (scene_select)
    {
        case 0U: return &p->light_welcome;
        case 1U: return &p->light_drive;
        case 2U: return &p->light_turn;
        case 3U: return &p->light_brake;
        default: return 0;
    }
}

static void store_factory_raw(system_param_t *candidate, uint8_t slot, const uint8_t *payload, uint8_t len)
{
    if ((candidate == 0) || (payload == 0) || (slot >= PARAM_FACTORY_CMD_COUNT) || (len > PARAM_FACTORY_CMD_MAX_SIZE)) {
        return;
    }
    (void)memset(candidate->factory_cmd[slot], 0, PARAM_FACTORY_CMD_MAX_SIZE);
    (void)memcpy(candidate->factory_cmd[slot], payload, len);
    candidate->factory_cmd_len[slot] = len;
}

static uint8_t handle_cmd_switch(const app_proto_v2_frame_t *f)
{
    system_param_t c;

    if (f->len < 6U) {
        return APP_ST_LEN_ERR;
    }

    c = *param_get();
    c.main_switch_enable = (f->payload[0] != 0U);
    c.wash_function_switch = (f->payload[2] != 0U) ? 1U : 0U;
    c.wash_hold_seconds = le16(&f->payload[3]);
    c.physical_switch_state = (f->payload[5] != 0U) ? 1U : 0U;
    if (!param_commit(&c)) {
        return APP_ST_PARAM_ERR;
    }
    if (!c.main_switch_enable) {
        post_event_simple(EV_MAIN_SWITCH_OFF);
    } else {
        post_event_simple(EV_MAIN_SWITCH_ON);
    }
    switch (f->payload[1]) {
        case 0x01U: post_event_simple(EV_L_EXT_CMD); post_event_simple(EV_R_EXT_CMD); break;
        case 0x02U: post_event_simple(EV_L_RET_CMD); post_event_simple(EV_R_RET_CMD); break;
        default: break;
    }
    if (f->payload[2] != 0U) {
        post_event_simple(EV_ENTER_WASH);
    } else {
        post_event_simple(EV_WASH_TIMEOUT);
    }
    return APP_ST_OK;
}

static uint8_t handle_cmd_feature(const app_proto_v2_frame_t *f)
{
    system_param_t c;

    if (f->len < 13U) {
        return APP_ST_LEN_ERR;
    }

    c = *param_get();
    c.welcome_enable = (f->payload[0] != 0U);
    c.welcome_hold_seconds = f->payload[1];
    c.anti_pinch_enable = (f->payload[2] != 0U);
    c.anti_pinch_level = f->payload[3];
    c.hand_drive = (f->payload[4] != 0U) ? HAND_DRIVE_RIGHT : HAND_DRIVE_LEFT;
    c.sound_enable = (f->payload[5] != 0U);
    c.voice_language = voice_lang_from_proto(f->payload[6]);
    c.motor_left_reverse = ((f->payload[7] & 0x01U) != 0U);
    c.motor_right_reverse = ((f->payload[7] & 0x02U) != 0U);
    c.rear_door_reverse = (f->payload[8] != 0U);
    c.left_right_swap = (f->payload[9] != 0U);
    c.welcome_mode = (f->payload[10] != 0U) ? WELCOME_BOTH_SIDES : WELCOME_DRIVER_ONLY;
    c.magnetic_mode = (f->payload[11] != 0U);
    return param_commit(&c) ? APP_ST_OK : APP_ST_PARAM_ERR;
}

static uint8_t handle_cmd_light(const app_proto_v2_frame_t *f)
{
    system_param_t c;
    light_scene_ref_t ref;

    if (f->len < 12U) {
        return APP_ST_LEN_ERR;
    }

    c = *param_get();
    ref = resolve_scene_ref(&c, f->payload[0]);
    if (ref.scene == 0) {
        return APP_ST_PARAM_ERR;
    }
    ref.scene->r = f->payload[1];
    ref.scene->g = f->payload[2];
    ref.scene->b = f->payload[3];
    ref.scene->mode = f->payload[4];
    c.light_brightness = f->payload[5];
    c.light_strip_type = f->payload[6];
    c.auto_drive_blue = (f->payload[7] != 0U);
    c.light_enable = true;
    c.light_alert = c.light_brake;
    return param_commit(&c) ? APP_ST_OK : APP_ST_PARAM_ERR;
}

static uint8_t handle_cmd_install(const app_proto_v2_frame_t *f)
{
    system_param_t c;

    if (f->len < 6U) {
        return APP_ST_LEN_ERR;
    }

    c = *param_get();
    c.install_manual_switch = (f->payload[1] == 1U || f->payload[2] == 1U) ? 1U : 0U;
    if (!param_commit(&c)) {
        return APP_ST_PARAM_ERR;
    }
    if (f->payload[0] != 0U) {
        post_event_simple(EV_ENTER_INSTALL_TEST);
    } else {
        post_event_simple(EV_EXIT_INSTALL_TEST);
    }
    if (f->payload[1] == 1U) post_event_simple(EV_L_EXT_CMD); else if (f->payload[1] == 2U) post_event_simple(EV_L_RET_CMD);
    if (f->payload[2] == 1U) post_event_simple(EV_R_EXT_CMD); else if (f->payload[2] == 2U) post_event_simple(EV_R_RET_CMD);
    if ((f->payload[3] != 0U) || (f->payload[4] != 0U)) {
        drv_light_apply_scene(LIGHT_SCENE_WELCOME);
    } else {
        drv_light_apply_scene(LIGHT_SCENE_OFF);
    }
    (void)f->payload[5]; /* V1.03 硬件没有蜂鸣器输出。 */
    return APP_ST_OK;
}

static uint8_t handle_cmd_vehicle(const app_proto_v2_frame_t *f)
{
    system_param_t c;

    if (f->len < 24U) {
        return APP_ST_LEN_ERR;
    }

    c = *param_get();
    c.vehicle_type = f->payload[0];
    c.vehicle_id = le32(&f->payload[1]);
    (void)memset(c.vehicle_code_ascii, 0, sizeof(c.vehicle_code_ascii));
    (void)memcpy(c.vehicle_code_ascii, &f->payload[5], 16U);
    c.vehicle_code = c.vehicle_id;
    c.vehicle_config_ver = f->payload[21];
    c.magnetic_mode = (f->payload[22] != 0U);
    return param_commit(&c) ? APP_ST_OK : APP_ST_PARAM_ERR;
}

static uint8_t handle_factory_b1_b2(const app_proto_v2_frame_t *f, uint8_t slot, door_pos_t first, door_pos_t second)
{
    system_param_t c = *param_get();

    if (f->len != PARAM_FACTORY_CMD_B1_LEN) {
        return APP_ST_LEN_ERR;
    }
    store_factory_raw(&c, slot, f->payload, f->len);
    c.door_signal[first].module_id = le16(&f->payload[0]);
    c.door_signal[first].group_no = f->payload[2];
    c.door_signal[first].bit_no = f->payload[3];
    c.door_signal[first].active_value = f->payload[4] & 0x01U;
    c.door_can_id[first] = c.door_signal[first].module_id;
    c.door_signal[second].module_id = le16(&f->payload[5]);
    c.door_signal[second].group_no = f->payload[7];
    c.door_signal[second].bit_no = f->payload[8];
    c.door_signal[second].active_value = f->payload[9] & 0x01U;
    c.door_can_id[second] = c.door_signal[second].module_id;
    return param_commit(&c) ? APP_ST_OK : APP_ST_PARAM_ERR;
}

static uint8_t handle_factory_b5(const app_proto_v2_frame_t *f)
{
    system_param_t c = *param_get();

    if (f->len != PARAM_FACTORY_CMD_B5_LEN) {
        return APP_ST_LEN_ERR;
    }
    store_factory_raw(&c, FACTORY_SLOT_B5, f->payload, f->len);
    c.headlamp_signal.module_id = le16(&f->payload[0]);
    c.headlamp_signal.group_no = f->payload[2];
    c.headlamp_signal.bit_no = f->payload[3];
    c.headlamp_signal.active_value = f->payload[4] & 0x01U;
    c.ignition_signal.module_id = le16(&f->payload[5]);
    c.ignition_signal.group_no = f->payload[7];
    c.ignition_signal.bit_no = f->payload[8];
    c.ignition_signal.active_value = f->payload[9] & 0x01U;
    return param_commit(&c) ? APP_ST_OK : APP_ST_PARAM_ERR;
}

static uint8_t handle_factory_b6(const app_proto_v2_frame_t *f)
{
    system_param_t c = *param_get();

    if (f->len != PARAM_FACTORY_CMD_B6_LEN) {
        return APP_ST_LEN_ERR;
    }
    store_factory_raw(&c, FACTORY_SLOT_B6, f->payload, f->len);
    c.left_turn_signal.module_id = le16(&f->payload[0]);
    c.left_turn_signal.group_no = f->payload[2];
    c.left_turn_signal.bit_no = f->payload[3];
    c.left_turn_signal.active_value = f->payload[4] & 0x01U;
    c.right_turn_signal.module_id = c.left_turn_signal.module_id;
    c.right_turn_signal.group_no = f->payload[5];
    c.right_turn_signal.bit_no = f->payload[6];
    c.right_turn_signal.active_value = f->payload[7] & 0x01U;
    c.hazard_signal.module_id = le16(&f->payload[8]);
    c.hazard_signal.group_no = f->payload[10];
    c.hazard_signal.bit_no = f->payload[11];
    c.hazard_signal.active_value = f->payload[12] & 0x01U;
    return param_commit(&c) ? APP_ST_OK : APP_ST_PARAM_ERR;
}

static uint8_t handle_factory_b7(const app_proto_v2_frame_t *f)
{
    system_param_t c = *param_get();

    if (f->len != PARAM_FACTORY_CMD_B7_LEN) {
        return APP_ST_LEN_ERR;
    }
    store_factory_raw(&c, FACTORY_SLOT_B7, f->payload, f->len);
    c.brake_signal.module_id = le16(&f->payload[0]);
    c.brake_signal.group_no = f->payload[2];
    c.brake_signal.bit_no = f->payload[3];
    c.brake_signal.active_value = f->payload[4] & 0x01U;
    c.unlock_signal.module_id = le16(&f->payload[5]);
    c.unlock_signal.group_no = f->payload[7];
    c.unlock_signal.bit_no = f->payload[8];
    c.unlock_signal.active_value = f->payload[9] & 0x01U;
    c.speed_signal.module_id = le16(&f->payload[10]);
    c.speed_signal.hi_group_no = f->payload[12];
    c.speed_signal.lo_group_no = f->payload[13];
    return param_commit(&c) ? APP_ST_OK : APP_ST_PARAM_ERR;
}

static uint8_t handle_factory_b8(const app_proto_v2_frame_t *f)
{
    system_param_t c = *param_get();

    if (f->len != PARAM_FACTORY_CMD_B8_LEN) {
        return APP_ST_LEN_ERR;
    }
    store_factory_raw(&c, FACTORY_SLOT_B8, f->payload, f->len);
    c.activated = (f->payload[0] != 0U);
    c.area_code[0] = f->payload[1];
    c.area_code[1] = f->payload[2];
    c.area_code[2] = f->payload[3];
    c.unactivated_use_count = f->payload[4];
    c.can_baud_code = f->payload[5];
    c.led_count = f->payload[6];
    c.hand_drive = (f->payload[7] != 0U) ? HAND_DRIVE_RIGHT : HAND_DRIVE_LEFT;
    c.sound_enable = (f->payload[8] != 0U);
    c.voice_language = voice_lang_from_proto(f->payload[9]);
    c.main_switch_enable = (f->payload[10] != 0U);
    c.anti_pinch_level = f->payload[11];
    c.anti_pinch_enable = (c.anti_pinch_level != 0U);
    return param_commit(&c) ? APP_ST_OK : APP_ST_PARAM_ERR;
}

static uint8_t handle_factory_b9(const app_proto_v2_frame_t *f)
{
    system_param_t c = *param_get();
    uint16_t lv[8];
    uint32_t i;

    if (f->len != PARAM_FACTORY_CMD_B9_LEN) {
        return APP_ST_LEN_ERR;
    }
    store_factory_raw(&c, FACTORY_SLOT_B9, f->payload, f->len);

    for (i = 0U; i < 8U; ++i) {
        lv[i] = scale_factory_threshold_u16(le16(&f->payload[i * 2U]));
        if ((i > 0U) && (lv[i] <= lv[i - 1U])) {
            lv[i] = (uint16_t)(lv[i - 1U] + 10U);
        }
    }

    c.adc_left_antipinch_th_lv1 = lv[0];
    c.adc_left_antipinch_th_lv2 = lv[1];
    c.adc_left_antipinch_th_lv3 = lv[2];
    c.adc_left_antipinch_th_lv4 = lv[3];
    c.adc_left_antipinch_th_lv5 = lv[4];
    c.adc_left_antipinch_th_lv6 = lv[5];
    c.adc_left_antipinch_th_lv7 = lv[6];
    c.adc_left_antipinch_th_lv8 = lv[7];
    c.adc_right_antipinch_th_lv1 = lv[0];
    c.adc_right_antipinch_th_lv2 = lv[1];
    c.adc_right_antipinch_th_lv3 = lv[2];
    c.adc_right_antipinch_th_lv4 = lv[3];
    c.adc_right_antipinch_th_lv5 = lv[4];
    c.adc_right_antipinch_th_lv6 = lv[5];
    c.adc_right_antipinch_th_lv7 = lv[6];
    c.adc_right_antipinch_th_lv8 = lv[7];
    if (c.adc_left_overcurrent_th <= lv[7]) c.adc_left_overcurrent_th = (uint16_t)(lv[7] + 200U);
    if (c.adc_right_overcurrent_th <= lv[7]) c.adc_right_overcurrent_th = (uint16_t)(lv[7] + 200U);
    c.wash_hold_seconds = le16(&f->payload[16]);
    c.welcome_hold_seconds = f->payload[18];
    c.welcome_start_interval_s = le16(&f->payload[19]);
    c.welcome_mode = (f->payload[21] != 0U) ? WELCOME_BOTH_SIDES : WELCOME_DRIVER_ONLY;
    return param_commit(&c) ? APP_ST_OK : APP_ST_PARAM_ERR;
}

static uint8_t build_param_value(uint16_t param_id, uint8_t *data_type, uint8_t *out)
{
    const system_param_t *p = param_get();
    const light_scene_cfg_t *scene;

    if ((data_type == 0) || (out == 0)) {
        return 0U;
    }

    switch (param_id) {
        case APP_PARAM_ACTIVATED: *data_type = APP_DT_BOOL; out[0] = p->activated ? 1U : 0U; return 1U;
        case APP_PARAM_REGION_CODE: *data_type = APP_DT_BYTES; (void)memcpy(out, p->area_code, 3U); return 3U;
        case APP_PARAM_MAIN_SWITCH: *data_type = APP_DT_BOOL; out[0] = p->main_switch_enable ? 1U : 0U; return 1U;
        case APP_PARAM_WASH_ENABLE: *data_type = APP_DT_BOOL; out[0] = p->wash_function_switch; return 1U;
        case APP_PARAM_WASH_HOLD_S: *data_type = APP_DT_UINT16; put_le16(out, p->wash_hold_seconds); return 2U;
        case APP_PARAM_WELCOME_ENABLE: *data_type = APP_DT_BOOL; out[0] = p->welcome_enable ? 1U : 0U; return 1U;
        case APP_PARAM_WELCOME_DELAY_S: *data_type = APP_DT_UINT8; out[0] = (uint8_t)p->welcome_hold_seconds; return 1U;
        case APP_PARAM_ANTIPINCH_ENABLE: *data_type = APP_DT_BOOL; out[0] = p->anti_pinch_enable ? 1U : 0U; return 1U;
        case APP_PARAM_ANTIPINCH_LEVEL: *data_type = APP_DT_UINT8; out[0] = p->anti_pinch_level; return 1U;
        case APP_PARAM_STEERING_TYPE: *data_type = APP_DT_ENUM8; out[0] = (p->hand_drive == HAND_DRIVE_RIGHT) ? 1U : 0U; return 1U;
        case APP_PARAM_SOUND_ENABLE: *data_type = APP_DT_BOOL; out[0] = p->sound_enable ? 1U : 0U; return 1U;
        case APP_PARAM_VOICE_LANGUAGE: *data_type = APP_DT_ENUM8; out[0] = voice_lang_to_proto(p->voice_language); return 1U;
        case APP_PARAM_MOTOR_REVERSE_BITS: *data_type = APP_DT_UINT8; out[0] = (p->motor_left_reverse ? 1U : 0U) | ((p->motor_right_reverse ? 1U : 0U) << 1); return 1U;
        case APP_PARAM_REAR_DOOR_REVERSE: *data_type = APP_DT_BOOL; out[0] = p->rear_door_reverse ? 1U : 0U; return 1U;
        case APP_PARAM_LEFT_RIGHT_SWAP: *data_type = APP_DT_BOOL; out[0] = p->left_right_swap ? 1U : 0U; return 1U;
        case APP_PARAM_UNLOCK_MODE: *data_type = APP_DT_ENUM8; out[0] = (uint8_t)p->welcome_mode; return 1U;
        case APP_PARAM_MAGNETIC_MODE: *data_type = APP_DT_BOOL; out[0] = p->magnetic_mode ? 1U : 0U; return 1U;
        case APP_PARAM_STRIP_TYPE: *data_type = APP_DT_UINT8; out[0] = p->light_strip_type; return 1U;
        case APP_PARAM_BRIGHTNESS: *data_type = APP_DT_UINT8; out[0] = p->light_brightness; return 1U;
        case APP_PARAM_LIGHT_WELCOME:
        case APP_PARAM_LIGHT_DRIVE:
        case APP_PARAM_LIGHT_TURN:
        case APP_PARAM_LIGHT_BRAKE:
            *data_type = APP_DT_BYTES;
            scene = resolve_scene_cfg_const(p,
                (param_id == APP_PARAM_LIGHT_WELCOME) ? 0U :
                (param_id == APP_PARAM_LIGHT_DRIVE) ? 1U :
                (param_id == APP_PARAM_LIGHT_TURN) ? 2U : 3U);
            if (scene == 0) return 0U;
            out[0] = scene->r; out[1] = scene->g; out[2] = scene->b; out[3] = scene->mode; out[4] = p->light_brightness; return 5U;
        case APP_PARAM_LIGHT_AUTO_DRIVE: *data_type = APP_DT_BOOL; out[0] = p->auto_drive_blue ? 1U : 0U; return 1U;
        case APP_PARAM_VEHICLE_TYPE: *data_type = APP_DT_UINT8; out[0] = p->vehicle_type; return 1U;
        case APP_PARAM_VEHICLE_ID: *data_type = APP_DT_UINT32; put_le32(out, p->vehicle_id); return 4U;
        case APP_PARAM_VEHICLE_CODE: *data_type = APP_DT_ASCII; (void)memcpy(out, p->vehicle_code_ascii, 16U); return 16U;
        case APP_PARAM_VEHICLE_CFG_VER: *data_type = APP_DT_UINT8; out[0] = p->vehicle_config_ver; return 1U;
        case APP_PARAM_DOOR_MODULE_ID: *data_type = APP_DT_UINT16; put_le16(out, p->door_signal[DOOR_POS_FL].module_id); return 2U;
        case APP_PARAM_DOOR_MAP_FL: *data_type = APP_DT_BYTES; out[0] = p->door_signal[DOOR_POS_FL].group_no; out[1] = p->door_signal[DOOR_POS_FL].bit_no; out[2] = p->door_signal[DOOR_POS_FL].active_value; return 3U;
        case APP_PARAM_DOOR_MAP_RL: *data_type = APP_DT_BYTES; out[0] = p->door_signal[DOOR_POS_RL].group_no; out[1] = p->door_signal[DOOR_POS_RL].bit_no; out[2] = p->door_signal[DOOR_POS_RL].active_value; return 3U;
        case APP_PARAM_DOOR_MAP_FR: *data_type = APP_DT_BYTES; out[0] = p->door_signal[DOOR_POS_FR].group_no; out[1] = p->door_signal[DOOR_POS_FR].bit_no; out[2] = p->door_signal[DOOR_POS_FR].active_value; return 3U;
        case APP_PARAM_DOOR_MAP_RR: *data_type = APP_DT_BYTES; out[0] = p->door_signal[DOOR_POS_RR].group_no; out[1] = p->door_signal[DOOR_POS_RR].bit_no; out[2] = p->door_signal[DOOR_POS_RR].active_value; return 3U;
        case APP_PARAM_LOGO_ID: *data_type = APP_DT_UINT16; put_le16(out, p->logo_id); return 2U;
        case APP_PARAM_CUSTOMER_ID: *data_type = APP_DT_UINT16; put_le16(out, p->customer_id); return 2U;
        default: return 0U;
    }
}

static uint8_t set_param_value(uint16_t param_id, const uint8_t *val, uint16_t len)
{
    system_param_t c = *param_get();
    light_scene_cfg_t *scene;
    if (val == 0) return APP_ST_PARAM_ERR;
    switch (param_id) {
        case APP_PARAM_ACTIVATED: if (len != 1U) return APP_ST_PARAM_ERR; c.activated = (val[0] != 0U); break;
        case APP_PARAM_REGION_CODE: if (len != 3U) return APP_ST_PARAM_ERR; (void)memcpy(c.area_code, val, 3U); break;
        case APP_PARAM_MAIN_SWITCH: if (len != 1U) return APP_ST_PARAM_ERR; c.main_switch_enable = (val[0] != 0U); break;
        case APP_PARAM_WASH_ENABLE: if (len != 1U) return APP_ST_PARAM_ERR; c.wash_function_switch = (val[0] != 0U) ? 1U : 0U; break;
        case APP_PARAM_WASH_HOLD_S: if (len != 2U) return APP_ST_PARAM_ERR; c.wash_hold_seconds = le16(val); break;
        case APP_PARAM_WELCOME_ENABLE: if (len != 1U) return APP_ST_PARAM_ERR; c.welcome_enable = (val[0] != 0U); break;
        case APP_PARAM_WELCOME_DELAY_S: if (len != 1U) return APP_ST_PARAM_ERR; c.welcome_hold_seconds = val[0]; break;
        case APP_PARAM_ANTIPINCH_ENABLE: if (len != 1U) return APP_ST_PARAM_ERR; c.anti_pinch_enable = (val[0] != 0U); break;
        case APP_PARAM_ANTIPINCH_LEVEL: if (len != 1U) return APP_ST_PARAM_ERR; c.anti_pinch_level = val[0]; break;
        case APP_PARAM_STEERING_TYPE: if (len != 1U) return APP_ST_PARAM_ERR; c.hand_drive = (val[0] != 0U) ? HAND_DRIVE_RIGHT : HAND_DRIVE_LEFT; break;
        case APP_PARAM_SOUND_ENABLE: if (len != 1U) return APP_ST_PARAM_ERR; c.sound_enable = (val[0] != 0U); break;
        case APP_PARAM_VOICE_LANGUAGE: if (len != 1U) return APP_ST_PARAM_ERR; c.voice_language = voice_lang_from_proto(val[0]); break;
        case APP_PARAM_MOTOR_REVERSE_BITS: if (len != 1U) return APP_ST_PARAM_ERR; c.motor_left_reverse = ((val[0] & 0x01U) != 0U); c.motor_right_reverse = ((val[0] & 0x02U) != 0U); break;
        case APP_PARAM_REAR_DOOR_REVERSE: if (len != 1U) return APP_ST_PARAM_ERR; c.rear_door_reverse = (val[0] != 0U); break;
        case APP_PARAM_LEFT_RIGHT_SWAP: if (len != 1U) return APP_ST_PARAM_ERR; c.left_right_swap = (val[0] != 0U); break;
        case APP_PARAM_UNLOCK_MODE: if (len != 1U) return APP_ST_PARAM_ERR; c.welcome_mode = (val[0] != 0U) ? WELCOME_BOTH_SIDES : WELCOME_DRIVER_ONLY; break;
        case APP_PARAM_MAGNETIC_MODE: if (len != 1U) return APP_ST_PARAM_ERR; c.magnetic_mode = (val[0] != 0U); break;
        case APP_PARAM_STRIP_TYPE: if (len != 1U) return APP_ST_PARAM_ERR; c.light_strip_type = val[0]; break;
        case APP_PARAM_BRIGHTNESS: if (len != 1U) return APP_ST_PARAM_ERR; c.light_brightness = val[0]; break;
        case APP_PARAM_LIGHT_WELCOME:
        case APP_PARAM_LIGHT_DRIVE:
        case APP_PARAM_LIGHT_TURN:
        case APP_PARAM_LIGHT_BRAKE:
            if (len != 5U) return APP_ST_PARAM_ERR;
            scene = resolve_scene_ref(&c,
                (param_id == APP_PARAM_LIGHT_WELCOME) ? 0U :
                (param_id == APP_PARAM_LIGHT_DRIVE) ? 1U :
                (param_id == APP_PARAM_LIGHT_TURN) ? 2U : 3U).scene;
            if (scene == 0) return APP_ST_PARAM_ERR;
            scene->r = val[0]; scene->g = val[1]; scene->b = val[2]; scene->mode = val[3];
            c.light_brightness = val[4];
            c.light_alert = c.light_brake;
            break;
        case APP_PARAM_LIGHT_AUTO_DRIVE: if (len != 1U) return APP_ST_PARAM_ERR; c.auto_drive_blue = (val[0] != 0U); break;
        case APP_PARAM_VEHICLE_TYPE: if (len != 1U) return APP_ST_PARAM_ERR; c.vehicle_type = val[0]; break;
        case APP_PARAM_VEHICLE_ID: if (len != 4U) return APP_ST_PARAM_ERR; c.vehicle_id = le32(val); c.vehicle_code = c.vehicle_id; break;
        case APP_PARAM_VEHICLE_CODE: if (len != 16U) return APP_ST_PARAM_ERR; (void)memset(c.vehicle_code_ascii, 0, sizeof(c.vehicle_code_ascii)); (void)memcpy(c.vehicle_code_ascii, val, 16U); break;
        case APP_PARAM_VEHICLE_CFG_VER: if (len != 1U) return APP_ST_PARAM_ERR; c.vehicle_config_ver = val[0]; break;
        case APP_PARAM_DOOR_MODULE_ID:
            if (len != 2U) return APP_ST_PARAM_ERR;
            c.door_can_id[DOOR_POS_FL] = le16(val); c.door_signal[DOOR_POS_FL].module_id = c.door_can_id[DOOR_POS_FL];
            c.door_can_id[DOOR_POS_RL] = le16(val); c.door_signal[DOOR_POS_RL].module_id = c.door_can_id[DOOR_POS_RL];
            c.door_can_id[DOOR_POS_FR] = le16(val); c.door_signal[DOOR_POS_FR].module_id = c.door_can_id[DOOR_POS_FR];
            c.door_can_id[DOOR_POS_RR] = le16(val); c.door_signal[DOOR_POS_RR].module_id = c.door_can_id[DOOR_POS_RR];
            break;
        case APP_PARAM_DOOR_MAP_FL: if (len != 3U) return APP_ST_PARAM_ERR; c.door_signal[DOOR_POS_FL].group_no = val[0]; c.door_signal[DOOR_POS_FL].bit_no = val[1]; c.door_signal[DOOR_POS_FL].active_value = (uint8_t)(val[2] & 0x01U); break;
        case APP_PARAM_DOOR_MAP_RL: if (len != 3U) return APP_ST_PARAM_ERR; c.door_signal[DOOR_POS_RL].group_no = val[0]; c.door_signal[DOOR_POS_RL].bit_no = val[1]; c.door_signal[DOOR_POS_RL].active_value = (uint8_t)(val[2] & 0x01U); break;
        case APP_PARAM_DOOR_MAP_FR: if (len != 3U) return APP_ST_PARAM_ERR; c.door_signal[DOOR_POS_FR].group_no = val[0]; c.door_signal[DOOR_POS_FR].bit_no = val[1]; c.door_signal[DOOR_POS_FR].active_value = (uint8_t)(val[2] & 0x01U); break;
        case APP_PARAM_DOOR_MAP_RR: if (len != 3U) return APP_ST_PARAM_ERR; c.door_signal[DOOR_POS_RR].group_no = val[0]; c.door_signal[DOOR_POS_RR].bit_no = val[1]; c.door_signal[DOOR_POS_RR].active_value = (uint8_t)(val[2] & 0x01U); break;
        case APP_PARAM_LOGO_ID: if (len != 2U) return APP_ST_PARAM_ERR; c.logo_id = le16(val); break;
        case APP_PARAM_CUSTOMER_ID: if (len != 2U) return APP_ST_PARAM_ERR; c.customer_id = le16(val); break;
        default: return APP_ST_UNKNOWN_CMD;
    }
    return param_commit(&c) ? APP_ST_OK : APP_ST_PARAM_ERR;
}

static void fill_query_common(const app_proto_v2_frame_t *f, app_cmd_reply_t *reply)
{
    const system_param_t *p = param_get();
    policy_status_t st = policy_get_status();
    const light_scene_cfg_t *scene;
    ota_service_status_t ost;

    switch (f->cmd) {
        case APP_CMD_Q_ACT:
            reply->payload[0] = p->activated ? 1U : 0U;
            (void)memcpy(&reply->payload[1], p->area_code, 3U);
            reply->len = 4U;
            reply->status = APP_ST_OK;
            return;
        case APP_CMD_Q_SWITCH:
            reply->payload[0] = p->main_switch_enable ? 1U : 0U;
            reply->payload[1] = (st.mode == SYS_WASH) ? 1U : 0U;
            put_le16(&reply->payload[2], p->wash_hold_seconds);
            reply->payload[4] = p->physical_switch_state;
            reply->len = 5U;
            reply->status = APP_ST_OK;
            return;
        case APP_CMD_Q_FEAT:
            reply->payload[0] = p->welcome_enable ? 1U : 0U;
            reply->payload[1] = (uint8_t)p->welcome_hold_seconds;
            reply->payload[2] = p->anti_pinch_enable ? 1U : 0U;
            reply->payload[3] = p->anti_pinch_level;
            reply->payload[4] = (p->hand_drive == HAND_DRIVE_RIGHT) ? 1U : 0U;
            reply->payload[5] = p->sound_enable ? 1U : 0U;
            reply->payload[6] = voice_lang_to_proto(p->voice_language);
            reply->payload[7] = (p->motor_left_reverse ? 1U : 0U) | ((p->motor_right_reverse ? 1U : 0U) << 1);
            reply->payload[8] = p->rear_door_reverse ? 1U : 0U;
            reply->payload[9] = p->left_right_swap ? 1U : 0U;
            reply->payload[10] = (uint8_t)p->welcome_mode;
            reply->payload[11] = p->magnetic_mode ? 1U : 0U;
            reply->payload[12] = 0U;
            reply->len = 13U;
            reply->status = APP_ST_OK;
            return;
        case APP_CMD_Q_LIGHT:
            if (f->len < 1U) {
                reply->status = APP_ST_LEN_ERR;
                reply->len = 0U;
                return;
            }
            scene = resolve_scene_cfg_const(p, f->payload[0]);
            if (scene == 0) {
                reply->status = APP_ST_PARAM_ERR;
                reply->len = 0U;
                return;
            }
            reply->payload[0] = f->payload[0];
            reply->payload[1] = scene->r;
            reply->payload[2] = scene->g;
            reply->payload[3] = scene->b;
            reply->payload[4] = scene->mode;
            reply->payload[5] = p->light_brightness;
            reply->payload[6] = p->light_strip_type;
            reply->payload[7] = p->auto_drive_blue ? 1U : 0U;
            reply->len = 8U;
            reply->status = APP_ST_OK;
            return;
        case APP_CMD_Q_STATS1:
            put_le16(&reply->payload[0], (uint16_t)st.left_run_count);
            put_le16(&reply->payload[2], (uint16_t)st.right_run_count);
            put_le16(&reply->payload[4], (uint16_t)st.left_antipinch_count);
            put_le16(&reply->payload[6], (uint16_t)st.right_antipinch_count);
            reply->len = 8U;
            reply->status = APP_ST_OK;
            return;
        case APP_CMD_Q_STATUS:
            reply->payload[0] = (st.door_open[DOOR_POS_FL] ? 1U : 0U) |
                                ((st.door_open[DOOR_POS_RL] ? 1U : 0U) << 1) |
                                ((st.door_open[DOOR_POS_FR] ? 1U : 0U) << 2) |
                                ((st.door_open[DOOR_POS_RR] ? 1U : 0U) << 3);
            reply->payload[1] = (policy_get_step_status_code(STEP_SIDE_LEFT) == 62U ? 1U : 0U); /* 后续会被覆盖 */
            reply->payload[1] = (st.left_state == STEP_STATE_EXTENDED ? 1U : 0U) |
                                ((st.right_state == STEP_STATE_EXTENDED ? 1U : 0U) << 1) |
                                ((p->main_switch_enable ? 1U : 0U) << 2) |
                                (((st.mode == SYS_WASH) ? 1U : 0U) << 3) |
                                (((st.mode == SYS_INSTALL_TEST) ? 1U : 0U) << 4) |
                                ((st.key_unlocked ? 1U : 0U) << 5) |
                                (((!p->main_switch_enable) ? 1U : 0U) << 6) |
                                ((p->physical_switch_state ? 1U : 0U) << 7);
            reply->payload[2] = (st.can_signal_valid ? 1U : 0U) |
                                ((vehicle_profile_loaded(p) ? 1U : 0U) << 1) |
                                ((s_link_active ? 1U : 0U) << 2) |
                                ((p->magnetic_mode ? 1U : 0U) << 3) |
                                ((p->anti_pinch_enable ? 1U : 0U) << 4) |
                                ((fault_has_critical() ? 1U : 0U) << 5) |
                                (((st.mode == SYS_OTA) ? 1U : 0U) << 6);
            reply->payload[3] = policy_get_step_status_code(STEP_SIDE_LEFT);
            reply->payload[4] = policy_get_step_status_code(STEP_SIDE_RIGHT);
            reply->payload[5] = 0U;
            reply->payload[6] = 0U;
            reply->len = 7U;
            reply->status = APP_ST_OK;
            return;
        case APP_CMD_Q_DEVINFO:
            (void)memcpy(&reply->payload[0], p->serial_ascii, 12U);
            put_le32(&reply->payload[12], build_version_u32(p->sw_version_major, p->sw_version_minor, p->sw_version_patch));
            put_le32(&reply->payload[16], 0U);
            reply->len = 20U;
            reply->status = APP_ST_OK;
            return;
        case APP_CMD_Q_EXTINFO:
            put_le16(&reply->payload[0], p->logo_id);
            put_le16(&reply->payload[2], p->customer_id);
            reply->payload[4] = p->password_enable ? 1U : 0U;
            reply->payload[5] = build_feature_flags(p);
            reply->len = 6U;
            reply->status = APP_ST_OK;
            return;
        case APP_CMD_Q_OTA:
            ota_service_get_status(&ost);
            reply->payload[0] = ost.supported ? 1U : 0U;
            reply->payload[1] = ost.upgrade_available ? 1U : 0U;
            put_le32(&reply->payload[2], ost.target_ver);
            reply->payload[6] = (uint8_t)ost.stage;
            reply->len = 7U;
            reply->status = APP_ST_OK;
            return;
        default:
            reply->status = APP_ST_UNKNOWN_CMD;
            reply->len = 0U;
            return;
    }
}

void app_cmd_dispatch_init(void)
{
    s_link_active = false;
    s_unsupported_cmd_count = 0U;
}

void app_cmd_dispatch_set_link_active(bool active)
{
    s_link_active = active;
}

uint32_t app_cmd_dispatch_get_unsupported_count(void)
{
    return s_unsupported_cmd_count;
}

void app_cmd_dispatch_process(const app_proto_v2_frame_t *f, app_cmd_reply_t *reply)
{
    uint16_t pid;
    uint16_t vlen;
    uint8_t dtype;
    system_param_t c;

    if ((f == 0) || (reply == 0)) {
        return;
    }

    (void)memset(reply, 0, sizeof(*reply));
    reply->send_reply = true;
    reply->status = APP_ST_OK;

    if (ota_service_is_busy()) {
        switch (f->cmd)
        {
            case APP_CMD_HANDSHAKE:
            case APP_CMD_Q_OTA:
            case APP_CMD_EVT_ACK:
            case APP_CMD_OTA_C2:
            case APP_CMD_OTA_C3:
            case APP_CMD_OTA_C4:
            case APP_CMD_OTA_C5:
                break;
            default:
                reply->status = APP_ST_BUSY;
                return;
        }
    }

    switch (f->cmd) {
        case APP_CMD_HANDSHAKE:
            reply->payload[0] = 1U;
            reply->payload[1] = 0U;
            (void)memcpy(&reply->payload[2], &param_get()->serial_ascii[8], 4U);
            reply->payload[6] = build_feature_flags(param_get());
            reply->len = 7U;
            break;
        case APP_CMD_PWD_CHECK:
            reply->status = pwd_check(f->payload, f->len);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 1U;
            break;
        case APP_CMD_PWD_SET:
            if (f->len != 12U) {
                reply->status = APP_ST_LEN_ERR;
            } else if (pwd_check(f->payload, 6U) != APP_ST_OK) {
                reply->status = APP_ST_PWD_ERR;
            } else if (!pwd_is_digits6(&f->payload[6])) {
                reply->status = APP_ST_PWD_FMT_ERR;
            } else {
                c = *param_get();
                (void)memcpy(c.password_ascii, &f->payload[6], 6U);
                c.password_ascii[6] = '\0';
                c.password_enable = true;
                reply->status = param_commit(&c) ? APP_ST_OK : APP_ST_SAVE_FAIL;
                reply->payload[0] = 0U;
                reply->len = 1U;
            }
            break;
        case APP_CMD_ACTIVATE:
            if (f->len != 4U) {
                reply->status = APP_ST_LEN_ERR;
            } else {
                c = *param_get();
                c.activated = (f->payload[0] != 0U);
                (void)memcpy(c.area_code, &f->payload[1], 3U);
                reply->status = param_commit(&c) ? APP_ST_OK : APP_ST_PARAM_ERR;
                reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
                reply->len = 1U;
                if (reply->status == APP_ST_OK) {
                    (void)event_report_service_enqueue_code(APP_EVENT_SETUP_DONE, 0, 0U);
                }
            }
            break;
        case APP_CMD_SWITCH:
            reply->status = handle_cmd_switch(f);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 1U;
            if (reply->status == APP_ST_OK) {
                (void)event_report_service_enqueue_code(APP_EVENT_SETUP_DONE, 0, 0U);
            }
            break;
        case APP_CMD_FEATURE:
            reply->status = handle_cmd_feature(f);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 1U;
            if (reply->status == APP_ST_OK) {
                (void)event_report_service_enqueue_code(APP_EVENT_SETUP_DONE, 0, 0U);
            }
            break;
        case APP_CMD_LIGHT:
            reply->status = handle_cmd_light(f);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 1U;
            if (reply->status == APP_ST_OK) {
                (void)event_report_service_enqueue_code(APP_EVENT_LIGHT_SET_OK, 0, 0U);
            }
            break;
        case APP_CMD_INSTALL:
            reply->status = handle_cmd_install(f);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 1U;
            break;
        case APP_CMD_VEHICLE:
            reply->status = handle_cmd_vehicle(f);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 1U;
            if (reply->status == APP_ST_OK) {
                (void)event_report_service_enqueue_code(APP_EVENT_SETUP_DONE, 0, 0U);
            }
            break;
        case APP_CMD_PARAM_R:
            if (f->len < 3U) {
                reply->status = APP_ST_LEN_ERR;
                break;
            }
            pid = le16(&f->payload[0]);
            dtype = 0U;
            vlen = build_param_value(pid, &dtype, &reply->payload[5]);
            if (vlen == 0U) {
                reply->status = APP_ST_PARAM_ERR;
                break;
            }
            put_le16(&reply->payload[0], pid);
            reply->payload[2] = dtype;
            put_le16(&reply->payload[3], vlen);
            reply->len = (uint8_t)(5U + vlen);
            break;
        case APP_CMD_PARAM_W:
            if (f->len < 5U) {
                reply->status = APP_ST_LEN_ERR;
                break;
            }
            pid = le16(&f->payload[0]);
            vlen = le16(&f->payload[3]);
            if ((uint16_t)(5U + vlen) != f->len) {
                reply->status = APP_ST_LEN_ERR;
                break;
            }
            reply->status = set_param_value(pid, &f->payload[5], vlen);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 1U;
            if (reply->status == APP_ST_OK) {
                (void)event_report_service_enqueue_code(APP_EVENT_SETUP_DONE, 0, 0U);
            }
            break;
        case APP_CMD_Q_ACT:
        case APP_CMD_Q_SWITCH:
        case APP_CMD_Q_FEAT:
        case APP_CMD_Q_LIGHT:
        case APP_CMD_Q_STATS1:
        case APP_CMD_Q_STATUS:
        case APP_CMD_Q_DEVINFO:
        case APP_CMD_Q_EXTINFO:
        case APP_CMD_Q_OTA:
            fill_query_common(f, reply);
            break;
        case APP_CMD_EVT_ACK:
            if (f->len >= 3U) {
                event_report_service_handle_ack(f->payload[0], f->payload[1], f->payload[2]);
            }
            reply->send_reply = false;
            break;
        case APP_CMD_FACTORY_B1:
            reply->status = handle_factory_b1_b2(f, FACTORY_SLOT_B1, DOOR_POS_FL, DOOR_POS_RL);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 1U;
            if (reply->status == APP_ST_OK) { (void)event_report_service_enqueue_code(APP_EVENT_SETUP_DONE, 0, 0U); }
            break;
        case APP_CMD_FACTORY_B2:
            reply->status = handle_factory_b1_b2(f, FACTORY_SLOT_B2, DOOR_POS_FR, DOOR_POS_RR);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 1U;
            if (reply->status == APP_ST_OK) { (void)event_report_service_enqueue_code(APP_EVENT_SETUP_DONE, 0, 0U); }
            break;
        case APP_CMD_FACTORY_B3:
        case APP_CMD_FACTORY_B4:
            reply->status = APP_ST_NOT_ALLOWED;
            break;
        case APP_CMD_FACTORY_B5:
            reply->status = handle_factory_b5(f);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 1U;
            if (reply->status == APP_ST_OK) { (void)event_report_service_enqueue_code(APP_EVENT_SETUP_DONE, 0, 0U); }
            break;
        case APP_CMD_FACTORY_B6:
            reply->status = handle_factory_b6(f);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 1U;
            if (reply->status == APP_ST_OK) { (void)event_report_service_enqueue_code(APP_EVENT_SETUP_DONE, 0, 0U); }
            break;
        case APP_CMD_FACTORY_B7:
            reply->status = handle_factory_b7(f);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 1U;
            if (reply->status == APP_ST_OK) { (void)event_report_service_enqueue_code(APP_EVENT_SETUP_DONE, 0, 0U); }
            break;
        case APP_CMD_FACTORY_B8:
            reply->status = handle_factory_b8(f);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 1U;
            if (reply->status == APP_ST_OK) { (void)event_report_service_enqueue_code(APP_EVENT_SETUP_DONE, 0, 0U); }
            break;
        case APP_CMD_FACTORY_B9:
            reply->status = handle_factory_b9(f);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 1U;
            if (reply->status == APP_ST_OK) { (void)event_report_service_enqueue_code(APP_EVENT_SETUP_DONE, 0, 0U); }
            break;
        case APP_CMD_OTA_C1:
        {
            uint8_t boot_state = 0U;
            if (f->len != 9U) {
                reply->status = APP_ST_LEN_ERR;
                break;
            }
            if (f->payload[0] != 0x01U) {
                reply->status = APP_ST_PARAM_ERR;
                break;
            }
            reply->status = ota_service_begin(le32(&f->payload[1]), le32(&f->payload[5]), &boot_state);
            reply->payload[0] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->payload[1] = boot_state;
            reply->len = 2U;
            if (reply->status == APP_ST_OK) {
                post_event_simple(EV_ENTER_OTA);
            }
            break;
        }
        case APP_CMD_OTA_C2:
        {
            uint16_t block_index;
            uint16_t data_len;
            uint16_t echo_block_index = 0U;
            if (f->len < 10U) {
                reply->status = APP_ST_LEN_ERR;
                break;
            }
            block_index = le16(&f->payload[0]);
            data_len = le16(&f->payload[6]);
            if (data_len > APP_OTA_C2_DATA_MAX) {
                reply->status = APP_ST_LEN_ERR;
                break;
            }
            if ((uint16_t)(10U + data_len) != f->len) {
                reply->status = APP_ST_LEN_ERR;
                break;
            }
            reply->status = ota_service_write_block(block_index,
                                                    le32(&f->payload[2]),
                                                    &f->payload[10],
                                                    data_len,
                                                    le16(&f->payload[8]),
                                                    &echo_block_index);
            put_le16(&reply->payload[0], echo_block_index);
            reply->payload[2] = (reply->status == APP_ST_OK) ? 0U : 1U;
            reply->len = 3U;
            break;
        }
        case APP_CMD_OTA_C3:
        {
            uint8_t verify_result = 1U;
            uint8_t next_action = 1U;
            if (f->len != 10U) {
                reply->status = APP_ST_LEN_ERR;
                break;
            }
            reply->status = ota_service_finish(le32(&f->payload[0]), le32(&f->payload[4]), le16(&f->payload[8]), &verify_result, &next_action);
            reply->payload[0] = verify_result;
            reply->payload[1] = next_action;
            reply->len = 2U;
            break;
        }
        case APP_CMD_OTA_C4:
        {
            uint8_t result = 1U;
            if (f->len != 1U) {
                reply->status = APP_ST_LEN_ERR;
                break;
            }
            reply->status = ota_service_activate(f->payload[0], &result);
            reply->payload[0] = result;
            reply->len = 1U;
            if (reply->status == APP_ST_OK) {
                reply->reboot_after_reply = true;
                post_event_simple(EV_OTA_FINISH);
            }
            break;
        }
        case APP_CMD_OTA_C5:
        {
            ota_service_status_t ost;
            if ((f->len != 0U) && (f->len != 1U)) {
                reply->status = APP_ST_LEN_ERR;
                break;
            }
            ota_service_get_status(&ost);
            reply->payload[0] = (uint8_t)ost.stage;
            put_le16(&reply->payload[1], ost.received_blocks);
            put_le16(&reply->payload[3], ost.total_blocks);
            reply->payload[5] = ost.last_error;
            reply->len = 6U;
            break;
        }
        default:
            s_unsupported_cmd_count++;
            reply->status = APP_ST_UNKNOWN_CMD;
            break;
    }
}
