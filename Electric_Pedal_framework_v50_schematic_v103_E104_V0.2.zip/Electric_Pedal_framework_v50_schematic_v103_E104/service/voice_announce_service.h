#ifndef SERVICE_VOICE_ANNOUNCE_SERVICE_H
#define SERVICE_VOICE_ANNOUNCE_SERVICE_H

/*
 * 语音播报服务接口：把故障和模式事件转换为业务语音，并控制播报节奏。
 */
#include "event.h"

void voice_announce_service_init(void);
void voice_announce_service_tick_10ms(void);
void voice_announce_service_on_event(const event_t *ev);

#endif
