#include "can_if.h"
#include "param.h"
#include "fault.h"
#include "bsp_can.h"
#include "event_flags.h"
#include <string.h>

/*
 * CAN 信号服务：解析车门、车速、灯光等整车信号，并维护信号有效/超时状态。
 * 掉电恢复逻辑会依赖这里的有效位，避免刚上电时使用尚未稳定的 CAN 状态。
 */
#define CAN_IF_QUEUE_SIZE     32U
#define CAN_ID_AUTO_DRIVE     0x123U

static can_frame_t s_queue[CAN_IF_QUEUE_SIZE];
static volatile uint16_t s_head = 0U;
static volatile uint16_t s_tail = 0U;
static bool s_signal_valid = false;
static uint16_t s_silent_ms = 0U;
static bool s_speed_above_8 = false;
static bool s_unlock_active = false;
static bool s_turn_left_raw = false;
static bool s_turn_right_raw = false;
static bool s_hazard_raw = false;
static bool s_turn_left = false;
static bool s_turn_right = false;
static bool s_brake = false;
static bool s_headlamp = false;
static bool s_auto_drive = false;
static uint8_t s_door_open[DOOR_POS_MAX] = {0U, 0U, 0U, 0U};

static uint16_t next_idx(uint16_t idx)
{
    return (uint16_t)((idx + 1U) % CAN_IF_QUEUE_SIZE);
}

static bool signal_matches_frame(const signal_trigger_t *sig, const can_frame_t *frm)
{
    return ((sig != 0) && (frm != 0) && (sig->module_id != 0U) && (frm->id == sig->module_id));
}

static bool signal_value_active(const signal_trigger_t *sig, const can_frame_t *frm)
{
    uint8_t group_val;
    uint8_t bit_val;

    if ((sig == 0) || (frm == 0) || (sig->group_no >= frm->dlc) || (sig->bit_no >= 8U)) {
        return false;
    }

    group_val = frm->data[sig->group_no];
    bit_val = (uint8_t)((group_val >> sig->bit_no) & 0x01U);
    return (bit_val == sig->active_value);
}

static bool speed_matches_frame(const speed_signal_cfg_t *sig, const can_frame_t *frm)
{
    return ((sig != 0) && (frm != 0) && (sig->module_id != 0U) && (frm->id == sig->module_id));
}

static uint16_t speed_value_from_frame(const speed_signal_cfg_t *sig, const can_frame_t *frm)
{
    uint8_t hi;
    uint8_t lo;

    if ((sig == 0) || (frm == 0)) {
        return 0U;
    }

    if ((sig->hi_group_no >= frm->dlc) || (sig->lo_group_no >= frm->dlc)) {
        return 0U;
    }

    hi = frm->data[sig->hi_group_no];
    lo = frm->data[sig->lo_group_no];
    if (sig->hi_group_no == sig->lo_group_no) {
        return lo;
    }

    return (uint16_t)(((uint16_t)hi << 8) | lo);
}

static bool update_door_state(door_pos_t pos, bool open_now)
{
    if (pos >= DOOR_POS_MAX) {
        return false;
    }

    if (s_door_open[pos] == (uint8_t)open_now) {
        return false;
    }

    s_door_open[pos] = (uint8_t)open_now;
    return true;
}

static bool update_bool_state(bool *state, bool new_value)
{
    if (state == 0) {
        return false;
    }

    if (*state == new_value) {
        return false;
    }

    *state = new_value;
    return true;
}

static bool refresh_turn_state(void)
{
    bool left_now = (s_turn_left_raw || s_hazard_raw);
    bool right_now = (s_turn_right_raw || s_hazard_raw);
    bool changed = false;

    if (update_bool_state(&s_turn_left, left_now)) {
        changed = true;
    }
    if (update_bool_state(&s_turn_right, right_now)) {
        changed = true;
    }
    return changed;
}

static void note_state_dirty_if_needed(bool dirty)
{
    if (dirty) {
        event_flags_mark(EVENT_FLAG_CAN_STATE_DIRTY);
    }
}

static void handle_frame(const can_frame_t *frm)
{
    const system_param_t *param;
    uint32_t i;
    bool handled = false;
    bool active;
    uint16_t speed_value;
    bool dirty = false;

    if (frm == 0) {
        return;
    }

    s_silent_ms = 0U;
    if (!s_signal_valid) {
        s_signal_valid = true;
        fault_clear(FAULT_CAN_TIMEOUT);
        dirty = true;
    }

    param = param_get();

    for (i = 0U; i < (uint32_t)DOOR_POS_MAX; ++i) {
        if (signal_matches_frame(&param->door_signal[i], frm)) {
            active = signal_value_active(&param->door_signal[i], frm);
            if (update_door_state((door_pos_t)i, active)) {
                dirty = true;
            }
            handled = true;
        }
    }

    if (signal_matches_frame(&param->unlock_signal, frm)) {
        active = signal_value_active(&param->unlock_signal, frm);
        if (update_bool_state(&s_unlock_active, active)) {
            dirty = true;
        }
        handled = true;
    }

    if (signal_matches_frame(&param->headlamp_signal, frm)) {
        active = signal_value_active(&param->headlamp_signal, frm);
        if (update_bool_state(&s_headlamp, active)) {
            dirty = true;
        }
        handled = true;
    }

    if (signal_matches_frame(&param->brake_signal, frm)) {
        active = signal_value_active(&param->brake_signal, frm);
        if (update_bool_state(&s_brake, active)) {
            dirty = true;
        }
        handled = true;
    }

    if (signal_matches_frame(&param->left_turn_signal, frm)) {
        s_turn_left_raw = signal_value_active(&param->left_turn_signal, frm);
        if (refresh_turn_state()) {
            dirty = true;
        }
        handled = true;
    }

    if (signal_matches_frame(&param->right_turn_signal, frm)) {
        s_turn_right_raw = signal_value_active(&param->right_turn_signal, frm);
        if (refresh_turn_state()) {
            dirty = true;
        }
        handled = true;
    }

    if (signal_matches_frame(&param->hazard_signal, frm)) {
        s_hazard_raw = signal_value_active(&param->hazard_signal, frm);
        if (refresh_turn_state()) {
            dirty = true;
        }
        handled = true;
    }

    if (speed_matches_frame(&param->speed_signal, frm)) {
        speed_value = speed_value_from_frame(&param->speed_signal, frm);
        if (update_bool_state(&s_speed_above_8, (speed_value > 8U))) {
            dirty = true;
        }
        handled = true;
    }

    if (!handled && (frm->id == CAN_ID_AUTO_DRIVE) && (frm->dlc >= 1U)) {
        active = ((frm->data[0] & 0x01U) != 0U);
        if (update_bool_state(&s_auto_drive, active)) {
            dirty = true;
        }
    }

    note_state_dirty_if_needed(dirty);
}

void can_if_apply_monitor_from_param(void)
{
    const system_param_t *param = param_get();
    bsp_can_set_monitor_sel((bsp_can_monitor_sel_t)param->can_monitor_sel);
}

void can_if_init(void)
{
    uint32_t i;

    s_head = 0U;
    s_tail = 0U;
    s_signal_valid = false;
    s_silent_ms = 0U;
    s_speed_above_8 = false;
    s_unlock_active = false;
    s_turn_left_raw = false;
    s_turn_right_raw = false;
    s_hazard_raw = false;
    s_turn_left = false;
    s_turn_right = false;
    s_brake = false;
    s_headlamp = false;
    s_auto_drive = false;

    for (i = 0U; i < (uint32_t)DOOR_POS_MAX; ++i) {
        s_door_open[i] = 0U;
    }
    can_if_apply_monitor_from_param();
}

bool can_if_rx_isr_push(const can_frame_t *frame)
{
    uint16_t next;

    if (frame == 0) {
        return false;
    }

    next = next_idx(s_head);
    if (next == s_tail) {
        return false;
    }

    s_queue[s_head] = *frame;
    s_head = next;
    event_flags_mark_isr(EVENT_FLAG_CAN_RX_PENDING);
    return true;
}

void can_if_poll(void)
{
    can_frame_t frm;
    bsp_can_frame_t hw;

    while (bsp_can_receive(&hw)) {
        frm.id = hw.id;
        frm.dlc = hw.dlc;
        frm.is_extended = hw.is_extended;
        frm.fd_enable = hw.fd_enable;
        frm.brs_enable = hw.brs_enable;
        frm.bus = hw.bus;
        (void)memcpy(frm.data, hw.data, sizeof(frm.data));
        handle_frame(&frm);
    }

    while (s_tail != s_head)
    {
        frm = s_queue[s_tail];
        s_tail = next_idx(s_tail);
        handle_frame(&frm);
    }
}

void can_if_tick_100ms(void)
{
    const system_param_t *param;
    bool dirty = false;

    param = param_get();
    if (s_silent_ms < 0xFFF0U) {
        s_silent_ms = (uint16_t)(s_silent_ms + 100U);
    }

    if (s_signal_valid && (s_silent_ms >= param->can_timeout_ms)) {
        s_signal_valid = false;
        fault_set(FAULT_CAN_TIMEOUT);
        dirty = true;
    }

    note_state_dirty_if_needed(dirty);
}

bool can_if_signal_valid(void)
{
    return s_signal_valid;
}

void can_if_get_signal_snapshot(can_if_signal_snapshot_t *snapshot)
{
    uint32_t i;

    if (snapshot == 0) {
        return;
    }

    snapshot->signal_valid = s_signal_valid;
    snapshot->speed_above_8 = s_speed_above_8;
    snapshot->unlock_active = s_unlock_active;
    snapshot->turn_left = s_turn_left;
    snapshot->turn_right = s_turn_right;
    snapshot->brake = s_brake;
    snapshot->headlamp = s_headlamp;
    snapshot->auto_drive = s_auto_drive;

    for (i = 0U; i < (uint32_t)DOOR_POS_MAX; ++i) {
        snapshot->door_open[i] = (s_door_open[i] != 0U);
    }
}
