#include "ota_service.h"
#include "bsp_build.h"
#include "bsp_board.h"
#include "bsp_platform.h"
#include "boot_info.h"
#include "flash_layout.h"
#include <string.h>

#define OTA_META_MAGIC            0x4F544130UL
#define OTA_META_VERSION          0x0001U
#define OTA_MAX_BLOCKS            4096U
#define OTA_VERIFY_CHUNK_BYTES    256U

#if BSP_PLATFORM_GD32 && BSP_HAS_FLASH
#include "bsp_spi.h"

#define W25_CMD_WRITE_ENABLE       0x06U
#define W25_CMD_READ_STATUS1       0x05U
#define W25_CMD_READ_DATA          0x03U
#define W25_CMD_PAGE_PROGRAM       0x02U
#define W25_CMD_SECTOR_ERASE_4K    0x20U
#define W25_SR1_BUSY               0x01U
#endif

typedef struct
{
    uint32_t magic;
    uint16_t version;
    uint8_t  stage;
    uint8_t  last_error;
    uint32_t fw_size;
    uint32_t target_ver;
    uint32_t image_crc32;
    uint16_t total_blocks;
    uint16_t received_blocks;
    uint8_t  boot_pending;
    uint8_t  reserved[11];
    uint32_t meta_crc32;
} ota_meta_t;

typedef struct
{
    bool               supported;
    ota_meta_t         meta;
    uint8_t            block_bitmap[OTA_MAX_BLOCKS / 8U];
} ota_ctx_t;

static ota_ctx_t s_ota;

static uint32_t crc32_calc(const uint8_t *data, uint32_t len)
{
    uint32_t crc = 0xFFFFFFFFUL;
    uint32_t i;
    uint32_t j;
    uint32_t byte_val;

    if ((data == 0) && (len != 0U)) {
        return 0UL;
    }

    for (i = 0U; i < len; ++i) {
        byte_val = (uint32_t)data[i];
        crc ^= byte_val;
        for (j = 0U; j < 8U; ++j) {
            if ((crc & 1UL) != 0UL) {
                crc = (crc >> 1U) ^ 0xEDB88320UL;
            } else {
                crc >>= 1U;
            }
        }
    }

    return ~crc;
}

static uint16_t crc16_ibm(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFFU;
    uint16_t i;
    uint8_t bit;

    if ((data == 0) && (len != 0U)) {
        return 0U;
    }

    for (i = 0U; i < len; ++i) {
        crc ^= (uint16_t)data[i];
        for (bit = 0U; bit < 8U; ++bit) {
            if ((crc & 0x0001U) != 0U) {
                crc = (uint16_t)((crc >> 1U) ^ 0xA001U);
            } else {
                crc >>= 1U;
            }
        }
    }

    return crc;
}

static uint32_t ota_meta_crc(const ota_meta_t *meta)
{
    ota_meta_t tmp;

    if (meta == 0) {
        return 0UL;
    }

    tmp = *meta;
    tmp.meta_crc32 = 0UL;
    return crc32_calc((const uint8_t *)&tmp, (uint32_t)sizeof(tmp));
}

static bool ota_meta_valid(const ota_meta_t *meta)
{
    if (meta == 0) {
        return false;
    }

    if ((meta->magic != OTA_META_MAGIC) ||
        (meta->version != OTA_META_VERSION) ||
        (meta->stage > OTA_STAGE_FAIL)) {
        return false;
    }

    return (ota_meta_crc(meta) == meta->meta_crc32);
}

static void bitmap_clear_all(void)
{
    (void)memset(s_ota.block_bitmap, 0, sizeof(s_ota.block_bitmap));
}

static bool bitmap_mark_block(uint16_t block_index)
{
    uint16_t byte_idx;
    uint8_t mask;
    bool was_set;

    if (block_index >= OTA_MAX_BLOCKS) {
        return false;
    }

    byte_idx = (uint16_t)(block_index / 8U);
    mask = (uint8_t)(1U << (block_index % 8U));
    was_set = ((s_ota.block_bitmap[byte_idx] & mask) != 0U);
    s_ota.block_bitmap[byte_idx] |= mask;
    return !was_set;
}

static bool bitmap_test_block(uint16_t block_index)
{
    uint16_t byte_idx;
    uint8_t mask;

    if (block_index >= OTA_MAX_BLOCKS) {
        return false;
    }

    byte_idx = (uint16_t)(block_index / 8U);
    mask = (uint8_t)(1U << (block_index % 8U));
    return ((s_ota.block_bitmap[byte_idx] & mask) != 0U);
}

#if BSP_PLATFORM_GD32 && BSP_HAS_FLASH

static bool flash_xfer_cmd_addr(uint8_t cmd, uint32_t addr)
{
    uint8_t hdr[4];
    hdr[0] = cmd;
    hdr[1] = (uint8_t)((addr >> 16U) & 0xFFU);
    hdr[2] = (uint8_t)((addr >> 8U) & 0xFFU);
    hdr[3] = (uint8_t)(addr & 0xFFU);
    return bsp_spi_flash_transfer(hdr, 0, sizeof(hdr));
}

static bool flash_write_enable(void)
{
    const uint8_t cmd = W25_CMD_WRITE_ENABLE;
    bsp_spi_flash_select(true);
    if (!bsp_spi_flash_transfer(&cmd, 0, 1U)) {
        bsp_spi_flash_select(false);
        return false;
    }
    bsp_spi_flash_select(false);
    return true;
}

static bool flash_wait_ready(void)
{
    uint8_t tx[2] = {W25_CMD_READ_STATUS1, 0xFFU};
    uint8_t rx[2];
    uint32_t timeout = 0x3FFFFUL;

    while (timeout-- > 0U) {
        bsp_spi_flash_select(true);
        (void)bsp_spi_flash_transfer(tx, rx, sizeof(tx));
        bsp_spi_flash_select(false);
        if ((rx[1] & W25_SR1_BUSY) == 0U) {
            return true;
        }
    }
    return false;
}

static bool flash_read(uint32_t addr, uint8_t *data, uint32_t len)
{
    uint8_t cmd[4];

    if ((data == 0) || (len == 0U)) {
        return false;
    }

    cmd[0] = W25_CMD_READ_DATA;
    cmd[1] = (uint8_t)((addr >> 16U) & 0xFFU);
    cmd[2] = (uint8_t)((addr >> 8U) & 0xFFU);
    cmd[3] = (uint8_t)(addr & 0xFFU);

    bsp_spi_flash_select(true);
    if (!bsp_spi_flash_transfer(cmd, 0, sizeof(cmd))) {
        bsp_spi_flash_select(false);
        return false;
    }
    if (!bsp_spi_flash_transfer(0, data, len)) {
        bsp_spi_flash_select(false);
        return false;
    }
    bsp_spi_flash_select(false);
    return true;
}

static bool flash_sector_erase(uint32_t addr)
{
    if (!flash_write_enable()) {
        return false;
    }
    bsp_spi_flash_select(true);
    if (!flash_xfer_cmd_addr(W25_CMD_SECTOR_ERASE_4K, addr)) {
        bsp_spi_flash_select(false);
        return false;
    }
    bsp_spi_flash_select(false);
    return flash_wait_ready();
}

static bool flash_program(uint32_t addr, const uint8_t *data, uint32_t len)
{
    uint32_t done = 0U;
    uint32_t page_ofs;
    uint32_t chunk;

    if ((data == 0) || (len == 0U)) {
        return false;
    }

    while (done < len) {
        page_ofs = (addr + done) % BSP_FLASH_PAGE_SIZE;
        chunk = BSP_FLASH_PAGE_SIZE - page_ofs;
        if (chunk > (len - done)) {
            chunk = len - done;
        }
        if (!flash_write_enable()) {
            return false;
        }
        bsp_spi_flash_select(true);
        if (!flash_xfer_cmd_addr(W25_CMD_PAGE_PROGRAM, addr + done)) {
            bsp_spi_flash_select(false);
            return false;
        }
        if (!bsp_spi_flash_transfer(&data[done], 0, chunk)) {
            bsp_spi_flash_select(false);
            return false;
        }
        bsp_spi_flash_select(false);
        if (!flash_wait_ready()) {
            return false;
        }
        done += chunk;
    }
    return true;
}

static bool storage_meta_read(ota_meta_t *meta)
{
    return flash_read(BSP_FLASH_OTA_META_ADDR, (uint8_t *)meta, (uint32_t)sizeof(*meta));
}

static bool storage_meta_write(const ota_meta_t *meta)
{
    if (meta == 0) {
        return false;
    }
    if (!flash_sector_erase(BSP_FLASH_OTA_META_ADDR)) {
        return false;
    }
    return flash_program(BSP_FLASH_OTA_META_ADDR, (const uint8_t *)meta, (uint32_t)sizeof(*meta));
}

static bool storage_image_erase(uint32_t len)
{
    uint32_t addr = BSP_FLASH_OTA_IMAGE_ADDR;
    uint32_t remaining;

    if (len == 0U) {
        return false;
    }

    remaining = ((len + BSP_FLASH_SECTOR_SIZE - 1U) / BSP_FLASH_SECTOR_SIZE) * BSP_FLASH_SECTOR_SIZE;
    while (remaining > 0U) {
        if (!flash_sector_erase(addr)) {
            return false;
        }
        addr += BSP_FLASH_SECTOR_SIZE;
        remaining = (remaining > BSP_FLASH_SECTOR_SIZE) ? (remaining - BSP_FLASH_SECTOR_SIZE) : 0U;
    }
    return true;
}

static bool storage_image_write(uint32_t offset, const uint8_t *data, uint32_t len)
{
    return flash_program(BSP_FLASH_OTA_IMAGE_ADDR + offset, data, len);
}

static bool storage_image_read(uint32_t offset, uint8_t *data, uint32_t len)
{
    return flash_read(BSP_FLASH_OTA_IMAGE_ADDR + offset, data, len);
}

#else

static ota_meta_t s_host_meta;
static uint8_t s_host_image[BSP_FLASH_OTA_IMAGE_MAX_BYTES];

static bool storage_meta_read(ota_meta_t *meta)
{
    if (meta == 0) {
        return false;
    }
    *meta = s_host_meta;
    return true;
}

static bool storage_meta_write(const ota_meta_t *meta)
{
    if (meta == 0) {
        return false;
    }
    s_host_meta = *meta;
    return true;
}

static bool storage_image_erase(uint32_t len)
{
    if ((len == 0U) || (len > BSP_FLASH_OTA_IMAGE_MAX_BYTES)) {
        return false;
    }
    (void)memset(s_host_image, 0xFF, len);
    return true;
}

static bool storage_image_write(uint32_t offset, const uint8_t *data, uint32_t len)
{
    if ((data == 0) || ((offset + len) > BSP_FLASH_OTA_IMAGE_MAX_BYTES)) {
        return false;
    }
    (void)memcpy(&s_host_image[offset], data, len);
    return true;
}

static bool storage_image_read(uint32_t offset, uint8_t *data, uint32_t len)
{
    if ((data == 0) || ((offset + len) > BSP_FLASH_OTA_IMAGE_MAX_BYTES)) {
        return false;
    }
    (void)memcpy(data, &s_host_image[offset], len);
    return true;
}

#endif

static void ota_apply_meta_defaults(ota_meta_t *meta)
{
    if (meta == 0) {
        return;
    }

    (void)memset(meta, 0, sizeof(*meta));
    meta->magic = OTA_META_MAGIC;
    meta->version = OTA_META_VERSION;
    meta->stage = OTA_STAGE_IDLE;
    meta->meta_crc32 = ota_meta_crc(meta);
}

static void ota_set_fail(uint8_t status)
{
    s_ota.meta.stage = OTA_STAGE_FAIL;
    s_ota.meta.last_error = status;
    s_ota.meta.meta_crc32 = ota_meta_crc(&s_ota.meta);
    (void)storage_meta_write(&s_ota.meta);
}

void ota_service_init(void)
{
    ota_meta_t meta;

    (void)memset(&s_ota, 0, sizeof(s_ota));
    s_ota.supported = (BSP_PLATFORM_GD32 != 0U) ? (BSP_HAS_FLASH != 0U) : true;
    bitmap_clear_all();

#if BSP_PLATFORM_GD32 && BSP_HAS_FLASH
    bsp_spi_init();
#endif

    if (!s_ota.supported) {
        ota_apply_meta_defaults(&s_ota.meta);
        return;
    }

    if (storage_meta_read(&meta) && ota_meta_valid(&meta)) {
        s_ota.meta = meta;
    } else {
        ota_apply_meta_defaults(&s_ota.meta);
        (void)storage_meta_write(&s_ota.meta);
    }
}

bool ota_service_supported(void)
{
    return s_ota.supported;
}

bool ota_service_is_busy(void)
{
    return (s_ota.meta.stage != OTA_STAGE_IDLE) && (s_ota.meta.stage != OTA_STAGE_FAIL);
}

uint8_t ota_service_begin(uint32_t fw_size, uint32_t fw_ver, uint8_t *boot_state)
{
    if (boot_state != 0) {
        *boot_state = 0U;
    }

    if (!s_ota.supported) {
        return APP_ST_OTA_NO_SPACE;
    }
    if ((fw_size == 0U) || (fw_size > BSP_FLASH_OTA_IMAGE_MAX_BYTES)) {
        return APP_ST_OTA_NO_SPACE;
    }

    if (!storage_image_erase(fw_size)) {
        ota_set_fail(APP_ST_SAVE_FAIL);
        return APP_ST_SAVE_FAIL;
    }

    bitmap_clear_all();
    ota_apply_meta_defaults(&s_ota.meta);
    s_ota.meta.stage = OTA_STAGE_PREPARE;
    s_ota.meta.fw_size = fw_size;
    s_ota.meta.target_ver = fw_ver;
    s_ota.meta.boot_pending = 0U;
    s_ota.meta.received_blocks = 0U;
    s_ota.meta.total_blocks = 0U;
    s_ota.meta.last_error = 0U;
    s_ota.meta.meta_crc32 = ota_meta_crc(&s_ota.meta);

    if (!storage_meta_write(&s_ota.meta)) {
        ota_set_fail(APP_ST_SAVE_FAIL);
        return APP_ST_SAVE_FAIL;
    }
    return APP_ST_OK;
}

uint8_t ota_service_write_block(uint16_t block_index,
                                uint32_t offset,
                                const uint8_t *data,
                                uint16_t data_len,
                                uint16_t block_crc16,
                                uint16_t *echo_block_index)
{
    if (echo_block_index != 0) {
        *echo_block_index = block_index;
    }

    if (!s_ota.supported) {
        return APP_ST_OTA_NO_SPACE;
    }
    if ((s_ota.meta.stage != OTA_STAGE_PREPARE) && (s_ota.meta.stage != OTA_STAGE_RECEIVE)) {
        return APP_ST_NOT_ALLOWED;
    }
    if ((data == 0) || (data_len == 0U) || ((offset + data_len) > s_ota.meta.fw_size)) {
        return APP_ST_PARAM_ERR;
    }
    if (block_index >= OTA_MAX_BLOCKS) {
        return APP_ST_OTA_NO_SPACE;
    }

    if (crc16_ibm(data, data_len) != block_crc16) {
        s_ota.meta.last_error = APP_ST_OTA_BLK_FAIL;
        return APP_ST_OTA_BLK_FAIL;
    }

    if (!storage_image_write(offset, data, data_len)) {
        s_ota.meta.last_error = APP_ST_SAVE_FAIL;
        return APP_ST_SAVE_FAIL;
    }

    if (bitmap_mark_block(block_index)) {
        if (s_ota.meta.received_blocks < 0xFFFFU) {
            s_ota.meta.received_blocks++;
        }
    }

    s_ota.meta.stage = OTA_STAGE_RECEIVE;
    s_ota.meta.last_error = 0U;
    return APP_ST_OK;
}

uint8_t ota_service_finish(uint32_t image_size,
                           uint32_t image_crc32,
                           uint16_t total_blocks,
                           uint8_t *verify_result,
                           uint8_t *next_action)
{
    uint8_t buf[OTA_VERIFY_CHUNK_BYTES];
    uint32_t remaining;
    uint32_t offset;
    uint32_t crc = 0xFFFFFFFFUL;
    uint32_t i;
    uint32_t j;
    uint32_t byte_val;
    uint32_t chunk;

    if (verify_result != 0) {
        *verify_result = 1U;
    }
    if (next_action != 0) {
        *next_action = 1U;
    }

    if (!s_ota.supported) {
        return APP_ST_OTA_NO_SPACE;
    }
    if ((s_ota.meta.stage != OTA_STAGE_PREPARE) && (s_ota.meta.stage != OTA_STAGE_RECEIVE)) {
        return APP_ST_NOT_ALLOWED;
    }
    if ((image_size == 0U) || (image_size != s_ota.meta.fw_size) || (total_blocks == 0U) || (total_blocks > OTA_MAX_BLOCKS)) {
        ota_set_fail(APP_ST_PARAM_ERR);
        return APP_ST_PARAM_ERR;
    }

    for (i = 0U; i < total_blocks; ++i) {
        if (!bitmap_test_block((uint16_t)i)) {
            ota_set_fail(APP_ST_OTA_IMG_FAIL);
            return APP_ST_OTA_IMG_FAIL;
        }
    }

    remaining = image_size;
    offset = 0U;
    while (remaining > 0U) {
        chunk = (remaining > OTA_VERIFY_CHUNK_BYTES) ? OTA_VERIFY_CHUNK_BYTES : remaining;
        if (!storage_image_read(offset, buf, chunk)) {
            ota_set_fail(APP_ST_SAVE_FAIL);
            return APP_ST_SAVE_FAIL;
        }
        for (i = 0U; i < chunk; ++i) {
            byte_val = (uint32_t)buf[i];
            crc ^= byte_val;
            for (j = 0U; j < 8U; ++j) {
                if ((crc & 1UL) != 0UL) {
                    crc = (crc >> 1U) ^ 0xEDB88320UL;
                } else {
                    crc >>= 1U;
                }
            }
        }
        offset += chunk;
        remaining -= chunk;
    }
    crc = ~crc;

    if (crc != image_crc32) {
        ota_set_fail(APP_ST_OTA_IMG_FAIL);
        return APP_ST_OTA_IMG_FAIL;
    }

    s_ota.meta.stage = OTA_STAGE_VERIFY;
    s_ota.meta.image_crc32 = image_crc32;
    s_ota.meta.fw_size = image_size;
    s_ota.meta.total_blocks = total_blocks;
    s_ota.meta.last_error = 0U;
    s_ota.meta.meta_crc32 = ota_meta_crc(&s_ota.meta);

    if (!storage_meta_write(&s_ota.meta)) {
        ota_set_fail(APP_ST_SAVE_FAIL);
        return APP_ST_SAVE_FAIL;
    }

    if (verify_result != 0) {
        *verify_result = 0U;
    }
    if (next_action != 0) {
        *next_action = 0U;
    }
    return APP_ST_OK;
}

uint8_t ota_service_activate(uint8_t reboot_mode, uint8_t *result)
{
    if (result != 0) {
        *result = 1U;
    }

    if (!s_ota.supported) {
        return APP_ST_OTA_NO_SPACE;
    }
    if (reboot_mode != 0x01U) {
        return APP_ST_PARAM_ERR;
    }
    if (s_ota.meta.stage != OTA_STAGE_VERIFY) {
        return APP_ST_NOT_ALLOWED;
    }

    s_ota.meta.stage = OTA_STAGE_SWITCH;
    s_ota.meta.boot_pending = 1U;
    s_ota.meta.last_error = 0U;
    s_ota.meta.meta_crc32 = ota_meta_crc(&s_ota.meta);

    if (!storage_meta_write(&s_ota.meta)) {
        ota_set_fail(APP_ST_SAVE_FAIL);
        return APP_ST_SAVE_FAIL;
    }

    /*
     * 桥接 bootloader: 把切换请求写到 EEPROM 的 boot_info, bootloader 在下次
     * 启动时会从外部 W25 (BSP_FLASH_OTA_IMAGE_ADDR) 把镜像拷到内部 Flash 槽,
     * 校验通过再切 active_slot. 这一步如果失败就把 OTA 置为 FAIL,
     * 上位机 0xC5 能立即看到错误。
     *
     * 选定目标槽位的策略: 简单地"指向另一个非当前激活槽". bootloader 端
     * 用 boot_info.active_slot 判断当前激活, 这里取反即可。
     */
    {
        boot_info_t bi;
        uint8_t target_slot;

        (void)boot_info_load(&bi);
        target_slot = (bi.active_slot == (uint8_t)BOOT_SLOT_A)
                          ? (uint8_t)BOOT_SLOT_B
                          : (uint8_t)BOOT_SLOT_A;

        if (!boot_info_request_pending(target_slot,
                                       s_ota.meta.fw_size,
                                       s_ota.meta.image_crc32,
                                       s_ota.meta.target_ver)) {
            ota_set_fail(APP_ST_SAVE_FAIL);
            return APP_ST_SAVE_FAIL;
        }
    }

    if (result != 0) {
        *result = 0U;
    }
    return APP_ST_OK;
}

void ota_service_get_status(ota_service_status_t *st)
{
    if (st == 0) {
        return;
    }

    st->supported = s_ota.supported;
    st->upgrade_available = ((s_ota.meta.stage == OTA_STAGE_PREPARE) ||
                             (s_ota.meta.stage == OTA_STAGE_RECEIVE) ||
                             (s_ota.meta.stage == OTA_STAGE_VERIFY) ||
                             (s_ota.meta.stage == OTA_STAGE_SWITCH));
    st->target_ver = s_ota.meta.target_ver;
    st->image_size = s_ota.meta.fw_size;
    st->stage = (ota_service_stage_t)s_ota.meta.stage;
    st->received_blocks = s_ota.meta.received_blocks;
    st->total_blocks = s_ota.meta.total_blocks;
    st->last_error = s_ota.meta.last_error;
    st->boot_pending = (s_ota.meta.boot_pending != 0U);
}
