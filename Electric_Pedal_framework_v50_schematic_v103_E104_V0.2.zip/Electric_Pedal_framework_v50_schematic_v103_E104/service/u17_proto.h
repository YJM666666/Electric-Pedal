﻿#ifndef SERVICE_U17_PROTO_H
#define SERVICE_U17_PROTO_H

/*
 * 文件: service/u17_proto.h
 * 描述: U17 从设备与主控（U12/U17）之间的串口协议定义。
 * 责任: 定义帧格式、命令字、标志及解析/构建接口，供 u17_link 层使用。
 */

#include "project_bool.h"
#include <stddef.h>
#include <stdint.h>

/*
 * U12 <-> U17 串口协议定义
 * ---------------------------------------------------------------
 * 帧格式（逻辑上）:
 *   帧头0 帧头1 版本 标志 命令 序号 应答序号 长度 负载 CRC16
 *
 * 当前协议特点：
 * - 双字节帧头，便于串口流里重新同步
 * - 16bit seq / ack_seq，便于请求-应答匹配
 * - CRC16-IBM 保护
 * - CLASS + ACK_REQ 等标志位统一放在 flags
 */
#define U17_PROTO_HDR0             0x5AU
#define U17_PROTO_HDR1             0xA5U
#define U17_PROTO_VERSION          0x01U
#define U17_PROTO_MAX_PAYLOAD      64U
#define U17_PROTO_MAX_FRAME        (uint16_t)(12U + U17_PROTO_MAX_PAYLOAD)
#define U17_PROTO_FLAG_CLASS_MASK  0x03U
#define U17_PROTO_FLAG_ACK_REQ     0x04U
#define U17_PROTO_FLAG_ERROR       0x08U

/* 帧类别：请求 / 应答 / 事件 */
#define U17_PROTO_CLASS_REQ        0x00U
#define U17_PROTO_CLASS_RSP        0x01U
#define U17_PROTO_CLASS_EVT        0x02U

/* 当前命令字分配 */
#define U17_CMD_HEARTBEAT          0x01U
#define U17_CMD_PARAM_SYNC         0x02U
#define U17_CMD_STEP_CTRL          0x10U
#define U17_CMD_LIGHT_SCENE        0x11U
#define U17_CMD_BUZZER_CTRL        0x12U  /* 保留：当前 U17 硬件无蜂鸣器。 */
#define U17_CMD_VOICE_CTRL         0x13U
#define U17_CMD_BOOT_REPORT        0x30U
#define U17_CMD_STATUS_REPORT      0x31U
#define U17_CMD_FAULT_REPORT       0x32U

/* 应答结果码 */
#define U17_PROTO_RESULT_OK        0x00U
#define U17_PROTO_RESULT_INVALID   0x01U
#define U17_PROTO_RESULT_UNSUP     0x02U
#define U17_PROTO_RESULT_BUSY      0x03U

/* 状态上报中的标志位定义 */
#define U17_PROTO_STATUSF_L_EXT    0x01U
#define U17_PROTO_STATUSF_L_RET    0x02U
#define U17_PROTO_STATUSF_R_EXT    0x04U
#define U17_PROTO_STATUSF_R_RET    0x08U
#define U17_PROTO_STATUSF_LIGHT    0x10U
#define U17_PROTO_STATUSF_BUZZER   0x20U  /* 保留 / 在当前 U17 硬件上始终为 0。 */
#define U17_PROTO_STATUSF_READY    0x40U
#define U17_PROTO_STATUSF_VOICE    0x80U

/* 启动上报中的能力标志 */
#define U17_PROTO_BOOTF_READY      0x01U
#define U17_PROTO_BOOTF_HAS_EE     0x02U
#define U17_PROTO_BOOTF_HAS_FLASH  0x04U

/* 灯光开关语义 */
#define U17_PROTO_LIGHT_OFF        0x00U
#define U17_PROTO_LIGHT_ENABLE     0x01U

typedef struct
{
    uint8_t  version;
    uint8_t  flags;
    uint8_t  cmd;
    uint16_t seq;
    uint16_t ack_seq;
    uint8_t  payload_len;
    uint8_t  payload[U17_PROTO_MAX_PAYLOAD];
} u17_proto_frame_t;

typedef struct
{
    uint8_t  buf[U17_PROTO_MAX_FRAME];
    uint16_t idx;
    uint16_t expected_len;
} u17_proto_parser_t;

void u17_proto_parser_init(u17_proto_parser_t *parser);
uint16_t u17_proto_crc16_ibm(const uint8_t *data, uint16_t len);
bool u17_proto_build(uint8_t flags,
                     uint8_t cmd,
                     uint16_t seq,
                     uint16_t ack_seq,
                     const uint8_t *payload,
                     uint8_t payload_len,
                     uint8_t *out_buf,
                     uint16_t *out_len);
bool u17_proto_parser_feed(u17_proto_parser_t *parser,
                           uint8_t byte,
                           u17_proto_frame_t *frame,
                           bool *frame_ready);

#endif
