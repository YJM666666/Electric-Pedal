#ifndef SERVICE_EVENT_REPORT_SERVICE_H
#define SERVICE_EVENT_REPORT_SERVICE_H

/*
 * 文件: service/event_report_service.h
 * 描述: 事件上报到应用（APP）侧的封装接口。
 * 责任: 管理事件队列、重试、ACK 超时及通过协议发送事件上报。
 */

#include <stdint.h>
#include "project_bool.h"
#include "event.h"

void event_report_service_init(void);
void event_report_service_set_link_active(bool active);
void event_report_service_notify_link_established(void);
void event_report_service_on_event(const event_t *ev);
void event_report_service_tick_100ms(void);
void event_report_service_handle_ack(uint8_t event_id, uint8_t event_seq, uint8_t ack_result);
bool event_report_service_enqueue_code(uint8_t app_event_id, const uint8_t *data, uint8_t data_len);
uint32_t event_report_service_get_drop_count(void);
uint32_t event_report_service_get_ack_timeout_count(void);

#endif
