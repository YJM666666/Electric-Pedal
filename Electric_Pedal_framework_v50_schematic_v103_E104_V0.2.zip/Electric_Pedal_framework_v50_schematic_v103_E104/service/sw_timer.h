#ifndef SERVICE_SW_TIMER_H
#define SERVICE_SW_TIMER_H

/*
 * 软件定时接口：封装毫秒计数读取，避免业务层直接依赖具体硬件定时器。
 */
#include <stdint.h>
#include "project_bool.h"

void sw_timer_init(void);
void sw_timer_tick_1ms(void);
uint32_t sw_timer_now_ms(void);
bool sw_timer_is_expired(uint32_t now_ms, uint32_t deadline_ms);

#endif
