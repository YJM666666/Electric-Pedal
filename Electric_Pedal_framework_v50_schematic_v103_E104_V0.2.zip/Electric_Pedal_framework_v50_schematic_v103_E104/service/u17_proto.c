/*
 * U17 串口协议编解码：负责帧同步、CRC16、字段打包和解析状态机。
 */
#include "u17_proto.h"
#include <string.h>

static void put_le16(uint8_t *dst, uint16_t value)
{
    dst[0] = (uint8_t)(value & 0xFFU);
    dst[1] = (uint8_t)((value >> 8U) & 0xFFU);
}

static uint16_t get_le16(const uint8_t *src)
{
    return (uint16_t)((uint16_t)src[0] | ((uint16_t)src[1] << 8U));
}

void u17_proto_parser_init(u17_proto_parser_t *parser)
{
    if (parser == 0) {
        return;
    }

    (void)memset(parser, 0, sizeof(*parser));
}

uint16_t u17_proto_crc16_ibm(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFFU;
    uint16_t i;
    uint8_t bit;

    if ((data == 0) && (len != 0U)) {
        return 0U;
    }

    for (i = 0U; i < len; ++i) {
        crc ^= (uint16_t)data[i];
        for (bit = 0U; bit < 8U; ++bit) {
            if ((crc & 0x0001U) != 0U) {
                crc = (uint16_t)((crc >> 1U) ^ 0xA001U);
            } else {
                crc >>= 1U;
            }
        }
    }

    return crc;
}

bool u17_proto_build(uint8_t flags,
                     uint8_t cmd,
                     uint16_t seq,
                     uint16_t ack_seq,
                     const uint8_t *payload,
                     uint8_t payload_len,
                     uint8_t *out_buf,
                     uint16_t *out_len)
{
    uint16_t crc;
    uint16_t frame_len;

    if ((out_buf == 0) || (out_len == 0) || (payload_len > U17_PROTO_MAX_PAYLOAD)) {
        return false;
    }

    frame_len = (uint16_t)(12U + payload_len);
    out_buf[0] = U17_PROTO_HDR0;
    out_buf[1] = U17_PROTO_HDR1;
    out_buf[2] = U17_PROTO_VERSION;
    out_buf[3] = flags;
    out_buf[4] = cmd;
    put_le16(&out_buf[5], seq);
    put_le16(&out_buf[7], ack_seq);
    out_buf[9] = payload_len;

    if ((payload_len > 0U) && (payload != 0)) {
        (void)memcpy(&out_buf[10], payload, payload_len);
    }

    crc = u17_proto_crc16_ibm(&out_buf[2], (uint16_t)(8U + payload_len));
    put_le16(&out_buf[10U + payload_len], crc);
    *out_len = frame_len;
    return true;
}

bool u17_proto_parser_feed(u17_proto_parser_t *parser,
                           uint8_t byte,
                           u17_proto_frame_t *frame,
                           bool *frame_ready)
{
    uint8_t payload_len;
    uint16_t crc_rx;
    uint16_t crc_calc;

    if ((parser == 0) || (frame_ready == 0)) {
        return false;
    }

    *frame_ready = false;

    if (parser->idx == 0U) {
        if (byte != U17_PROTO_HDR0) {
            return true;
        }
        parser->buf[parser->idx++] = byte;
        return true;
    }

    if (parser->idx == 1U) {
        if (byte != U17_PROTO_HDR1) {
            parser->idx = 0U;
            return true;
        }
        parser->buf[parser->idx++] = byte;
        return true;
    }

    if (parser->idx >= U17_PROTO_MAX_FRAME) {
        parser->idx = 0U;
        parser->expected_len = 0U;
        return false;
    }

    parser->buf[parser->idx++] = byte;

    if (parser->idx == 10U) {
        payload_len = parser->buf[9];
        if (payload_len > U17_PROTO_MAX_PAYLOAD) {
            parser->idx = 0U;
            parser->expected_len = 0U;
            return false;
        }
        parser->expected_len = (uint16_t)(12U + payload_len);
    }

    if ((parser->expected_len != 0U) && (parser->idx == parser->expected_len)) {
        payload_len = parser->buf[9];
        crc_rx = get_le16(&parser->buf[10U + payload_len]);
        crc_calc = u17_proto_crc16_ibm(&parser->buf[2], (uint16_t)(8U + payload_len));
        if (crc_rx != crc_calc) {
            parser->idx = 0U;
            parser->expected_len = 0U;
            return false;
        }

        if (frame != 0) {
            frame->version = parser->buf[2];
            frame->flags = parser->buf[3];
            frame->cmd = parser->buf[4];
            frame->seq = get_le16(&parser->buf[5]);
            frame->ack_seq = get_le16(&parser->buf[7]);
            frame->payload_len = payload_len;
            if (payload_len > 0U) {
                (void)memcpy(frame->payload, &parser->buf[10], payload_len);
            }
        }
        *frame_ready = true;
        parser->idx = 0U;
        parser->expected_len = 0U;
    }

    return true;
}
