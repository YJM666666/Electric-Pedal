#ifndef SERVICE_EVENT_H
#define SERVICE_EVENT_H

/*
 * 文件: service/event.h
 * 描述: 事件定义与事件队列接口。
 * 责任: 声明系统内部事件 ID、事件来源以及事件推送/弹出等 API。
 */

#include <stdint.h>
#include "project_bool.h"

typedef enum
{
    EV_SRC_NONE = 0,
    EV_SRC_SYSTEM,
    EV_SRC_TIMER,
    EV_SRC_CAN,
    EV_SRC_APP,
    EV_SRC_PROTECT,
    EV_SRC_U17,
    EV_SRC_HALL
} event_source_t;

typedef enum
{
    EV_NONE = 0,
    EV_BOOT,
    EV_POWER_RECOVERED,
    EV_TICK_1MS,
    EV_TICK_10MS,
    EV_TICK_100MS,
    EV_TICK_1S,

    /* 车辆/通信 */
    EV_CAN_RX,
    EV_CAN_TIMEOUT,
    EV_CAN_RECOVER,
    EV_BLE_RX,
    EV_KEY_UNLOCK,
    EV_KEY_LOCK,
    EV_SPEED_ABOVE_8,
    EV_SPEED_BELOW_8,

    EV_DOOR_FL_OPEN,
    EV_DOOR_FL_CLOSE,
    EV_DOOR_FR_OPEN,
    EV_DOOR_FR_CLOSE,
    EV_DOOR_RL_OPEN,
    EV_DOOR_RL_CLOSE,
    EV_DOOR_RR_OPEN,
    EV_DOOR_RR_CLOSE,

    EV_TURN_LEFT_ON,
    EV_TURN_LEFT_OFF,
    EV_TURN_RIGHT_ON,
    EV_TURN_RIGHT_OFF,
    EV_BRAKE_ON,
    EV_BRAKE_OFF,
    EV_HEADLAMP_ON,
    EV_HEADLAMP_OFF,
    EV_AUTO_DRIVE_ON,
    EV_AUTO_DRIVE_OFF,

    /* 模式 */
    EV_ENTER_WASH,
    EV_WASH_TIMEOUT,
    EV_ENTER_INSTALL_TEST,
    EV_EXIT_INSTALL_TEST,
    EV_ENTER_OTA,
    EV_OTA_FINISH,
    EV_MAIN_SWITCH_ON,
    EV_MAIN_SWITCH_OFF,

    /* 左/右 步进控制 */
    EV_L_EXT_CMD,
    EV_L_RET_CMD,
    EV_R_EXT_CMD,
    EV_R_RET_CMD,

    EV_L_HALL_PULSE,
    EV_R_HALL_PULSE,

    EV_L_DONE,
    EV_R_DONE,
    EV_L_TIMEOUT,
    EV_R_TIMEOUT,
    EV_L_ANTI_PINCH,
    EV_R_ANTI_PINCH,
    EV_L_OVERCURRENT,
    EV_R_OVERCURRENT,

    /* 参数/存储 */
    EV_PARAM_UPDATED,
    EV_COUNTER_SAVE,

    /* 故障 */
    EV_FAULT_SET,
    EV_FAULT_CLEAR
} event_id_t;

typedef struct
{
    event_id_t      id;
    event_source_t  source;
    uint32_t        param_u32;
    void           *param_ptr;
} event_t;

typedef struct
{
    uint16_t current_depth;
    uint16_t high_watermark;
    uint32_t push_fail_count;
    bool     overflow_latched;
} event_diag_t;

void event_init(void);
bool event_push(const event_t *ev);
bool event_push_isr(const event_t *ev);
bool event_pop(event_t *ev);
void event_get_diag(event_diag_t *diag);
bool event_has_overflowed(void);
void event_clear_overflow(void);

#endif
