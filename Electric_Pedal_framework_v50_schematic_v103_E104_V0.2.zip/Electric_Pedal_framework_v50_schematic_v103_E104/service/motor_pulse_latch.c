/*
 * 霍尔脉冲锁存服务：把中断侧累计的脉冲安全地交给主循环消费。
 */
#include "motor_pulse_latch.h"
#include "event_flags.h"
#include <string.h>

static volatile uint16_t s_pulses[STEP_SIDE_MAX];

#if defined(__arm__) || defined(__thumb__) || defined(__ARM_ARCH)
static uint32_t latch_irq_save(void)
{
    uint32_t primask;

    __asm volatile("MRS %0, primask" : "=r"(primask) :: "memory");
    __asm volatile("cpsid i" ::: "memory");
    return primask;
}

static void latch_irq_restore(uint32_t primask)
{
    __asm volatile("MSR primask, %0" :: "r"(primask) : "memory");
}
#else
static uint32_t latch_irq_save(void)
{
    return 0U;
}

static void latch_irq_restore(uint32_t primask)
{
    (void)primask;
}
#endif

static void latch_add(step_side_t side, uint16_t pulses)
{
    uint32_t key;
    uint32_t sum;

    if ((side >= STEP_SIDE_MAX) || (pulses == 0U)) {
        return;
    }

    key = latch_irq_save();
    sum = (uint32_t)s_pulses[side] + (uint32_t)pulses;
    s_pulses[side] = (sum > 0xFFFFU) ? 0xFFFFU : (uint16_t)sum;
    latch_irq_restore(key);
}

void motor_pulse_latch_init(void)
{
    uint32_t key = latch_irq_save();

    (void)memset((void *)s_pulses, 0, sizeof(s_pulses));
    latch_irq_restore(key);
}

void motor_pulse_latch_on_edge_isr(step_side_t side)
{
    latch_add(side, 1U);
    event_flags_mark_isr(EVENT_FLAG_MOTOR_HALL_PENDING);
}

void motor_pulse_latch_add_mock(step_side_t side, uint16_t pulses)
{
    latch_add(side, pulses);
    event_flags_mark(EVENT_FLAG_MOTOR_HALL_PENDING);
}

void motor_pulse_latch_take_snapshot(motor_pulse_snapshot_t *out)
{
    uint32_t key;
    uint32_t i;

    if (out == 0) {
        return;
    }

    key = latch_irq_save();
    for (i = 0U; i < (uint32_t)STEP_SIDE_MAX; ++i) {
        out->pulses[i] = s_pulses[i];
        s_pulses[i] = 0U;
    }
    latch_irq_restore(key);
}
