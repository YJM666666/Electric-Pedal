/*
 * APP 协议编解码：负责帧头、长度、CRC 和负载拷贝，不处理具体业务命令。
 */
#include "app_proto_v2.h"
#include <string.h>

uint8_t app_proto_v2_crc8(const uint8_t *data, uint16_t len)
{
    uint8_t crc = 0x00U;
    uint16_t i;
    uint8_t bit;
    for (i = 0U; i < len; ++i) {
        crc ^= data[i];
        for (bit = 0U; bit < 8U; ++bit) {
            crc = (crc & 0x80U) ? (uint8_t)((crc << 1U) ^ 0x07U) : (uint8_t)(crc << 1U);
        }
    }
    return crc;
}

void app_proto_v2_parser_init(app_proto_v2_parser_t *parser)
{
    if (parser != 0) {
        (void)memset(parser, 0, sizeof(*parser));
    }
}

bool app_proto_v2_build(uint8_t cmd, uint8_t seq, uint8_t status, const uint8_t *payload, uint16_t len, uint8_t *out, uint16_t *out_len)
{
    uint16_t total_len;
    if ((out == 0) || (out_len == 0)) {
        return false;
    }

    if ((len > 0U) && (payload == 0)) {
        return false;
    }
    total_len = (uint16_t)(10U + len);
    out[0] = APP_PROTO_V2_SOF1;
    out[1] = APP_PROTO_V2_SOF2;
    out[2] = APP_PROTO_V2_VER;
    out[3] = cmd;
    out[4] = seq;
    out[5] = (uint8_t)len;
    out[6] = (uint8_t)(len >> 8);
    out[7] = status;
    if ((len > 0U) && (payload != 0)) {
        (void)memcpy(&out[8], payload, len);
    }
    out[8U + len] = app_proto_v2_crc8(&out[2], (uint16_t)(6U + len));
    out[9U + len] = APP_PROTO_V2_EOF;
    *out_len = total_len;
    return true;
}

bool app_proto_v2_feed(app_proto_v2_parser_t *parser, uint8_t byte, app_proto_v2_frame_t *frame, bool *frame_ready)
{
    uint16_t len;
    uint8_t crc;
    if ((parser == 0) || (frame_ready == 0)) {
        return false;
    }
    *frame_ready = false;
    if (parser->idx == 0U) {
        if (byte == APP_PROTO_V2_SOF1) parser->buf[parser->idx++] = byte;
        return true;
    }
    if (parser->idx == 1U) {
        if (byte != APP_PROTO_V2_SOF2) { parser->idx = 0U; return true; }
        parser->buf[parser->idx++] = byte;
        return true;
    }
    if (parser->idx >= APP_PROTO_V2_MAX_FRAME) { parser->idx = 0U; parser->expected_len = 0U; return false; }
    parser->buf[parser->idx++] = byte;
    if (parser->idx == 8U) {
        len = (uint16_t)parser->buf[5] | ((uint16_t)parser->buf[6] << 8);
        parser->expected_len = (uint16_t)(10U + len);
        if (parser->expected_len > APP_PROTO_V2_MAX_FRAME) { parser->idx = 0U; parser->expected_len = 0U; return false; }
    }
    if ((parser->expected_len != 0U) && (parser->idx == parser->expected_len)) {
        if (parser->buf[parser->expected_len - 1U] != APP_PROTO_V2_EOF) { parser->idx = 0U; parser->expected_len = 0U; return false; }
        len = (uint16_t)parser->buf[5] | ((uint16_t)parser->buf[6] << 8);
        crc = app_proto_v2_crc8(&parser->buf[2], (uint16_t)(6U + len));
        if (crc != parser->buf[8U + len]) { parser->idx = 0U; parser->expected_len = 0U; return false; }
        if (frame != 0) {
            frame->cmd = parser->buf[3];
            frame->seq = parser->buf[4];
            frame->len = len;
            frame->status = parser->buf[7];
            if (len > 0U) (void)memcpy(frame->payload, &parser->buf[8], len);
        }
        *frame_ready = true;
        parser->idx = 0U;
        parser->expected_len = 0U;
    }
    return true;
}
