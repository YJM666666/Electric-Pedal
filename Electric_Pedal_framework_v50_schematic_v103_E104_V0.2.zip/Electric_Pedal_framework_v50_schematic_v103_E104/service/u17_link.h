#ifndef SERVICE_U17_LINK_H
#define SERVICE_U17_LINK_H

/*
 * 文件: service/u17_link.h
 * 描述: U17 链路层接口与诊断数据结构声明。
 * 责任: 声明链路状态、远端状态镜像以及主控与 U17 交互的公共接口。
 */

#include "project_bool.h"
#include <stdint.h>
#include "pedal_types.h"
#include "param.h"

typedef enum
{
    U17_LINK_STATE_INIT = 0,
    U17_LINK_STATE_ONLINE,
    U17_LINK_STATE_LOST,
    U17_LINK_STATE_OFFLINE
} u17_link_state_t;

/*
 * U12 <-> U17 链路诊断信息。
 * 用来观察：
 * - 收发帧数量
 * - CRC 错误
 * - 心跳超时 / 丢失 / 恢复
 * - 请求重试/超时
 */
typedef struct
{
    uint32_t tx_frame_count;
    uint32_t rx_frame_count;
    uint32_t rx_crc_error_count;
    uint32_t rx_drop_count;
    uint32_t heartbeat_timeout_count;
    uint32_t heartbeat_miss_count;
    uint32_t heartbeat_recover_count;
    uint32_t request_retry_count;
    uint32_t request_timeout_count;
    uint16_t tx_sequence;
    u17_link_state_t link_state;
    bool     link_online;
    bool     param_sync_pending;
    bool     timeout_latched;
    bool     boot_seen;
} u17_link_diag_t;

/*
 * U17 最近一次上报的执行侧状态镜像。
 * 主控想了解 U17 的当前状态，就读这里。
 */
typedef struct
{
    bool          boot_seen;
    bool          slave_ready;
    bool          left_ext_limit;
    bool          left_ret_limit;
    bool          right_ext_limit;
    bool          right_ret_limit;
    bool          light_enabled;
    bool          buzzer_enabled;
    bool          voice_busy;
    step_action_t left_action;
    step_action_t right_action;
    uint16_t      left_current_raw;
    uint16_t      right_current_raw;
    uint32_t      fault_mask;
    uint8_t       active_light_scene;
    light_scene_cfg_t active_light_cfg;
} u17_remote_status_t;

void u17_link_init(void);
void u17_link_poll(void);
void u17_link_tick_10ms(void);
void u17_link_mark_param_dirty(void);
void u17_link_clear_timeout_latch(void);
bool u17_link_has_timeout_latched(void);
bool u17_link_is_online(void);
u17_link_state_t u17_link_get_state(void);
void u17_link_get_diag(u17_link_diag_t *diag);
void u17_link_get_remote_status(u17_remote_status_t *status);

/*
 * 下列接口都是“主控发命令给 U17”的统一入口。
 * - step  : 预留/兼容，当前传统有刷电机不再由 U17 执行
 * - light : 灯光执行命令
 * - buzzer: 当前 U17 无蜂鸣器，保持为空操作
 * - voice : 语音播放命令
 */
bool u17_link_request_step(step_side_t side, step_action_t action);
bool u17_link_request_light(uint8_t scene, const light_scene_cfg_t *cfg, bool enable);
bool u17_link_request_buzzer(bool enable, uint8_t pattern, uint16_t duration_10ms);
bool u17_link_request_voice(uint8_t lang, uint16_t voice_id, bool stop);

/* 从远端状态镜像里取限位和电流。 */
bool u17_link_remote_limit(step_side_t side, step_action_t action);
uint16_t u17_link_remote_current(step_side_t side);

#endif
