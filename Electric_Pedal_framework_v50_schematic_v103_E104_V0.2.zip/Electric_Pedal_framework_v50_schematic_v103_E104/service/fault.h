#ifndef SERVICE_FAULT_H
#define SERVICE_FAULT_H

/*
 * 故障接口：统一设置、清除和查询故障位，供保护、状态机和上报服务共用。
 */
#include <stdint.h>
#include "project_bool.h"

typedef enum
{
    FAULT_NONE             = 0x00000000UL,
    FAULT_L_TIMEOUT        = 0x00000001UL,
    FAULT_R_TIMEOUT        = 0x00000002UL,
    FAULT_L_OVERCURRENT    = 0x00000004UL,
    FAULT_R_OVERCURRENT    = 0x00000008UL,
    FAULT_L_ANTI_PINCH     = 0x00000010UL,
    FAULT_R_ANTI_PINCH     = 0x00000020UL,
    FAULT_CAN_TIMEOUT      = 0x00000040UL,
    FAULT_NVM              = 0x00000080UL,
    FAULT_U17_LINK         = 0x00000100UL,
    FAULT_EVENT_QUEUE      = 0x00000200UL,
    FAULT_BLE_RX_OVERFLOW  = 0x00000400UL,
    FAULT_PARAM_INVALID    = 0x00000800UL
} fault_code_t;

void fault_init(void);
void fault_set(uint32_t mask);
void fault_clear(uint32_t mask);
void fault_clear_all(void);
uint32_t fault_get_mask(void);
bool fault_has(uint32_t mask);
bool fault_has_critical(void);

#endif
