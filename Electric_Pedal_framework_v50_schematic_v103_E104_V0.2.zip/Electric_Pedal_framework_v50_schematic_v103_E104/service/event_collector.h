#ifndef SERVICE_EVENT_COLLECTOR_H
#define SERVICE_EVENT_COLLECTOR_H

/*
 * 文件: service/event_collector.h
 * 描述: 事件采集器接口。
 * 责任: 聚合底层标志与外设信号，翻译为业务事件并推入事件队列。
 */

void event_collector_init(void);
void event_collector_poll(void);

#endif
