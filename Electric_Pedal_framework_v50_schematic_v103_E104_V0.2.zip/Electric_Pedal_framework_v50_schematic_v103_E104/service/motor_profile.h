#ifndef SERVICE_MOTOR_PROFILE_H
#define SERVICE_MOTOR_PROFILE_H

/*
 * 电机画像接口：为参数默认值和保护逻辑提供电机额定能力、堵转阈值和防夹档位。
 */
#include <stdint.h>
#include "project_bool.h"
#include "driver/drv_motor_backend.h"

#define MOTOR_FEEDBACK_CURRENT     (1U << 0)
#define MOTOR_FEEDBACK_HALL        (1U << 1)
#define MOTOR_FEEDBACK_LIMIT_SW    (1U << 2)

typedef enum
{
    MOTOR_KIND_BRUSHED_DC = 0,
    MOTOR_KIND_BRUSHLESS_DC,
    MOTOR_KIND_SMART_ACTUATOR
} motor_kind_t;

typedef struct
{
    uint8_t  motor_kind;
    uint8_t  drive_backend;
    uint8_t  feedback_flags;
    uint8_t  hall_pulses_per_rev;

    uint16_t rated_voltage_mv;
    uint16_t no_load_current_ma;
    uint16_t rated_power_w;
    uint16_t no_load_speed_rpm_x10;
    uint16_t load_5nm_current_ma;
    uint16_t load_20nm_current_ma;
    uint16_t stall_current_ma;

    uint16_t no_pulse_start_grace_ms;
    uint16_t no_pulse_timeout_ms;
    uint16_t stall_debounce_ms;
    uint16_t anti_pinch_backoff_ms;
    uint16_t default_overcurrent_adc;
    uint16_t default_anti_pinch_adc[8];
} motor_profile_t;

void motor_profile_init(void);
const motor_profile_t *motor_profile_get(void);
bool motor_profile_set_active(const motor_profile_t *profile);
void motor_profile_load_tb1661b_defaults(motor_profile_t *out);

bool motor_profile_has_feedback(uint8_t feedback_bit);
uint8_t motor_profile_get_drive_backend(void);

#endif
