#ifndef SERVICE_OTA_SERVICE_H
#define SERVICE_OTA_SERVICE_H

/*
 * 文件: service/ota_service.h
 * 描述: 应用侧 OTA 状态机, 处理协议 0x1A / 0xC1~0xC5.
 * 责任:
 *   - 维护 OTA 阶段 / 已接收块数 / 块位图 / 镜像 CRC
 *   - 把分包写入外部 W25 SPI Flash 的 OTA 区, 用 meta+image 双 sector 持久化
 *   - 校验通过后写入 boot_pending 标记, 由 bootloader 在下次启动时切换
 *   - 给 app_cmd_dispatch 提供具体的处理函数, 保持与 V2.0 协议字段对齐
 */

#include <stdint.h>
#include "project_bool.h"
#include "app_proto_v2_ids.h"

/*
 * OTA 内部阶段. 数值会作为 0x1A / 0xC5 回复中 ota_stage 字段直接外露,
 * 所以编号必须与协议 V2.0 §9.13 表格保持一致:
 *   0=空闲 1=准备 2=接收 3=校验 4=切换 5=失败
 */
typedef enum
{
    OTA_STAGE_IDLE    = 0,
    OTA_STAGE_PREPARE = 1,
    OTA_STAGE_RECEIVE = 2,
    OTA_STAGE_VERIFY  = 3,
    OTA_STAGE_SWITCH  = 4,
    OTA_STAGE_FAIL    = 5
} ota_service_stage_t;

typedef struct
{
    bool                supported;          /* 设备是否具备 OTA 能力 */
    bool                upgrade_available;  /* 0x1A 字段, 已存在尚未启动的镜像 */
    bool                boot_pending;       /* 校验通过等待重启切换 */
    uint32_t            target_ver;         /* 目标版本号 (协议 0xC1 fw_ver) */
    uint32_t            image_size;         /* 当前流程绑定的镜像总长度 */
    ota_service_stage_t stage;              /* 当前阶段 */
    uint16_t            received_blocks;    /* 已接收块数 (去重后) */
    uint16_t            total_blocks;       /* 协议 0xC3 上报的总块数 */
    uint8_t             last_error;         /* 最近一次错误码, 与 APP_ST_* 对齐 */
} ota_service_status_t;

void ota_service_init(void);

/* 设备能力探测, 0x1A.byte0 直接取返回值. */
bool ota_service_supported(void);

/* OTA 流程是否处于"占用其他业务"的状态. dispatch 用它屏蔽常规命令. */
bool ota_service_is_busy(void);

/* 0xC1 进入升级模式. boot_state: 0=应用态, 1=Bootloader 态 (本实现固定 0). */
uint8_t ota_service_begin(uint32_t fw_size, uint32_t fw_ver, uint8_t *boot_state);

/*
 * 0xC2 接收固件分包.
 *   data 已扣掉协议头, 是裸的固件字节;
 *   echo_block_index 用于把当前块号回显到 0xC2 回复 PAYLOAD 前两个字节.
 */
uint8_t ota_service_write_block(uint16_t block_index,
                                uint32_t offset,
                                const uint8_t *data,
                                uint16_t data_len,
                                uint16_t block_crc16,
                                uint16_t *echo_block_index);

/*
 * 0xC3 整体校验.
 *   verify_result: 0=通过, 非 0=失败 (直接写入 0xC3 回复)
 *   next_action:   0=等待重启, 1=需重传
 */
uint8_t ota_service_finish(uint32_t image_size,
                           uint32_t image_crc32,
                           uint16_t total_blocks,
                           uint8_t *verify_result,
                           uint8_t *next_action);

/*
 * 0xC4 请求重启切换. 实际复位由 dispatch 在协议回复发完之后再触发,
 * 由 reply->reboot_after_reply 通知 BLE/UART 层。
 *   result: 0=接受, 非 0=拒绝
 */
uint8_t ota_service_activate(uint8_t reboot_mode, uint8_t *result);

/* 0x1A / 0xC5 综合查询. */
void ota_service_get_status(ota_service_status_t *st);

#endif /* SERVICE_OTA_SERVICE_H */
