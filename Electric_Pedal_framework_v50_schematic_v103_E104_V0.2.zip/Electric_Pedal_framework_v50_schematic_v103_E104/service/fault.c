#include "fault.h"

/*
 * 故障位管理：集中保存当前故障掩码，并区分会影响整机运行的严重故障。
 * 策略层和系统状态机会根据这些标志决定是否停止踏板动作。
 */
static uint32_t s_fault_mask = 0UL;

static uint32_t fault_critical_mask(void)
{
    return (uint32_t)(FAULT_L_TIMEOUT |
                      FAULT_R_TIMEOUT |
                      FAULT_L_OVERCURRENT |
                      FAULT_R_OVERCURRENT |
                      FAULT_NVM |
                      FAULT_U17_LINK |
                      FAULT_EVENT_QUEUE |
                      FAULT_PARAM_INVALID);
}

void fault_init(void)
{
    s_fault_mask = 0UL;
}

void fault_set(uint32_t mask)
{
    s_fault_mask |= mask;
}

void fault_clear(uint32_t mask)
{
    s_fault_mask &= ~mask;
}

void fault_clear_all(void)
{
    s_fault_mask = 0UL;
}

uint32_t fault_get_mask(void)
{
    return s_fault_mask;
}

bool fault_has(uint32_t mask)
{
    return ((s_fault_mask & mask) != 0UL) ? true : false;
}

bool fault_has_critical(void)
{
    return ((s_fault_mask & fault_critical_mask()) != 0UL) ? true : false;
}
