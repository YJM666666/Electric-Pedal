#include "event.h"

/*
 * 轻量事件队列：连接中断/采集层和业务状态机。
 * 在 ARM 目标上通过关中断保护队列指针，在主机测试上保持同一套接口。
 */
#define EVENT_QUEUE_SIZE 256U

#if defined(__arm__) || defined(__thumb__) || defined(__ARM_ARCH)
static uint32_t event_irq_save(void)
{
    uint32_t primask;

    __asm volatile("MRS %0, primask" : "=r"(primask) :: "memory");
    __asm volatile("cpsid i" ::: "memory");
    return primask;
}

static void event_irq_restore(uint32_t primask)
{
    __asm volatile("MSR primask, %0" :: "r"(primask) : "memory");
}
#else
static uint32_t event_irq_save(void)
{
    return 0U;
}

static void event_irq_restore(uint32_t primask)
{
    (void)primask;
}
#endif

typedef struct
{
    volatile uint16_t head;
    volatile uint16_t tail;
    uint16_t          high_watermark;
    uint32_t          push_fail_count;
    bool              overflow_latched;
    event_t           queue[EVENT_QUEUE_SIZE];
} event_ctx_t;

static event_ctx_t s_event;

static uint16_t next_idx(uint16_t idx)
{
    return (uint16_t)((idx + 1U) % EVENT_QUEUE_SIZE);
}

static uint16_t queue_depth(uint16_t head, uint16_t tail)
{
    if (head >= tail) {
        return (uint16_t)(head - tail);
    }

    return (uint16_t)(EVENT_QUEUE_SIZE - tail + head);
}

static void update_high_watermark_locked(uint16_t head, uint16_t tail)
{
    uint16_t depth;

    depth = queue_depth(head, tail);
    if (depth > s_event.high_watermark) {
        s_event.high_watermark = depth;
    }
}

static bool event_push_locked(const event_t *ev)
{
    uint16_t head;
    uint16_t next;
    uint16_t tail;

    if (ev == 0) {
        return false;
    }

    head = s_event.head;
    tail = s_event.tail;
    next = next_idx(head);
    if (next == tail) {
        s_event.push_fail_count++;
        s_event.overflow_latched = true;
        return false;
    }

    s_event.queue[head] = *ev;
    s_event.head = next;
    update_high_watermark_locked(next, tail);
    return true;
}

static bool event_pop_locked(event_t *ev)
{
    uint16_t tail;
    uint16_t head;

    if (ev == 0) {
        return false;
    }

    tail = s_event.tail;
    head = s_event.head;
    if (tail == head) {
        return false;
    }

    *ev = s_event.queue[tail];
    s_event.tail = next_idx(tail);
    return true;
}

void event_init(void)
{
    uint32_t key;

    key = event_irq_save();
    s_event.head = 0U;
    s_event.tail = 0U;
    s_event.high_watermark = 0U;
    s_event.push_fail_count = 0U;
    s_event.overflow_latched = false;
    event_irq_restore(key);
}

bool event_push(const event_t *ev)
{
    bool ok;
    uint32_t key;

    key = event_irq_save();
    ok = event_push_locked(ev);
    event_irq_restore(key);
    return ok;
}

bool event_push_isr(const event_t *ev)
{
    bool ok;
    uint32_t key;

    key = event_irq_save();
    ok = event_push_locked(ev);
    event_irq_restore(key);
    return ok;
}

bool event_pop(event_t *ev)
{
    bool ok;
    uint32_t key;

    key = event_irq_save();
    ok = event_pop_locked(ev);
    event_irq_restore(key);
    return ok;
}

void event_get_diag(event_diag_t *diag)
{
    uint32_t key;

    if (diag == 0) {
        return;
    }

    key = event_irq_save();
    diag->current_depth = queue_depth(s_event.head, s_event.tail);
    diag->high_watermark = s_event.high_watermark;
    diag->push_fail_count = s_event.push_fail_count;
    diag->overflow_latched = s_event.overflow_latched;
    event_irq_restore(key);
}

bool event_has_overflowed(void)
{
    bool overflow;
    uint32_t key;

    key = event_irq_save();
    overflow = s_event.overflow_latched;
    event_irq_restore(key);
    return overflow;
}

void event_clear_overflow(void)
{
    uint32_t key;

    key = event_irq_save();
    s_event.overflow_latched = false;
    event_irq_restore(key);
}
