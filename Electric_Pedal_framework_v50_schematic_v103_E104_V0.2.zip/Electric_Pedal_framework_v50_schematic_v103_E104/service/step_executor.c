#include "step_executor.h"
#include "drv_motor.h"

/*
 * 踏板动作执行器：缓存状态机提出的动作请求，并在调度点统一下发到电机驱动。
 * 这样可以把“决策”和“硬件输出”分开，减少同一轮事件中反复切换继电器的风险。
 */
static step_action_t s_requested_action[STEP_SIDE_MAX];
static step_action_t s_applied_action[STEP_SIDE_MAX];
static uint32_t s_sequence[STEP_SIDE_MAX];
static bool s_pending[STEP_SIDE_MAX];

static step_action_t sanitize_action(step_action_t action)
{
    switch (action)
    {
        case STEP_ACT_EXTEND:
        case STEP_ACT_RETRACT:
        case STEP_ACT_RETRACT_SLOW:
        case STEP_ACT_STOP:
            return action;

        default:
            return STEP_ACT_STOP;
    }
}

void step_executor_init(void)
{
    uint32_t i;

    for (i = 0U; i < (uint32_t)STEP_SIDE_MAX; ++i) {
        step_side_t side = (step_side_t)i;
        step_action_t action = drv_motor_get_action(side);
        action = sanitize_action(action);
        s_requested_action[i] = action;
        s_applied_action[i] = action;
        s_sequence[i] = 0U;
        s_pending[i] = false;
    }
}

void step_executor_request(step_side_t side, step_action_t action)
{
    if (side >= STEP_SIDE_MAX) {
        return;
    }

    s_requested_action[side] = sanitize_action(action);
    s_sequence[side]++;
    s_pending[side] = true;
}

bool step_executor_take_pending(step_side_t side, step_exec_cmd_t *out)
{
    if ((side >= STEP_SIDE_MAX) || (out == 0)) {
        return false;
    }

    if (!s_pending[side]) {
        return false;
    }

    s_pending[side] = false;
    out->side = side;
    out->action = s_requested_action[side];
    out->sequence = s_sequence[side];
    return true;
}

void step_executor_apply_pending(void)
{
    uint32_t i;

    for (i = 0U; i < (uint32_t)STEP_SIDE_MAX; ++i) {
        step_exec_cmd_t cmd;

        if (!step_executor_take_pending((step_side_t)i, &cmd)) {
            continue;
        }

        if ((s_applied_action[cmd.side] == cmd.action) &&
            (drv_motor_get_action(cmd.side) == cmd.action)) {
            continue;
        }

        drv_motor_exec(cmd.side, cmd.action);
        s_applied_action[cmd.side] = cmd.action;
    }
}

step_action_t step_executor_get_requested_action(step_side_t side)
{
    if (side >= STEP_SIDE_MAX) {
        return STEP_ACT_STOP;
    }

    return s_requested_action[side];
}

step_action_t step_executor_get_applied_action(step_side_t side)
{
    if (side >= STEP_SIDE_MAX) {
        return STEP_ACT_STOP;
    }

    return s_applied_action[side];
}

bool step_executor_is_limit_reached(step_side_t side, step_action_t action)
{
    return drv_motor_is_limit_reached(side, sanitize_action(action));
}
