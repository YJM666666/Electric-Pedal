#ifndef SERVICE_APP_PROTO_V2_H
#define SERVICE_APP_PROTO_V2_H

/*
 * 文件: service/app_proto_v2.h
 * 描述: 应用层协议 APP_PROTO_V2（版本 2.0）定义与工具函数。
 * 责任: 定义帧格式、最大长度、CRC、构建与解析接口，供传输层和命令分发使用。
 */

#include <stddef.h>
#include <stdint.h>
#include "project_bool.h"
#include "config/protocol/app_proto_v2_ids.h"

#define APP_PROTO_V2_SOF1            0x55U
#define APP_PROTO_V2_SOF2            0xAAU
#define APP_PROTO_V2_VER             0x20U
#define APP_PROTO_V2_EOF             0xEEU
#define APP_PROTO_V2_MAX_PAYLOAD     512U
#define APP_PROTO_V2_MAX_FRAME       522U

typedef struct
{
    uint8_t cmd;
    uint8_t seq;
    uint8_t status;
    uint16_t len;
    uint8_t payload[APP_PROTO_V2_MAX_PAYLOAD];
} app_proto_v2_frame_t;

typedef struct
{
    uint8_t buf[APP_PROTO_V2_MAX_FRAME];
    uint16_t idx;
    uint16_t expected_len;
} app_proto_v2_parser_t;

uint8_t app_proto_v2_crc8(const uint8_t *data, uint16_t len);
void app_proto_v2_parser_init(app_proto_v2_parser_t *parser);
bool app_proto_v2_build(uint8_t cmd,
                        uint8_t seq,
                        uint8_t status,
                        const uint8_t *payload,
                        uint16_t len,
                        uint8_t *out,
                        uint16_t *out_len);
bool app_proto_v2_feed(app_proto_v2_parser_t *parser,
                       uint8_t byte,
                       app_proto_v2_frame_t *frame,
                       bool *frame_ready);

#endif
