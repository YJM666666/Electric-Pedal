#ifndef SERVICE_CURRENT_GUARD_H
#define SERVICE_CURRENT_GUARD_H

/*
 * 电流保护接口：根据动作类型和参数阈值判断过流、防夹和堵转风险。
 */
#include <stdint.h>
#include "pedal_types.h"

typedef enum
{
    CG_MOTION_IDLE = 0,
    CG_MOTION_EXTEND,
    CG_MOTION_RETRACT,
    CG_MOTION_RECOVERY_RETRACT
} current_guard_motion_t;

enum
{
    CURRENT_GUARD_ALERT_L_ANTI_PINCH  = (1UL << 0),
    CURRENT_GUARD_ALERT_R_ANTI_PINCH  = (1UL << 1),
    CURRENT_GUARD_ALERT_L_OVERCURRENT = (1UL << 2),
    CURRENT_GUARD_ALERT_R_OVERCURRENT = (1UL << 3)
};

void current_guard_init(void);
void current_guard_set_motion(step_side_t side, current_guard_motion_t motion);
void current_guard_update_1ms(uint16_t left_raw, uint16_t right_raw);
uint16_t current_guard_get_filtered(step_side_t side);
uint32_t current_guard_take_alert_flags(void);

#endif
