#ifndef SERVICE_EVENT_FLAGS_H
#define SERVICE_EVENT_FLAGS_H

/*
 * 事件标志接口：用于跨中断/主循环传递简单状态变化，避免在中断里执行复杂业务。
 */
#include <stdint.h>
#include "event.h"

#define EVENT_FLAG_NONE                   0UL
#define EVENT_FLAG_BLE_RX_PENDING         (1UL << 0)
#define EVENT_FLAG_U17_RX_PENDING         (1UL << 1)
#define EVENT_FLAG_CAN_RX_PENDING         (1UL << 2)
#define EVENT_FLAG_CAN_STATE_DIRTY        (1UL << 3)
#define EVENT_FLAG_PROTECT_ALERT_PENDING  (1UL << 4)
#define EVENT_FLAG_MOTOR_HALL_PENDING      (1UL << 5)

typedef struct
{
    uint16_t tick_1ms;
    uint16_t tick_10ms;
    uint16_t tick_100ms;
    uint16_t tick_1s;
    uint32_t flags;
} event_flag_snapshot_t;

void event_flags_init(void);
void event_flags_mark(uint32_t flags);
void event_flags_mark_isr(uint32_t flags);
void event_flags_raise_tick_isr(event_id_t tick_id);
void event_flags_take_snapshot(event_flag_snapshot_t *out);

#endif
