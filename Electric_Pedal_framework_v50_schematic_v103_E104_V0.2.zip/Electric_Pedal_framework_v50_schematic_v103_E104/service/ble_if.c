﻿#include "ble_if.h"
#include "app_proto_v2.h"
#include "app_cmd_dispatch.h"
#include "event_report_service.h"
#include "bsp_uart.h"
#include "bsp_board.h"
#include "bsp_platform.h"
#include "bsp_timer.h"
#include "bsp_wdg.h"
#include "ota_service.h"
#include "event_flags.h"
#include <string.h>

#ifndef BSP_BLE_MODULE_E104_BT52
#define BSP_BLE_MODULE_E104_BT52 0U
#endif

#ifndef BSP_BLE_E104_AUTOCONFIG
#define BSP_BLE_E104_AUTOCONFIG 0U
#endif

#if (BSP_PLATFORM_GD32 != 0) && (BSP_BLE_MODULE_E104_BT52 != 0U)
#if defined(BSP_TARGET_GD32C103)
#include "gd32c10x_rcu.h"
#include "gd32c10x_gpio.h"
#else
#include "gd32f1x0_rcu.h"
#include "gd32f1x0_gpio.h"
#endif
#endif


#define BLE_RX_FIFO_SIZE 256U

typedef struct
{
    uint8_t buf[BLE_RX_FIFO_SIZE];
    uint16_t head;
    uint16_t tail;
} ble_fifo_t;

static ble_fifo_t s_fifo;
static ble_if_diag_t s_diag;
static app_proto_v2_parser_t s_parser;
static bool s_link_active = false;

static uint16_t fifo_next(uint16_t idx)
{
    return (uint16_t)((idx + 1U) % BLE_RX_FIFO_SIZE);
}

static bool fifo_push(uint8_t b)
{
    uint16_t next = fifo_next(s_fifo.head);

    if (next == s_fifo.tail) {
        s_diag.rx_overflow_count++;
        s_diag.rx_overflow_latched = true;
        return false;
    }
    s_fifo.buf[s_fifo.head] = b;
    s_fifo.head = next;
    return true;
}

static bool fifo_pop(uint8_t *b)
{
    if ((b == 0) || (s_fifo.head == s_fifo.tail)) {
        return false;
    }

    *b = s_fifo.buf[s_fifo.tail];
    s_fifo.tail = fifo_next(s_fifo.tail);
    return true;
}


#if (BSP_PLATFORM_GD32 != 0) && (BSP_BLE_MODULE_E104_BT52 != 0U)
static void e104_delay_ms(uint32_t ms)
{
    uint32_t start = bsp_timer_now_ms();

    while ((uint32_t)(bsp_timer_now_ms() - start) < ms) {
        bsp_wdg_feed();
    }
}

static void e104_send_at(const char *cmd)
{
    if (cmd == 0) {
        return;
    }
    (void)bsp_uart_send(BSP_UART_PORT_BLE, (const uint8_t *)cmd, strlen(cmd));
    e104_delay_ms(120U);
}
#endif

static void e104_bt52_prepare(void)
{
#if (BSP_PLATFORM_GD32 != 0) && (BSP_BLE_MODULE_E104_BT52 != 0U)
    static const char *const init_cmds[] = {
        "AT",
        "AT+BAUD=7",
        "AT+PARI=0",
        "AT+DATABITS=3",
        "AT+ROLE=0",
        "AT+ADV=1",
        "AT+TRANMD=1",
        "AT+LOGMSG=1", // 0为关闭日志输出，避免干扰通信，1为打开日志输出，方便调试
        "AT+MTU=247",
        "AT+UUIDSVR=FFF0",
        "AT+UUIDSLAVE=FFF1",
        "AT+UUIDMAST=FFF2",
        "AT+NAME=ElectricPedal",
        "AT+RESET"
    };
    size_t i;

    rcu_periph_clock_enable(BSP_BLE_E104_PWR_EN_N_RCU);
    rcu_periph_clock_enable(BSP_BLE_E104_WKP_RCU);

#if defined(BSP_TARGET_GD32C103)
    gpio_init(BSP_BLE_E104_PWR_EN_N_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, BSP_BLE_E104_PWR_EN_N_PIN);
    gpio_init(BSP_BLE_E104_WKP_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, BSP_BLE_E104_WKP_PIN);
#else
    gpio_mode_set(BSP_BLE_E104_PWR_EN_N_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, BSP_BLE_E104_PWR_EN_N_PIN);
    gpio_output_options_set(BSP_BLE_E104_PWR_EN_N_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, BSP_BLE_E104_PWR_EN_N_PIN);
    gpio_mode_set(BSP_BLE_E104_WKP_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, BSP_BLE_E104_WKP_PIN);
    gpio_output_options_set(BSP_BLE_E104_WKP_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, BSP_BLE_E104_WKP_PIN);
#endif

    /* V1.03锛歈5 璁捐浣?BLE-PWR-EN-N 涓轰綆鐢靛钩鏈夋晥锛汦104 鐨?WKP 鎷変綆浠ヤ繚鎸佹ā鍧楀敜閱掋€?*/
    gpio_bit_reset(BSP_BLE_E104_PWR_EN_N_PORT, BSP_BLE_E104_PWR_EN_N_PIN);
    gpio_bit_reset(BSP_BLE_E104_WKP_PORT, BSP_BLE_E104_WKP_PIN);
    e104_delay_ms(1200U);

#if (BSP_BLE_E104_AUTOCONFIG != 0U)
    bsp_uart_clear_rx(BSP_UART_PORT_BLE);
    for (i = 0U; i < (sizeof(init_cmds) / sizeof(init_cmds[0])); ++i) {
        e104_send_at(init_cmds[i]);
    }
    bsp_uart_clear_rx(BSP_UART_PORT_BLE);
#endif
#else
    (void)0;
#endif
}

static void drain_uart_to_fifo(void)
{
    uint8_t buf[32];
    size_t count;
    size_t i;

    do {
        count = bsp_uart_recv(BSP_UART_PORT_BLE, buf, sizeof(buf));
        for (i = 0U; i < count; ++i) {
            (void)fifo_push(buf[i]);
        }
    } while (count == sizeof(buf));
}

static void send_reply(uint8_t cmd, uint8_t seq, uint8_t status, const uint8_t *payload, uint16_t len)
{
    uint8_t frm[APP_PROTO_V2_MAX_FRAME];
    uint16_t out_len = 0U;

    if (app_proto_v2_build(cmd, seq, status, payload, len, frm, &out_len)) {
        (void)bsp_uart_send(BSP_UART_PORT_BLE, frm, out_len);
    }
}

static void activate_link_if_needed(void)
{
    if (s_link_active) {
        return;
    }

    s_link_active = true;
    app_cmd_dispatch_set_link_active(true);
    event_report_service_set_link_active(true);
    event_report_service_notify_link_established();
}

void ble_if_init(void)
{
    e104_bt52_prepare();
    app_cmd_dispatch_init();
    event_report_service_init();
    ota_service_init();
    (void)memset(&s_fifo, 0, sizeof(s_fifo));
    (void)memset(&s_diag, 0, sizeof(s_diag));
    app_proto_v2_parser_init(&s_parser);
    s_link_active = false;
    app_cmd_dispatch_set_link_active(false);
    event_report_service_set_link_active(false);
}

void ble_if_rx_byte_isr(uint8_t byte)
{
    if (fifo_push(byte)) {
        event_flags_mark_isr(EVENT_FLAG_BLE_RX_PENDING);
    }
}

void ble_if_rx_buf_isr(const uint8_t *data, size_t len)
{
    size_t i;
    bool pushed = false;

    if (data == 0) {
        return;
    }
    for (i = 0U; i < len; ++i) {
        if (fifo_push(data[i])) {
            pushed = true;
        }
    }
    if (pushed) {
        event_flags_mark_isr(EVENT_FLAG_BLE_RX_PENDING);
    }
}

void ble_if_poll(void)
{
    uint8_t b;
    app_proto_v2_frame_t f;
    bool ready = false;
    app_cmd_reply_t reply;

    drain_uart_to_fifo();

    while (fifo_pop(&b)) {
        if (!app_proto_v2_feed(&s_parser, b, &f, &ready)) {
            s_diag.frame_error_count++;
            continue;
        }
        if (!ready) {
            continue;
        }

        activate_link_if_needed();
        app_cmd_dispatch_process(&f, &reply);
        if (reply.send_reply) {
            send_reply(f.cmd, f.seq, reply.status, reply.payload, reply.len);
        }
        if (reply.reboot_after_reply) {
            bsp_platform_system_reset();
        }
    }
}

void ble_if_get_diag(ble_if_diag_t *diag)
{
    if (diag == 0) {
        return;
    }

    *diag = s_diag;
    diag->unsupported_cmd_count = app_cmd_dispatch_get_unsupported_count();
    diag->event_drop_count = event_report_service_get_drop_count();
    diag->event_ack_timeout_count = event_report_service_get_ack_timeout_count();
}

bool ble_if_has_rx_overflowed(void)
{
    return s_diag.rx_overflow_latched;
}

void ble_if_clear_rx_overflow(void)
{
    s_diag.rx_overflow_latched = false;
}

void ble_if_on_event(const event_t *ev)
{
    event_report_service_on_event(ev);
}

void ble_if_tick_100ms(void)
{
    event_report_service_tick_100ms();
}


