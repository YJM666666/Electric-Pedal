/*
 * 电机配置画像：保存当前 TB1661B 有刷电机的默认保护参数和动作特性。
 */
#include "motor_profile.h"
#include "bsp_board.h"
#include <string.h>

#ifndef BSP_MOTOR_DRIVE_BACKEND
#define BSP_MOTOR_DRIVE_BACKEND DRV_MOTOR_BACKEND_RELAY_GPIO
#endif

#ifndef BSP_MOTOR_FEEDBACK_FLAGS
#if (BSP_HAS_MOTOR_HALL_INPUT != 0U)
#define BSP_MOTOR_FEEDBACK_FLAGS (MOTOR_FEEDBACK_CURRENT | MOTOR_FEEDBACK_HALL | MOTOR_FEEDBACK_LIMIT_SW)
#else
#define BSP_MOTOR_FEEDBACK_FLAGS (MOTOR_FEEDBACK_CURRENT | MOTOR_FEEDBACK_LIMIT_SW)
#endif
#endif

void motor_profile_load_tb1661b_defaults(motor_profile_t *out)
{
    static const uint16_t th[8] = {
        1600U, 1800U, 2000U, 2200U, 2400U, 2600U, 2800U, 3000U
    };

    if (out == 0) {
        return;
    }

    (void)memset(out, 0, sizeof(*out));
    out->motor_kind = (uint8_t)MOTOR_KIND_BRUSHED_DC;
    out->drive_backend = (uint8_t)BSP_MOTOR_DRIVE_BACKEND;
    out->feedback_flags = (uint8_t)BSP_MOTOR_FEEDBACK_FLAGS;
    out->hall_pulses_per_rev = 8U;
    out->rated_voltage_mv = 12000U;
    out->no_load_current_ma = 1350U;
    out->rated_power_w = 50U;
    out->no_load_speed_rpm_x10 = 135U;
    out->load_5nm_current_ma = 5000U;
    out->load_20nm_current_ma = 10000U;
    out->stall_current_ma = 20000U;
    out->no_pulse_start_grace_ms = 600U;
    out->no_pulse_timeout_ms = 800U;
    out->stall_debounce_ms = 80U;
    out->anti_pinch_backoff_ms = 250U;
    out->default_overcurrent_adc = 3200U;
    (void)memcpy(out->default_anti_pinch_adc, th, sizeof(th));
}

static motor_profile_t s_active_profile;
static bool s_initialized = false;

void motor_profile_init(void)
{
    motor_profile_load_tb1661b_defaults(&s_active_profile);
    s_initialized = true;
}

const motor_profile_t *motor_profile_get(void)
{
    if (!s_initialized) {
        motor_profile_init();
    }

    return &s_active_profile;
}

bool motor_profile_set_active(const motor_profile_t *profile)
{
    if (profile == 0) {
        return false;
    }

    s_active_profile = *profile;
    s_initialized = true;
    return true;
}

bool motor_profile_has_feedback(uint8_t feedback_bit)
{
    const motor_profile_t *profile = motor_profile_get();
    return ((profile->feedback_flags & feedback_bit) != 0U);
}

uint8_t motor_profile_get_drive_backend(void)
{
    return motor_profile_get()->drive_backend;
}
