#ifndef SERVICE_PARAM_H
#define SERVICE_PARAM_H

/*
 * 文件: service/param.h
 * 描述: 系统参数结构与 NVM 存取接口声明。
 * 责任: 提供参数读写、默认值加载与校验接口，供配置与运行时使用。
 */

#include <stdint.h>
#include "project_bool.h"
#include "pedal_types.h"

#define PARAM_MAGIC_VALUE         0x5045444CUL
#define PARAM_FORMAT_VERSION      0x0008U
#define PARAM_FACTORY_CMD_COUNT   9U
#define PARAM_FACTORY_CMD_B1_LEN  10U
#define PARAM_FACTORY_CMD_B2_LEN  10U
#define PARAM_FACTORY_CMD_B3_LEN  0U
#define PARAM_FACTORY_CMD_B4_LEN  0U
#define PARAM_FACTORY_CMD_B5_LEN  10U
#define PARAM_FACTORY_CMD_B6_LEN  13U
#define PARAM_FACTORY_CMD_B7_LEN  14U
#define PARAM_FACTORY_CMD_B8_LEN  12U
#define PARAM_FACTORY_CMD_B9_LEN  22U
#define PARAM_FACTORY_CMD_MAX_SIZE 22U

typedef enum
{
    WELCOME_DRIVER_ONLY = 0,
    WELCOME_BOTH_SIDES
} welcome_mode_t;

typedef enum
{
    HAND_DRIVE_LEFT = 0,
    HAND_DRIVE_RIGHT
} hand_drive_t;

typedef enum
{
    VOICE_LANG_CHINESE = 0,
    VOICE_LANG_ENGLISH = 1
} voice_language_t;

typedef enum
{
    DOOR_POS_FL = 0,
    DOOR_POS_FR,
    DOOR_POS_RL,
    DOOR_POS_RR,
    DOOR_POS_MAX
} door_pos_t;

typedef struct
{
    uint8_t r;
    uint8_t g;
    uint8_t b;
    uint8_t mode;
} light_scene_cfg_t;

typedef struct
{
    uint16_t module_id;
    uint8_t  group_no;
    uint8_t  bit_no;
    uint8_t  active_value;
} signal_trigger_t;

typedef struct
{
    uint16_t module_id;
    uint8_t  hi_group_no;
    uint8_t  lo_group_no;
} speed_signal_cfg_t;

typedef struct
{
    uint32_t         magic;
    uint16_t         format_version;
    uint16_t         reserved0;

    bool             activated;
    uint8_t          area_code[3];

    bool             main_switch_enable;
    bool             welcome_enable;
    bool             anti_pinch_enable;
    uint8_t          anti_pinch_level;      /* 0=关闭，1~8 */

    hand_drive_t     hand_drive;
    bool             sound_enable;
    voice_language_t voice_language;
    bool             light_enable;
    welcome_mode_t   welcome_mode;

    bool             rear_door_reverse;
    bool             left_right_swap;
    bool             motor_left_reverse;
    bool             motor_right_reverse;
    bool             ota_enable;
    bool             magnetic_mode;
    bool             password_enable;

    uint16_t         welcome_hold_seconds;
    uint16_t         wash_hold_seconds;
    uint16_t         extend_timeout_ms;
    uint16_t         retract_timeout_ms;
    uint16_t         recovery_retract_timeout_ms;
    uint16_t         anti_pinch_backoff_ms;
    uint16_t         stall_debounce_ms;
    uint16_t         recovery_stall_debounce_ms;
    uint16_t         can_timeout_ms;

    uint16_t         door_can_id[DOOR_POS_MAX];
    uint8_t          vehicle_type;
    uint8_t          vehicle_config_ver;
    uint16_t         customer_id;
    uint32_t         vehicle_id;
    uint32_t         vehicle_code;
    char             vehicle_code_ascii[17];
    char             serial_ascii[13];
    char             password_ascii[7];
    uint16_t         logo_id;
    uint8_t          feature_flags;
    uint8_t          canfd_data_rate_sel; /* 0=2M，1=5M */
    uint8_t          can_monitor_sel;     /* 0=同时监测，1=仅监测 HS，2=仅监测 LS */
    uint8_t          can_baud_code;
    uint8_t          led_count;
    uint8_t          unactivated_use_count;
    uint8_t          physical_switch_state;
    uint8_t          install_manual_switch;
    uint8_t          wash_function_switch;

    uint16_t         sw_version_major;
    uint16_t         sw_version_minor;
    uint16_t         sw_version_patch;
    uint16_t         reserved1;

    light_scene_cfg_t light_welcome;
    light_scene_cfg_t light_drive;
    light_scene_cfg_t light_turn;
    light_scene_cfg_t light_brake;
    light_scene_cfg_t light_alert;
    uint8_t          light_brightness;
    uint8_t          light_strip_type;
    bool             auto_drive_blue;

    signal_trigger_t door_signal[DOOR_POS_MAX];
    signal_trigger_t headlamp_signal;
    signal_trigger_t ignition_signal;
    signal_trigger_t left_turn_signal;
    signal_trigger_t right_turn_signal;
    signal_trigger_t hazard_signal;
    signal_trigger_t brake_signal;
    signal_trigger_t unlock_signal;
    speed_signal_cfg_t speed_signal;

    uint8_t          factory_cmd[PARAM_FACTORY_CMD_COUNT][PARAM_FACTORY_CMD_MAX_SIZE];
    uint8_t          factory_cmd_len[PARAM_FACTORY_CMD_COUNT];

    uint16_t         adc_left_overcurrent_th;
    uint16_t         adc_right_overcurrent_th;
    uint16_t         adc_left_antipinch_th_lv1;
    uint16_t         adc_left_antipinch_th_lv2;
    uint16_t         adc_left_antipinch_th_lv3;
    uint16_t         adc_left_antipinch_th_lv4;
    uint16_t         adc_left_antipinch_th_lv5;
    uint16_t         adc_left_antipinch_th_lv6;
    uint16_t         adc_left_antipinch_th_lv7;
    uint16_t         adc_left_antipinch_th_lv8;
    uint16_t         adc_right_antipinch_th_lv1;
    uint16_t         adc_right_antipinch_th_lv2;
    uint16_t         adc_right_antipinch_th_lv3;
    uint16_t         adc_right_antipinch_th_lv4;
    uint16_t         adc_right_antipinch_th_lv5;
    uint16_t         adc_right_antipinch_th_lv6;
    uint16_t         adc_right_antipinch_th_lv7;
    uint16_t         adc_right_antipinch_th_lv8;
    uint16_t         adc_left_recovery_overcurrent_th;
    uint16_t         adc_right_recovery_overcurrent_th;
    uint16_t         recovery_no_pulse_start_grace_ms;
    uint16_t         recovery_no_pulse_timeout_ms;
    uint16_t         welcome_start_interval_s;
} system_param_t;

void param_init(void);
void param_load_default(system_param_t *p);
bool param_load_from_nvm(system_param_t *p);
bool param_save_to_nvm(const system_param_t *p);
void param_periodic_1s(void);

const system_param_t *param_get(void);
system_param_t *param_get_mutable(void);
bool param_commit(const system_param_t *candidate);
bool param_validate(const system_param_t *candidate);

bool param_set_activated(bool activated);
bool param_set_area_code(const uint8_t area[3]);
bool param_set_main_switch_enable(bool en);
bool param_set_welcome_enable(bool en);
bool param_set_welcome_mode(welcome_mode_t mode);
bool param_set_welcome_hold_seconds(uint16_t sec);
bool param_set_anti_pinch_enable(bool en);
bool param_set_anti_pinch_level(uint8_t level);
bool param_set_wash_hold_seconds(uint16_t sec);
bool param_set_hand_drive(hand_drive_t mode);
bool param_set_sound_enable(bool en);
bool param_set_voice_language(voice_language_t lang);
bool param_set_light_enable(bool en);
bool param_set_motor_reverse(bool left_rev, bool right_rev);
bool param_set_swap(bool rear_reverse, bool lr_swap);
bool param_set_vehicle_id(uint32_t id);
bool param_set_vehicle_code(uint32_t code);
bool param_set_vehicle_code_ascii(const char *code16);
bool param_set_can_monitor(uint8_t monitor_sel, uint8_t canfd_rate_sel);
bool param_set_door_can_id(door_pos_t pos, uint16_t can_id);
bool param_set_serial_ascii(const char *serial12);
bool param_set_light_scenes(const light_scene_cfg_t *welcome_scene,
                            const light_scene_cfg_t *alert_scene,
                            const light_scene_cfg_t *drive_scene);
bool param_store_factory_cmd(uint8_t slot, const uint8_t *payload, uint8_t len);

uint16_t param_get_left_antipinch_threshold(void);
uint16_t param_get_right_antipinch_threshold(void);
uint16_t param_get_recovery_overcurrent_threshold(step_side_t side);
uint8_t param_get_antipinch_proto_level(void);
bool param_is_dirty(void);

#endif
