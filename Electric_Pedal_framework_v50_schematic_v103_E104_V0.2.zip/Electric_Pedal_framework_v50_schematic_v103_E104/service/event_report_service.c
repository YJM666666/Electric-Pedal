/*
 * 事件上报服务：把故障、状态和确认信息封装为 APP 协议上报，并维护重试/超时。
 */
#include "event_report_service.h"
#include "app_proto_v2.h"
#include "config/protocol/app_proto_v2_ids.h"
#include "bsp_uart.h"
#include "policy.h"
#include "param.h"
#include <string.h>

#define BLE_EVENT_QUEUE_SIZE        16U
#define BLE_EVENT_DATA_MAX          8U
#define BLE_EVENT_ACK_TIMEOUT_MS    300U
#define BLE_EVENT_RETRY_MAX         3U

typedef struct
{
    uint8_t event_id;
    uint8_t event_seq;
    uint8_t data_len;
    uint8_t data[BLE_EVENT_DATA_MAX];
} ble_event_report_t;

typedef struct
{
    bool    active;
    uint8_t event_id;
    uint8_t event_seq;
    uint8_t transport_seq;
    uint8_t data_len;
    uint8_t data[BLE_EVENT_DATA_MAX];
    uint8_t retry_count;
    uint16_t wait_ms;
} ble_event_pending_t;

static bool s_link_active = false;
static bool s_ble_connected_reported = false;
static ble_event_report_t s_evt_queue[BLE_EVENT_QUEUE_SIZE];
static uint8_t s_evt_head = 0U;
static uint8_t s_evt_tail = 0U;
static uint8_t s_evt_count = 0U;
static uint8_t s_next_evt_seq = 0U;
static uint8_t s_next_tx_seq = 0U;
static ble_event_pending_t s_evt_pending;
static policy_status_t s_prev_status;
static bool s_prev_status_valid = false;
static uint32_t s_event_drop_count = 0U;
static uint32_t s_event_ack_timeout_count = 0U;

static void send_reply(uint8_t cmd, uint8_t seq, uint8_t status, const uint8_t *payload, uint16_t len)
{
    uint8_t frm[APP_PROTO_V2_MAX_FRAME];
    uint16_t out_len = 0U;

    if (app_proto_v2_build(cmd, seq, status, payload, len, frm, &out_len)) {
        (void)bsp_uart_send(BSP_UART_PORT_BLE, frm, out_len);
    }
}

static bool step_is_expanded(step_state_t st)
{
    return (st == STEP_STATE_EXTENDED);
}

static uint8_t event_queue_next(uint8_t idx)
{
    return (uint8_t)((idx + 1U) % BLE_EVENT_QUEUE_SIZE);
}

static bool dequeue_app_event(ble_event_report_t *out)
{
    if ((out == 0) || (s_evt_count == 0U)) {
        return false;
    }

    *out = s_evt_queue[s_evt_tail];
    s_evt_tail = event_queue_next(s_evt_tail);
    s_evt_count--;
    return true;
}

bool event_report_service_enqueue_code(uint8_t app_event_id, const uint8_t *data, uint8_t data_len)
{
    ble_event_report_t *slot;

    if (data_len > BLE_EVENT_DATA_MAX) {
        return false;
    }

    if (s_evt_count >= BLE_EVENT_QUEUE_SIZE) {
        s_event_drop_count++;
        return false;
    }

    slot = &s_evt_queue[s_evt_head];
    slot->event_id = app_event_id;
    slot->event_seq = s_next_evt_seq++;
    slot->data_len = data_len;
    if ((data_len > 0U) && (data != 0)) {
        (void)memcpy(slot->data, data, data_len);
    }
    s_evt_head = event_queue_next(s_evt_head);
    s_evt_count++;
    return true;
}

static void retry_pending_event(void)
{
    uint8_t payload[2U + BLE_EVENT_DATA_MAX];

    if (!s_evt_pending.active) {
        return;
    }

    payload[0] = s_evt_pending.event_id;
    payload[1] = s_evt_pending.event_seq;
    if (s_evt_pending.data_len > 0U) {
        (void)memcpy(&payload[2], s_evt_pending.data, s_evt_pending.data_len);
    }
    send_reply(APP_CMD_EVT_ACK,
               s_evt_pending.transport_seq,
               APP_ST_OK,
               payload,
               (uint8_t)(2U + s_evt_pending.data_len));
}

static void try_send_next_event(void)
{
    ble_event_report_t rpt;
    uint8_t payload[2U + BLE_EVENT_DATA_MAX];

    if (!s_link_active || s_evt_pending.active) {
        return;
    }

    if (!dequeue_app_event(&rpt)) {
        return;
    }

    payload[0] = rpt.event_id;
    payload[1] = rpt.event_seq;
    if (rpt.data_len > 0U) {
        (void)memcpy(&payload[2], rpt.data, rpt.data_len);
    }

    s_evt_pending.active = true;
    s_evt_pending.event_id = rpt.event_id;
    s_evt_pending.event_seq = rpt.event_seq;
    s_evt_pending.transport_seq = s_next_tx_seq++;
    s_evt_pending.data_len = rpt.data_len;
    if (rpt.data_len > 0U) {
        (void)memcpy(s_evt_pending.data, rpt.data, rpt.data_len);
    }
    s_evt_pending.retry_count = 0U;
    s_evt_pending.wait_ms = 0U;
    send_reply(APP_CMD_EVT_ACK,
               s_evt_pending.transport_seq,
               APP_ST_OK,
               payload,
               (uint8_t)(2U + rpt.data_len));
}

void event_report_service_handle_ack(uint8_t event_id, uint8_t event_seq, uint8_t ack_result)
{
    if (!s_evt_pending.active) {
        return;
    }

    if ((event_id == s_evt_pending.event_id) &&
        (event_seq == s_evt_pending.event_seq) &&
        (ack_result == 0x00U)) {
        (void)memset(&s_evt_pending, 0, sizeof(s_evt_pending));
        try_send_next_event();
    }
}

static bool map_internal_event_to_app(event_id_t id, uint8_t *app_event_id)
{
    if (app_event_id == 0) {
        return false;
    }

    switch (id)
    {
        case EV_BOOT: *app_event_id = APP_EVENT_POWER_ON; return true;
        case EV_DOOR_FL_OPEN: *app_event_id = APP_EVENT_LF_DOOR_OPEN; return true;
        case EV_DOOR_FL_CLOSE: *app_event_id = APP_EVENT_LF_DOOR_CLOSED; return true;
        case EV_DOOR_RL_OPEN: *app_event_id = APP_EVENT_LR_DOOR_OPEN; return true;
        case EV_DOOR_RL_CLOSE: *app_event_id = APP_EVENT_LR_DOOR_CLOSED; return true;
        case EV_DOOR_FR_OPEN: *app_event_id = APP_EVENT_RF_DOOR_OPEN; return true;
        case EV_DOOR_FR_CLOSE: *app_event_id = APP_EVENT_RF_DOOR_CLOSED; return true;
        case EV_DOOR_RR_OPEN: *app_event_id = APP_EVENT_RR_DOOR_OPEN; return true;
        case EV_DOOR_RR_CLOSE: *app_event_id = APP_EVENT_RR_DOOR_CLOSED; return true;
        case EV_ENTER_WASH: *app_event_id = APP_EVENT_WASH_MODE; return true;
        case EV_ENTER_INSTALL_TEST: *app_event_id = APP_EVENT_PEDAL_SELFTEST; return true;
        case EV_L_OVERCURRENT:
        case EV_R_OVERCURRENT: *app_event_id = APP_EVENT_CURRENT_OVERLOAD; return true;
        case EV_L_TIMEOUT: *app_event_id = APP_EVENT_L_MOTOR_ERROR; return true;
        case EV_R_TIMEOUT: *app_event_id = APP_EVENT_R_MOTOR_ERROR; return true;
        case EV_L_ANTI_PINCH:
        case EV_R_ANTI_PINCH: *app_event_id = APP_EVENT_ANTI_PINCH_ACTIVE; return true;
        default: return false;
    }
}

static void monitor_policy_status_events(void)
{
    policy_status_t st;
    bool prev_any_expanded;
    bool now_any_expanded;

    st = policy_get_status();
    if (!s_prev_status_valid) {
        s_prev_status = st;
        s_prev_status_valid = true;
        return;
    }

    if (!s_link_active) {
        s_prev_status = st;
        return;
    }

    if (!s_prev_status.key_unlocked && st.key_unlocked) {
        (void)event_report_service_enqueue_code(APP_EVENT_PEDAL_UNLOCK, 0, 0U);
    }

    prev_any_expanded = step_is_expanded(s_prev_status.left_state) || step_is_expanded(s_prev_status.right_state);
    now_any_expanded = step_is_expanded(st.left_state) || step_is_expanded(st.right_state);
    if (!prev_any_expanded && now_any_expanded) {
        (void)event_report_service_enqueue_code(APP_EVENT_PEDAL_EXTEND, 0, 0U);
    } else if (prev_any_expanded && !now_any_expanded) {
        (void)event_report_service_enqueue_code(APP_EVENT_PEDAL_CLOSED, 0, 0U);
    }

    if ((s_prev_status.mode != SYS_INSTALL_TEST) && (st.mode == SYS_INSTALL_TEST)) {
        (void)event_report_service_enqueue_code(APP_EVENT_PEDAL_SELFTEST, 0, 0U);
    }

    if ((s_prev_status.mode != SYS_WASH) && (st.mode == SYS_WASH)) {
        (void)event_report_service_enqueue_code(APP_EVENT_WASH_MODE, 0, 0U);
    }

    s_prev_status = st;
}

void event_report_service_init(void)
{
    (void)memset(&s_evt_queue, 0, sizeof(s_evt_queue));
    (void)memset(&s_evt_pending, 0, sizeof(s_evt_pending));
    s_link_active = false;
    s_ble_connected_reported = false;
    s_evt_head = 0U;
    s_evt_tail = 0U;
    s_evt_count = 0U;
    s_next_evt_seq = 0U;
    s_next_tx_seq = 0U;
    s_prev_status_valid = false;
    s_event_drop_count = 0U;
    s_event_ack_timeout_count = 0U;
}

void event_report_service_set_link_active(bool active)
{
    s_link_active = active;
}

void event_report_service_notify_link_established(void)
{
    (void)event_report_service_enqueue_code(APP_EVENT_POWER_ON, 0, 0U);
    if (!s_ble_connected_reported) {
        (void)event_report_service_enqueue_code(APP_EVENT_BLE_CONNECTED, 0, 0U);
        s_ble_connected_reported = true;
    }
}

void event_report_service_on_event(const event_t *ev)
{
    uint8_t app_event_id;

    if (ev == 0) {
        return;
    }

    monitor_policy_status_events();

    if (!s_link_active) {
        return;
    }

    if (map_internal_event_to_app(ev->id, &app_event_id)) {
        (void)event_report_service_enqueue_code(app_event_id, 0, 0U);
    }
}

void event_report_service_tick_100ms(void)
{
    if (!s_link_active) {
        return;
    }

    if (s_evt_pending.active) {
        s_evt_pending.wait_ms = (uint16_t)(s_evt_pending.wait_ms + 100U);
        if (s_evt_pending.wait_ms >= BLE_EVENT_ACK_TIMEOUT_MS) {
            s_event_ack_timeout_count++;
            s_evt_pending.wait_ms = 0U;
            if (s_evt_pending.retry_count < BLE_EVENT_RETRY_MAX) {
                s_evt_pending.retry_count++;
                retry_pending_event();
            } else {
                (void)memset(&s_evt_pending, 0, sizeof(s_evt_pending));
            }
        }
        return;
    }

    try_send_next_event();
}

uint32_t event_report_service_get_drop_count(void)
{
    return s_event_drop_count;
}

uint32_t event_report_service_get_ack_timeout_count(void)
{
    return s_event_ack_timeout_count;
}
