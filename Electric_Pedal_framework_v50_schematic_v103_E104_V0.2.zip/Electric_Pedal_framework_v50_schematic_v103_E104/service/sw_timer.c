/*
 * 软件时间基准：基于 BSP 毫秒计数提供简单的延时判断和时间差计算。
 */
#include "sw_timer.h"

static volatile uint32_t s_ms = 0U;

void sw_timer_init(void)
{
    s_ms = 0U;
}

void sw_timer_tick_1ms(void)
{
    s_ms++;
}

uint32_t sw_timer_now_ms(void)
{
    return s_ms;
}

bool sw_timer_is_expired(uint32_t now_ms, uint32_t deadline_ms)
{
    return ((int32_t)(now_ms - deadline_ms) >= 0) ? true : false;
}
