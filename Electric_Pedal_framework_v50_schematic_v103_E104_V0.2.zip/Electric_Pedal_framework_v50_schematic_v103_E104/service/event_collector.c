#include "service/event_collector.h"
#include "event_flags.h"
#include "ble_if.h"
#include "can_if.h"
#include "u17_link.h"
#include "current_guard.h"
#include "motor_pulse_latch.h"
#include "event.h"
#include <string.h>

typedef struct
{
    bool initialized;
    can_if_signal_snapshot_t can_snapshot;
} event_collector_latch_t;

static event_collector_latch_t s_latch;

static void post_event(event_id_t id, event_source_t source)
{
    event_t ev;

    ev.id = id;
    ev.source = source;
    ev.param_u32 = 0U;
    ev.param_ptr = 0;
    (void)event_push(&ev);
}

static uint16_t saturating_add_u16(uint16_t a, uint16_t b)
{
    uint32_t sum = (uint32_t)a + (uint32_t)b;

    return (sum > 0xFFFFU) ? 0xFFFFU : (uint16_t)sum;
}

static void merge_snapshot(event_flag_snapshot_t *dst, const event_flag_snapshot_t *src)
{
    if ((dst == 0) || (src == 0)) {
        return;
    }

    dst->tick_1ms = saturating_add_u16(dst->tick_1ms, src->tick_1ms);
    dst->tick_10ms = saturating_add_u16(dst->tick_10ms, src->tick_10ms);
    dst->tick_100ms = saturating_add_u16(dst->tick_100ms, src->tick_100ms);
    dst->tick_1s = saturating_add_u16(dst->tick_1s, src->tick_1s);
    dst->flags |= src->flags;
}

static void translate_ticks(const event_flag_snapshot_t *snapshot)
{
    uint16_t i;

    if (snapshot == 0) {
        return;
    }

    for (i = 0U; i < snapshot->tick_1ms; ++i) {
        post_event(EV_TICK_1MS, EV_SRC_TIMER);
    }
    for (i = 0U; i < snapshot->tick_10ms; ++i) {
        post_event(EV_TICK_10MS, EV_SRC_TIMER);
    }
    for (i = 0U; i < snapshot->tick_100ms; ++i) {
        post_event(EV_TICK_100MS, EV_SRC_TIMER);
    }
    for (i = 0U; i < snapshot->tick_1s; ++i) {
        post_event(EV_TICK_1S, EV_SRC_TIMER);
    }
}

static void translate_can_edges(void)
{
    static const event_id_t door_open_evt[DOOR_POS_MAX] = {
        EV_DOOR_FL_OPEN, EV_DOOR_FR_OPEN, EV_DOOR_RL_OPEN, EV_DOOR_RR_OPEN
    };
    static const event_id_t door_close_evt[DOOR_POS_MAX] = {
        EV_DOOR_FL_CLOSE, EV_DOOR_FR_CLOSE, EV_DOOR_RL_CLOSE, EV_DOOR_RR_CLOSE
    };
    can_if_signal_snapshot_t now;
    uint32_t i;

    can_if_get_signal_snapshot(&now);
    if (!s_latch.initialized) {
        s_latch.can_snapshot = now;
        s_latch.initialized = true;
        return;
    }

    if (s_latch.can_snapshot.signal_valid != now.signal_valid) {
        post_event(now.signal_valid ? EV_CAN_RECOVER : EV_CAN_TIMEOUT, EV_SRC_CAN);
    }

    if (s_latch.can_snapshot.speed_above_8 != now.speed_above_8) {
        post_event(now.speed_above_8 ? EV_SPEED_ABOVE_8 : EV_SPEED_BELOW_8, EV_SRC_CAN);
    }

    if (s_latch.can_snapshot.unlock_active != now.unlock_active) {
        post_event(now.unlock_active ? EV_KEY_UNLOCK : EV_KEY_LOCK, EV_SRC_CAN);
    }

    for (i = 0U; i < (uint32_t)DOOR_POS_MAX; ++i) {
        if (s_latch.can_snapshot.door_open[i] != now.door_open[i]) {
            post_event(now.door_open[i] ? door_open_evt[i] : door_close_evt[i], EV_SRC_CAN);
        }
    }

    if (s_latch.can_snapshot.turn_left != now.turn_left) {
        post_event(now.turn_left ? EV_TURN_LEFT_ON : EV_TURN_LEFT_OFF, EV_SRC_CAN);
    }
    if (s_latch.can_snapshot.turn_right != now.turn_right) {
        post_event(now.turn_right ? EV_TURN_RIGHT_ON : EV_TURN_RIGHT_OFF, EV_SRC_CAN);
    }
    if (s_latch.can_snapshot.brake != now.brake) {
        post_event(now.brake ? EV_BRAKE_ON : EV_BRAKE_OFF, EV_SRC_CAN);
    }
    if (s_latch.can_snapshot.headlamp != now.headlamp) {
        post_event(now.headlamp ? EV_HEADLAMP_ON : EV_HEADLAMP_OFF, EV_SRC_CAN);
    }
    if (s_latch.can_snapshot.auto_drive != now.auto_drive) {
        post_event(now.auto_drive ? EV_AUTO_DRIVE_ON : EV_AUTO_DRIVE_OFF, EV_SRC_CAN);
    }

    s_latch.can_snapshot = now;
}

static void translate_current_guard_alerts(void)
{
    uint32_t alerts = current_guard_take_alert_flags();

    if ((alerts & CURRENT_GUARD_ALERT_L_ANTI_PINCH) != 0U) {
        post_event(EV_L_ANTI_PINCH, EV_SRC_PROTECT);
    }
    if ((alerts & CURRENT_GUARD_ALERT_R_ANTI_PINCH) != 0U) {
        post_event(EV_R_ANTI_PINCH, EV_SRC_PROTECT);
    }
    if ((alerts & CURRENT_GUARD_ALERT_L_OVERCURRENT) != 0U) {
        post_event(EV_L_OVERCURRENT, EV_SRC_PROTECT);
    }
    if ((alerts & CURRENT_GUARD_ALERT_R_OVERCURRENT) != 0U) {
        post_event(EV_R_OVERCURRENT, EV_SRC_PROTECT);
    }
}

static void post_pulse_event(event_id_t id, uint16_t pulses)
{
    event_t ev;

    if (pulses == 0U) {
        return;
    }

    ev.id = id;
    ev.source = EV_SRC_HALL;
    ev.param_u32 = pulses;
    ev.param_ptr = 0;
    (void)event_push(&ev);
}

static void translate_motor_hall_pulses(void)
{
    motor_pulse_snapshot_t snapshot;

    (void)memset(&snapshot, 0, sizeof(snapshot));
    motor_pulse_latch_take_snapshot(&snapshot);
    post_pulse_event(EV_L_HALL_PULSE, snapshot.pulses[STEP_SIDE_LEFT]);
    post_pulse_event(EV_R_HALL_PULSE, snapshot.pulses[STEP_SIDE_RIGHT]);
}

void event_collector_init(void)
{
    event_flags_init();
    motor_pulse_latch_init();
    (void)memset(&s_latch, 0, sizeof(s_latch));
    can_if_get_signal_snapshot(&s_latch.can_snapshot);
    s_latch.initialized = true;
}

void event_collector_poll(void)
{
    event_flag_snapshot_t first;
    event_flag_snapshot_t second;
    uint32_t deferred_source_flags;

    (void)memset(&first, 0, sizeof(first));
    (void)memset(&second, 0, sizeof(second));

    event_flags_take_snapshot(&first);

    if ((first.flags & EVENT_FLAG_BLE_RX_PENDING) != 0U) {
        ble_if_poll();
    }
    if ((first.flags & EVENT_FLAG_U17_RX_PENDING) != 0U) {
        u17_link_poll();
    }

    /* CAN 保留 BSP 轮询作为回退；轮询不再直接生成业务事件。 */
    can_if_poll();

    event_flags_take_snapshot(&second);
    merge_snapshot(&first, &second);

    translate_ticks(&first);

    if ((first.flags & EVENT_FLAG_CAN_STATE_DIRTY) != 0U) {
        translate_can_edges();
    }
    if ((first.flags & EVENT_FLAG_PROTECT_ALERT_PENDING) != 0U) {
        translate_current_guard_alerts();
    }
    if ((first.flags & EVENT_FLAG_MOTOR_HALL_PENDING) != 0U) {
        translate_motor_hall_pulses();
    }

    deferred_source_flags = second.flags & (EVENT_FLAG_BLE_RX_PENDING |
                                            EVENT_FLAG_U17_RX_PENDING |
                                            EVENT_FLAG_CAN_RX_PENDING);
    if (deferred_source_flags != 0U) {
        event_flags_mark(deferred_source_flags);
    }
}
