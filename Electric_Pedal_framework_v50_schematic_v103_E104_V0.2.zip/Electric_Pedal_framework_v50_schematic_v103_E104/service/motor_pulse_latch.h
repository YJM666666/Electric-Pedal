#ifndef SERVICE_MOTOR_PULSE_LATCH_H
#define SERVICE_MOTOR_PULSE_LATCH_H

/*
 * 脉冲锁存接口：用于电机霍尔中断和反馈计算之间传递脉冲增量。
 */
#include "project_bool.h"
#include "pedal_types.h"
#include <stdint.h>

typedef struct
{
    uint16_t pulses[STEP_SIDE_MAX];
} motor_pulse_snapshot_t;

void motor_pulse_latch_init(void);
void motor_pulse_latch_on_edge_isr(step_side_t side);
void motor_pulse_latch_add_mock(step_side_t side, uint16_t pulses);
void motor_pulse_latch_take_snapshot(motor_pulse_snapshot_t *out);

#endif
