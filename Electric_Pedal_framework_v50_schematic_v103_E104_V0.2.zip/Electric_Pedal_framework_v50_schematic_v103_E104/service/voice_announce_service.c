#include "voice_announce_service.h"
#include "drv_voice.h"
#include "param.h"
#include "u17_link.h"
#include <string.h>

#define VOICE_ANNOUNCE_COOLDOWN_10MS   30U
typedef struct
{
    bool pending_valid;
    voice_id_t pending_id;
    uint16_t cooldown_10ms;
} voice_announce_ctx_t;

static voice_announce_ctx_t s_ctx;

static bool sound_allowed(void)
{
    const system_param_t *p = param_get();
    return p->sound_enable;
}

static voice_language_t current_lang(void)
{
    const system_param_t *p = param_get();
    return p->voice_language;
}

static bool event_to_voice(const event_t *ev, voice_id_t *out_id, bool *fault_buzz)
{
    *out_id = VOICE_ID_NONE;
    *fault_buzz = false;

    switch (ev->id)
    {
        case EV_BOOT:           *out_id = VOICE_ID_ECU_POWER_ON; return true;
        case EV_DOOR_FL_OPEN:   *out_id = VOICE_ID_LF_DOOR_OPEN; return true;
        case EV_DOOR_RL_OPEN:   *out_id = VOICE_ID_LR_DOOR_OPEN; return true;
        case EV_DOOR_FR_OPEN:   *out_id = VOICE_ID_RF_DOOR_OPEN; return true;
        case EV_DOOR_RR_OPEN:   *out_id = VOICE_ID_RR_DOOR_OPEN; return true;
        case EV_L_EXT_CMD:
        case EV_R_EXT_CMD:      *out_id = VOICE_ID_STEP_EXTENDING; return true;
        case EV_L_RET_CMD:
        case EV_R_RET_CMD:      *out_id = VOICE_ID_STEP_RETRACTING; return true;
        case EV_MAIN_SWITCH_OFF:*out_id = VOICE_ID_STEP_DISABLED; return true;
        case EV_L_TIMEOUT:      *out_id = VOICE_ID_LEFT_MOTOR_ERROR; *fault_buzz = true; return true;
        case EV_R_TIMEOUT:      *out_id = VOICE_ID_RIGHT_MOTOR_ERROR; *fault_buzz = true; return true;
        case EV_L_OVERCURRENT:  *out_id = VOICE_ID_LEFT_CURRENT_OVER; *fault_buzz = true; return true;
        case EV_R_OVERCURRENT:  *out_id = VOICE_ID_RIGHT_CURRENT_OVER; *fault_buzz = true; return true;
        case EV_L_ANTI_PINCH:
        case EV_R_ANTI_PINCH:   *out_id = VOICE_ID_ANTI_PINCH_ACTIVE; *fault_buzz = true; return true;
        case EV_CAN_TIMEOUT:    *out_id = VOICE_ID_CAN_SIGNAL_LOST; *fault_buzz = true; return true;
        default:                return false;
    }
}

static bool try_start_voice(voice_id_t id)
{
    if (!sound_allowed()) {
        return true;
    }
    if (!u17_link_is_online()) {
        return false;
    }
    if (drv_voice_is_busy()) {
        return false;
    }
    if (!drv_voice_play(id, current_lang())) {
        return false;
    }
    s_ctx.cooldown_10ms = VOICE_ANNOUNCE_COOLDOWN_10MS;
    return true;
}

void voice_announce_service_init(void)
{
    (void)memset(&s_ctx, 0, sizeof(s_ctx));
    drv_voice_init();
}

void voice_announce_service_tick_10ms(void)
{
    if (s_ctx.cooldown_10ms > 0U) {
        s_ctx.cooldown_10ms--;
    }

    if (s_ctx.pending_valid && (s_ctx.cooldown_10ms == 0U) && !drv_voice_is_busy()) {
        if (try_start_voice(s_ctx.pending_id)) {
            s_ctx.pending_valid = false;
            s_ctx.pending_id = VOICE_ID_NONE;
        }
    }
}

void voice_announce_service_on_event(const event_t *ev)
{
    voice_id_t id;
    bool fault_buzz;

    if (ev == 0) {
        return;
    }

    if (!event_to_voice(ev, &id, &fault_buzz)) {
        return;
    }

    (void)fault_buzz; /* 当前 U17 硬件无蜂鸣器，改用语音播报代替。 */

    if (id == VOICE_ID_NONE) {
        return;
    }

    if (!try_start_voice(id)) {
        s_ctx.pending_valid = true;
        s_ctx.pending_id = id;
    }
}
