#include "u17_link.h"
#include "u17_proto.h"
#include "bsp_uart.h"
#include "bsp_board.h"
#include "fault.h"
#include "param.h"
#include <string.h>

#define U17_LINK_HEARTBEAT_PERIOD_10MS  20U
#define U17_LINK_OFFLINE_TIMEOUT_10MS   150U
#define U17_LINK_MISS_LIMIT             3U
#define U17_LINK_RECOVER_STABLE_COUNT   2U
#define U17_LINK_TX_BUF_SIZE            U17_PROTO_MAX_FRAME

volatile uint32_t g_u12_u17_start_request_count = 0U;
volatile uint32_t g_u12_u17_send_fail_count = 0U;
volatile uint32_t g_u12_u17_param_sync_try_count = 0U;
volatile uint32_t g_u12_u17_heartbeat_try_count = 0U;

typedef struct
{
    bool     active;
    uint8_t  cmd;
    uint16_t seq;
    uint8_t  frame[U17_PROTO_MAX_FRAME];
    uint16_t frame_len;
    uint8_t  retry_count;
    uint16_t wait_tick_10ms;
} u17_pending_tx_t;

typedef struct
{
    uint32_t tx_frame_count;
    uint32_t rx_frame_count;
    uint32_t rx_crc_error_count;
    uint32_t rx_drop_count;
    uint32_t heartbeat_timeout_count;
    uint32_t request_retry_count;
    uint32_t request_timeout_count;
    uint16_t tx_sequence;
    uint16_t heartbeat_tick_10ms;
    uint16_t since_rx_tick_10ms;
    uint8_t  heartbeat_miss_count;
    uint8_t  heartbeat_recover_count;
    uint32_t heartbeat_miss_total;
    uint32_t heartbeat_recover_total;
    u17_link_state_t link_state;
    bool     link_online;
    bool     param_sync_pending;
    bool     timeout_latched;
    bool     boot_seen;
    u17_pending_tx_t pending_param;
    u17_pending_tx_t pending_heartbeat;
    u17_pending_tx_t pending_step[STEP_SIDE_MAX];
    u17_pending_tx_t pending_light;
    u17_pending_tx_t pending_voice;
} u17_link_ctx_t;

static u17_link_ctx_t s_ctx;
static u17_proto_parser_t s_parser;
static u17_remote_status_t s_remote;

static void put_le16(uint8_t *dst, uint16_t value)
{
    dst[0] = (uint8_t)(value & 0xFFU);
    dst[1] = (uint8_t)((value >> 8U) & 0xFFU);
}

static uint16_t get_le16(const uint8_t *src)
{
    return (uint16_t)((uint16_t)src[0] | ((uint16_t)src[1] << 8U));
}

static uint32_t get_le32(const uint8_t *src)
{
    return (uint32_t)src[0] |
           ((uint32_t)src[1] << 8U) |
           ((uint32_t)src[2] << 16U) |
           ((uint32_t)src[3] << 24U);
}

static uint16_t next_sequence(void)
{
    s_ctx.tx_sequence++;
    if (s_ctx.tx_sequence == 0U) {
        s_ctx.tx_sequence = 1U;
    }
    return s_ctx.tx_sequence;
}

static bool send_frame_bytes(const uint8_t *frame, uint16_t frame_len)
{
    if ((frame == 0) || (frame_len == 0U)) {
        return false;
    }

    if (bsp_uart_send(BSP_UART_PORT_U17, frame, frame_len) != frame_len) {
        g_u12_u17_send_fail_count++;
        s_ctx.rx_drop_count++;
        return false;
    }

    s_ctx.tx_frame_count++;
    return true;
}

static void pending_reset(u17_pending_tx_t *pending)
{
    if (pending == 0) {
        return;
    }

    (void)memset(pending, 0, sizeof(*pending));
}

static bool prepare_pending_tx(u17_pending_tx_t *pending,
                               uint8_t class_flags,
                               uint8_t cmd,
                               const uint8_t *payload,
                               uint8_t payload_len)
{
    uint16_t frame_len;
    uint16_t seq;

    if (pending == 0) {
        return false;
    }

    seq = next_sequence();
    if (!u17_proto_build(class_flags,
                         cmd,
                         seq,
                         0U,
                         payload,
                         payload_len,
                         pending->frame,
                         &frame_len)) {
        return false;
    }

    pending->active = true;
    pending->cmd = cmd;
    pending->seq = seq;
    pending->frame_len = frame_len;
    pending->retry_count = 0U;
    pending->wait_tick_10ms = 0U;
    return true;
}


static bool start_request(u17_pending_tx_t *pending,
                          uint8_t class_flags,
                          uint8_t cmd,
                          const uint8_t *payload,
                          uint8_t payload_len)
{
    if (pending->active) {
        return false;
    }

    g_u12_u17_start_request_count++;
    if (!prepare_pending_tx(pending, class_flags, cmd, payload, payload_len)) {
        return false;
    }

    if (!send_frame_bytes(pending->frame, pending->frame_len)) {
        pending_reset(pending);
        return false;
    }
    return true;
}

static bool resend_pending(u17_pending_tx_t *pending)
{
    if ((pending == 0) || !pending->active) {
        return false;
    }

    pending->wait_tick_10ms = 0U;
    pending->retry_count++;
    s_ctx.request_retry_count++;
    return send_frame_bytes(pending->frame, pending->frame_len);
}

static void note_request_timeout(u17_pending_tx_t *pending)
{
    if ((pending == 0) || !pending->active) {
        return;
    }

    if (pending == &s_ctx.pending_heartbeat) {
        s_ctx.heartbeat_timeout_count++;
        s_ctx.heartbeat_miss_total++;
        if (s_ctx.heartbeat_miss_count < 0xFFU) {
            s_ctx.heartbeat_miss_count++;
        }
        s_ctx.heartbeat_recover_count = 0U;
        if (s_ctx.heartbeat_miss_count >= U17_LINK_MISS_LIMIT) {
            s_ctx.link_online = false;
            s_ctx.link_state = U17_LINK_STATE_OFFLINE;
            s_ctx.timeout_latched = true;
            fault_set(FAULT_U17_LINK);
        } else {
            s_ctx.link_state = U17_LINK_STATE_LOST;
        }
        pending_reset(pending);
        return;
    }

    s_ctx.request_timeout_count++;
    s_ctx.timeout_latched = true;
    fault_set(FAULT_U17_LINK);

    if (pending == &s_ctx.pending_param) {
        s_ctx.param_sync_pending = true;
    }
    pending_reset(pending);
}

static void service_pending_timeout(u17_pending_tx_t *pending)
{
    if ((pending == 0) || !pending->active) {
        return;
    }

    if (pending->wait_tick_10ms < 0xFFFFU) {
        pending->wait_tick_10ms++;
    }

    if (pending->wait_tick_10ms < BSP_UART_LINK_RETRY_TMO_10MS) {
        return;
    }

    if (pending->retry_count < BSP_UART_LINK_MAX_RETRY) {
        (void)resend_pending(pending);
    } else {
        note_request_timeout(pending);
    }
}

static void complete_pending(u17_pending_tx_t *pending, bool ok)
{
    if ((pending == 0) || !pending->active) {
        return;
    }

    if (!ok) {
        s_ctx.rx_drop_count++;
    }

    if (pending == &s_ctx.pending_heartbeat) {
        if (ok) {
            if (s_ctx.heartbeat_miss_count != 0U) {
                s_ctx.heartbeat_recover_count++;
                s_ctx.heartbeat_recover_total++;
            }
            s_ctx.heartbeat_miss_count = 0U;
            if (s_ctx.heartbeat_recover_count >= U17_LINK_RECOVER_STABLE_COUNT) {
                s_ctx.heartbeat_recover_count = U17_LINK_RECOVER_STABLE_COUNT;
            }
            s_ctx.link_online = true;
            s_ctx.link_state = U17_LINK_STATE_ONLINE;
            s_ctx.timeout_latched = false;
            fault_clear(FAULT_U17_LINK);
        }
    } else if (pending == &s_ctx.pending_param) {
        s_ctx.param_sync_pending = false;
    }

    pending_reset(pending);
}

static u17_pending_tx_t *find_pending_by_ack(uint16_t ack_seq)
{
    uint32_t i;

    if ((s_ctx.pending_param.active) && (s_ctx.pending_param.seq == ack_seq)) {
        return &s_ctx.pending_param;
    }
    if ((s_ctx.pending_heartbeat.active) && (s_ctx.pending_heartbeat.seq == ack_seq)) {
        return &s_ctx.pending_heartbeat;
    }
    for (i = 0U; i < (uint32_t)STEP_SIDE_MAX; ++i) {
        if ((s_ctx.pending_step[i].active) && (s_ctx.pending_step[i].seq == ack_seq)) {
            return &s_ctx.pending_step[i];
        }
    }
    if ((s_ctx.pending_light.active) && (s_ctx.pending_light.seq == ack_seq)) {
        return &s_ctx.pending_light;
    }
    if ((s_ctx.pending_voice.active) && (s_ctx.pending_voice.seq == ack_seq)) {
        return &s_ctx.pending_voice;
    }
    return 0;
}

static uint16_t pack_param_snapshot(uint8_t *payload, uint16_t max_len)
{
    const system_param_t *param = param_get();
    uint16_t ofs = 0U;

    if ((payload == 0) || (max_len < 39U) || (param == 0)) {
        return 0U;
    }

    payload[ofs++] = param->motor_left_reverse ? 1U : 0U;
    payload[ofs++] = param->motor_right_reverse ? 1U : 0U;
    payload[ofs++] = param->anti_pinch_enable ? 1U : 0U;
    payload[ofs++] = param->anti_pinch_level;
    payload[ofs++] = (param->hand_drive == HAND_DRIVE_RIGHT) ? 1U : 0U;
    payload[ofs++] = param->rear_door_reverse ? 1U : 0U;
    payload[ofs++] = param->left_right_swap ? 1U : 0U;
    payload[ofs++] = param->sound_enable ? 1U : 0U;

    payload[ofs++] = param->light_welcome.r;
    payload[ofs++] = param->light_welcome.g;
    payload[ofs++] = param->light_welcome.b;
    payload[ofs++] = param->light_welcome.mode;

    payload[ofs++] = param->light_alert.r;
    payload[ofs++] = param->light_alert.g;
    payload[ofs++] = param->light_alert.b;
    payload[ofs++] = param->light_alert.mode;

    payload[ofs++] = param->light_drive.r;
    payload[ofs++] = param->light_drive.g;
    payload[ofs++] = param->light_drive.b;
    payload[ofs++] = param->light_drive.mode;

    put_le16(&payload[ofs], param->extend_timeout_ms);
    ofs += 2U;
    put_le16(&payload[ofs], param->retract_timeout_ms);
    ofs += 2U;
    put_le16(&payload[ofs], param->anti_pinch_backoff_ms);
    ofs += 2U;
    put_le16(&payload[ofs], param->stall_debounce_ms);
    ofs += 2U;

    put_le16(&payload[ofs], param->adc_left_overcurrent_th);
    ofs += 2U;
    put_le16(&payload[ofs], param->adc_right_overcurrent_th);
    ofs += 2U;
    put_le16(&payload[ofs], param_get_left_antipinch_threshold());
    ofs += 2U;
    put_le16(&payload[ofs], param_get_right_antipinch_threshold());
    ofs += 2U;

    put_le16(&payload[ofs], (uint16_t)(param->vehicle_code & 0xFFFFUL));
    ofs += 2U;
    put_le16(&payload[ofs], (uint16_t)((param->vehicle_code >> 16U) & 0xFFFFUL));
    ofs += 2U;
    put_le16(&payload[ofs], param->can_timeout_ms);
    ofs += 2U;

    return ofs;
}

static void note_rx_alive(void)
{
    s_ctx.rx_frame_count++;
    s_ctx.since_rx_tick_10ms = 0U;
    s_ctx.link_online = true;
    s_ctx.link_state = U17_LINK_STATE_ONLINE;
    s_ctx.timeout_latched = false;
    fault_clear(FAULT_U17_LINK);
}

static void handle_rsp(const u17_proto_frame_t *frame)
{
    uint8_t result;
    u17_pending_tx_t *pending;

    if ((frame == 0) || (frame->payload_len < 1U)) {
        s_ctx.rx_drop_count++;
        return;
    }

    pending = find_pending_by_ack(frame->ack_seq);
    result = frame->payload[0];

    if (pending != 0) {
        complete_pending(pending, (result == U17_PROTO_RESULT_OK));
        return;
    }

    s_ctx.rx_drop_count++;
}

static void handle_boot_evt(const u17_proto_frame_t *frame)
{
    if ((frame == 0) || (frame->payload_len < 3U)) {
        s_ctx.rx_drop_count++;
        return;
    }

    s_ctx.boot_seen = true;
    s_remote.boot_seen = true;
    s_remote.slave_ready = ((frame->payload[1] & U17_PROTO_BOOTF_READY) != 0U);
}

static void handle_status_evt(const u17_proto_frame_t *frame)
{
    const uint8_t *p;

    if ((frame == 0) || (frame->payload_len < 13U)) {
        s_ctx.rx_drop_count++;
        return;
    }

    p = frame->payload;
    s_remote.left_ext_limit = ((p[0] & U17_PROTO_STATUSF_L_EXT) != 0U);
    s_remote.left_ret_limit = ((p[0] & U17_PROTO_STATUSF_L_RET) != 0U);
    s_remote.right_ext_limit = ((p[0] & U17_PROTO_STATUSF_R_EXT) != 0U);
    s_remote.right_ret_limit = ((p[0] & U17_PROTO_STATUSF_R_RET) != 0U);
    s_remote.light_enabled = ((p[0] & U17_PROTO_STATUSF_LIGHT) != 0U);
    s_remote.buzzer_enabled = false; /* 当前 U17 硬件无蜂鸣器�?*/
    s_remote.slave_ready = ((p[0] & U17_PROTO_STATUSF_READY) != 0U);
    s_remote.voice_busy = ((p[0] & U17_PROTO_STATUSF_VOICE) != 0U);
    s_remote.left_action = (step_action_t)p[1];
    s_remote.right_action = (step_action_t)p[2];
    s_remote.active_light_scene = p[3];
    s_remote.active_light_cfg.r = p[4];
    s_remote.active_light_cfg.g = p[5];
    s_remote.active_light_cfg.b = p[6];
    s_remote.active_light_cfg.mode = p[7];
    s_remote.left_current_raw = get_le16(&p[8]);
    s_remote.right_current_raw = get_le16(&p[10]);
    s_remote.fault_mask = 0U;
}

static void handle_fault_evt(const u17_proto_frame_t *frame)
{
    if ((frame == 0) || (frame->payload_len < 4U)) {
        s_ctx.rx_drop_count++;
        return;
    }

    s_remote.fault_mask = get_le32(frame->payload);
}

static void handle_frame(const u17_proto_frame_t *frame)
{
    uint8_t frame_class;

    if (frame == 0) {
        return;
    }

    note_rx_alive();
    frame_class = (uint8_t)(frame->flags & U17_PROTO_FLAG_CLASS_MASK);

    switch (frame_class)
    {
        case U17_PROTO_CLASS_RSP:
            handle_rsp(frame);
            break;

        case U17_PROTO_CLASS_EVT:
            switch (frame->cmd)
            {
                case U17_CMD_BOOT_REPORT:
                    handle_boot_evt(frame);
                    break;

                case U17_CMD_STATUS_REPORT:
                    handle_status_evt(frame);
                    break;

                case U17_CMD_FAULT_REPORT:
                    handle_fault_evt(frame);
                    break;

                default:
                    s_ctx.rx_drop_count++;
                    break;
            }
            break;

        default:
            s_ctx.rx_drop_count++;
            break;
    }
}

void u17_link_init(void)
{
    (void)memset(&s_ctx, 0, sizeof(s_ctx));
    (void)memset(&s_remote, 0, sizeof(s_remote));
    u17_proto_parser_init(&s_parser);
    s_ctx.param_sync_pending = true;
    s_ctx.link_state = U17_LINK_STATE_INIT;
}

void u17_link_poll(void)
{
    uint8_t rx_buf[32];
    size_t rx_len;
    size_t i;
    u17_proto_frame_t frame;
    bool frame_ready;

    do {
        rx_len = bsp_uart_recv(BSP_UART_PORT_U17, rx_buf, sizeof(rx_buf));
        for (i = 0U; i < rx_len; ++i) {
            if (!u17_proto_parser_feed(&s_parser, rx_buf[i], &frame, &frame_ready)) {
                s_ctx.rx_crc_error_count++;
                continue;
            }
            if (frame_ready) {
                handle_frame(&frame);
            }
        }
    } while (rx_len > 0U);
}

void u17_link_tick_10ms(void)
{
    uint8_t hb_payload[2];
    uint8_t param_payload[U17_PROTO_MAX_PAYLOAD];
    uint16_t payload_len;

    if (s_ctx.since_rx_tick_10ms < 0xFFFFU) {
        s_ctx.since_rx_tick_10ms++;
    }
    if (s_ctx.heartbeat_tick_10ms < 0xFFFFU) {
        s_ctx.heartbeat_tick_10ms++;
    }

    service_pending_timeout(&s_ctx.pending_param);
    service_pending_timeout(&s_ctx.pending_heartbeat);
    service_pending_timeout(&s_ctx.pending_step[STEP_SIDE_LEFT]);
    service_pending_timeout(&s_ctx.pending_step[STEP_SIDE_RIGHT]);
    service_pending_timeout(&s_ctx.pending_light);
    service_pending_timeout(&s_ctx.pending_voice);

    if (s_ctx.since_rx_tick_10ms >= U17_LINK_OFFLINE_TIMEOUT_10MS) {
        if (!s_ctx.timeout_latched) {
            s_ctx.heartbeat_timeout_count++;
            s_ctx.timeout_latched = true;
        }
        s_ctx.link_online = false;
        s_ctx.link_state = U17_LINK_STATE_OFFLINE;
        fault_set(FAULT_U17_LINK);
    }

    if (s_ctx.param_sync_pending && !s_ctx.pending_param.active) {
        g_u12_u17_param_sync_try_count++;
        payload_len = pack_param_snapshot(param_payload, sizeof(param_payload));
        if (payload_len > 0U) {
            if (!start_request(&s_ctx.pending_param,
                               (uint8_t)(U17_PROTO_CLASS_REQ | U17_PROTO_FLAG_ACK_REQ),
                               U17_CMD_PARAM_SYNC,
                               param_payload,
                               (uint8_t)payload_len)) {
                s_ctx.rx_drop_count++;
            }
        }
        return;
    }

    if ((s_ctx.heartbeat_tick_10ms >= U17_LINK_HEARTBEAT_PERIOD_10MS) &&
        !s_ctx.pending_heartbeat.active) {
        g_u12_u17_heartbeat_try_count++;
        hb_payload[0] = U17_PROTO_VERSION;
        hb_payload[1] = s_ctx.heartbeat_miss_count;
        if (!start_request(&s_ctx.pending_heartbeat,
                           (uint8_t)(U17_PROTO_CLASS_REQ | U17_PROTO_FLAG_ACK_REQ),
                           U17_CMD_HEARTBEAT,
                           hb_payload,
                           (uint8_t)sizeof(hb_payload))) {
            s_ctx.rx_drop_count++;
        }
        s_ctx.heartbeat_tick_10ms = 0U;
    }
}

void u17_link_mark_param_dirty(void)
{
    s_ctx.param_sync_pending = true;
}

void u17_link_clear_timeout_latch(void)
{
    s_ctx.timeout_latched = false;
}

bool u17_link_has_timeout_latched(void)
{
    return s_ctx.timeout_latched;
}

bool u17_link_is_online(void)
{
    return s_ctx.link_online;
}

u17_link_state_t u17_link_get_state(void)
{
    return s_ctx.link_state;
}

void u17_link_get_diag(u17_link_diag_t *diag)
{
    if (diag == 0) {
        return;
    }

    diag->tx_frame_count = s_ctx.tx_frame_count;
    diag->rx_frame_count = s_ctx.rx_frame_count;
    diag->rx_crc_error_count = s_ctx.rx_crc_error_count;
    diag->rx_drop_count = s_ctx.rx_drop_count;
    diag->heartbeat_timeout_count = s_ctx.heartbeat_timeout_count;
    diag->heartbeat_miss_count = s_ctx.heartbeat_miss_total;
    diag->heartbeat_recover_count = s_ctx.heartbeat_recover_total;
    diag->request_retry_count = s_ctx.request_retry_count;
    diag->request_timeout_count = s_ctx.request_timeout_count;
    diag->tx_sequence = s_ctx.tx_sequence;
    diag->link_state = s_ctx.link_state;
    diag->link_online = s_ctx.link_online;
    diag->param_sync_pending = s_ctx.param_sync_pending;
    diag->timeout_latched = s_ctx.timeout_latched;
    diag->boot_seen = s_ctx.boot_seen;
}

void u17_link_get_remote_status(u17_remote_status_t *status)
{
    if (status == 0) {
        return;
    }

    *status = s_remote;
}

bool u17_link_request_step(step_side_t side, step_action_t action)
{
    uint8_t payload[3];

    if (side >= STEP_SIDE_MAX) {
        return false;
    }

    payload[0] = (uint8_t)side;
    payload[1] = (uint8_t)action;
    payload[2] = 0U;

    return start_request(&s_ctx.pending_step[side],
                         (uint8_t)(U17_PROTO_CLASS_REQ | U17_PROTO_FLAG_ACK_REQ),
                         U17_CMD_STEP_CTRL,
                         payload,
                         (uint8_t)sizeof(payload));
}

bool u17_link_request_light(uint8_t scene, const light_scene_cfg_t *cfg, bool enable)
{
    uint8_t payload[6];

    if (cfg == 0) {
        return false;
    }

    payload[0] = scene;
    payload[1] = cfg->r;
    payload[2] = cfg->g;
    payload[3] = cfg->b;
    payload[4] = cfg->mode;
    payload[5] = enable ? U17_PROTO_LIGHT_ENABLE : U17_PROTO_LIGHT_OFF;

    return start_request(&s_ctx.pending_light,
                         (uint8_t)(U17_PROTO_CLASS_REQ | U17_PROTO_FLAG_ACK_REQ),
                         U17_CMD_LIGHT_SCENE,
                         payload,
                         (uint8_t)sizeof(payload));
}

bool u17_link_request_buzzer(bool enable, uint8_t pattern, uint16_t duration_10ms)
{
    (void)enable;
    (void)pattern;
    (void)duration_10ms;

    /* 当前 U17 灯光/语音从设备无蜂鸣器硬件�?*/
    return false;
}

bool u17_link_remote_limit(step_side_t side, step_action_t action)
{
    if (side == STEP_SIDE_LEFT) {
        if (action == STEP_ACT_EXTEND) {
            return s_remote.left_ext_limit;
        }
        if ((action == STEP_ACT_RETRACT) || (action == STEP_ACT_RETRACT_SLOW)) {
            return s_remote.left_ret_limit;
        }
    } else if (side == STEP_SIDE_RIGHT) {
        if (action == STEP_ACT_EXTEND) {
            return s_remote.right_ext_limit;
        }
        if ((action == STEP_ACT_RETRACT) || (action == STEP_ACT_RETRACT_SLOW)) {
            return s_remote.right_ret_limit;
        }
    }

    return false;
}

uint16_t u17_link_remote_current(step_side_t side)
{
    if (side == STEP_SIDE_LEFT) {
        return s_remote.left_current_raw;
    }
    if (side == STEP_SIDE_RIGHT) {
        return s_remote.right_current_raw;
    }
    return 0U;
}


bool u17_link_request_voice(uint8_t lang, uint16_t voice_id, bool stop)
{
    uint8_t payload[4];

    payload[0] = lang;
    put_le16(&payload[1], voice_id);
    payload[3] = stop ? 1U : 0U;

    return start_request(&s_ctx.pending_voice,
                         (uint8_t)(U17_PROTO_CLASS_REQ | U17_PROTO_FLAG_ACK_REQ),
                         U17_CMD_VOICE_CTRL,
                         payload,
                         (uint8_t)sizeof(payload));
}



