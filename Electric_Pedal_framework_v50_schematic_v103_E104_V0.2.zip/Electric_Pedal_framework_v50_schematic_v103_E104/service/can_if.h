#ifndef SERVICE_CAN_IF_H
#define SERVICE_CAN_IF_H

/*
 * 文件: service/can_if.h
 * 描述: CAN 总线抽象接口定义（帧结构、信号快照）。
 * 责任: 屏蔽底层 BSP CAN，提供信号采样与轮询接口供事件收集使用。
 */

#include <stdint.h>
#include "project_bool.h"
#include "bsp_can.h"
#include "param.h"

typedef struct
{
    uint32_t id;
    uint8_t  dlc;
    uint8_t  data[64];
    bool     is_extended;
    bool     fd_enable;
    bool     brs_enable;
    bsp_can_bus_t bus;
} can_frame_t;

typedef struct
{
    bool signal_valid;
    bool speed_above_8;
    bool unlock_active;
    bool turn_left;
    bool turn_right;
    bool brake;
    bool headlamp;
    bool auto_drive;
    bool door_open[DOOR_POS_MAX];
} can_if_signal_snapshot_t;

void can_if_init(void);
bool can_if_rx_isr_push(const can_frame_t *frame);
void can_if_poll(void);
void can_if_tick_100ms(void);
bool can_if_signal_valid(void);
void can_if_apply_monitor_from_param(void);
void can_if_get_signal_snapshot(can_if_signal_snapshot_t *snapshot);

#endif
