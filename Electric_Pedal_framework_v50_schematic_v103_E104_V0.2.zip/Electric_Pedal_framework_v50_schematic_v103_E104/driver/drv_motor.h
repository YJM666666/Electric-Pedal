#ifndef DRIVER_DRV_MOTOR_H
#define DRIVER_DRV_MOTOR_H

#include "project_bool.h"
#include "pedal_types.h"
#include "driver/drv_motor_backend.h"
#include <stdint.h>

/*
 * 电机驱动外观层。
 *
 * 上层只调用 drv_motor_exec()。实际驱动后端由板级配置和电机 profile 选择，
 * MCU 或电机功率级迁移时，差异保持在这个接口以下。
 */
void drv_motor_init(void);

/* 对指定侧执行一个动作（伸出/收回/停止）。 */
void drv_motor_exec(step_side_t side, step_action_t action);

/* 获取最近一次缓存的动作状态。 */
step_action_t drv_motor_get_action(step_side_t side);

/* 读取指定动作对应的限位开关是否触发。 */
bool drv_motor_is_limit_reached(step_side_t side, step_action_t action);

/* 活动后端驱动的元数据，用于诊断和未来平台适配。 */
uint8_t drv_motor_get_backend_id(void);
const char *drv_motor_get_backend_name(void);
void drv_motor_get_backend_capability(drv_motor_backend_cap_t *out);

#endif
