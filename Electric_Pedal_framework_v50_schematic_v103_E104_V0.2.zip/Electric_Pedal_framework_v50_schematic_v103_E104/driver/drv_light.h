#ifndef DRIVER_DRV_LIGHT_H
#define DRIVER_DRV_LIGHT_H

#include "param.h"

/*
 * 灯光场景枚举。
 *
 * 这里只定义“业务上的场景名”，真正的颜色/模式值由参数表或构造函数给出。
 */
typedef enum
{
    LIGHT_SCENE_OFF = 0,
    LIGHT_SCENE_WELCOME,
    LIGHT_SCENE_TURN,
    LIGHT_SCENE_BRAKE,
    LIGHT_SCENE_ALERT,
    LIGHT_SCENE_DRIVE,
    LIGHT_SCENE_AUTO_BLUE,
    LIGHT_SCENE_WASH,
    LIGHT_SCENE_FAULT
} drv_light_scene_t;

void drv_light_init(void);
void drv_light_apply_scene(drv_light_scene_t scene);
drv_light_scene_t drv_light_get_scene(void);
light_scene_cfg_t drv_light_get_current_cfg(void);

#endif
