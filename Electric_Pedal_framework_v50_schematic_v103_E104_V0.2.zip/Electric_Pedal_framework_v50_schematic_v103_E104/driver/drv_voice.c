/*
 * 语音驱动外观层：把业务语音请求转交给 U17 执行侧，主控不直接驱动语音芯片。
 */
#include "drv_voice.h"
#include "u17_link.h"

typedef struct
{
    voice_id_t last_id;
    voice_language_t last_lang;
} drv_voice_ctx_t;

static drv_voice_ctx_t s_voice;

void drv_voice_init(void)
{
    s_voice.last_id = VOICE_ID_NONE;
    s_voice.last_lang = VOICE_LANG_CHINESE;
}

bool drv_voice_play(voice_id_t id, voice_language_t lang)
{
    bool ok;
    uint8_t proto_lang;

    if ((id <= VOICE_ID_NONE) || (id >= VOICE_ID_MAX)) {
        return false;
    }

    proto_lang = (lang == VOICE_LANG_ENGLISH) ? 1U : 0U;
    s_voice.last_id = id;
    s_voice.last_lang = lang;
    ok = u17_link_request_voice(proto_lang, (uint16_t)id, false);
    if (!ok) {
        s_voice.last_id = VOICE_ID_NONE;
    }
    return ok;
}

bool drv_voice_stop(void)
{
    return u17_link_request_voice(0U, 0U, true);
}

bool drv_voice_is_busy(void)
{
    u17_remote_status_t st;
    u17_link_get_remote_status(&st);
    return st.voice_busy;
}

voice_id_t drv_voice_get_last_requested(void)
{
    return s_voice.last_id;
}

voice_language_t drv_voice_get_last_language(void)
{
    return s_voice.last_lang;
}
