#include "drv_motor_backend_relay.h"
#include "bsp_gpio.h"

/*
 * 当前 GD32C103 + ULN2003 + 继电器双线圈电机后端。
 * 上层只表达伸出/收回/停止意图，A/B 线圈互斥输出细节只收敛在这里。
 */
static void relay_init(void)
{
    bsp_gpio_write(BSP_GPIO_OUT_L_MOTOR_A, false);
    bsp_gpio_write(BSP_GPIO_OUT_L_MOTOR_B, false);
    bsp_gpio_write(BSP_GPIO_OUT_R_MOTOR_A, false);
    bsp_gpio_write(BSP_GPIO_OUT_R_MOTOR_B, false);
}

static void relay_write_side(step_side_t side, bool out_a, bool out_b)
{
    if (side == STEP_SIDE_LEFT) {
        bsp_gpio_write(BSP_GPIO_OUT_L_MOTOR_A, out_a);
        bsp_gpio_write(BSP_GPIO_OUT_L_MOTOR_B, out_b);
    } else if (side == STEP_SIDE_RIGHT) {
        bsp_gpio_write(BSP_GPIO_OUT_R_MOTOR_A, out_a);
        bsp_gpio_write(BSP_GPIO_OUT_R_MOTOR_B, out_b);
    }
}

static void relay_exec(step_side_t side, step_action_t action, bool reverse)
{
    bool out_a = false;
    bool out_b = false;

    switch (action)
    {
        case STEP_ACT_EXTEND:
            out_a = !reverse;
            out_b = reverse;
            break;

        case STEP_ACT_RETRACT:
        case STEP_ACT_RETRACT_SLOW:
            /*
             * V1.03 原理图中主电机由继电器线圈驱动，当前后端没有连续 PWM 调速能力。
             * 上层仍保留“恢复慢速收回”的动作语义，用于切换更严格的电流和霍尔保护；
             * 在本硬件上实际输出仍是同一个安全收回方向。
             */
            out_a = reverse;
            out_b = !reverse;
            break;

        case STEP_ACT_STOP:
        default:
            out_a = false;
            out_b = false;
            break;
    }

    relay_write_side(side, out_a, out_b);
}

static void relay_capability(drv_motor_backend_cap_t *out)
{
    if (out == 0) {
        return;
    }

    out->backend_id = DRV_MOTOR_BACKEND_RELAY_GPIO;
    out->supports_local_output = true;
    out->supports_pwm = false;
    out->supports_remote_command = false;
}

static const drv_motor_backend_api_t s_relay_backend = {
    DRV_MOTOR_BACKEND_RELAY_GPIO,
    "relay-gpio",
    relay_init,
    relay_exec,
    relay_capability
};

const drv_motor_backend_api_t *drv_motor_backend_relay_get(void)
{
    return &s_relay_backend;
}
