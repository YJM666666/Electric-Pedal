#include "drv_light.h"
#include "u17_link.h"
#include "bsp_gpio.h"

/*
 * 灯光驱动策略说明
 * ---------------------------------------------------------------
 * 主控侧并不直接“编码”灯带数据波形，而是把场景/颜色参数下发给 U17。
 *
 * 当前实现做了两件事：
 * 1. 缓存当前灯光场景和颜色配置
 * 2. 通过 u17_link_request_light() 把场景命令发给 U17
 *
 * 另外，为了 host 测试和最小化板级联调，主控侧还会同步拉一下本地
 * LIGHT_DATA_L/R mock 输出，让测试能看到“灯光被使能/关闭”这个状态。
 */

static drv_light_scene_t s_scene = LIGHT_SCENE_OFF;
static light_scene_cfg_t s_cfg;

static light_scene_cfg_t make_auto_blue_cfg(void)
{
    light_scene_cfg_t cfg;
    cfg.r = 0U;
    cfg.g = 0U;
    cfg.b = 0xFFU;
    cfg.mode = 0x01U;
    return cfg;
}

static light_scene_cfg_t make_fault_cfg(void)
{
    light_scene_cfg_t cfg;
    cfg.r = 0xFFU;
    cfg.g = 0U;
    cfg.b = 0U;
    cfg.mode = 0x01U;
    return cfg;
}

void drv_light_init(void)
{
    s_scene = LIGHT_SCENE_OFF;
    s_cfg.r = 0U;
    s_cfg.g = 0U;
    s_cfg.b = 0U;
    s_cfg.mode = 0U;
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_L1, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_R1, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_L2, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_R2, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_L1, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_R1, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_L2, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_R2, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_EN, false);
}

void drv_light_apply_scene(drv_light_scene_t scene)
{
    const system_param_t *param = param_get();
    bool enable = true;

    /* 全局灯光开关关闭时，不论上层发什么场景，都统一退回 OFF。 */
    if (!param->light_enable) {
        scene = LIGHT_SCENE_OFF;
    }

    s_scene = scene;

    switch (scene)
    {
        case LIGHT_SCENE_WELCOME:
            s_cfg = param->light_welcome;
            break;

        case LIGHT_SCENE_TURN:
            s_cfg = param->light_turn;
            break;

        case LIGHT_SCENE_BRAKE:
            s_cfg = param->light_brake;
            break;

        case LIGHT_SCENE_ALERT:
            s_cfg = param->light_alert;
            break;

        case LIGHT_SCENE_DRIVE:
            s_cfg = param->light_drive;
            break;

        case LIGHT_SCENE_AUTO_BLUE:
            if (param->auto_drive_blue) {
                s_cfg = make_auto_blue_cfg();
            } else {
                s_cfg = param->light_drive;
            }
            break;

        case LIGHT_SCENE_WASH:
            /* 当前先复用 welcome 参数，后续可单独扩成 wash 参数。 */
            s_cfg = param->light_welcome;
            break;

        case LIGHT_SCENE_FAULT:
            s_cfg = make_fault_cfg();
            break;

        case LIGHT_SCENE_OFF:
        default:
            s_cfg.r = 0U;
            s_cfg.g = 0U;
            s_cfg.b = 0U;
            s_cfg.mode = 0U;
            enable = false;
            break;
    }

    /* 真实执行侧在 U17。 */
    (void)u17_link_request_light((uint8_t)scene, &s_cfg, enable);

    /* 本地 GPIO 只作为最小状态镜像/测试钩子。 */
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_L1, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_R1, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_L2, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_R2, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_L1, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_R1, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_L2, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_R2, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_EN, enable);
}

drv_light_scene_t drv_light_get_scene(void)
{
    return s_scene;
}

light_scene_cfg_t drv_light_get_current_cfg(void)
{
    return s_cfg;
}
