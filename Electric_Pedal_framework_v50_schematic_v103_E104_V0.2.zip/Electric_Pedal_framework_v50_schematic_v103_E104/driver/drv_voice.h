#ifndef DRIVER_DRV_VOICE_H
#define DRIVER_DRV_VOICE_H

/*
 * 语音驱动接口：供业务层按语义触发播报，具体曲目和硬件时序由下层处理。
 */
#include "project_bool.h"
#include "param.h"
#include "service/voice_catalog.h"

void drv_voice_init(void);
bool drv_voice_play(voice_id_t id, voice_language_t lang);
bool drv_voice_stop(void);
bool drv_voice_is_busy(void);
voice_id_t drv_voice_get_last_requested(void);
voice_language_t drv_voice_get_last_language(void);

#endif
