#ifndef DRV_NVM_H
#define DRV_NVM_H

/*
 * NVM 接口：提供参数区和掉电恢复记录的读写封装，屏蔽 Flash/EEPROM 介质差异。
 */
#include <stdint.h>
#include "project_bool.h"
#include "pedal_types.h"

typedef struct
{
    step_side_t   last_side;
    uint8_t       last_state;
    step_action_t last_action;
} drv_nvm_power_recovery_t;

bool drv_nvm_init(void);
bool drv_nvm_read_params(uint8_t *buf, uint32_t len);
bool drv_nvm_write_params(const uint8_t *buf, uint32_t len);
bool drv_nvm_read_power_recovery(drv_nvm_power_recovery_t *rec);
bool drv_nvm_write_power_recovery(const drv_nvm_power_recovery_t *rec);

#endif
