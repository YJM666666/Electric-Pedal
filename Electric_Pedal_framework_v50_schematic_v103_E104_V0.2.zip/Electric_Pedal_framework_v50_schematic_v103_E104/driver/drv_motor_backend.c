#include "drv_motor_backend.h"
#include "drv_motor_backend_relay.h"

static void backend_none_init(void)
{
}

static void backend_none_exec(step_side_t side, step_action_t action, bool reverse)
{
    (void)side;
    (void)action;
    (void)reverse;
}

static void backend_none_capability(drv_motor_backend_cap_t *out)
{
    if (out == 0) {
        return;
    }

    out->backend_id = DRV_MOTOR_BACKEND_NONE;
    out->supports_local_output = false;
    out->supports_pwm = false;
    out->supports_remote_command = false;
}

static const drv_motor_backend_api_t s_none_backend = {
    DRV_MOTOR_BACKEND_NONE,
    "none",
    backend_none_init,
    backend_none_exec,
    backend_none_capability
};

const drv_motor_backend_api_t *drv_motor_backend_select(uint8_t backend_id)
{
    switch (backend_id)
    {
        case DRV_MOTOR_BACKEND_RELAY_GPIO:
            return drv_motor_backend_relay_get();

        case DRV_MOTOR_BACKEND_NONE:
        case DRV_MOTOR_BACKEND_PWM_HBRIDGE:
        case DRV_MOTOR_BACKEND_REMOTE_U17:
        case DRV_MOTOR_BACKEND_CAN_ACTUATOR:
        default:
            /*
             * 预留后端先映射到安全的无输出实现。
             * 等底层驱动真正实现后，再切换到对应后端。
             */
            return &s_none_backend;
    }
}

const char *drv_motor_backend_name(uint8_t backend_id)
{
    return drv_motor_backend_select(backend_id)->name;
}
