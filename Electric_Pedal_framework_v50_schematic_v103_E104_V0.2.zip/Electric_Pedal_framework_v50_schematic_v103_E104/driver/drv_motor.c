#include "drv_motor.h"
#include "current_guard.h"
#include "drv_motor_backend.h"
#include "bsp_gpio.h"
#include "motor_profile.h"
#include "param.h"

/*
 * 平台电机驱动外观层。
 *
 * 状态机与步进执行器只调用此文件。可选的驱动后端包括继电器 GPIO、PWM H 桥、远端 U17、CAN 执行器等。
 * 增加新的电机功率级不应要求修改 step_sm 或 scheduler。
 */
static step_action_t s_last_action[STEP_SIDE_MAX];
static const drv_motor_backend_api_t *s_backend = 0;

static bool side_reverse(step_side_t side)
{
    const system_param_t *param = param_get();

    if (side == STEP_SIDE_LEFT) {
        return param->motor_left_reverse;
    }

    if (side == STEP_SIDE_RIGHT) {
        return param->motor_right_reverse;
    }

    return false;
}

static void set_current_guard_motion(step_side_t side, step_action_t action)
{
    switch (action)
    {
        case STEP_ACT_EXTEND:
            current_guard_set_motion(side, CG_MOTION_EXTEND);
            break;

        case STEP_ACT_RETRACT:
            current_guard_set_motion(side, CG_MOTION_RETRACT);
            break;

        case STEP_ACT_RETRACT_SLOW:
            current_guard_set_motion(side, CG_MOTION_RECOVERY_RETRACT);
            break;

        case STEP_ACT_STOP:
        default:
            current_guard_set_motion(side, CG_MOTION_IDLE);
            break;
    }
}

void drv_motor_init(void)
{
    const motor_profile_t *profile = motor_profile_get();
    uint8_t backend_id = DRV_MOTOR_BACKEND_NONE;

    if (profile != 0) {
        backend_id = profile->drive_backend;
    }

#if BSP_APP_IS_U17
    /* U17 不负责旧有刷电机功率级。 */
    backend_id = DRV_MOTOR_BACKEND_NONE;
#endif

    s_backend = drv_motor_backend_select(backend_id);
    if ((s_backend != 0) && (s_backend->init != 0)) {
        s_backend->init();
    }

    s_last_action[STEP_SIDE_LEFT] = STEP_ACT_STOP;
    s_last_action[STEP_SIDE_RIGHT] = STEP_ACT_STOP;
    current_guard_set_motion(STEP_SIDE_LEFT, CG_MOTION_IDLE);
    current_guard_set_motion(STEP_SIDE_RIGHT, CG_MOTION_IDLE);
}

void drv_motor_exec(step_side_t side, step_action_t action)
{
    if (side >= STEP_SIDE_MAX) {
        return;
    }

    set_current_guard_motion(side, action);

    if ((s_backend != 0) && (s_backend->exec != 0)) {
        s_backend->exec(side, action, side_reverse(side));
    }

    s_last_action[side] = action;
}

step_action_t drv_motor_get_action(step_side_t side)
{
    if (side >= STEP_SIDE_MAX) {
        return STEP_ACT_STOP;
    }

    return s_last_action[side];
}

bool drv_motor_is_limit_reached(step_side_t side, step_action_t action)
{
    /*
     * V1.03 使用霍尔脉冲与 LM258 电流采样作为运动反馈。
     * 仅在板子明确支持离散限位引脚时才读取限位输入。
     */
    if (!motor_profile_has_feedback(MOTOR_FEEDBACK_LIMIT_SW)) {
        return false;
    }

    if (side == STEP_SIDE_LEFT) {
        if (action == STEP_ACT_EXTEND) {
            return bsp_gpio_read_in(BSP_GPIO_IN_L_EXT_LIMIT);
        }
        if ((action == STEP_ACT_RETRACT) || (action == STEP_ACT_RETRACT_SLOW)) {
            return bsp_gpio_read_in(BSP_GPIO_IN_L_RET_LIMIT);
        }
    } else if (side == STEP_SIDE_RIGHT) {
        if (action == STEP_ACT_EXTEND) {
            return bsp_gpio_read_in(BSP_GPIO_IN_R_EXT_LIMIT);
        }
        if ((action == STEP_ACT_RETRACT) || (action == STEP_ACT_RETRACT_SLOW)) {
            return bsp_gpio_read_in(BSP_GPIO_IN_R_RET_LIMIT);
        }
    }

    return false;
}

uint8_t drv_motor_get_backend_id(void)
{
    return (s_backend == 0) ? DRV_MOTOR_BACKEND_NONE : s_backend->backend_id;
}

const char *drv_motor_get_backend_name(void)
{
    return (s_backend == 0) ? "none" : s_backend->name;
}

void drv_motor_get_backend_capability(drv_motor_backend_cap_t *out)
{
    if (out == 0) {
        return;
    }

    if ((s_backend != 0) && (s_backend->get_capability != 0)) {
        s_backend->get_capability(out);
    } else {
        out->backend_id = DRV_MOTOR_BACKEND_NONE;
        out->supports_local_output = false;
        out->supports_pwm = false;
        out->supports_remote_command = false;
    }
}
