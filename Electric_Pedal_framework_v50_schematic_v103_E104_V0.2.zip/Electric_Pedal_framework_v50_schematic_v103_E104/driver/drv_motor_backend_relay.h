#ifndef DRIVER_DRV_MOTOR_BACKEND_RELAY_H
#define DRIVER_DRV_MOTOR_BACKEND_RELAY_H

/*
 * 继电器电机后端接口：适配 V1.03 的 ULN2003 + 继电器有刷电机功率级。
 */
#include "drv_motor_backend.h"

const drv_motor_backend_api_t *drv_motor_backend_relay_get(void);

#endif
