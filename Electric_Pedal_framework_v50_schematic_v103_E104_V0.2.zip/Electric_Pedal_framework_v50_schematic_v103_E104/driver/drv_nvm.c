﻿#include "drv_nvm.h"
#include "bsp_build.h"
#include <string.h>

/*
 * 闈炴槗澶卞瓨鍌ㄩ┍鍔細璐熻矗绯荤粺鍙傛暟鍙屾Ы淇濆瓨銆丆RC 鏍￠獙锛屼互鍙婃帀鐢垫仮澶嶈褰曠殑璇诲啓銆? * 鍙傛暟鍖轰娇鐢?SPI Flash 鍙屾Ы婊氬姩锛屾仮澶嶈褰曞悓姝ヤ繚瀛樺湪 Flash 鍜?EEPROM 闀滃儚閲屻€? */
#define DRV_NVM_FLASH_SLOT_PAYLOAD_MAX   1024U
#define DRV_NVM_FLASH_SLOT_COUNT         2U
#define DRV_NVM_FLASH_SLOT_MAGIC         0x4E564D31UL
#define DRV_NVM_FLASH_SLOT_VERSION       0x0003U
#define DRV_NVM_EEPROM_BYTES             440U
#define DRV_NVM_RECOVERY_EEPROM_ADDR     480U
#define DRV_NVM_RECOVERY_MAGIC           0x50575231UL

typedef struct
{
    uint32_t magic;
    uint16_t version;
    uint16_t length;
    uint32_t sequence;
    uint32_t crc32;
} drv_nvm_flash_slot_hdr_t;

typedef struct
{
    drv_nvm_flash_slot_hdr_t hdr;
    uint8_t                  payload[DRV_NVM_FLASH_SLOT_PAYLOAD_MAX];
} drv_nvm_flash_slot_t;

typedef struct
{
    uint32_t magic;
    uint8_t  last_side;
    uint8_t  last_state;
    uint8_t  last_action;
    uint8_t  reserved;
    uint32_t crc32;
} drv_nvm_recovery_blob_t;

static uint32_t crc32_calc(const uint8_t *data, uint32_t len)
{
    uint32_t crc = 0xFFFFFFFFUL;
    uint32_t i;
    uint32_t j;
    uint32_t byte_val;

    if ((data == 0) && (len != 0U)) {
        return 0UL;
    }

    for (i = 0U; i < len; ++i) {
        byte_val = (uint32_t)data[i];
        crc ^= byte_val;
        for (j = 0U; j < 8U; ++j) {
            if ((crc & 1UL) != 0UL) {
                crc = (crc >> 1U) ^ 0xEDB88320UL;
            } else {
                crc >>= 1U;
            }
        }
    }

    return ~crc;
}

static bool recovery_blob_to_record(const drv_nvm_recovery_blob_t *blob, drv_nvm_power_recovery_t *rec)
{
    uint32_t crc;

    if ((blob == 0) || (rec == 0)) {
        return false;
    }

    if ((blob->magic != DRV_NVM_RECOVERY_MAGIC) ||
        (blob->last_side >= (uint8_t)STEP_SIDE_MAX) ||
        (blob->last_action > (uint8_t)STEP_ACT_RETRACT_SLOW)) {
        return false;
    }

    crc = crc32_calc((const uint8_t *)blob, (uint32_t)(sizeof(*blob) - sizeof(blob->crc32)));
    if (crc != blob->crc32) {
        return false;
    }

    rec->last_side = (step_side_t)blob->last_side;
    rec->last_state = blob->last_state;
    rec->last_action = (step_action_t)blob->last_action;
    return true;
}

static void recovery_record_to_blob(const drv_nvm_power_recovery_t *rec, drv_nvm_recovery_blob_t *blob)
{
    (void)memset(blob, 0, sizeof(*blob));
    blob->magic = DRV_NVM_RECOVERY_MAGIC;
    blob->last_side = (uint8_t)rec->last_side;
    blob->last_state = rec->last_state;
    blob->last_action = (uint8_t)rec->last_action;
    blob->crc32 = crc32_calc((const uint8_t *)blob, (uint32_t)(sizeof(*blob) - sizeof(blob->crc32)));
}

#if BSP_PLATFORM_GD32
#include "bsp_board.h"
#include "bsp_spi.h"
#include "bsp_i2c.h"

#define W25_CMD_WRITE_ENABLE       0x06U
#define W25_CMD_READ_STATUS1       0x05U
#define W25_CMD_READ_DATA          0x03U
#define W25_CMD_PAGE_PROGRAM       0x02U
#define W25_CMD_SECTOR_ERASE_4K    0x20U
#define W25_SR1_BUSY               0x01U

typedef struct
{
    bool    inited;
    uint8_t last_slot;
} drv_nvm_ctx_t;

static drv_nvm_ctx_t s_ctx;

static bool flash_xfer_cmd_addr(uint8_t cmd, uint32_t addr)
{
    uint8_t hdr[4];
    hdr[0] = cmd;
    hdr[1] = (uint8_t)((addr >> 16U) & 0xFFU);
    hdr[2] = (uint8_t)((addr >> 8U) & 0xFFU);
    hdr[3] = (uint8_t)(addr & 0xFFU);
    return bsp_spi_flash_transfer(hdr, 0, sizeof(hdr));
}

static bool flash_write_enable(void)
{
    const uint8_t cmd = W25_CMD_WRITE_ENABLE;
    bsp_spi_flash_select(true);
    if (!bsp_spi_flash_transfer(&cmd, 0, 1U)) {
        bsp_spi_flash_select(false);
        return false;
    }
    bsp_spi_flash_select(false);
    return true;
}

static bool flash_wait_ready(void)
{
    uint8_t tx[2] = {W25_CMD_READ_STATUS1, 0xFFU};
    uint8_t rx[2];
    uint32_t timeout = 0x3FFFFUL;

    while (timeout-- > 0U) {
        bsp_spi_flash_select(true);
        (void)bsp_spi_flash_transfer(tx, rx, sizeof(tx));
        bsp_spi_flash_select(false);
        if ((rx[1] & W25_SR1_BUSY) == 0U) {
            return true;
        }
    }
    return false;
}

static bool flash_read(uint32_t addr, uint8_t *data, uint32_t len)
{
    uint8_t cmd[4];

    if ((data == 0) || (len == 0U)) {
        return false;
    }

    cmd[0] = W25_CMD_READ_DATA;
    cmd[1] = (uint8_t)((addr >> 16U) & 0xFFU);
    cmd[2] = (uint8_t)((addr >> 8U) & 0xFFU);
    cmd[3] = (uint8_t)(addr & 0xFFU);

    bsp_spi_flash_select(true);
    if (!bsp_spi_flash_transfer(cmd, 0, sizeof(cmd))) {
        bsp_spi_flash_select(false);
        return false;
    }
    if (!bsp_spi_flash_transfer(0, data, len)) {
        bsp_spi_flash_select(false);
        return false;
    }
    bsp_spi_flash_select(false);
    return true;
}

static bool flash_sector_erase(uint32_t addr)
{
    if (!flash_write_enable()) {
        return false;
    }
    bsp_spi_flash_select(true);
    if (!flash_xfer_cmd_addr(W25_CMD_SECTOR_ERASE_4K, addr)) {
        bsp_spi_flash_select(false);
        return false;
    }
    bsp_spi_flash_select(false);
    return flash_wait_ready();
}

static bool flash_program(uint32_t addr, const uint8_t *data, uint32_t len)
{
    uint32_t done = 0U;
    uint32_t page_ofs;
    uint32_t chunk;

    if ((data == 0) || (len == 0U)) {
        return false;
    }

    while (done < len) {
        page_ofs = (addr + done) % BSP_FLASH_PAGE_SIZE;
        chunk = BSP_FLASH_PAGE_SIZE - page_ofs;
        if (chunk > (len - done)) {
            chunk = len - done;
        }
        if (!flash_write_enable()) {
            return false;
        }
        bsp_spi_flash_select(true);
        if (!flash_xfer_cmd_addr(W25_CMD_PAGE_PROGRAM, addr + done)) {
            bsp_spi_flash_select(false);
            return false;
        }
        if (!bsp_spi_flash_transfer(&data[done], 0, chunk)) {
            bsp_spi_flash_select(false);
            return false;
        }
        bsp_spi_flash_select(false);
        if (!flash_wait_ready()) {
            return false;
        }
        done += chunk;
    }
    return true;
}

static bool flash_slot_is_valid(const drv_nvm_flash_slot_t *slot, uint32_t expected_len)
{
    uint32_t crc;

    if (slot == 0) {
        return false;
    }

    if ((slot->hdr.magic != DRV_NVM_FLASH_SLOT_MAGIC) ||
        (slot->hdr.version != DRV_NVM_FLASH_SLOT_VERSION) ||
        (slot->hdr.length != expected_len) ||
        (expected_len > DRV_NVM_FLASH_SLOT_PAYLOAD_MAX)) {
        return false;
    }

    crc = crc32_calc(slot->payload, expected_len);
    return (crc == slot->hdr.crc32);
}

static bool read_slot(uint32_t addr, drv_nvm_flash_slot_t *slot)
{
    return flash_read(addr, (uint8_t *)slot, sizeof(drv_nvm_flash_slot_t));
}

static bool select_latest_valid_slot(uint32_t len, uint8_t *slot_idx, drv_nvm_flash_slot_t *slot0, drv_nvm_flash_slot_t *slot1)
{
    bool valid0;
    bool valid1;

    if ((slot_idx == 0) || (slot0 == 0) || (slot1 == 0)) {
        return false;
    }

    valid0 = flash_slot_is_valid(slot0, len);
    valid1 = flash_slot_is_valid(slot1, len);
    if (!valid0 && !valid1) {
        return false;
    }
    if (valid0 && !valid1) {
        *slot_idx = 0U;
        return true;
    }
    if (!valid0 && valid1) {
        *slot_idx = 1U;
        return true;
    }
    *slot_idx = (slot1->hdr.sequence >= slot0->hdr.sequence) ? 1U : 0U;
    return true;
}

bool drv_nvm_init(void)
{
    bsp_spi_init();
    bsp_i2c_init();
    s_ctx.inited = true;
    s_ctx.last_slot = 0U;
    return true;
}

bool drv_nvm_read_params(uint8_t *buf, uint32_t len)
{
    drv_nvm_flash_slot_t slot0;
    drv_nvm_flash_slot_t slot1;
    uint8_t slot_idx;

    if ((!s_ctx.inited) || (buf == 0) || (len == 0U) || (len > DRV_NVM_FLASH_SLOT_PAYLOAD_MAX)) {
        return false;
    }

    if (!read_slot(BSP_FLASH_PARAM_SLOT_A_ADDR, &slot0) ||
        !read_slot(BSP_FLASH_PARAM_SLOT_B_ADDR, &slot1)) {
        return false;
    }

    if (!select_latest_valid_slot(len, &slot_idx, &slot0, &slot1)) {
        return false;
    }

    if (slot_idx == 0U) {
        (void)memcpy(buf, slot0.payload, len);
    } else {
        (void)memcpy(buf, slot1.payload, len);
    }
    s_ctx.last_slot = slot_idx;
    return true;
}

bool drv_nvm_write_params(const uint8_t *buf, uint32_t len)
{
    drv_nvm_flash_slot_t slot0;
    drv_nvm_flash_slot_t slot1;
    drv_nvm_flash_slot_t slot;
    uint8_t latest_slot;
    uint8_t target_slot;
    uint32_t target_addr;
    uint32_t next_seq = 1UL;
    uint16_t ee_len;

    if ((!s_ctx.inited) || (buf == 0) || (len == 0U) || (len > DRV_NVM_FLASH_SLOT_PAYLOAD_MAX)) {
        return false;
    }

    (void)read_slot(BSP_FLASH_PARAM_SLOT_A_ADDR, &slot0);
    (void)read_slot(BSP_FLASH_PARAM_SLOT_B_ADDR, &slot1);
    if (select_latest_valid_slot(len, &latest_slot, &slot0, &slot1)) {
        next_seq = (latest_slot == 0U ? slot0.hdr.sequence : slot1.hdr.sequence) + 1UL;
        target_slot = (uint8_t)((latest_slot + 1U) % DRV_NVM_FLASH_SLOT_COUNT);
    } else {
        target_slot = 0U;
    }

    (void)memset(&slot, 0, sizeof(slot));
    slot.hdr.magic = DRV_NVM_FLASH_SLOT_MAGIC;
    slot.hdr.version = DRV_NVM_FLASH_SLOT_VERSION;
    slot.hdr.length = (uint16_t)len;
    slot.hdr.sequence = next_seq;
    (void)memcpy(slot.payload, buf, len);
    slot.hdr.crc32 = crc32_calc(slot.payload, len);

    target_addr = (target_slot == 0U) ? BSP_FLASH_PARAM_SLOT_A_ADDR : BSP_FLASH_PARAM_SLOT_B_ADDR;
    if (!flash_sector_erase(target_addr)) {
        return false;
    }
    if (!flash_program(target_addr, (const uint8_t *)&slot, sizeof(slot))) {
        return false;
    }

    ee_len = (len < DRV_NVM_EEPROM_BYTES) ? (uint16_t)len : (uint16_t)DRV_NVM_EEPROM_BYTES;
    (void)bsp_i2c_eeprom_write(0U, buf, ee_len);

    s_ctx.last_slot = target_slot;
    return true;
}

bool drv_nvm_read_power_recovery(drv_nvm_power_recovery_t *rec)
{
    drv_nvm_recovery_blob_t blob;

    if ((!s_ctx.inited) || (rec == 0)) {
        return false;
    }

    if (!bsp_i2c_eeprom_read((uint16_t)DRV_NVM_RECOVERY_EEPROM_ADDR, (uint8_t *)&blob, sizeof(blob))) {
        return false;
    }

    return recovery_blob_to_record(&blob, rec);
}

bool drv_nvm_write_power_recovery(const drv_nvm_power_recovery_t *rec)
{
    drv_nvm_recovery_blob_t blob;

    if ((!s_ctx.inited) || (rec == 0) ||
        (rec->last_side >= STEP_SIDE_MAX) ||
        (rec->last_action > STEP_ACT_RETRACT_SLOW)) {
        return false;
    }

    recovery_record_to_blob(rec, &blob);
    return bsp_i2c_eeprom_write((uint16_t)DRV_NVM_RECOVERY_EEPROM_ADDR, (const uint8_t *)&blob, sizeof(blob));
}

#else

static drv_nvm_flash_slot_t s_flash_slots[DRV_NVM_FLASH_SLOT_COUNT];
static uint8_t s_eeprom_shadow[DRV_NVM_EEPROM_BYTES];
static bool s_inited = false;
static uint8_t s_last_slot = 0U;
static drv_nvm_recovery_blob_t s_recovery_blob;

static bool flash_slot_is_valid(const drv_nvm_flash_slot_t *slot, uint32_t expected_len)
{
    uint32_t crc;

    if (slot == 0) {
        return false;
    }

    if ((slot->hdr.magic != DRV_NVM_FLASH_SLOT_MAGIC) ||
        (slot->hdr.version != DRV_NVM_FLASH_SLOT_VERSION) ||
        (slot->hdr.length != expected_len) ||
        (expected_len > DRV_NVM_FLASH_SLOT_PAYLOAD_MAX)) {
        return false;
    }

    crc = crc32_calc(slot->payload, expected_len);
    return (crc == slot->hdr.crc32);
}

static bool select_latest_valid_slot(uint32_t len, uint8_t *slot_idx)
{
    bool valid0;
    bool valid1;

    if (slot_idx == 0) {
        return false;
    }

    valid0 = flash_slot_is_valid(&s_flash_slots[0], len);
    valid1 = flash_slot_is_valid(&s_flash_slots[1], len);

    if (!valid0 && !valid1) {
        return false;
    }

    if (valid0 && !valid1) {
        *slot_idx = 0U;
        return true;
    }

    if (!valid0 && valid1) {
        *slot_idx = 1U;
        return true;
    }

    *slot_idx = (s_flash_slots[1].hdr.sequence >= s_flash_slots[0].hdr.sequence) ? 1U : 0U;
    return true;
}

bool drv_nvm_init(void)
{
    s_inited = true;
    (void)memset(s_eeprom_shadow, 0, sizeof(s_eeprom_shadow));
    return true;
}

bool drv_nvm_read_params(uint8_t *buf, uint32_t len)
{
    uint8_t slot_idx;

    if ((!s_inited) || (buf == 0) || (len == 0U) || (len > DRV_NVM_FLASH_SLOT_PAYLOAD_MAX)) {
        return false;
    }

    if (!select_latest_valid_slot(len, &slot_idx)) {
        return false;
    }

    (void)memcpy(buf, s_flash_slots[slot_idx].payload, len);
    s_last_slot = slot_idx;
    return true;
}

bool drv_nvm_write_params(const uint8_t *buf, uint32_t len)
{
    drv_nvm_flash_slot_t *slot;
    uint8_t target_slot;
    uint8_t latest_slot;
    uint32_t next_seq = 1UL;

    if ((!s_inited) || (buf == 0) || (len == 0U) || (len > DRV_NVM_FLASH_SLOT_PAYLOAD_MAX)) {
        return false;
    }

    if (select_latest_valid_slot(len, &latest_slot)) {
        next_seq = s_flash_slots[latest_slot].hdr.sequence + 1UL;
        target_slot = (uint8_t)((latest_slot + 1U) % DRV_NVM_FLASH_SLOT_COUNT);
    } else {
        target_slot = 0U;
    }

    slot = &s_flash_slots[target_slot];
    slot->hdr.magic = DRV_NVM_FLASH_SLOT_MAGIC;
    slot->hdr.version = DRV_NVM_FLASH_SLOT_VERSION;
    slot->hdr.length = (uint16_t)len;
    slot->hdr.sequence = next_seq;
    (void)memcpy(slot->payload, buf, len);
    slot->hdr.crc32 = crc32_calc(slot->payload, len);

    if (len <= sizeof(s_eeprom_shadow)) {
        (void)memcpy(s_eeprom_shadow, buf, len);
    } else {
        (void)memcpy(s_eeprom_shadow, buf, sizeof(s_eeprom_shadow));
    }

    s_last_slot = target_slot;
    return true;
}

bool drv_nvm_read_power_recovery(drv_nvm_power_recovery_t *rec)
{
    if ((!s_inited) || (rec == 0)) {
        return false;
    }

    return recovery_blob_to_record(&s_recovery_blob, rec);
}

bool drv_nvm_write_power_recovery(const drv_nvm_power_recovery_t *rec)
{
    if ((!s_inited) || (rec == 0) ||
        (rec->last_side >= STEP_SIDE_MAX) ||
        (rec->last_action > STEP_ACT_RETRACT_SLOW)) {
        return false;
    }

    recovery_record_to_blob(rec, &s_recovery_blob);
    return true;
}

#endif

