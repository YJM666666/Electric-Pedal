#ifndef DRIVER_DRV_MOTOR_BACKEND_H
#define DRIVER_DRV_MOTOR_BACKEND_H

#include "project_bool.h"
#include "pedal_types.h"
#include <stdint.h>

/*
 * 电机驱动后端 ID 使用数字宏，便于板级配置在预处理表达式中直接引用。
 */
#define DRV_MOTOR_BACKEND_NONE          0U
#define DRV_MOTOR_BACKEND_RELAY_GPIO    1U
#define DRV_MOTOR_BACKEND_PWM_HBRIDGE   2U
#define DRV_MOTOR_BACKEND_REMOTE_U17    3U
#define DRV_MOTOR_BACKEND_CAN_ACTUATOR  4U

typedef struct
{
    uint8_t backend_id;
    bool    supports_local_output;
    bool    supports_pwm;
    bool    supports_remote_command;
} drv_motor_backend_cap_t;

typedef struct
{
    uint8_t backend_id;
    const char *name;
    void (*init)(void);
    void (*exec)(step_side_t side, step_action_t action, bool reverse);
    void (*get_capability)(drv_motor_backend_cap_t *out);
} drv_motor_backend_api_t;

const drv_motor_backend_api_t *drv_motor_backend_select(uint8_t backend_id);
const char *drv_motor_backend_name(uint8_t backend_id);

#endif
