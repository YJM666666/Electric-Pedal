#include "bsp_voice.h"
#include "bsp_build.h"

#if BSP_PLATFORM_GD32
#include "bsp_board.h"
#if defined(BSP_TARGET_GD32C103)
#include "gd32c10x_rcu.h"
#include "gd32c10x_gpio.h"
#else
#include "gd32f1x0_rcu.h"
#include "gd32f1x0_gpio.h"
#endif
#endif

/*
 * MX5008F 时序参数（按当前厂商资料/联调经验收口）
 * --------------------------------------------------
 * BOOT_WAIT_MS        : 上电后等待芯片完成初始化
 * POWER_SETTLE_MS     : 避开电机/继电器等电源扰动，播报前额外等待时间
 * POST_SEND_SAMPLE_MS : 发码后等待一小段时间再看 BUSY
 * PULSE_HIGH_US       : 单个脉冲高电平持续时间
 * PULSE_GAP_MS        : 相邻脉冲之间的间隔
 * STOP_PULSES         : 当前用 1 脉冲作为“停止/静音”兜底指令
 */
#define MX5008_BOOT_WAIT_MS           50U
#define MX5008_POWER_SETTLE_MS        200U
#define MX5008_POST_SEND_SAMPLE_MS    15U
#define MX5008_PULSE_HIGH_US          1000U
#define MX5008_PULSE_GAP_MS           50U
#define MX5008_STOP_PULSES            1U
#define MX5008_SLOT_TO_PULSES(slot)   ((uint16_t)((slot) + 1U))

typedef struct
{
    bool busy;
    bool hw_busy_seen;
    bool pending_start;
    uint16_t remain_10ms;
    uint16_t sample_wait_10ms;
    uint16_t last_word;
    uint16_t boot_guard_10ms;

    bool queued_play;
    uint16_t queued_slot;
    uint16_t queued_estimated_ms;
    uint16_t queued_guard_10ms;
} bsp_voice_ctx_t;

static bsp_voice_ctx_t s_voice;

#if BSP_PLATFORM_GD32
static void voice_delay_cycles(uint32_t cycles)
{
    while (cycles-- > 0U) {
        __asm__("nop");
    }
}

static void voice_delay_us(uint32_t us)
{
    voice_delay_cycles(us * 12U);
}

static void voice_delay_ms(uint32_t ms)
{
    while (ms-- > 0U) {
        voice_delay_us(1000U);
    }
}

static void voice_data(bool level)
{
    if (level) {
        gpio_bit_set(BSP_GPIO_VOICE_DATA_PORT, BSP_GPIO_VOICE_DATA_PIN);
    } else {
        gpio_bit_reset(BSP_GPIO_VOICE_DATA_PORT, BSP_GPIO_VOICE_DATA_PIN);
    }
}

static bool voice_busy_pin(void) 
{
#if BSP_VOICE_BUSY_WIRED
    bool level = (gpio_input_bit_get(BSP_GPIO_VOICE_BUSY_PORT, BSP_GPIO_VOICE_BUSY_PIN) != RESET);
#if BSP_VOICE_BUSY_ACTIVE_LOW
    return !level;
#else
    return level;
#endif
#else
    return false;
#endif
}
#endif

static void voice_arm_soft_fallback(uint16_t estimated_ms)
{
    s_voice.remain_10ms = (uint16_t)((estimated_ms + 9U) / 10U);
    if (s_voice.remain_10ms == 0U) {
        s_voice.remain_10ms = 1U;
    }
}

static bool voice_send_pulses(uint16_t pulses)
{
#if BSP_PLATFORM_GD32
    uint16_t i;

    if (pulses == 0U) {
        return false;
    }
    if (s_voice.boot_guard_10ms > 0U) {
        return false;
    }

    for (i = 0U; i < pulses; ++i) {
        voice_data(true);
        voice_delay_us(MX5008_PULSE_HIGH_US);
        voice_data(false);
        if ((i + 1U) < pulses) {
            voice_delay_ms(MX5008_PULSE_GAP_MS);
        }
    }
    voice_delay_ms(MX5008_POST_SEND_SAMPLE_MS);
#else
    (void)pulses;
#endif
    s_voice.last_word = pulses;
    return true;
}

static bool voice_start_now(uint16_t slot, uint16_t estimated_ms)
{
    uint16_t pulses;

    if (slot == 0U) {
        return false;
    }

    pulses = MX5008_SLOT_TO_PULSES(slot);
    if (!voice_send_pulses(pulses)) {
        return false;
    }

    voice_arm_soft_fallback(estimated_ms);
#if BSP_PLATFORM_GD32 && BSP_VOICE_BUSY_WIRED
    s_voice.hw_busy_seen = false;
    s_voice.pending_start = true;
    s_voice.sample_wait_10ms = 2U;
    s_voice.busy = voice_busy_pin();
    if (s_voice.busy) {
        s_voice.hw_busy_seen = true;
        s_voice.pending_start = false;
    }
#else
    s_voice.busy = true;
#endif
    return true;
}

void bsp_voice_init(void)
{
#if BSP_PLATFORM_GD32
    rcu_periph_clock_enable(BSP_GPIO_VOICE_DATA_RCU);
#if BSP_VOICE_BUSY_WIRED
    rcu_periph_clock_enable(BSP_GPIO_VOICE_BUSY_RCU);
#endif

#if defined(BSP_TARGET_GD32C103)
    gpio_init(BSP_GPIO_VOICE_DATA_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, BSP_GPIO_VOICE_DATA_PIN);
#if BSP_VOICE_BUSY_WIRED
    gpio_init(BSP_GPIO_VOICE_BUSY_PORT, GPIO_MODE_IPU, GPIO_OSPEED_50MHZ, BSP_GPIO_VOICE_BUSY_PIN);
#endif
#else
    gpio_mode_set(BSP_GPIO_VOICE_DATA_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, BSP_GPIO_VOICE_DATA_PIN);
    gpio_output_options_set(BSP_GPIO_VOICE_DATA_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, BSP_GPIO_VOICE_DATA_PIN);
#if BSP_VOICE_BUSY_WIRED
    gpio_mode_set(BSP_GPIO_VOICE_BUSY_PORT, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, BSP_GPIO_VOICE_BUSY_PIN);
#endif
#endif
    voice_data(false);
    voice_delay_ms(MX5008_BOOT_WAIT_MS);
#endif

    s_voice.busy = false;
    s_voice.hw_busy_seen = false;
    s_voice.pending_start = false;
    s_voice.remain_10ms = 0U;
    s_voice.sample_wait_10ms = 0U;
    s_voice.last_word = 0U;
    s_voice.boot_guard_10ms = (uint16_t)((MX5008_BOOT_WAIT_MS + 9U) / 10U);
    s_voice.queued_play = false;
    s_voice.queued_slot = 0U;
    s_voice.queued_estimated_ms = 0U;
    s_voice.queued_guard_10ms = 0U;
}

void bsp_voice_tick_10ms(void)
{
    if (s_voice.boot_guard_10ms > 0U) {
        s_voice.boot_guard_10ms--;
    }

    if (s_voice.remain_10ms > 0U) {
        s_voice.remain_10ms--;
    }

#if BSP_PLATFORM_GD32 && BSP_VOICE_BUSY_WIRED
    {
        bool pin_busy = voice_busy_pin();

        if (s_voice.sample_wait_10ms > 0U) {
            s_voice.sample_wait_10ms--;
        }

        if (pin_busy) {
            s_voice.hw_busy_seen = true;
            s_voice.pending_start = false;
            s_voice.busy = true;
        } else if (s_voice.hw_busy_seen) {
            s_voice.hw_busy_seen = false;
            s_voice.pending_start = false;
            s_voice.busy = false;
            s_voice.remain_10ms = 0U;
        } else if (s_voice.pending_start) {
            if (s_voice.sample_wait_10ms == 0U) {
                s_voice.pending_start = false;
                s_voice.busy = false;
                s_voice.remain_10ms = 0U;
            }
        } else {
            s_voice.busy = false;
        }
    }
#else
    if (s_voice.remain_10ms == 0U) {
        s_voice.busy = false;
    }
#endif

    if (s_voice.queued_play) {
        if (s_voice.queued_guard_10ms > 0U) {
            s_voice.queued_guard_10ms--;
        }

        if ((s_voice.queued_guard_10ms == 0U) &&
            !s_voice.busy &&
            !s_voice.pending_start &&
            !s_voice.hw_busy_seen) {
            if (voice_start_now(s_voice.queued_slot, s_voice.queued_estimated_ms)) {
                s_voice.queued_play = false;
                s_voice.queued_slot = 0U;
                s_voice.queued_estimated_ms = 0U;
            }
        }
    }
}

bool bsp_voice_is_busy(void)
{
    return s_voice.busy || s_voice.queued_play;
}

bool bsp_voice_send_word(uint16_t pulses)
{
    return voice_send_pulses(pulses);
}

bool bsp_voice_play_slot(uint16_t slot, uint16_t estimated_ms)
{
    if (slot == 0U) {
        return false;
    }

    /*
     * 参考 MX5008F 资料：若系统里有电机/继电器等对电源有影响的负载，
     * 建议在电源稳定后再驱动语音芯片，建议延时 200ms 以上。
     * 当前统一采用“排队 + 200ms 守门”策略，提高实车鲁棒性。
     */
    s_voice.queued_play = true;
    s_voice.queued_slot = slot;
    s_voice.queued_estimated_ms = estimated_ms;
    s_voice.queued_guard_10ms = (uint16_t)((MX5008_POWER_SETTLE_MS + 9U) / 10U);
    return true;
}

bool bsp_voice_stop(void)
{
    s_voice.busy = false;
    s_voice.hw_busy_seen = false;
    s_voice.pending_start = false;
    s_voice.sample_wait_10ms = 0U;
    s_voice.remain_10ms = 0U;
    s_voice.queued_play = false;
    s_voice.queued_slot = 0U;
    s_voice.queued_estimated_ms = 0U;
    s_voice.queued_guard_10ms = 0U;

    (void)voice_send_pulses(MX5008_STOP_PULSES);
#if BSP_PLATFORM_GD32
    voice_data(false);
#endif
    return true;
}
