#ifndef BSP_CAN_H
#define BSP_CAN_H

#include <stdint.h>
#include "project_bool.h"

typedef enum
{
    BSP_CAN_BUS0_HS_FD = 0,
    BSP_CAN_BUS1_LS_CLASSIC,
    BSP_CAN_BUS_MAX
} bsp_can_bus_t;

typedef enum
{
    BSP_CAN_MONITOR_BOTH = 0,
    BSP_CAN_MONITOR_HS_ONLY = 1,
    BSP_CAN_MONITOR_LS_ONLY = 2
} bsp_can_monitor_sel_t;

typedef struct
{
    uint32_t id;
    uint8_t  dlc;
    uint8_t  data[64];
    bool     is_extended;
    bool     fd_enable;
    bool     brs_enable;
    bsp_can_bus_t bus;
} bsp_can_frame_t;

typedef struct
{
    uint32_t nominal_bitrate;
    uint32_t data_bitrate;
    bool     fd_enable;
    bool     listen_only;
} bsp_can_bus_cfg_t;

typedef struct
{
    bsp_can_bus_cfg_t bus0_hs_fd;      /* CAN0 对应 SIT1044 高速 CAN-FD 收发器 */
    bsp_can_bus_cfg_t bus1_ls_classic; /* CAN1 使用 TJA1055（容错低速 PHY） */
    /* CAN0 使用 SIT1044（CAN-FD PHY） */
    /* 注意：上面的顺序与硬件拓扑一致 */
    bsp_can_monitor_sel_t monitor_sel;
} bsp_can_dual_cfg_t;

void bsp_can_init(void);
void bsp_can_init_with_cfg(const bsp_can_dual_cfg_t *cfg);
void bsp_can_set_monitor_sel(bsp_can_monitor_sel_t sel);
bool bsp_can_send(const bsp_can_frame_t *frame);
bool bsp_can_receive(bsp_can_frame_t *frame);
const bsp_can_dual_cfg_t *bsp_can_get_cfg(void);

#endif
