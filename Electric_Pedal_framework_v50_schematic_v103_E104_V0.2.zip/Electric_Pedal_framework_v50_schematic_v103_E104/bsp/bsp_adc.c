﻿/*
 * ADC 鏉跨骇椹卞姩锛氶噰闆嗗乏鍙崇數鏈虹數娴佺瓑妯℃嫙閲忥紝骞跺悜淇濇姢閫昏緫鎻愪緵鍘熷閲囨牱鍊笺€? */
#include "bsp_adc.h"
#include "bsp_build.h"

#if BSP_PLATFORM_GD32 && defined(BSP_TARGET_GD32F130)
#include "gd32f1x0.h"
#include "gd32f1x0_adc.h"

static void adc_polling_mode_irq_guard(void)
{
    /* U17 当前使用轮询方式读取 ADC，不使用 ADC/CMP 中断。 */
    adc_interrupt_disable(ADC_INT_WDE | ADC_INT_EOC | ADC_INT_EO     IC);
    adc_interrupt_flag_clear(ADC_INT_FLAG_WDE | ADC_INT_FLAG_EOC | ADC_INT_FLAG_EOIC);
    NVIC_DisableIRQ(ADC_CMP_IRQn);
    NVIC_ClearPendingIRQ(ADC_CMP_IRQn);
}

void ADC_CMP_IRQHandler(void)
{
    adc_polling_mode_irq_guard();
}
#endif
#if BSP_PLATFORM_GD32 && (BSP_HAS_CURRENT_ADC != 0U)
#include "bsp_board.h"

static uint16_t adc_sample(uint8_t channel)
{
    #if defined(BSP_TARGET_GD32C103)
    adc_regular_channel_config(ADC0, 0U, channel, ADC_SAMPLETIME_7POINT5);
    adc_software_trigger_enable(ADC0, ADC_REGULAR_CHANNEL);
    while (!adc_flag_get(ADC0, ADC_FLAG_EOC)) {
    }
    adc_flag_clear(ADC0, ADC_FLAG_EOC);
    return adc_regular_data_read(ADC0);
#else
    adc_regular_channel_config(0U, channel, ADC_SAMPLETIME_7POINT5);
    adc_software_trigger_enable(ADC_REGULAR_CHANNEL);
    while (!adc_flag_get(ADC_FLAG_EOC)) {
    }
    adc_flag_clear(ADC_FLAG_EOC);
    return adc_regular_data_read();
#endif
}

void bsp_adc_init(void)
{
    if (BSP_HAS_CURRENT_ADC == 0U) {
        return;
    }

#if defined(BSP_TARGET_GD32C103)
    rcu_periph_clock_enable(BSP_ADC_GPIO_RCU);
    rcu_periph_clock_enable(RCU_ADC0);
    rcu_adc_clock_config(RCU_CKADC_CKAPB2_DIV6);
    gpio_init(BSP_ADC_LEFT_PORT, GPIO_MODE_AIN, GPIO_OSPEED_50MHZ, BSP_ADC_LEFT_PIN | BSP_ADC_RIGHT_PIN);
    adc_deinit(ADC0);
    adc_data_alignment_config(ADC0, ADC_DATAALIGN_RIGHT);
    adc_channel_length_config(ADC0, ADC_REGULAR_CHANNEL, 1U);
    adc_external_trigger_source_config(ADC0, ADC_REGULAR_CHANNEL, ADC0_1_EXTTRIG_REGULAR_NONE);
    adc_external_trigger_config(ADC0, ADC_REGULAR_CHANNEL, ENABLE);
    adc_enable(ADC0);
    for (volatile uint32_t i = 0U; i < 2000U; ++i) { }
    adc_calibration_enable(ADC0);
#else
    rcu_periph_clock_enable(BSP_ADC_GPIO_RCU);
    rcu_periph_clock_enable(RCU_ADC);
    rcu_adc_clock_config(RCU_ADCCK_APB2_DIV6);

    gpio_mode_set(BSP_ADC_LEFT_PORT,
                  GPIO_MODE_ANALOG,
                  GPIO_PUPD_NONE,
                  BSP_ADC_LEFT_PIN | BSP_ADC_RIGHT_PIN);

    adc_deinit();
    adc_polling_mode_irq_guard();
    adc_data_alignment_config(ADC_DATAALIGN_RIGHT);
    adc_channel_length_config(ADC_REGULAR_CHANNEL, 1U);
    adc_external_trigger_source_config(ADC_REGULAR_CHANNEL, ADC_EXTTRIG_REGULAR_NONE);
    adc_external_trigger_config(ADC_REGULAR_CHANNEL, ENABLE);
    adc_enable();

    for (volatile uint32_t i = 0U; i < 2000U; ++i) {
    }
    adc_calibration_enable();
    adc_polling_mode_irq_guard();
#endif
}

uint16_t bsp_adc_get_left_current_raw(void)
{
    if (BSP_HAS_CURRENT_ADC == 0U) {
        return 0U;
    }
    return adc_sample(BSP_ADC_LEFT_CHANNEL);
}

uint16_t bsp_adc_get_right_current_raw(void)
{
    if (BSP_HAS_CURRENT_ADC == 0U) {
        return 0U;
    }
    return adc_sample(BSP_ADC_RIGHT_CHANNEL);
}

void bsp_adc_mock_set_left_current_raw(uint16_t value)
{
    (void)value;
}

void bsp_adc_mock_set_right_current_raw(uint16_t value)
{
    (void)value;
}

#else

static uint16_t s_left_raw = 0U;
static uint16_t s_right_raw = 0U;

void bsp_adc_init(void)
{
    s_left_raw = 0U;
    s_right_raw = 0U;
}

uint16_t bsp_adc_get_left_current_raw(void)
{
    return s_left_raw;
}

uint16_t bsp_adc_get_right_current_raw(void)
{
    return s_right_raw;
}

void bsp_adc_mock_set_left_current_raw(uint16_t value)
{
    s_left_raw = value;
}

void bsp_adc_mock_set_right_current_raw(uint16_t value)
{
    s_right_raw = value;
}

#endif



