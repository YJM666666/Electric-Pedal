#ifndef BSP_SPI_H
#define BSP_SPI_H

/*
 * SPI 抽象接口：上层存储驱动通过这里完成片选控制和字节传输。
 */
#include "project_bool.h"
#include <stddef.h>
#include <stdint.h>

void bsp_spi_init(void);
bool bsp_spi_flash_select(bool active);
bool bsp_spi_flash_transfer(const uint8_t *tx, uint8_t *rx, size_t len);

#endif
