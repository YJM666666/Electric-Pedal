#include <string.h>
/*
 * I2C 板级驱动：用于访问板载 EEPROM 等低速外设。
 */
#include "bsp_i2c.h"
#include "bsp_build.h"

#if BSP_PLATFORM_GD32
#include "bsp_board.h"

#define I2C_TIMEOUT_MAX  0x1FFFFUL

typedef struct
{
    uint32_t        periph;
    rcu_periph_enum periph_rcu;
    rcu_periph_enum gpio_rcu;
    uint32_t        scl_port;
    uint32_t        scl_pin;
    uint32_t        sda_port;
    uint32_t        sda_pin;
    uint32_t        af;
    bool            enabled;
} i2c_hw_t;

#if BSP_HAS_EEPROM
static i2c_hw_t s_i2c_eeprom = {
    BSP_I2C_EE_PERIPH,
    BSP_I2C_EE_RCU,
    BSP_I2C_EE_GPIO_RCU,
    BSP_I2C_EE_SCL_PORT,
    BSP_I2C_EE_SCL_PIN,
    BSP_I2C_EE_SDA_PORT,
    BSP_I2C_EE_SDA_PIN,
    BSP_I2C_EE_AF,
    false
};
#endif

#if BSP_HAS_VOICE_I2C
static i2c_hw_t s_i2c_voice = {
    BSP_I2C_VOICE_PERIPH,
    BSP_I2C_VOICE_RCU,
    BSP_I2C_VOICE_GPIO_RCU,
    BSP_I2C_VOICE_SCL_PORT,
    BSP_I2C_VOICE_SCL_PIN,
    BSP_I2C_VOICE_SDA_PORT,
    BSP_I2C_VOICE_SDA_PIN,
    BSP_I2C_VOICE_AF,
    false
};
#endif

static uint32_t ee_dev_addr_from_mem(uint16_t mem_addr)
{
    return (uint32_t)((BSP_EEPROM_DEV_ADDR | ((mem_addr >> 8U) & 0x01U)) << 1U);
}

static bool wait_flag(uint32_t periph, i2c_flag_enum flag, FlagStatus want)
{
    uint32_t timeout = I2C_TIMEOUT_MAX;
    while (i2c_flag_get(periph, flag) != want) {
        if (timeout == 0U) {
            return false;
        }
        timeout--;
    }
    return true;
}

static void i2c_bus_init(i2c_hw_t *hw)
{
    if ((hw == 0) || hw->enabled) {
        return;
    }

    rcu_periph_clock_enable(hw->gpio_rcu);
    rcu_periph_clock_enable(hw->periph_rcu);

#if defined(BSP_TARGET_GD32C103)
#ifdef BSP_I2C_EE_REMAP
    rcu_periph_clock_enable(RCU_AF);
    gpio_pin_remap_config(BSP_I2C_EE_REMAP, ENABLE);
#endif
    gpio_init(hw->scl_port, GPIO_MODE_AF_OD, GPIO_OSPEED_50MHZ, hw->scl_pin);
    gpio_init(hw->sda_port, GPIO_MODE_AF_OD, GPIO_OSPEED_50MHZ, hw->sda_pin);
#else
    gpio_af_set(hw->scl_port, hw->af, hw->scl_pin);
    gpio_af_set(hw->sda_port, hw->af, hw->sda_pin);
    gpio_mode_set(hw->scl_port, GPIO_MODE_AF, GPIO_PUPD_PULLUP, hw->scl_pin);
    gpio_output_options_set(hw->scl_port, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, hw->scl_pin);
    gpio_mode_set(hw->sda_port, GPIO_MODE_AF, GPIO_PUPD_PULLUP, hw->sda_pin);
    gpio_output_options_set(hw->sda_port, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, hw->sda_pin);
#endif

    i2c_deinit(hw->periph);
    i2c_clock_config(hw->periph, 100000U, I2C_DTCY_2);
    i2c_mode_addr_config(hw->periph, I2C_I2CMODE_ENABLE, I2C_ADDFORMAT_7BITS, 0x00U);
    i2c_enable(hw->periph);
    i2c_ack_config(hw->periph, I2C_ACK_ENABLE);
    hw->enabled = true;
}

static bool i2c_tx_only(i2c_hw_t *hw, uint8_t dev_addr_7bit, const uint8_t *data, size_t len)
{
    size_t i;
    uint32_t dev_addr;

    if ((hw == 0) || (data == 0) || (len == 0U)) {
        return false;
    }

    i2c_bus_init(hw);
    dev_addr = (uint32_t)dev_addr_7bit << 1U;

    i2c_ack_config(hw->periph, I2C_ACK_ENABLE);
    i2c_start_on_bus(hw->periph);
    if (!wait_flag(hw->periph, I2C_FLAG_SBSEND, SET)) {
        return false;
    }
    i2c_master_addressing(hw->periph, dev_addr, I2C_TRANSMITTER);
    if (!wait_flag(hw->periph, I2C_FLAG_ADDSEND, SET)) {
        return false;
    }
    i2c_flag_clear(hw->periph, I2C_FLAG_ADDSEND);
    if (!wait_flag(hw->periph, I2C_FLAG_TBE, SET)) {
        return false;
    }

    for (i = 0U; i < len; ++i) {
        i2c_data_transmit(hw->periph, data[i]);
        if (!wait_flag(hw->periph, I2C_FLAG_TBE, SET)) {
            return false;
        }
    }

    i2c_stop_on_bus(hw->periph);
    return true;
}

static bool i2c_tx_rx(i2c_hw_t *hw,
                      uint8_t dev_addr_7bit,
                      const uint8_t *tx,
                      size_t tx_len,
                      uint8_t *rx,
                      size_t rx_len)
{
    size_t i;
    uint32_t dev_addr;

    if ((hw == 0) || (rx == 0) || (rx_len == 0U)) {
        return false;
    }

    i2c_bus_init(hw);
    dev_addr = (uint32_t)dev_addr_7bit << 1U;

    if ((tx != 0) && (tx_len > 0U)) {
        i2c_ack_config(hw->periph, I2C_ACK_ENABLE);
        i2c_start_on_bus(hw->periph);
        if (!wait_flag(hw->periph, I2C_FLAG_SBSEND, SET)) {
            return false;
        }
        i2c_master_addressing(hw->periph, dev_addr, I2C_TRANSMITTER);
        if (!wait_flag(hw->periph, I2C_FLAG_ADDSEND, SET)) {
            return false;
        }
        i2c_flag_clear(hw->periph, I2C_FLAG_ADDSEND);
        if (!wait_flag(hw->periph, I2C_FLAG_TBE, SET)) {
            return false;
        }
        for (i = 0U; i < tx_len; ++i) {
            i2c_data_transmit(hw->periph, tx[i]);
            if (!wait_flag(hw->periph, I2C_FLAG_TBE, SET)) {
                return false;
            }
        }
    }

    i2c_start_on_bus(hw->periph);
    if (!wait_flag(hw->periph, I2C_FLAG_SBSEND, SET)) {
        return false;
    }
    i2c_master_addressing(hw->periph, dev_addr, I2C_RECEIVER);
    if (!wait_flag(hw->periph, I2C_FLAG_ADDSEND, SET)) {
        return false;
    }
    i2c_flag_clear(hw->periph, I2C_FLAG_ADDSEND);

    for (i = 0U; i < rx_len; ++i) {
        if (i == (rx_len - 1U)) {
            i2c_ack_config(hw->periph, I2C_ACK_DISABLE);
            i2c_stop_on_bus(hw->periph);
        }
        if (!wait_flag(hw->periph, I2C_FLAG_RBNE, SET)) {
            return false;
        }
        rx[i] = i2c_data_receive(hw->periph);
    }

    i2c_ack_config(hw->periph, I2C_ACK_ENABLE);
    return true;
}

#if BSP_HAS_EEPROM
static bool eeprom_write_page(uint16_t mem_addr, const uint8_t *data, size_t len)
{
    size_t i;
    uint8_t tmp[1U + BSP_EEPROM_PAGE_SIZE];

    if ((data == 0) || (len == 0U) || (len > BSP_EEPROM_PAGE_SIZE)) {
        return false;
    }

    tmp[0] = (uint8_t)(mem_addr & 0xFFU);
    for (i = 0U; i < len; ++i) {
        tmp[1U + i] = data[i];
    }

    if (!i2c_tx_only(&s_i2c_eeprom, (uint8_t)(ee_dev_addr_from_mem(mem_addr) >> 1U), tmp, len + 1U)) {
        return false;
    }

    for (volatile uint32_t d = 0U; d < 5000U; ++d) {
    }
    return true;
}
#endif

void bsp_i2c_init(void)
{
#if BSP_HAS_EEPROM
    i2c_bus_init(&s_i2c_eeprom);
#endif
#if BSP_HAS_VOICE_I2C
    i2c_bus_init(&s_i2c_voice);
#endif
}

bool bsp_i2c_eeprom_read(uint16_t mem_addr, uint8_t *data, size_t len)
{
#if BSP_HAS_EEPROM
    uint8_t reg = (uint8_t)(mem_addr & 0xFFU);
    return i2c_tx_rx(&s_i2c_eeprom,
                     (uint8_t)(ee_dev_addr_from_mem(mem_addr) >> 1U),
                     &reg,
                     1U,
                     data,
                     len);
#else
    (void)mem_addr;
    if ((data == 0) || (len == 0U)) {
        return false;
    }
    memset(data, 0, len);
    return true;
#endif
}

bool bsp_i2c_eeprom_write(uint16_t mem_addr, const uint8_t *data, size_t len)
{
#if BSP_HAS_EEPROM
    size_t done = 0U;
    size_t chunk;
    uint16_t page_space;

    if ((data == 0) || (len == 0U)) {
        return false;
    }

    while (done < len) {
        page_space = (uint16_t)(BSP_EEPROM_PAGE_SIZE - (mem_addr % BSP_EEPROM_PAGE_SIZE));
        chunk = len - done;
        if (chunk > page_space) {
            chunk = page_space;
        }
        if (!eeprom_write_page(mem_addr, &data[done], chunk)) {
            return false;
        }
        mem_addr = (uint16_t)(mem_addr + chunk);
        done += chunk;
    }
    return true;
#else
    (void)mem_addr;
    (void)data;
    return (len > 0U);
#endif
}

bool bsp_i2c_voice_write(uint8_t dev_addr_7bit, const uint8_t *data, size_t len)
{
#if BSP_HAS_VOICE_I2C
    return i2c_tx_only(&s_i2c_voice, dev_addr_7bit, data, len);
#else
    (void)dev_addr_7bit;
    (void)data;
    return (len > 0U);
#endif
}

bool bsp_i2c_voice_write_read(uint8_t dev_addr_7bit,
                              const uint8_t *tx,
                              size_t tx_len,
                              uint8_t *rx,
                              size_t rx_len)
{
#if BSP_HAS_VOICE_I2C
    return i2c_tx_rx(&s_i2c_voice, dev_addr_7bit, tx, tx_len, rx, rx_len);
#else
    (void)dev_addr_7bit;
    (void)tx;
    (void)tx_len;
    if ((rx == 0) || (rx_len == 0U)) {
        return false;
    }
    memset(rx, 0, rx_len);
    return true;
#endif
}

#else

void bsp_i2c_init(void)
{
}

bool bsp_i2c_eeprom_read(uint16_t mem_addr, uint8_t *data, size_t len)
{
    (void)mem_addr;
    if ((data == 0) || (len == 0U)) {
        return false;
    }
    memset(data, 0, len);
    return true;
}

bool bsp_i2c_eeprom_write(uint16_t mem_addr, const uint8_t *data, size_t len)
{
    (void)mem_addr;
    (void)data;
    return (len > 0U);
}

bool bsp_i2c_voice_write(uint8_t dev_addr_7bit, const uint8_t *data, size_t len)
{
    (void)dev_addr_7bit;
    (void)data;
    return (len > 0U);
}

bool bsp_i2c_voice_write_read(uint8_t dev_addr_7bit,
                              const uint8_t *tx,
                              size_t tx_len,
                              uint8_t *rx,
                              size_t rx_len)
{
    (void)dev_addr_7bit;
    (void)tx;
    (void)tx_len;
    if ((rx == 0) || (rx_len == 0U)) {
        return false;
    }
    memset(rx, 0, rx_len);
    return true;
}

#endif
