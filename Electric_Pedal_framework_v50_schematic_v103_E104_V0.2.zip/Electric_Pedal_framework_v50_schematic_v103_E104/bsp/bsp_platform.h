#ifndef BSP_PLATFORM_H
#define BSP_PLATFORM_H

/*
 * 平台初始化接口：封装时钟、调试口和 MCU 基础配置。
 */
#include "project_bool.h"
#include <stdint.h>

void bsp_platform_init(void);
uint32_t bsp_platform_system_clock_hz(void);
bool bsp_platform_is_target(void);
void bsp_platform_system_reset(void);

#endif
