#ifndef BSP_GPIO_H
#define BSP_GPIO_H

#include "project_bool.h"
#include "bsp_board.h"
#include <stdint.h>

typedef bsp_gpio_out_id_t bsp_gpio_out_t;
typedef bsp_gpio_in_id_t bsp_gpio_in_t;

/* 供灯光/语音模块兼容使用的别名。 */
#define BSP_GPIO_OUT_LIGHT_DATA_L   BSP_GPIO_OUT_LIGHT_L
#define BSP_GPIO_OUT_LIGHT_DATA_R   BSP_GPIO_OUT_LIGHT_R
#define BSP_GPIO_OUT_LIGHT_DATA_L1  BSP_GPIO_OUT_LIGHT_L
#define BSP_GPIO_OUT_LIGHT_DATA_R1  BSP_GPIO_OUT_LIGHT_R
#define BSP_GPIO_OUT_LIGHT_EN       BSP_GPIO_OUT_DRIVER_EN
#define BSP_GPIO_OUT_VOICE_EN       BSP_GPIO_OUT_BUZZER
#define BSP_GPIO_OUT_VOICE_RESET_N  BSP_GPIO_OUT_VOICE_RESET

void bsp_gpio_init(void);
void bsp_gpio_write(bsp_gpio_out_t id, bool level);
bool bsp_gpio_read_in(bsp_gpio_in_t id);
bool bsp_gpio_read_out(bsp_gpio_out_t id);

/* 测试/框架辅助函数 */
void bsp_gpio_mock_set_in(bsp_gpio_in_t id, bool level);

#endif
