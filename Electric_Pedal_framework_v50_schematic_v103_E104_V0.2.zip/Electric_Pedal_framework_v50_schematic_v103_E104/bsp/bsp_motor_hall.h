#ifndef BSP_MOTOR_HALL_H
#define BSP_MOTOR_HALL_H

/*
 * 霍尔反馈接口：隐藏具体 GPIO/中断来源，只向上层提供脉冲计数和边沿状态。
 */
#include "project_bool.h"
#include "pedal_types.h"
#include <stdint.h>

void bsp_motor_hall_init(void);
void bsp_motor_hall_irq_edge(step_side_t side);
void bsp_motor_hall_mock_trigger(step_side_t side, uint16_t pulses);

#endif
