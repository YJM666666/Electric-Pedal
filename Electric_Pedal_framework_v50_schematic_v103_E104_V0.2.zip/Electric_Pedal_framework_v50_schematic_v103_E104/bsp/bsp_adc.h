#ifndef BSP_ADC_H
#define BSP_ADC_H

/*
 * ADC 抽象接口：业务层只读取规范化的原始值，不直接关心具体通道和采样时序。
 */
#include <stdint.h>

void bsp_adc_init(void);
uint16_t bsp_adc_get_left_current_raw(void);
uint16_t bsp_adc_get_right_current_raw(void);
void bsp_adc_mock_set_left_current_raw(uint16_t value);
void bsp_adc_mock_set_right_current_raw(uint16_t value);

#endif
