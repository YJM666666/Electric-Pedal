#ifndef BSP_BUILD_H
#define BSP_BUILD_H

/*
 * 编译角色选择。
 * U12 主控：定义 APP_ROLE_U12_MAIN。
 * U17 执行侧：定义 APP_ROLE_U17_SLAVE。
 *
 * 使用 ARMCC/ARMClang 构建，或显式设置 BSP_TARGET_* 宏时，启用真实 GD32 目标路径。
 */
#if defined(BSP_TARGET_GD32F130) || defined(BSP_TARGET_GD32C103) || defined(__CC_ARM) || defined(__ARMCC_VERSION) || defined(__ARM_ARCH)
#define BSP_PLATFORM_GD32   1
#else
#define BSP_PLATFORM_GD32   0
#endif


#if !defined(APP_ROLE_U12_MAIN) && !defined(APP_ROLE_U17_SLAVE)
#define APP_ROLE_U12_MAIN    1
#endif

#endif
