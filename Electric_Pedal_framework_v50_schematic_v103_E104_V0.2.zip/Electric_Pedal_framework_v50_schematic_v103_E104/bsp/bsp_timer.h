#ifndef BSP_TIMER_H
#define BSP_TIMER_H

/*
 * 定时器接口：提供系统毫秒计数和定时器初始化入口。
 */
#include <stdint.h>

void bsp_timer_init(void);
void bsp_timer_irq_1ms(void);
void bsp_timer_mock_advance(uint32_t ms);
uint32_t bsp_timer_now_ms(void);

#endif
