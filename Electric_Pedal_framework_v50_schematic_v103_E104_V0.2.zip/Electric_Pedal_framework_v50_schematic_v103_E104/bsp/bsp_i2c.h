﻿#ifndef BSP_I2C_H
#define BSP_I2C_H

#include "project_bool.h"
#include <stddef.h>
#include <stdint.h>

void bsp_i2c_init(void);

bool bsp_i2c_eeprom_read(uint16_t mem_addr, uint8_t *data, size_t len);
bool bsp_i2c_eeprom_write(uint16_t mem_addr, const uint8_t *data, size_t len);

/*
 * 保留在 U17 的 PF6/PF7 总线上的通用主机到语音芯片传输接口。
 * 初版 MX5008F 数据手册未公布最终命令表或固定的 7 位地址，因此上层需要显式传入设备地址。
 */
bool bsp_i2c_voice_write(uint8_t dev_addr_7bit, const uint8_t *data, size_t len);
bool bsp_i2c_voice_write_read(uint8_t dev_addr_7bit,
                              const uint8_t *tx,
                              size_t tx_len,
                              uint8_t *rx,
                              size_t rx_len);

#endif
