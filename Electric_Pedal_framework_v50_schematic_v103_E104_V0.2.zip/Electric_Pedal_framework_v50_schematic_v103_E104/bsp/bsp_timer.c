/*
 * 定时器板级驱动：产生系统节拍，并驱动调度器按固定周期运行。
 */
#include "bsp_timer.h"
#include "bsp_build.h"
#include "sw_timer.h"
#include "event_flags.h"

#if BSP_PLATFORM_GD32
#include "bsp_platform.h"
#if defined(BSP_TARGET_GD32C103)
#include "gd32c10x.h"
#else
#include "gd32f1x0.h"
#endif

static volatile uint32_t s_ms_tick = 0U;
static uint8_t s_div10 = 0U;
static uint8_t s_div100 = 0U;
static uint16_t s_div1000 = 0U;

static void post_tick_event(event_id_t id)
{
    event_flags_raise_tick_isr(id);
}

void bsp_timer_init(void)
{
    s_ms_tick = 0U;
    s_div10 = 0U;
    s_div100 = 0U;
    s_div1000 = 0U;
    SysTick_Config(bsp_platform_system_clock_hz() / 1000UL);
}

void bsp_timer_irq_1ms(void)
{
    sw_timer_tick_1ms();
    post_tick_event(EV_TICK_1MS);
    s_ms_tick++;

    s_div10++;
    if (s_div10 >= 10U) {
        s_div10 = 0U;
        post_tick_event(EV_TICK_10MS);
    }

    s_div100++;
    if (s_div100 >= 100U) {
        s_div100 = 0U;
        post_tick_event(EV_TICK_100MS);
    }

    s_div1000++;
    if (s_div1000 >= 1000U) {
        s_div1000 = 0U;
        post_tick_event(EV_TICK_1S);
    }
}

void SysTick_Handler(void)
{
    bsp_timer_irq_1ms();
}

void bsp_timer_mock_advance(uint32_t ms)
{
    (void)ms;
}

uint32_t bsp_timer_now_ms(void)
{
    return s_ms_tick;
}

#else

static uint8_t s_div10 = 0U;
static uint8_t s_div100 = 0U;
static uint16_t s_div1000 = 0U;
static uint32_t s_ms_tick = 0U;

static void post_tick_event(event_id_t id)
{
    event_flags_raise_tick_isr(id);
}

void bsp_timer_init(void)
{
    s_div10 = 0U;
    s_div100 = 0U;
    s_div1000 = 0U;
    s_ms_tick = 0U;
}

void bsp_timer_irq_1ms(void)
{
    sw_timer_tick_1ms();
    post_tick_event(EV_TICK_1MS);
    s_ms_tick++;

    s_div10++;
    if (s_div10 >= 10U) {
        s_div10 = 0U;
        post_tick_event(EV_TICK_10MS);
    }

    s_div100++;
    if (s_div100 >= 100U) {
        s_div100 = 0U;
        post_tick_event(EV_TICK_100MS);
    }

    s_div1000++;
    if (s_div1000 >= 1000U) {
        s_div1000 = 0U;
        post_tick_event(EV_TICK_1S);
    }
}

void bsp_timer_mock_advance(uint32_t ms)
{
    uint32_t i;

    for (i = 0U; i < ms; ++i) {
        bsp_timer_irq_1ms();
    }
}

uint32_t bsp_timer_now_ms(void)
{
    return s_ms_tick;
}

#endif
