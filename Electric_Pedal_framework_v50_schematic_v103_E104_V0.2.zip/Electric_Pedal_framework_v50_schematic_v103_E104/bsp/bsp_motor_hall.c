/*
 * 电机霍尔输入驱动：采集左右电机霍尔脉冲，为行程判断、防堵转和位置校准提供依据。
 */
#include "bsp_motor_hall.h"
#include "bsp_board.h"
#include "bsp_build.h"
#include "motor_pulse_latch.h"

#if !defined(BSP_HAS_MOTOR_HALL_INPUT) 
#define BSP_HAS_MOTOR_HALL_INPUT 0U
#endif

#if BSP_PLATFORM_GD32 && (BSP_HAS_MOTOR_HALL_INPUT != 0U)
#if defined(BSP_TARGET_GD32C103)
#include "gd32c10x.h"
#else
#include "gd32f1x0.h"
#endif

static void hall_gpio_prepare(void)
{
#if defined(BSP_TARGET_GD32C103)
    rcu_periph_clock_enable(BSP_GPIO_L_HALL_RCU);
    rcu_periph_clock_enable(BSP_GPIO_R_HALL_RCU);
    rcu_periph_clock_enable(RCU_AF);
    gpio_init(BSP_GPIO_L_HALL_PORT, GPIO_MODE_IPU, GPIO_OSPEED_50MHZ, BSP_GPIO_L_HALL_PIN);
    gpio_init(BSP_GPIO_R_HALL_PORT, GPIO_MODE_IPU, GPIO_OSPEED_50MHZ, BSP_GPIO_R_HALL_PIN);
#else
    rcu_periph_clock_enable(BSP_GPIO_L_HALL_RCU);
    rcu_periph_clock_enable(BSP_GPIO_R_HALL_RCU);
    gpio_mode_set(BSP_GPIO_L_HALL_PORT, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, BSP_GPIO_L_HALL_PIN);
    gpio_mode_set(BSP_GPIO_R_HALL_PORT, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, BSP_GPIO_R_HALL_PIN);
#endif
}

static void hall_exti_prepare(void)
{
#if defined(BSP_TARGET_GD32C103)
    gpio_exti_source_select(BSP_GPIO_L_HALL_PORT_SRC, BSP_GPIO_L_HALL_PIN_SRC);
    gpio_exti_source_select(BSP_GPIO_R_HALL_PORT_SRC, BSP_GPIO_R_HALL_PIN_SRC);
    exti_init(BSP_GPIO_L_HALL_EXTI_LINE, EXTI_INTERRUPT, EXTI_TRIG_RISING);
    exti_init(BSP_GPIO_R_HALL_EXTI_LINE, EXTI_INTERRUPT, EXTI_TRIG_RISING);
    exti_interrupt_flag_clear(BSP_GPIO_L_HALL_EXTI_LINE);
    exti_interrupt_flag_clear(BSP_GPIO_R_HALL_EXTI_LINE);
    nvic_irq_enable(BSP_GPIO_L_HALL_IRQN, 2U, 0U);
    nvic_irq_enable(BSP_GPIO_R_HALL_IRQN, 2U, 1U);
#endif
}

void bsp_motor_hall_init(void)
{
    hall_gpio_prepare();
    hall_exti_prepare();
}

#else

void bsp_motor_hall_init(void)
{
}

#endif

void bsp_motor_hall_irq_edge(step_side_t side)
{
    motor_pulse_latch_on_edge_isr(side);
}

void bsp_motor_hall_mock_trigger(step_side_t side, uint16_t pulses)
{
    motor_pulse_latch_add_mock(side, pulses);
}

#if BSP_PLATFORM_GD32 && (BSP_HAS_MOTOR_HALL_INPUT != 0U) && defined(BSP_TARGET_GD32C103)
void EXTI5_9_IRQHandler(void)
{
    if (exti_interrupt_flag_get(BSP_GPIO_L_HALL_EXTI_LINE) != RESET) {
        exti_interrupt_flag_clear(BSP_GPIO_L_HALL_EXTI_LINE);
        bsp_motor_hall_irq_edge(STEP_SIDE_LEFT);
    }
    if (exti_interrupt_flag_get(BSP_GPIO_R_HALL_EXTI_LINE) != RESET) {
        exti_interrupt_flag_clear(BSP_GPIO_R_HALL_EXTI_LINE);
        bsp_motor_hall_irq_edge(STEP_SIDE_RIGHT);
    }
}
#endif
