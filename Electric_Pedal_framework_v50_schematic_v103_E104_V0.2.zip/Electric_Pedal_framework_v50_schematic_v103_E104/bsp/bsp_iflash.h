#ifndef BSP_BSP_IFLASH_H
#define BSP_BSP_IFLASH_H

/*
 * 文件: bsp/bsp_iflash.h
 * 描述: 内部 Flash (FMC) 编程接口，供 bootloader 和 OTA 服务共用。
 * 责任: 屏蔽 GD32C10x / GD32F1x0 在 FMC 解锁/擦除/编程上的差异，
 *      上层只看到 erase_range / program / read_check 这一组对称接口。
 *
 * 注意:
 *   - 所有写入入参 (addr, len) 必须是 4 字节对齐, 否则返回 false。
 *   - 擦除以 sector 为粒度, 起止地址会向外扩到最近的 sector 边界。
 *   - 编程过程会临时关中断, 由调用方决定是否需要在外层补全保护。
 */

#include <stdint.h>
#include "project_bool.h"

void bsp_iflash_init(void);

bool bsp_iflash_erase_range(uint32_t addr, uint32_t len);

bool bsp_iflash_program(uint32_t addr, const uint8_t *data, uint32_t len);

/* 校验 [addr, addr+len) 与 data 的内容是否一致。 */
bool bsp_iflash_verify(uint32_t addr, const uint8_t *data, uint32_t len);

uint32_t bsp_iflash_sector_size(void);

#endif /* BSP_BSP_IFLASH_H */
