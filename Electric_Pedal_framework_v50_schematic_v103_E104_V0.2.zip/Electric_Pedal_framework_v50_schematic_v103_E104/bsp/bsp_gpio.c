/*
 * GPIO 板级驱动：按照 board_profile 的映射初始化输入/输出，并提供统一读写入口。
 */
#include "bsp_gpio.h"
#include "bsp_build.h"

#if BSP_PLATFORM_GD32
#include "bsp_board.h"

#ifndef BSP_HAS_BUZZER
#define BSP_HAS_BUZZER 0U
#endif

#ifndef BSP_HAS_LOCAL_MOTOR_GPIO
#define BSP_HAS_LOCAL_MOTOR_GPIO 1U
#endif
#ifndef BSP_HAS_LOCAL_LIGHT_GPIO
#define BSP_HAS_LOCAL_LIGHT_GPIO 1U
#endif
#ifndef BSP_HAS_LIGHT_PWR_GPIO
#define BSP_HAS_LIGHT_PWR_GPIO 0U
#endif
#ifndef BSP_HAS_LIMIT_SWITCH_INPUTS
#define BSP_HAS_LIMIT_SWITCH_INPUTS 1U
#endif
#ifndef BSP_HAS_MAIN_SWITCH_GPIO
#define BSP_HAS_MAIN_SWITCH_GPIO 1U
#endif
#ifndef BSP_HAS_DRIVER_EN_OUTPUT
#define BSP_HAS_DRIVER_EN_OUTPUT 1U
#endif
#ifndef BSP_HAS_DRIVER_PWM_OUTPUT
#define BSP_HAS_DRIVER_PWM_OUTPUT 1U
#endif
#ifndef BSP_HAS_VOICE_RESET_GPIO
#define BSP_HAS_VOICE_RESET_GPIO 0U
#endif

typedef struct
{
    rcu_periph_enum rcu;
    uint32_t port;
    uint32_t pin;
} gpio_desc_t;

static const gpio_desc_t s_out_desc[BSP_GPIO_OUT_MAX] = {
    {BSP_GPIO_L_MOTOR_A_RCU,      BSP_GPIO_L_MOTOR_A_PORT,      BSP_GPIO_L_MOTOR_A_PIN},
    {BSP_GPIO_L_MOTOR_B_RCU,      BSP_GPIO_L_MOTOR_B_PORT,      BSP_GPIO_L_MOTOR_B_PIN},
    {BSP_GPIO_R_MOTOR_A_RCU,      BSP_GPIO_R_MOTOR_A_PORT,      BSP_GPIO_R_MOTOR_A_PIN},
    {BSP_GPIO_R_MOTOR_B_RCU,      BSP_GPIO_R_MOTOR_B_PORT,      BSP_GPIO_R_MOTOR_B_PIN},
    {BSP_GPIO_LIGHT_L_RCU,        BSP_GPIO_LIGHT_L_PORT,        BSP_GPIO_LIGHT_L_PIN},
    {BSP_GPIO_LIGHT_R_RCU,        BSP_GPIO_LIGHT_R_PORT,        BSP_GPIO_LIGHT_R_PIN},
    {BSP_GPIO_LIGHT_DATA_L2_RCU,  BSP_GPIO_LIGHT_DATA_L2_PORT,  BSP_GPIO_LIGHT_DATA_L2_PIN},
    {BSP_GPIO_LIGHT_DATA_R2_RCU,  BSP_GPIO_LIGHT_DATA_R2_PORT,  BSP_GPIO_LIGHT_DATA_R2_PIN},
    {BSP_GPIO_LIGHT_PWR_L1_RCU,   BSP_GPIO_LIGHT_PWR_L1_PORT,   BSP_GPIO_LIGHT_PWR_L1_PIN},
    {BSP_GPIO_LIGHT_PWR_R1_RCU,   BSP_GPIO_LIGHT_PWR_R1_PORT,   BSP_GPIO_LIGHT_PWR_R1_PIN},
    {BSP_GPIO_LIGHT_PWR_L2_RCU,   BSP_GPIO_LIGHT_PWR_L2_PORT,   BSP_GPIO_LIGHT_PWR_L2_PIN},
    {BSP_GPIO_LIGHT_PWR_R2_RCU,   BSP_GPIO_LIGHT_PWR_R2_PORT,   BSP_GPIO_LIGHT_PWR_R2_PIN},
    {BSP_GPIO_BUZZER_RCU,         BSP_GPIO_BUZZER_PORT,         BSP_GPIO_BUZZER_PIN},
    {BSP_GPIO_DRIVER_EN_RCU,      BSP_GPIO_DRIVER_EN_PORT,      BSP_GPIO_DRIVER_EN_PIN},
    {BSP_GPIO_DRIVER_PWM_RCU,     BSP_GPIO_DRIVER_PWM_PORT,     BSP_GPIO_DRIVER_PWM_PIN},
    {BSP_GPIO_VOICE_RST_RCU,      BSP_GPIO_VOICE_RST_PORT,      BSP_GPIO_VOICE_RST_PIN}
};

static const gpio_desc_t s_in_desc[BSP_GPIO_IN_MAX] = {
    {BSP_GPIO_L_EXT_RCU,  BSP_GPIO_L_EXT_PORT,  BSP_GPIO_L_EXT_PIN},
    {BSP_GPIO_L_RET_RCU,  BSP_GPIO_L_RET_PORT,  BSP_GPIO_L_RET_PIN},
    {BSP_GPIO_R_EXT_RCU,  BSP_GPIO_R_EXT_PORT,  BSP_GPIO_R_EXT_PIN},
    {BSP_GPIO_R_RET_RCU,  BSP_GPIO_R_RET_PORT,  BSP_GPIO_R_RET_PIN},
    {BSP_GPIO_MAIN_SW_RCU, BSP_GPIO_MAIN_SW_PORT, BSP_GPIO_MAIN_SW_PIN}
};

static bool gpio_out_available(bsp_gpio_out_id_t id)
{
    switch (id) {
        case BSP_GPIO_OUT_L_MOTOR_A:
        case BSP_GPIO_OUT_L_MOTOR_B:
        case BSP_GPIO_OUT_R_MOTOR_A:
        case BSP_GPIO_OUT_R_MOTOR_B:
            return (BSP_HAS_LOCAL_MOTOR_GPIO != 0U);

        case BSP_GPIO_OUT_LIGHT_L:
        case BSP_GPIO_OUT_LIGHT_R:
        case BSP_GPIO_OUT_LIGHT_DATA_L2:
        case BSP_GPIO_OUT_LIGHT_DATA_R2:
            return (BSP_HAS_LOCAL_LIGHT_GPIO != 0U);

        case BSP_GPIO_OUT_LIGHT_PWR_L1:
        case BSP_GPIO_OUT_LIGHT_PWR_R1:
        case BSP_GPIO_OUT_LIGHT_PWR_L2:
        case BSP_GPIO_OUT_LIGHT_PWR_R2:
            return (BSP_HAS_LIGHT_PWR_GPIO != 0U);

        case BSP_GPIO_OUT_BUZZER:
            return (BSP_HAS_BUZZER != 0U);

        case BSP_GPIO_OUT_DRIVER_EN:
            return (BSP_HAS_DRIVER_EN_OUTPUT != 0U);

        case BSP_GPIO_OUT_DRIVER_PWM:
            return (BSP_HAS_DRIVER_PWM_OUTPUT != 0U);

        case BSP_GPIO_OUT_VOICE_RESET:
            return (BSP_HAS_VOICE_RESET_GPIO != 0U);

        default:
            return true;
    }
}

static bool gpio_in_available(bsp_gpio_in_id_t id)
{
    switch (id) {
        case BSP_GPIO_IN_L_EXT_LIMIT:
        case BSP_GPIO_IN_L_RET_LIMIT:
        case BSP_GPIO_IN_R_EXT_LIMIT:
        case BSP_GPIO_IN_R_RET_LIMIT:
            return (BSP_HAS_LIMIT_SWITCH_INPUTS != 0U);

        case BSP_GPIO_IN_MAIN_SWITCH:
            return (BSP_HAS_MAIN_SWITCH_GPIO != 0U);

        default:
            return true;
    }
}

static void gpio_prepare_output(uint32_t port, uint32_t pin)
{
#if defined(BSP_TARGET_GD32C103)
    gpio_init(port, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, pin);
#else
    gpio_mode_set(port, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, pin);
    gpio_output_options_set(port, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, pin);
#endif
    gpio_bit_reset(port, pin);
}

static void gpio_prepare_input(uint32_t port, uint32_t pin)
{
#if defined(BSP_TARGET_GD32C103)
    gpio_init(port, GPIO_MODE_IPU, GPIO_OSPEED_50MHZ, pin);
#else
    gpio_mode_set(port, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, pin);
#endif
}

static void gpio_enable_once(rcu_periph_enum rcu)
{
    static rcu_periph_enum enabled[16];
    static uint32_t count = 0U;
    uint32_t i;

    for (i = 0U; i < count; ++i) {
        if (enabled[i] == rcu) {
            return;
        }
    }

    rcu_periph_clock_enable(rcu);
    if (count < (sizeof(enabled) / sizeof(enabled[0]))) {
        enabled[count++] = rcu;
    }
}

void bsp_gpio_init(void)
{
    uint32_t i;

    for (i = 0U; i < (uint32_t)BSP_GPIO_OUT_MAX; ++i) {
        if (!gpio_out_available((bsp_gpio_out_id_t)i)) {
            continue;
        }
        gpio_enable_once(s_out_desc[i].rcu);
        gpio_prepare_output(s_out_desc[i].port, s_out_desc[i].pin);
    }

    for (i = 0U; i < (uint32_t)BSP_GPIO_IN_MAX; ++i) {
        if (!gpio_in_available((bsp_gpio_in_id_t)i)) {
            continue;
        }
        gpio_enable_once(s_in_desc[i].rcu);
        gpio_prepare_input(s_in_desc[i].port, s_in_desc[i].pin);
    }
}

void bsp_gpio_write(bsp_gpio_out_t id, bool level)
{
    if ((id >= BSP_GPIO_OUT_MAX) || !gpio_out_available(id)) {
        return;
    }

    if (level) {
        gpio_bit_set(s_out_desc[id].port, s_out_desc[id].pin);
    } else {
        gpio_bit_reset(s_out_desc[id].port, s_out_desc[id].pin);
    }
}

bool bsp_gpio_read_in(bsp_gpio_in_t id)
{
    if ((id >= BSP_GPIO_IN_MAX) || !gpio_in_available(id)) {
        return false;
    }

    return (gpio_input_bit_get(s_in_desc[id].port, s_in_desc[id].pin) != RESET);
}

bool bsp_gpio_read_out(bsp_gpio_out_t id)
{
    if ((id >= BSP_GPIO_OUT_MAX) || !gpio_out_available(id)) {
        return false;
    }

    return (gpio_output_bit_get(s_out_desc[id].port, s_out_desc[id].pin) != RESET);
}

void bsp_gpio_mock_set_in(bsp_gpio_in_t id, bool level)
{
    (void)id;
    (void)level;
}

#else

static bool s_out[BSP_GPIO_OUT_MAX];
static bool s_in[BSP_GPIO_IN_MAX];

void bsp_gpio_init(void)
{
    uint32_t i;

    for (i = 0U; i < (uint32_t)BSP_GPIO_OUT_MAX; ++i) {
        s_out[i] = false;
    }

    for (i = 0U; i < (uint32_t)BSP_GPIO_IN_MAX; ++i) {
        s_in[i] = false;
    }
}

void bsp_gpio_write(bsp_gpio_out_t id, bool level)
{
    if (id >= BSP_GPIO_OUT_MAX) {
        return;
    }

    s_out[id] = level;
}

bool bsp_gpio_read_in(bsp_gpio_in_t id)
{
    if (id >= BSP_GPIO_IN_MAX) {
        return false;
    }

    return s_in[id];
}

bool bsp_gpio_read_out(bsp_gpio_out_t id)
{
    if (id >= BSP_GPIO_OUT_MAX) {
        return false;
    }

    return s_out[id];
}

void bsp_gpio_mock_set_in(bsp_gpio_in_t id, bool level)
{
    if (id >= BSP_GPIO_IN_MAX) {
        return;
    }

    s_in[id] = level;
}

#endif
