/*
 * 文件: bsp/bsp_uart.c
 * 描述: UART 驱动与软 UART 实现�? * 责任: 提供串口初始化、环形缓冲、以及软/硬件发�?接收抽象，供上层传输模块使用�? */

#include "bsp_uart.h"
#include "bsp_build.h"
#include <string.h>
#include "event_flags.h"

#define BSP_UART_TX_BUF_SIZE 512U
#define BSP_UART_RX_BUF_SIZE 512U
#define BSP_UART_SEND_WAIT_LIMIT 100000UL

#if BSP_PLATFORM_GD32
#include "bsp_board.h"
#if defined(BSP_TARGET_GD32C103)
#include "gd32c10x_usart.h"
#include "gd32c10x_rcu.h"
#include "gd32c10x_gpio.h"
#include "gd32c10x_misc.h"
#else
#include "gd32f1x0_usart.h"
#include "gd32f1x0_rcu.h"
#include "gd32f1x0_gpio.h"
#include "gd32f1x0_misc.h"
#endif

typedef struct
{
    uint32_t periph;
    rcu_periph_enum periph_rcu;
    IRQn_Type irqn;
    rcu_periph_enum tx_gpio_rcu;
    rcu_periph_enum rx_gpio_rcu;
    uint32_t tx_port;
    uint32_t tx_pin;
    uint32_t rx_port;
    uint32_t rx_pin;
    uint32_t af;
    uint32_t baudrate;
    bool     enabled;
    bool     soft_uart;
} bsp_uart_hw_t;

typedef struct
{
    uint8_t data[BSP_UART_TX_BUF_SIZE];
    volatile uint16_t head;
    volatile uint16_t tail;
} bsp_uart_ring_t;

typedef struct
{
    uint8_t data[BSP_UART_TX_BUF_SIZE];
    size_t  len;
} bsp_uart_tx_shadow_t;

static const bsp_uart_hw_t s_uart_hw[BSP_UART_PORT_MAX] = {
    {
        BSP_UART_BLE_PERIPH, BSP_UART_BLE_RCU, BSP_UART_BLE_IRQN,
        BSP_UART_BLE_GPIO_RCU_TX, BSP_UART_BLE_GPIO_RCU_RX,
        BSP_UART_BLE_TX_PORT, BSP_UART_BLE_TX_PIN,
        BSP_UART_BLE_RX_PORT, BSP_UART_BLE_RX_PIN,
        BSP_UART_BLE_AF, 115200UL,
        true, false
    },
    {
        BSP_UART_LINK_PERIPH, BSP_UART_LINK_RCU, BSP_UART_LINK_IRQN,
        BSP_UART_LINK_GPIO_RCU_TX, BSP_UART_LINK_GPIO_RCU_RX,
        BSP_UART_LINK_TX_PORT, BSP_UART_LINK_TX_PIN,
        BSP_UART_LINK_RX_PORT, BSP_UART_LINK_RX_PIN,
        BSP_UART_LINK_AF, BSP_UART_LINK_BAUDRATE,
        true, (BSP_UART_LINK_IS_SOFT != 0U)
    }
};

volatile uint32_t g_u12_to_u17_tx_count = 0U;
volatile uint32_t g_u17_to_u12_rx_count = 0U;
static bsp_uart_ring_t s_rx_ring[BSP_UART_PORT_MAX];
static bsp_uart_tx_shadow_t s_tx_shadow[BSP_UART_PORT_MAX];

static void ring_reset(bsp_uart_ring_t *ring)
{
    if (ring == 0) {
        return;
    }
    ring->head = 0U;
    ring->tail = 0U;
}

static bool ring_push_byte(bsp_uart_ring_t *ring, uint8_t byte)
{
    uint16_t next;

    next = (uint16_t)((ring->head + 1U) % BSP_UART_RX_BUF_SIZE);
    if (next == ring->tail) {
        return false;
    }

    ring->data[ring->head] = byte;
    ring->head = next;
    return true;
}

static bool ring_pop_byte(bsp_uart_ring_t *ring, uint8_t *byte)
{
    if ((ring == 0) || (byte == 0) || (ring->head == ring->tail)) {
        return false;
    }

    *byte = ring->data[ring->tail];
    ring->tail = (uint16_t)((ring->tail + 1U) % BSP_UART_RX_BUF_SIZE);
    return true;
}

static void soft_uart_delay_loops(uint32_t loops)
{
    volatile uint32_t i;

    for (i = 0U; i < loops; ++i) {
        __NOP();
    }
}

static uint32_t soft_uart_loop_budget(const bsp_uart_hw_t *hw, bool half_bit)
{
    uint32_t loops;

    if ((hw == 0) || (hw->baudrate == 0U)) {
        return 1U;
    }

    /*
     * 针对 48MHz 内核的尽力位操作延时。除数选取略显保守�?     * 因为每次循环还包含函数调用与分支的开销�?     */
    loops = BSP_SYSCLK_TARGET_HZ / hw->baudrate;
    loops /= 13U;
    if (half_bit) {
        loops /= 2U;
    }
    if (loops == 0U) {
        loops = 1U;
    }
    return loops;
}

static void soft_uart_delay_bit(const bsp_uart_hw_t *hw)
{
    soft_uart_delay_loops(soft_uart_loop_budget(hw, false));
}

static void soft_uart_delay_half_bit(const bsp_uart_hw_t *hw)
{
    soft_uart_delay_loops(soft_uart_loop_budget(hw, true));
}

static void soft_uart_tx_byte(const bsp_uart_hw_t *hw, uint8_t byte)
{
    uint8_t i;

    gpio_bit_reset(hw->tx_port, hw->tx_pin);
    soft_uart_delay_bit(hw);

    for (i = 0U; i < 8U; ++i) {
        if ((byte & 0x01U) != 0U) {
            gpio_bit_set(hw->tx_port, hw->tx_pin);
        } else {
            gpio_bit_reset(hw->tx_port, hw->tx_pin);
        }
        soft_uart_delay_bit(hw);
        byte >>= 1U;
    }

    gpio_bit_set(hw->tx_port, hw->tx_pin);
    soft_uart_delay_bit(hw);
}

static bool soft_uart_try_rx_byte(const bsp_uart_hw_t *hw, uint8_t *byte)
{
    uint8_t i;
    uint8_t value = 0U;

    if ((byte == 0) || (gpio_input_bit_get(hw->rx_port, hw->rx_pin) != RESET)) {
        return false;
    }

    soft_uart_delay_bit(hw);
    soft_uart_delay_half_bit(hw);

    for (i = 0U; i < 8U; ++i) {
        value >>= 1U;
        if (gpio_input_bit_get(hw->rx_port, hw->rx_pin) != RESET) {
            value |= 0x80U;
        }
        soft_uart_delay_bit(hw);
    }

    soft_uart_delay_bit(hw);
    *byte = value;
    return true;
}

static void uart_hw_init_one(const bsp_uart_hw_t *hw)
{
    rcu_periph_clock_enable(hw->tx_gpio_rcu);
    rcu_periph_clock_enable(hw->rx_gpio_rcu);

    if (hw->soft_uart) {
#if defined(BSP_TARGET_GD32C103)
        gpio_init(hw->tx_port, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, hw->tx_pin);
        gpio_bit_set(hw->tx_port, hw->tx_pin);
        gpio_init(hw->rx_port, GPIO_MODE_IPU, GPIO_OSPEED_50MHZ, hw->rx_pin);
#else
        gpio_mode_set(hw->tx_port, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, hw->tx_pin);
        gpio_output_options_set(hw->tx_port, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, hw->tx_pin);
        gpio_bit_set(hw->tx_port, hw->tx_pin);
        gpio_mode_set(hw->rx_port, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, hw->rx_pin);
#endif
        return;
    }

    rcu_periph_clock_enable(hw->periph_rcu);

#if defined(BSP_TARGET_GD32C103)
    gpio_init(hw->tx_port, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, hw->tx_pin);
    gpio_init(hw->rx_port, GPIO_MODE_IN_FLOATING, GPIO_OSPEED_50MHZ, hw->rx_pin);
#else
    gpio_af_set(hw->tx_port, hw->af, hw->tx_pin);
    gpio_af_set(hw->rx_port, hw->af, hw->rx_pin);
    gpio_mode_set(hw->tx_port, GPIO_MODE_AF, GPIO_PUPD_PULLUP, hw->tx_pin);
    gpio_output_options_set(hw->tx_port, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, hw->tx_pin);
    gpio_mode_set(hw->rx_port, GPIO_MODE_AF, GPIO_PUPD_PULLUP, hw->rx_pin);
    gpio_output_options_set(hw->rx_port, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, hw->rx_pin);
#endif

    usart_deinit(hw->periph);
    usart_baudrate_set(hw->periph, hw->baudrate);
    usart_parity_config(hw->periph, USART_PM_NONE);
    usart_word_length_set(hw->periph, USART_WL_8BIT);
    usart_stop_bit_set(hw->periph, USART_STB_1BIT);
    usart_receive_config(hw->periph, USART_RECEIVE_ENABLE);
    usart_transmit_config(hw->periph, USART_TRANSMIT_ENABLE);
    usart_enable(hw->periph);
    usart_interrupt_enable(hw->periph, USART_INT_RBNE);
    nvic_irq_enable(hw->irqn, 2U, 0U);
}

void bsp_uart_init(void)
{
    uint32_t i;

    for (i = 0U; i < (uint32_t)BSP_UART_PORT_MAX; ++i) {
        ring_reset(&s_rx_ring[i]);
        s_tx_shadow[i].len = 0U;
        if (s_uart_hw[i].enabled) {
            uart_hw_init_one(&s_uart_hw[i]);
        }
    }
}

size_t bsp_uart_send(bsp_uart_port_t port, const uint8_t *data, size_t len)
{
    size_t i;
    const bsp_uart_hw_t *hw;

    if ((port >= BSP_UART_PORT_MAX) || (data == 0) || (len == 0U)) {
        return 0U;
    }

    hw = &s_uart_hw[port];

    if (port == BSP_UART_PORT_U17) {
        g_u12_to_u17_tx_count += (uint32_t)len;
    }

    if (hw->soft_uart) {
        s_tx_shadow[port].len = (len > sizeof(s_tx_shadow[port].data)) ? sizeof(s_tx_shadow[port].data) : len;
        (void)memcpy(s_tx_shadow[port].data, data, s_tx_shadow[port].len);
        for (i = 0U; i < len; ++i) {
            soft_uart_tx_byte(hw, data[i]);
        }
        return len;
    }

    for (i = 0U; i < len; ++i) {
        uint32_t wait = BSP_UART_SEND_WAIT_LIMIT;
        while (usart_flag_get(hw->periph, USART_FLAG_TBE) == RESET) {
            if (wait == 0U) {
                return i;
            }
            wait--;
        }
        usart_data_transmit(hw->periph, data[i]);
    }
    {
        uint32_t wait = BSP_UART_SEND_WAIT_LIMIT;
        while (usart_flag_get(hw->periph, USART_FLAG_TC) == RESET) {
            if (wait == 0U) {
                return i;
            }
            wait--;
        }
    }
    return len;
}

size_t bsp_uart_fetch_tx(bsp_uart_port_t port, uint8_t *buf, size_t max_len)
{
    size_t copy_len;

    if ((port >= BSP_UART_PORT_MAX) || (buf == 0) || (max_len == 0U)) {
        return 0U;
    }

    copy_len = s_tx_shadow[port].len;
    if (copy_len > max_len) {
        copy_len = max_len;
    }
    if (copy_len > 0U) {
        (void)memcpy(buf, s_tx_shadow[port].data, copy_len);
    }
    return copy_len;
}

void bsp_uart_clear_tx(bsp_uart_port_t port)
{
    if (port >= BSP_UART_PORT_MAX) {
        return;
    }
    s_tx_shadow[port].len = 0U;
}

size_t bsp_uart_recv(bsp_uart_port_t port, uint8_t *buf, size_t max_len)
{
    size_t count = 0U;
    uint8_t value;

    if ((port >= BSP_UART_PORT_MAX) || (buf == 0) || (max_len == 0U)) {
        return 0U;
    }

    if (s_uart_hw[port].soft_uart) {
        while ((count < max_len) && soft_uart_try_rx_byte(&s_uart_hw[port], &value)) {
            buf[count++] = value;
        }
        while ((count < max_len) && ring_pop_byte(&s_rx_ring[port], &value)) {
            buf[count++] = value;
        }
        if ((port == BSP_UART_PORT_U17) && (count > 0U)) {
            g_u17_to_u12_rx_count += (uint32_t)count;
        }
        /* soft_uart_rx_count_patch */
        return count;
    }

    while ((count < max_len) && ring_pop_byte(&s_rx_ring[port], &value)) {
        buf[count++] = value;
    }
    if ((port == BSP_UART_PORT_U17) && (count > 0U)) {
        g_u17_to_u12_rx_count += (uint32_t)count;
    }
    return count;
}

void bsp_uart_rx_buf_isr(bsp_uart_port_t port, const uint8_t *data, size_t len)
{
    size_t i;
    bool pushed = false;

    if ((port >= BSP_UART_PORT_MAX) || (data == 0) || (len == 0U)) {
        return;
    }

    for (i = 0U; i < len; ++i) {
        if (ring_push_byte(&s_rx_ring[port], data[i])) {
            pushed = true;
        }
    }

    if (pushed) {
        if (port == BSP_UART_PORT_U17) {
            event_flags_mark_isr(EVENT_FLAG_U17_RX_PENDING);
        } else if (port == BSP_UART_PORT_BLE) {
            event_flags_mark_isr(EVENT_FLAG_BLE_RX_PENDING);
        }
    }
}

void bsp_uart_clear_rx(bsp_uart_port_t port)
{
    if (port >= BSP_UART_PORT_MAX) {
        return;
    }
    ring_reset(&s_rx_ring[port]);
}

static void uart_irq_service(bsp_uart_port_t port)
{
    uint8_t value;
    const bsp_uart_hw_t *hw = &s_uart_hw[port];

    if (hw->soft_uart) {
        return;
    }

    if (usart_interrupt_flag_get(hw->periph, USART_INT_FLAG_RBNE) != RESET) {
        value = (uint8_t)usart_data_receive(hw->periph);
        if (ring_push_byte(&s_rx_ring[port], value)) {
            if (port == BSP_UART_PORT_U17) {
                event_flags_mark_isr(EVENT_FLAG_U17_RX_PENDING);
            } else if (port == BSP_UART_PORT_BLE) {
                event_flags_mark_isr(EVENT_FLAG_BLE_RX_PENDING);
            }
        }
    }

    if (usart_flag_get(hw->periph, USART_FLAG_ORERR) != RESET) {
        (void)usart_data_receive(hw->periph);
    }
}

void USART0_IRQHandler(void)
{
#if BSP_APP_IS_U17
    uart_irq_service(BSP_UART_PORT_U17);
#else
    uart_irq_service(BSP_UART_PORT_BLE);
#endif
}

void USART1_IRQHandler(void)
{
#if BSP_APP_IS_U17
    uart_irq_service(BSP_UART_PORT_BLE);
#else
    /* �?V1.03 中，U12 �?USART1 未连到活动运行端口�?*/
#endif
}

void USART2_IRQHandler(void)
{
#if !BSP_APP_IS_U17
    uart_irq_service(BSP_UART_PORT_U17);
#endif
}

#else

typedef struct
{
    uint8_t data[BSP_UART_TX_BUF_SIZE];
    size_t  len;
} bsp_uart_tx_shadow_t;

typedef struct
{
    uint8_t data[BSP_UART_RX_BUF_SIZE];
    size_t  len;
} bsp_uart_rx_shadow_t;

static bsp_uart_tx_shadow_t s_tx_shadow[BSP_UART_PORT_MAX];
static bsp_uart_rx_shadow_t s_rx_shadow[BSP_UART_PORT_MAX];

void bsp_uart_init(void)
{
    uint32_t i;

    for (i = 0U; i < (uint32_t)BSP_UART_PORT_MAX; ++i) {
        s_tx_shadow[i].len = 0U;
        s_rx_shadow[i].len = 0U;
    }
}

size_t bsp_uart_send(bsp_uart_port_t port, const uint8_t *data, size_t len)
{
    size_t copy_len;

    if ((port >= BSP_UART_PORT_MAX) || (data == 0) || (len == 0U)) {
        return 0U;
    }

    copy_len = len;
    if (copy_len > sizeof(s_tx_shadow[port].data)) {
        copy_len = sizeof(s_tx_shadow[port].data);
    }

    (void)memcpy(s_tx_shadow[port].data, data, copy_len);
    s_tx_shadow[port].len = copy_len;
    return len;
}

size_t bsp_uart_fetch_tx(bsp_uart_port_t port, uint8_t *buf, size_t max_len)
{
    size_t copy_len;

    if ((port >= BSP_UART_PORT_MAX) || (buf == 0) || (max_len == 0U)) {
        return 0U;
    }

    copy_len = s_tx_shadow[port].len;
    if (copy_len > max_len) {
        copy_len = max_len;
    }

    (void)memcpy(buf, s_tx_shadow[port].data, copy_len);
    return copy_len;
}

void bsp_uart_clear_tx(bsp_uart_port_t port)
{
    if (port >= BSP_UART_PORT_MAX) {
        return;
    }

    s_tx_shadow[port].len = 0U;
}

size_t bsp_uart_recv(bsp_uart_port_t port, uint8_t *buf, size_t max_len)
{
    size_t copy_len;

    if ((port >= BSP_UART_PORT_MAX) || (buf == 0) || (max_len == 0U)) {
        return 0U;
    }

    copy_len = s_rx_shadow[port].len;
    if (copy_len > max_len) {
        copy_len = max_len;
    }

    (void)memcpy(buf, s_rx_shadow[port].data, copy_len);
    if (copy_len < s_rx_shadow[port].len) {
        (void)memmove(s_rx_shadow[port].data,
                      &s_rx_shadow[port].data[copy_len],
                      s_rx_shadow[port].len - copy_len);
    }
    s_rx_shadow[port].len -= copy_len;
    return copy_len;
}

void bsp_uart_rx_buf_isr(bsp_uart_port_t port, const uint8_t *data, size_t len)
{
    size_t copy_len;

    if ((port >= BSP_UART_PORT_MAX) || (data == 0) || (len == 0U)) {
        return;
    }

    copy_len = len;
    if ((copy_len + s_rx_shadow[port].len) > sizeof(s_rx_shadow[port].data)) {
        copy_len = sizeof(s_rx_shadow[port].data) - s_rx_shadow[port].len;
    }

    if (copy_len > 0U) {
        (void)memcpy(&s_rx_shadow[port].data[s_rx_shadow[port].len], data, copy_len);
        s_rx_shadow[port].len += copy_len;
        if (port == BSP_UART_PORT_U17) {
            event_flags_mark_isr(EVENT_FLAG_U17_RX_PENDING);
        } else if (port == BSP_UART_PORT_BLE) {
            event_flags_mark_isr(EVENT_FLAG_BLE_RX_PENDING);
        }
    }
}

void bsp_uart_clear_rx(bsp_uart_port_t port)
{
    if (port >= BSP_UART_PORT_MAX) {
        return;
    }

    s_rx_shadow[port].len = 0U;
}

#endif





