﻿#include "bsp_platform.h"
#include "bsp_build.h"

#if BSP_PLATFORM_GD32 
#include "bsp_board.h"
#if defined(BSP_TARGET_GD32C103)
#include "gd32c10x_rcu.h"
#include "gd32c10x_gpio.h"
#include "gd32c10x_misc.h"
#include "system_gd32c10x.h"
#else
#include "gd32f1x0_rcu.h"
#include "gd32f1x0_misc.h"
#include "system_gd32f1x0.h"
#endif

static uint32_t s_system_clock_hz = 8000000UL;

static void wait_flag_set(volatile uint32_t *reg, uint32_t mask)
{
    uint32_t timeout = 0x1FFFFUL;
    while (((*reg) & mask) == 0U) {
        if (timeout == 0U) {
            break;
        }
        timeout--;
    }
}

#if !defined(BSP_TARGET_GD32C103)
static bool wait_clock_source(uint32_t source)
{
    uint32_t timeout = 0x1FFFFUL;

    while (rcu_system_clock_source_get() != source) {
        if (timeout == 0U) {
            return false;
        }
        timeout--;
    }
    return true;
}

static void clock_to_48m_from_irc8m(void)
{
    uint32_t reg;

    rcu_deinit();
    RCU_CTL0 |= RCU_CTL0_IRC8MEN;
    wait_flag_set((volatile uint32_t *)&RCU_CTL0, RCU_CTL0_IRC8MSTB);

    reg = RCU_CFG0;
    reg &= ~(RCU_CFG0_AHBPSC | RCU_CFG0_APB1PSC | RCU_CFG0_APB2PSC |
             RCU_CFG0_PLLSEL | RCU_CFG0_PLLMF | RCU_CFG0_PLLPREDV | RCU_CFG0_PLLDV);
    reg |= (RCU_AHB_CKSYS_DIV1 | RCU_APB1_CKAHB_DIV1 | RCU_APB2_CKAHB_DIV1);
    reg |= (RCU_PLLSRC_IRC8M_DIV2 | RCU_PLL_MUL12); /* U17 使用内部 8MHz/2*12=48MHz，避免依赖外部晶振。 */
    RCU_CFG0 = reg;

    RCU_CTL0 |= RCU_CTL0_PLLEN;
    wait_flag_set((volatile uint32_t *)&RCU_CTL0, RCU_CTL0_PLLSTB);

    if ((RCU_CTL0 & RCU_CTL0_PLLSTB) != 0U) {
        rcu_system_clock_source_config(RCU_CKSYSSRC_PLL);
        (void)wait_clock_source(RCU_SCSS_PLL);
    }

    SystemCoreClockUpdate();
    s_system_clock_hz = SystemCoreClock;
}
#endif

void bsp_platform_init(void)
{
#if defined(BSP_TARGET_GD32C103)
    SystemCoreClockUpdate();
    s_system_clock_hz = SystemCoreClock;
    rcu_periph_clock_enable(RCU_AF);
    gpio_pin_remap_config(GPIO_SWJ_SWDPENABLE_REMAP, ENABLE);
#else
    clock_to_48m_from_irc8m();
#endif
    NVIC_SetPriorityGrouping(3U);
}

uint32_t bsp_platform_system_clock_hz(void)
{
    return s_system_clock_hz;
}

bool bsp_platform_is_target(void)
{
    return true;
}

void bsp_platform_system_reset(void)
{
    NVIC_SystemReset();
}

#else

void bsp_platform_init(void)
{
}

uint32_t bsp_platform_system_clock_hz(void)
{
    return 1000UL;
}

bool bsp_platform_is_target(void)
{
    return false;
}

void bsp_platform_system_reset(void)
{
}

#endif

