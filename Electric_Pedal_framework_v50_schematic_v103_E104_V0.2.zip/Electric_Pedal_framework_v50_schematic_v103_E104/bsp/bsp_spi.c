/*
 * SPI 板级驱动：提供 Flash 等外设访问所需的片选和字节传输能力。
 */
#include "bsp_spi.h"
#include "bsp_build.h"

#if BSP_PLATFORM_GD32
#include "bsp_board.h"

static void spi_delay_half_bit(void)
{
    for (volatile uint32_t i = 0U; i < 8U; ++i) {
        __NOP();
    }
}

void bsp_spi_init(void)
{
    if (BSP_HAS_FLASH == 0U) {
        return;
    }

    rcu_periph_clock_enable(BSP_SPI_FLASH_CS_GPIO_RCU);
    rcu_periph_clock_enable(BSP_SPI_FLASH_SCK_GPIO_RCU);
    rcu_periph_clock_enable(BSP_SPI_FLASH_MISO_GPIO_RCU);
    rcu_periph_clock_enable(BSP_SPI_FLASH_MOSI_GPIO_RCU);

#if defined(BSP_TARGET_GD32C103)
    gpio_init(BSP_SPI_FLASH_CS_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, BSP_SPI_FLASH_CS_PIN);
    gpio_bit_set(BSP_SPI_FLASH_CS_PORT, BSP_SPI_FLASH_CS_PIN);

    gpio_init(BSP_SPI_FLASH_SCK_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, BSP_SPI_FLASH_SCK_PIN);
    gpio_bit_reset(BSP_SPI_FLASH_SCK_PORT, BSP_SPI_FLASH_SCK_PIN);

    gpio_init(BSP_SPI_FLASH_MOSI_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, BSP_SPI_FLASH_MOSI_PIN);
    gpio_bit_set(BSP_SPI_FLASH_MOSI_PORT, BSP_SPI_FLASH_MOSI_PIN);

    gpio_init(BSP_SPI_FLASH_MISO_PORT, GPIO_MODE_IPU, GPIO_OSPEED_50MHZ, BSP_SPI_FLASH_MISO_PIN);
#else
    gpio_mode_set(BSP_SPI_FLASH_CS_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, BSP_SPI_FLASH_CS_PIN);
    gpio_output_options_set(BSP_SPI_FLASH_CS_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, BSP_SPI_FLASH_CS_PIN);
    gpio_bit_set(BSP_SPI_FLASH_CS_PORT, BSP_SPI_FLASH_CS_PIN);

    gpio_mode_set(BSP_SPI_FLASH_SCK_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, BSP_SPI_FLASH_SCK_PIN);
    gpio_output_options_set(BSP_SPI_FLASH_SCK_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, BSP_SPI_FLASH_SCK_PIN);
    gpio_bit_reset(BSP_SPI_FLASH_SCK_PORT, BSP_SPI_FLASH_SCK_PIN);

    gpio_mode_set(BSP_SPI_FLASH_MOSI_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, BSP_SPI_FLASH_MOSI_PIN);
    gpio_output_options_set(BSP_SPI_FLASH_MOSI_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, BSP_SPI_FLASH_MOSI_PIN);
    gpio_bit_set(BSP_SPI_FLASH_MOSI_PORT, BSP_SPI_FLASH_MOSI_PIN);

    gpio_mode_set(BSP_SPI_FLASH_MISO_PORT, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, BSP_SPI_FLASH_MISO_PIN);
#endif
}

bool bsp_spi_flash_select(bool active)
{
    if (BSP_HAS_FLASH == 0U) {
        return false;
    }

    if (active) {
        gpio_bit_reset(BSP_SPI_FLASH_CS_PORT, BSP_SPI_FLASH_CS_PIN);
    } else {
        gpio_bit_set(BSP_SPI_FLASH_CS_PORT, BSP_SPI_FLASH_CS_PIN);
    }
    return true;
}

bool bsp_spi_flash_transfer(const uint8_t *tx, uint8_t *rx, size_t len)
{
    size_t i;
    uint8_t out;
    uint8_t in;
    uint8_t bit;

    if (BSP_HAS_FLASH == 0U) {
        return false;
    }

    for (i = 0U; i < len; ++i) {
        out = (tx != 0) ? tx[i] : 0xFFU;
        in = 0U;
        for (bit = 0U; bit < 8U; ++bit) {
            if ((out & 0x80U) != 0U) {
                gpio_bit_set(BSP_SPI_FLASH_MOSI_PORT, BSP_SPI_FLASH_MOSI_PIN);
            } else {
                gpio_bit_reset(BSP_SPI_FLASH_MOSI_PORT, BSP_SPI_FLASH_MOSI_PIN);
            }
            spi_delay_half_bit();
            gpio_bit_set(BSP_SPI_FLASH_SCK_PORT, BSP_SPI_FLASH_SCK_PIN);
            in <<= 1U;
            if (gpio_input_bit_get(BSP_SPI_FLASH_MISO_PORT, BSP_SPI_FLASH_MISO_PIN) != RESET) {
                in |= 0x01U;
            }
            spi_delay_half_bit();
            gpio_bit_reset(BSP_SPI_FLASH_SCK_PORT, BSP_SPI_FLASH_SCK_PIN);
            out <<= 1U;
        }
        if (rx != 0) {
            rx[i] = in;
        }
    }
    return true;
}

#else

void bsp_spi_init(void)
{
}

bool bsp_spi_flash_select(bool active)
{
    (void)active;
    return true;
}

bool bsp_spi_flash_transfer(const uint8_t *tx, uint8_t *rx, size_t len)
{
    size_t i;
    if (rx != 0) {
        for (i = 0U; i < len; ++i) {
            rx[i] = (tx != 0) ? tx[i] : 0xFFU;
        }
    }
    return true;
}

#endif
