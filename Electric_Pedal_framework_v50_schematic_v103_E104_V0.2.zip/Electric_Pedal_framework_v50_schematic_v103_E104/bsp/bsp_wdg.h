#ifndef BSP_WDG_H
#define BSP_WDG_H

/*
 * 看门狗接口：由调度器周期刷新，目标平台上接入硬件 IWDG。
 */
void bsp_wdg_init(void);
void bsp_wdg_feed(void);

#endif
