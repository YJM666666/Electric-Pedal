#ifndef BSP_UART_H
#define BSP_UART_H

/*
 * UART 抽象接口：统一硬件串口和软串口收发，供 BLE、U12/U17 链路和调试通道使用。
 */
#include <stddef.h>
#include <stdint.h>
#include "project_bool.h"

typedef enum
{
    BSP_UART_PORT_BLE = 0,
    BSP_UART_PORT_U17,
    BSP_UART_PORT_MAX
} bsp_uart_port_t;

void bsp_uart_init(void);
size_t bsp_uart_send(bsp_uart_port_t port, const uint8_t *data, size_t len);
size_t bsp_uart_fetch_tx(bsp_uart_port_t port, uint8_t *buf, size_t max_len);
void bsp_uart_clear_tx(bsp_uart_port_t port);

size_t bsp_uart_recv(bsp_uart_port_t port, uint8_t *buf, size_t max_len);
void bsp_uart_rx_buf_isr(bsp_uart_port_t port, const uint8_t *data, size_t len);
void bsp_uart_clear_rx(bsp_uart_port_t port);

#endif
