#include "bsp_iflash.h"
#include "bsp_build.h"
#include "flash_layout.h"
#include <string.h>

#if BSP_PLATFORM_GD32
#if BSP_APP_IS_U17
#include "gd32f1x0.h"
#define IFLASH_SECTOR_SIZE   FL_U17_SECTOR_SIZE
#else
#include "gd32c10x.h"
#define IFLASH_SECTOR_SIZE   FL_U12_SECTOR_SIZE
#endif
#endif

#ifndef IFLASH_SECTOR_SIZE
#define IFLASH_SECTOR_SIZE   FL_U12_SECTOR_SIZE
#endif

void bsp_iflash_init(void)
{
    /* FMC 在 SystemInit 之后即可访问, 这里保留接口便于将来增加锁/电压检查 */
}

uint32_t bsp_iflash_sector_size(void)
{
    return (uint32_t)IFLASH_SECTOR_SIZE;
}

#if BSP_PLATFORM_GD32

static uint32_t align_down(uint32_t value, uint32_t align)
{
    return value & ~(align - 1U);
}

static uint32_t align_up(uint32_t value, uint32_t align)
{
    return (value + align - 1U) & ~(align - 1U);
}

bool bsp_iflash_erase_range(uint32_t addr, uint32_t len)
{
    uint32_t start;
    uint32_t end;
    uint32_t page;
    fmc_state_enum st;

    if (len == 0U) {
        return false;
    }

    start = align_down(addr, IFLASH_SECTOR_SIZE);
    end = align_up(addr + len, IFLASH_SECTOR_SIZE);

    fmc_unlock();
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_WPERR | FMC_FLAG_PGERR);

    for (page = start; page < end; page += IFLASH_SECTOR_SIZE) {
        st = fmc_page_erase(page);
        if (st != FMC_READY) {
            fmc_lock();
            return false;
        }
    }

    fmc_lock();
    return true;
}

bool bsp_iflash_program(uint32_t addr, const uint8_t *data, uint32_t len)
{
    uint32_t i;
    uint32_t word;
    fmc_state_enum st;

    if ((data == 0) || (len == 0U) || ((addr & 0x3U) != 0U) || ((len & 0x3U) != 0U)) {
        return false;
    }

    fmc_unlock();
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_WPERR | FMC_FLAG_PGERR);

    for (i = 0U; i < len; i += 4U) {
        (void)memcpy(&word, &data[i], sizeof(word));
        st = fmc_word_program(addr + i, word);
        if (st != FMC_READY) {
            fmc_lock();
            return false;
        }
    }

    fmc_lock();
    return true;
}

#else

/* 主机/仿真平台: 提供一个内存数组作为后端, 方便单元测试。 */
#define IFLASH_FAKE_SIZE  (FL_U12_APP_B_BASE + FL_U12_APP_B_SIZE - FLASH_BASE_ADDR)

static uint8_t s_fake_flash[IFLASH_FAKE_SIZE];

bool bsp_iflash_erase_range(uint32_t addr, uint32_t len)
{
    uint32_t off;

    if (len == 0U) {
        return false;
    }
    if ((addr < FLASH_BASE_ADDR) ||
        ((addr + len) > (FLASH_BASE_ADDR + IFLASH_FAKE_SIZE))) {
        return false;
    }

    off = addr - FLASH_BASE_ADDR;
    (void)memset(&s_fake_flash[off], 0xFF, len);
    return true;
}

bool bsp_iflash_program(uint32_t addr, const uint8_t *data, uint32_t len)
{
    uint32_t off;

    if ((data == 0) || (len == 0U) || ((addr & 0x3U) != 0U) || ((len & 0x3U) != 0U)) {
        return false;
    }
    if ((addr < FLASH_BASE_ADDR) ||
        ((addr + len) > (FLASH_BASE_ADDR + IFLASH_FAKE_SIZE))) {
        return false;
    }

    off = addr - FLASH_BASE_ADDR;
    (void)memcpy(&s_fake_flash[off], data, len);
    return true;
}

#endif

bool bsp_iflash_verify(uint32_t addr, const uint8_t *data, uint32_t len)
{
    if ((data == 0) || (len == 0U)) {
        return false;
    }

#if BSP_PLATFORM_GD32
    return (memcmp((const void *)addr, data, len) == 0);
#else
    {
        uint32_t off;
        if ((addr < FLASH_BASE_ADDR) ||
            ((addr + len) > (FLASH_BASE_ADDR + IFLASH_FAKE_SIZE))) {
            return false;
        }
        off = addr - FLASH_BASE_ADDR;
        return (memcmp(&s_fake_flash[off], data, len) == 0);
    }
#endif
}
