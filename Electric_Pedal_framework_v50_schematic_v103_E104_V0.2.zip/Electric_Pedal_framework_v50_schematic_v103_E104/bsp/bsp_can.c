/*
 * 文件: bsp/bsp_can.c
 * 描述: CAN 总线抽象与初始化（支持 Classic 与 CAN-FD）。
 * 责任: 初始化 CAN PHY/GPIO/时序，管理滤波器及提供发送/接收接口。
 */

#include "bsp_can.h"
#include "bsp_build.h"
#include <string.h>
#include "bsp_board.h"

#ifndef BSP_CAN0_STB_WIRED
#define BSP_CAN0_STB_WIRED 0U
#endif

#ifndef BSP_CAN1_STB_WIRED
#define BSP_CAN1_STB_WIRED 0U
#endif

static bsp_can_dual_cfg_t s_can_cfg = {
    {BSP_CAN0_DEFAULT_NOMINAL, BSP_CAN0_DEFAULT_DATA_2M, true,  BSP_CAN0_DEFAULT_LISTEN_ONLY},
    {BSP_CAN1_DEFAULT_NOMINAL, BSP_CAN1_DEFAULT_NOMINAL,  false, BSP_CAN1_DEFAULT_LISTEN_ONLY},
    BSP_CAN_MONITOR_BOTH
};

const bsp_can_dual_cfg_t *bsp_can_get_cfg(void)
{
    return &s_can_cfg;
}

void bsp_can_set_monitor_sel(bsp_can_monitor_sel_t sel)
{
    if ((uint32_t)sel < (uint32_t)BSP_CAN_BUS_MAX + 1U) {
        s_can_cfg.monitor_sel = sel;
    }
}

#if BSP_PLATFORM_GD32 && defined(BSP_TARGET_GD32C103)
#include "gd32c10x.h"
#include "gd32c10x_rcu.h"
#include "gd32c10x_gpio.h"
#include "gd32c10x_can.h"


static void can_phy_stb_init(void)
{
#if (BSP_CAN0_STB_WIRED != 0U)
    rcu_periph_clock_enable(BSP_CAN0_STB_RCU);
    gpio_init(BSP_CAN0_STB_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, BSP_CAN0_STB_PIN);
    gpio_bit_reset(BSP_CAN0_STB_PORT, BSP_CAN0_STB_PIN); /* STB=0：正常/高速模式 */
#endif
#if (BSP_CAN1_STB_WIRED != 0U)
    rcu_periph_clock_enable(BSP_CAN1_STB_RCU);
    gpio_init(BSP_CAN1_STB_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, BSP_CAN1_STB_PIN);
    gpio_bit_reset(BSP_CAN1_STB_PORT, BSP_CAN1_STB_PIN); /* STB=0：正常模式 */
#endif
}

static void can_gpio_clock_init(void)
{
    rcu_periph_clock_enable(BSP_CAN0_RCU);
    rcu_periph_clock_enable(BSP_CAN1_RCU);
    rcu_periph_clock_enable(BSP_CAN_GPIOA_RCU);
    rcu_periph_clock_enable(BSP_CAN_GPIOB_RCU);
    rcu_periph_clock_enable(BSP_CAN_AF_RCU);
    can_phy_stb_init();

    /* 物理引脚映射由板级配置管理，不应在服务逻辑中硬编码。 */
    gpio_init(BSP_CAN0_RX_PORT, BSP_CAN_GPIO_INPUT_MODE, GPIO_OSPEED_50MHZ, BSP_CAN0_RX_PIN);
    gpio_init(BSP_CAN0_TX_PORT, BSP_CAN_GPIO_OUTPUT_MODE, GPIO_OSPEED_50MHZ, BSP_CAN0_TX_PIN);
    gpio_init(BSP_CAN1_RX_PORT, BSP_CAN_GPIO_INPUT_MODE, GPIO_OSPEED_50MHZ, BSP_CAN1_RX_PIN);
    gpio_init(BSP_CAN1_TX_PORT, BSP_CAN_GPIO_OUTPUT_MODE, GPIO_OSPEED_50MHZ, BSP_CAN1_TX_PIN);
}

static void can_apply_filter_accept_all(uint32_t canx, uint8_t filter_no, uint8_t fifo)
{
    can_filter_parameter_struct f;
    can_struct_para_init(CAN_FILTER_STRUCT, &f);
    f.filter_number = filter_no;
    f.filter_mode = CAN_FILTERMODE_MASK;
    f.filter_bits = CAN_FILTERBITS_32BIT;
    f.filter_fifo_number = fifo;
    f.filter_list_high = 0U;
    f.filter_list_low = 0U;
    f.filter_mask_high = 0U;
    f.filter_mask_low = 0U;
    f.filter_enable = ENABLE;
    can_filter_init(&f);
}

static void can_init_classic(uint32_t canx, uint32_t bitrate, uint8_t work_mode)
{
    can_parameter_struct p;
    can_struct_para_init(CAN_INIT_STRUCT, &p);
    p.working_mode = work_mode;
    p.resync_jump_width = CAN_BT_SJW_1TQ;
    p.time_segment_1 = CAN_BT_BS1_13TQ;
    p.time_segment_2 = CAN_BT_BS2_2TQ;
    /* APB1=60MHz：60M/(15*16)=250k，60M/(30*16)=125k */
    p.prescaler = (bitrate <= 125000UL) ? 30U : 15U;
    p.auto_retrans = DISABLE;
    p.auto_bus_off_recovery = ENABLE;
    p.rec_fifo_overwrite = ENABLE;
    (void)can_init(canx, &p);
}

static void can_init_fd(uint32_t canx, uint32_t nominal_bitrate, uint32_t data_bitrate, uint8_t work_mode)
{
    can_parameter_struct p;
    can_fdframe_struct fd;
    can_fd_tdc_struct tdc;

    can_struct_para_init(CAN_INIT_STRUCT, &p);
    p.working_mode = work_mode;
    p.resync_jump_width = CAN_BT_SJW_1TQ;
    p.time_segment_1 = CAN_BT_BS1_13TQ;
    p.time_segment_2 = CAN_BT_BS2_2TQ;
    /* 默认配置 CAN0 使用 500k 仲裁；时序可在不修改上层的情况下调整。 */
    p.prescaler = (nominal_bitrate >= 500000UL) ? 15U : 30U;
    p.auto_retrans = DISABLE;
    p.auto_bus_off_recovery = ENABLE;
    p.rec_fifo_overwrite = ENABLE;
    (void)can_init(canx, &p);

    can_struct_para_init(CAN_FD_FRAME_STRUCT, &fd);
    (void)memset(&tdc, 0, sizeof(tdc));
    tdc.tdc_mode = CAN_TDCMOD_CALC_AND_OFFSET;
    tdc.tdc_filter = 0U;
    tdc.tdc_offset = 0U;
    fd.fd_frame = ENABLE;
    fd.excp_event_detect = ENABLE;
    fd.delay_compensation = DISABLE;
    fd.p_delay_compensation = &tdc;
    fd.iso_bosch = CAN_FDMOD_ISO;
    fd.esi_mode = CAN_ESIMOD_HARDWARE;
    fd.data_resync_jump_width = CAN_BT_SJW_1TQ;
    fd.data_time_segment_1 = CAN_BT_BS1_3TQ;
    fd.data_time_segment_2 = CAN_BT_BS2_1TQ;
    /* 数据相速率可配置：默认 2M，可选 5M。 */
    fd.data_prescaler = (data_bitrate >= 5000000UL) ? 4U : 10U;
    can_fd_init(canx, &fd);
}

void bsp_can_init_with_cfg(const bsp_can_dual_cfg_t *cfg)
{
    if (cfg != 0) {
        s_can_cfg = *cfg;
    }

    can_gpio_clock_init();

    can_deinit(CAN0);
    can_deinit(CAN1);

    can_init_fd(CAN0,
                s_can_cfg.bus0_hs_fd.nominal_bitrate,
                s_can_cfg.bus0_hs_fd.data_bitrate,
                s_can_cfg.bus0_hs_fd.listen_only ? CAN_SILENT_MODE : CAN_NORMAL_MODE);

    can_init_classic(CAN1,
                     s_can_cfg.bus1_ls_classic.nominal_bitrate,
                     s_can_cfg.bus1_ls_classic.listen_only ? CAN_SILENT_MODE : CAN_NORMAL_MODE);

    can1_filter_start_bank(14U);
    can_apply_filter_accept_all(CAN0, 0U, CAN_FIFO0);
    can_apply_filter_accept_all(CAN1, 14U, CAN_FIFO0);
}

void bsp_can_init(void)
{
    bsp_can_init_with_cfg(0);
}

bool bsp_can_send(const bsp_can_frame_t *frame)
{
    can_trasnmit_message_struct tx;
    if (frame == 0) {
        return false;
    }
    if (((frame->bus == BSP_CAN_BUS0_HS_FD) && (s_can_cfg.monitor_sel == BSP_CAN_MONITOR_LS_ONLY)) ||
        ((frame->bus == BSP_CAN_BUS1_LS_CLASSIC) && (s_can_cfg.monitor_sel == BSP_CAN_MONITOR_HS_ONLY))) {
        return false;
    }
    can_struct_para_init(CAN_TX_MESSAGE_STRUCT, &tx);
    tx.tx_ff = frame->is_extended ? CAN_FF_EXTENDED : CAN_FF_STANDARD;
    tx.tx_ft = CAN_FT_DATA;
    tx.tx_sfid = frame->id & 0x7FFU;
    tx.tx_efid = frame->id;
    tx.tx_dlen = frame->dlc;
    tx.fd_flag = frame->fd_enable ? CAN_FDF_FDFRAME : CAN_FDF_CLASSIC;
    tx.fd_brs = frame->brs_enable ? CAN_BRS_ENABLE : CAN_BRS_DISABLE;
    (void)memcpy(tx.tx_data, frame->data, sizeof(tx.tx_data));
    return (can_message_transmit((frame->bus == BSP_CAN_BUS0_HS_FD) ? CAN0 : CAN1, &tx) != CAN_TRANSMIT_NOMAILBOX);
}

bool bsp_can_receive(bsp_can_frame_t *frame)
{
    can_receive_message_struct rx;
    uint32_t canx;
    if (frame == 0) {
        return false;
    }
    if ((s_can_cfg.monitor_sel == BSP_CAN_MONITOR_BOTH) || (s_can_cfg.monitor_sel == BSP_CAN_MONITOR_HS_ONLY)) {
        if (can_receive_message_length_get(CAN0, CAN_FIFO0) != 0U) {
            canx = CAN0;
            can_message_receive(canx, CAN_FIFO0, &rx);
            frame->bus = BSP_CAN_BUS0_HS_FD;
            goto fill;
        }
    }
    if ((s_can_cfg.monitor_sel == BSP_CAN_MONITOR_BOTH) || (s_can_cfg.monitor_sel == BSP_CAN_MONITOR_LS_ONLY)) {
        if (can_receive_message_length_get(CAN1, CAN_FIFO0) != 0U) {
            canx = CAN1;
            can_message_receive(canx, CAN_FIFO0, &rx);
            frame->bus = BSP_CAN_BUS1_LS_CLASSIC;
            goto fill;
        }
    }
    return false;
fill:
    frame->is_extended = (rx.rx_ff == CAN_FF_EXTENDED) ? true : false;
    frame->id = frame->is_extended ? rx.rx_efid : rx.rx_sfid;
    frame->dlc = rx.rx_dlen;
    frame->fd_enable = (rx.fd_flag != CAN_FDF_CLASSIC) ? true : false;
    frame->brs_enable = (rx.fd_brs != CAN_BRS_DISABLE) ? true : false;
    (void)memcpy(frame->data, rx.rx_data, sizeof(frame->data));
    return true;
}

#else
void bsp_can_init_with_cfg(const bsp_can_dual_cfg_t *cfg)
{
    if (cfg != 0) {
        s_can_cfg = *cfg;
    }
}
void bsp_can_init(void) { bsp_can_init_with_cfg(0); }
bool bsp_can_send(const bsp_can_frame_t *frame) { (void)frame; return false; }
bool bsp_can_receive(bsp_can_frame_t *frame) { (void)frame; return false; }
#endif
