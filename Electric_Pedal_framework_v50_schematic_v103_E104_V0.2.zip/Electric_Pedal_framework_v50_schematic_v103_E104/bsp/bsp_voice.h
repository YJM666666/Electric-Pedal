﻿#ifndef BSP_VOICE_H
#define BSP_VOICE_H

#include "project_bool.h"
#include <stdint.h>

/*
 * 语音语言枚举。
 * 这里只区分中/英，真正映射到哪条语音由 voice_catalog 决定。
 */
typedef enum
{
    BSP_VOICE_LANG_ZH = 0,
    BSP_VOICE_LANG_EN = 1
} bsp_voice_lang_t;

/*
 * 初始化 MX5008F 相关 GPIO 和内部状态机。
 * 需要在 U17 上电完成后尽早调用。
 */
void bsp_voice_init(void);

/*
 * 10ms 周期维护入口：
 * - 采样 BUSY 引脚
 * - 维护启动等待窗口
 * - 维护软件兜底剩余时间
 */
void bsp_voice_tick_10ms(void);

/* 当前是否处于播放中。优先使用硬件 BUSY 判定。 */
bool bsp_voice_is_busy(void);

/*
 * 播放“曲目槽位”。
 * slot         : 烧录到语音芯片里的曲目号（由 voice_catalog 提供）
 * estimated_ms : 当硬件 BUSY 异常时，软件用来兜底的预计时长
 *
 * 注意：
 * - 为了兼容 MX5008F 资料里“电机/继电器等电源扰动后建议延时 200ms 以上再播报”的要求，
 *   当前实现采用“排队 + 延时启动”策略，而不是收到请求后立刻发码。
 */
bool bsp_voice_play_slot(uint16_t slot, uint16_t estimated_ms);

/* 停止播放。 */
bool bsp_voice_stop(void);

/*
 * MX5008F 一线脉冲底层发送。
 *
 * 注意：
 * - 当前实现按厂商 DAC 参考说明做：DATA 线上发送脉冲个数来选曲。
 * - 上电后需等待 boot guard。
 * - 发送后等待 BUSY 进入播放态；如果 BUSY 没有响应，则退回软件时长兜底。
 */
bool bsp_voice_send_word(uint16_t word);

#endif
