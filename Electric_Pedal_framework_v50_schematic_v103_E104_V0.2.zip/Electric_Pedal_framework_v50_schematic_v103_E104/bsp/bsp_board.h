#ifndef BSP_BOARD_H
#define BSP_BOARD_H

/*
 * 软硬件解耦入口。
 * 业务逻辑不直接依赖原始引脚名；所有板级和 MCU 差异都收敛到 config/board 下的 profile。
 * 当 MCU、封装或引脚分配变化时，只需要切换或修改对应的板级 profile。
 */

#include "bsp_build.h"

#if BSP_PLATFORM_GD32
  #if defined(APP_ROLE_U17_SLAVE)
    #include "config/board/board_profile_u17_gd32f130.h"
  #elif defined(BSP_TARGET_GD32C103)
    #include "config/board/board_profile_u12_gd32c103.h"
  #else
    #include "config/board/board_profile_u12_gd32c103.h"
  #endif
#else
  #include "config/board/board_profile_host.h"
#endif

#endif
