/*
 * 看门狗板级驱动：初始化并周期喂狗，防止主循环卡死后长期保持危险输出。
 */
#include "bsp_wdg.h"
#include "bsp_build.h"

#if BSP_PLATFORM_GD32
#if defined(BSP_TARGET_GD32C103)
#include "gd32c10x_fwdgt.h"
#else
#include "gd32f1x0_fwdgt.h"
#endif

void bsp_wdg_init(void)
{
    fwdgt_write_enable();
    fwdgt_config(4095U, FWDGT_PSC_DIV64);
    fwdgt_counter_reload();
    fwdgt_enable();
}

void bsp_wdg_feed(void)
{
    fwdgt_counter_reload();
}

#else

void bsp_wdg_init(void)
{
}

void bsp_wdg_feed(void)
{
}

#endif
