./objects/u12/voice_announce_service.o: service\voice_announce_service.c \
  service\voice_announce_service.h service\event.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h project_bool.h \
  driver\drv_voice.h param.h service\param.h pedal_types.h \
  service\voice_catalog.h bsp\bsp_voice.h service\u17_link.h \
  D:\Keil_v5\ARM\ARMCLANG\include\string.h
