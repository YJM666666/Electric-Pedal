./objects/u12/gd32c10x_bkp.o: \
  vendor\GD32C10x_Firmware_Library_V1.7.0\Firmware\GD32C10x_standard_peripheral\Source\gd32c10x_bkp.c \
  local_include\c10x\gd32c10x_bkp.h local_include\c10x\gd32c10x.h \
  local_include\c10x\core_cm4.h D:\Keil_v5\ARM\ARMCLANG\include\stdint.h \
  vendor\GD32C10x_Firmware_Library_V1.7.0\Firmware\CMSIS\core_cmInstr.h \
  vendor\GD32C10x_Firmware_Library_V1.7.0\Firmware\CMSIS\core_cmFunc.h \
  vendor\GD32C10x_Firmware_Library_V1.7.0\Firmware\CMSIS\core_cm4_simd.h \
  local_include\c10x\system_gd32c10x.h \
  local_include\c10x\gd32c10x_libopt_local.h \
  local_include\c10x\RTE_Components_local.h \
  local_include\c10x\gd32c10x_adc.h local_include\c10x\gd32c10x_can.h \
  local_include\c10x\gd32c10x_crc.h local_include\c10x\gd32c10x_ctc.h \
  local_include\c10x\gd32c10x_dac.h local_include\c10x\gd32c10x_dbg.h \
  local_include\c10x\gd32c10x_dma.h local_include\c10x\gd32c10x_exmc.h \
  local_include\c10x\gd32c10x_exti.h local_include\c10x\gd32c10x_fmc.h \
  local_include\c10x\gd32c10x_fwdgt.h local_include\c10x\gd32c10x_gpio.h \
  local_include\c10x\gd32c10x_i2c.h local_include\c10x\gd32c10x_misc.h \
  local_include\c10x\gd32c10x_pmu.h local_include\c10x\gd32c10x_rcu.h \
  local_include\c10x\gd32c10x_rtc.h local_include\c10x\gd32c10x_spi.h \
  local_include\c10x\gd32c10x_timer.h \
  local_include\c10x\gd32c10x_usart.h \
  local_include\c10x\gd32c10x_wwdgt.h
