./objects/u12/event_report_service.o: service\event_report_service.c \
  service\event_report_service.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h project_bool.h \
  service\event.h service\app_proto_v2.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stddef.h \
  config\protocol\app_proto_v2_ids.h bsp_uart.h bsp\bsp_uart.h policy.h \
  control\policy.h control\sys_sm.h event.h control\step_sm.h \
  pedal_types.h param.h service\param.h \
  D:\Keil_v5\ARM\ARMCLANG\include\string.h
