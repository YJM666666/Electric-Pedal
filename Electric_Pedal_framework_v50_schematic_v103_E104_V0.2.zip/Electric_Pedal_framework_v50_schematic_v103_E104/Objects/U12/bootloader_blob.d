./objects/u12/bootloader_blob.o: boot\bootloader_blob.c \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h boot\bootloader_blob.inc
