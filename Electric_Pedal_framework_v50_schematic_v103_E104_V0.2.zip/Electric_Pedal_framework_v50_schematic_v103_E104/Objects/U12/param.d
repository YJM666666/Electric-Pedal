./objects/u12/param.o: service\param.c service\param.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h project_bool.h pedal_types.h \
  drv_nvm.h driver\drv_nvm.h service\event.h service\fault.h \
  service\u17_link.h service\motor_profile.h driver\drv_motor_backend.h \
  D:\Keil_v5\ARM\ARMCLANG\include\string.h
