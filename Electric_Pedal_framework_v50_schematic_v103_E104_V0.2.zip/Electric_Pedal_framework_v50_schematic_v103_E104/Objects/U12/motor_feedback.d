./objects/u12/motor_feedback.o: control\motor_feedback.c \
  control\motor_feedback.h project_bool.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h pedal_types.h event.h \
  service\event.h service\step_executor.h service\motor_profile.h \
  driver\drv_motor_backend.h param.h service\param.h sw_timer.h \
  service\sw_timer.h D:\Keil_v5\ARM\ARMCLANG\include\string.h
