./objects/u12/policy.o: control\policy.c control\policy.h project_bool.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h control\sys_sm.h event.h \
  service\event.h control\step_sm.h pedal_types.h param.h \
  service\param.h fault.h service\fault.h drv_light.h driver\drv_light.h \
  can_if.h service\can_if.h bsp_can.h bsp\bsp_can.h sw_timer.h \
  service\sw_timer.h
