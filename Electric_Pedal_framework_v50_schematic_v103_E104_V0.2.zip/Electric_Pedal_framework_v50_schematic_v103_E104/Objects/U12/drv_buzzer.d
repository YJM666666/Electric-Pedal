./objects/u12/drv_buzzer.o: driver\drv_buzzer.c driver\drv_buzzer.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h project_bool.h u17_link.h \
  service\u17_link.h pedal_types.h service\param.h
