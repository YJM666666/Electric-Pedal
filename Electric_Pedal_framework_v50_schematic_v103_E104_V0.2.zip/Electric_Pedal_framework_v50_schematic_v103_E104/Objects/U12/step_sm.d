./objects/u12/step_sm.o: control\step_sm.c control\step_sm.h \
  project_bool.h D:\Keil_v5\ARM\ARMCLANG\include\stdint.h event.h \
  service\event.h pedal_types.h service\step_executor.h fault.h \
  service\fault.h param.h service\param.h sw_timer.h service\sw_timer.h \
  drv_nvm.h driver\drv_nvm.h drv_motor.h driver\drv_motor.h \
  driver\drv_motor_backend.h control\motor_feedback.h
