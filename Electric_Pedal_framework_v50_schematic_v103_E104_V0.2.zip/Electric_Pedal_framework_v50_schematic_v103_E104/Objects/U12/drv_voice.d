./objects/u12/drv_voice.o: driver\drv_voice.c driver\drv_voice.h \
  project_bool.h D:\Keil_v5\ARM\ARMCLANG\include\stdint.h param.h \
  service\param.h pedal_types.h service\voice_catalog.h bsp\bsp_voice.h \
  u17_link.h service\u17_link.h
