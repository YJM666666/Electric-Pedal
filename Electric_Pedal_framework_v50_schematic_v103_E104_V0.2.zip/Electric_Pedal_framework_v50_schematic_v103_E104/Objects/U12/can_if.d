./objects/u12/can_if.o: service\can_if.c service\can_if.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h project_bool.h bsp_can.h \
  bsp\bsp_can.h service\param.h pedal_types.h service\fault.h \
  service\event_flags.h service\event.h \
  D:\Keil_v5\ARM\ARMCLANG\include\string.h
