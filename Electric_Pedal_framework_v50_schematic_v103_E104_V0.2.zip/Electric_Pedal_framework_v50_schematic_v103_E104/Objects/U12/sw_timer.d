./objects/u12/sw_timer.o: service\sw_timer.c service\sw_timer.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h project_bool.h
