./objects/u12/app_proto_v2.o: service\app_proto_v2.c \
  service\app_proto_v2.h D:\Keil_v5\ARM\ARMCLANG\include\stddef.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h project_bool.h \
  config\protocol\app_proto_v2_ids.h \
  D:\Keil_v5\ARM\ARMCLANG\include\string.h
