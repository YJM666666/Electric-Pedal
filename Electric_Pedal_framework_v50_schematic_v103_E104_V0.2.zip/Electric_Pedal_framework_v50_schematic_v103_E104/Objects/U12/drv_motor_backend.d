./objects/u12/drv_motor_backend.o: driver\drv_motor_backend.c \
  driver\drv_motor_backend.h project_bool.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h pedal_types.h \
  driver\drv_motor_backend_relay.h
