./objects/u12/step_executor.o: service\step_executor.c \
  service\step_executor.h project_bool.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h pedal_types.h drv_motor.h \
  driver\drv_motor.h driver\drv_motor_backend.h
