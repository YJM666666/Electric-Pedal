./objects/u12/event.o: service\event.c service\event.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h project_bool.h
