./objects/u17/bsp_uart.o: bsp\bsp_uart.c bsp\bsp_uart.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stddef.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h project_bool.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\CMSIS\GD\GD32F1x0\Include\gd32f1x0.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\CMSIS\core_cm3.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\CMSIS\core_cmInstr.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\CMSIS\core_cmFunc.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\CMSIS\GD\GD32F1x0\Include\system_gd32f1x0.h \
  gd32f1x0_libopt.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_adc.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_cec.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_crc.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_cmp.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_dac.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_dbg.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_dma.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_exti.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_fmc.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_gpio.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_syscfg.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_i2c.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_fwdgt.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_pmu.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_rcu.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_rtc.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_spi.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_timer.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_usart.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_wwdgt.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_misc.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_tsi.h \
  bsp\bsp_build.h D:\Keil_v5\ARM\ARMCLANG\include\string.h \
  service\event_flags.h service\event.h bsp\bsp_board.h \
  config\board\board_profile_u17_gd32f130.h \
  config\board\board_profile_common.h
