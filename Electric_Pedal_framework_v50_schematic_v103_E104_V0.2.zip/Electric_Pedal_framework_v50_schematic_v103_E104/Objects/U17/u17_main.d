./objects/u17/u17_main.o: u17_slave\app\u17_main.c bsp_build.h \
  bsp\bsp_build.h u17_slave\service\u12_u17_slave_link.h project_bool.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\CMSIS\GD\GD32F1x0\Include\gd32f1x0.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\CMSIS\core_cm3.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\CMSIS\core_cmInstr.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\CMSIS\core_cmFunc.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\CMSIS\GD\GD32F1x0\Include\system_gd32f1x0.h \
  gd32f1x0_libopt.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_adc.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_cec.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_crc.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_cmp.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_dac.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_dbg.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_dma.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_exti.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_fmc.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_gpio.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_syscfg.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_i2c.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_fwdgt.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_pmu.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_rcu.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_rtc.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_spi.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_timer.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_usart.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_wwdgt.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_misc.h \
  vendor\GD32F1x0_Firmware_Library_V3.8.0\Firmware\GD32F1x0_standard_peripheral\Include\gd32f1x0_tsi.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stddef.h pedal_types.h \
  u17_slave\control\u17_exec.h param.h service\param.h bsp_platform.h \
  bsp\bsp_platform.h bsp_gpio.h bsp\bsp_gpio.h bsp\bsp_board.h \
  config\board\board_profile_u17_gd32f130.h \
  config\board\board_profile_common.h bsp_adc.h bsp\bsp_adc.h bsp_uart.h \
  bsp\bsp_uart.h bsp_wdg.h bsp\bsp_wdg.h bsp_timer.h bsp\bsp_timer.h \
  bsp_i2c.h bsp\bsp_i2c.h bsp_voice.h bsp\bsp_voice.h
