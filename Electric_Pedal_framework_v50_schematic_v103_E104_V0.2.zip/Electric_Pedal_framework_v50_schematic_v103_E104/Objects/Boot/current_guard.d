./objects/boot/current_guard.o: service\current_guard.c \
  service\current_guard.h D:\Keil_v5\ARM\ARMCLANG\include\stdint.h \
  pedal_types.h service\param.h project_bool.h service\event_flags.h \
  service\event.h
