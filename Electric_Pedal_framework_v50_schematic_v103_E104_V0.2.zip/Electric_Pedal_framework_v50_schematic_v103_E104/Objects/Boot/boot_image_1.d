./objects/boot/boot_image_1.o: boot\boot_image.c boot\boot_image.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h project_bool.h \
  config\flash_layout.h boot\boot_crc32.h
