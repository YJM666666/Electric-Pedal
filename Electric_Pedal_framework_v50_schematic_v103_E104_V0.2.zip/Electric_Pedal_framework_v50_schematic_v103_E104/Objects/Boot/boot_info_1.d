./objects/boot/boot_info_1.o: boot\boot_info.c boot\boot_info.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h project_bool.h \
  config\flash_layout.h boot\boot_crc32.h bsp_i2c.h bsp\bsp_i2c.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stddef.h \
  D:\Keil_v5\ARM\ARMCLANG\include\string.h
