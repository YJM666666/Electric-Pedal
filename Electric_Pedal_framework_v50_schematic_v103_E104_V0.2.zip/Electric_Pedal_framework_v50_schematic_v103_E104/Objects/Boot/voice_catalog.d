./objects/boot/voice_catalog.o: service\voice_catalog.c \
  service\voice_catalog.h project_bool.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h bsp\bsp_voice.h
