./objects/boot//boot_crc32.o: boot\boot_crc32.c boot\boot_crc32.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h
