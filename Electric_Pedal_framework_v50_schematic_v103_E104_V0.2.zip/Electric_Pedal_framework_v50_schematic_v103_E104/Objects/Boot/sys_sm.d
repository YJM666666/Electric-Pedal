./objects/boot/sys_sm.o: control\sys_sm.c control\sys_sm.h event.h \
  service\event.h D:\Keil_v5\ARM\ARMCLANG\include\stdint.h \
  project_bool.h control\policy.h control\step_sm.h pedal_types.h \
  param.h service\param.h fault.h service\fault.h
