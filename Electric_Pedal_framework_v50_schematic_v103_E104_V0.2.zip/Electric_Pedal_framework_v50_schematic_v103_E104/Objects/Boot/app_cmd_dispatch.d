./objects/boot/app_cmd_dispatch.o: service\app_cmd_dispatch.c \
  service\app_cmd_dispatch.h D:\Keil_v5\ARM\ARMCLANG\include\stdint.h \
  project_bool.h service\app_proto_v2.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stddef.h \
  config\protocol\app_proto_v2_ids.h service\event_report_service.h \
  service\event.h service\param.h pedal_types.h policy.h \
  control\policy.h control\sys_sm.h event.h control\step_sm.h param.h \
  service\fault.h service\ota_service.h drv_light.h driver\drv_light.h \
  D:\Keil_v5\ARM\ARMCLANG\include\string.h
