./objects/boot/scheduler.o: control\scheduler.c control\scheduler.h \
  project_bool.h D:\Keil_v5\ARM\ARMCLANG\include\stdint.h event.h \
  service\event.h control\sys_sm.h control\policy.h control\step_sm.h \
  pedal_types.h param.h service\param.h fault.h service\fault.h \
  current_guard.h service\current_guard.h can_if.h service\can_if.h \
  bsp_can.h bsp\bsp_can.h ble_if.h service\ble_if.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stddef.h u17_link.h service\u17_link.h \
  bsp_adc.h bsp\bsp_adc.h bsp_board.h bsp\bsp_board.h bsp\bsp_build.h \
  config\board\board_profile_u12_gd32c103.h \
  config\board\board_profile_common.h local_include\c10x\gd32c10x.h \
  local_include\c10x\core_cm4.h local_include\c10x\core_cmInstr.h \
  local_include\c10x\core_cmFunc.h local_include\c10x\core_cm4_simd.h \
  local_include\c10x\system_gd32c10x.h \
  local_include\c10x\gd32c10x_libopt_local.h \
  local_include\c10x\RTE_Components_local.h \
  local_include\c10x\gd32c10x_adc.h local_include\c10x\gd32c10x_bkp.h \
  local_include\c10x\gd32c10x_can.h local_include\c10x\gd32c10x_crc.h \
  local_include\c10x\gd32c10x_ctc.h local_include\c10x\gd32c10x_dac.h \
  local_include\c10x\gd32c10x_dbg.h local_include\c10x\gd32c10x_dma.h \
  local_include\c10x\gd32c10x_exmc.h local_include\c10x\gd32c10x_exti.h \
  local_include\c10x\gd32c10x_fmc.h local_include\c10x\gd32c10x_fwdgt.h \
  local_include\c10x\gd32c10x_gpio.h local_include\c10x\gd32c10x_i2c.h \
  local_include\c10x\gd32c10x_misc.h local_include\c10x\gd32c10x_pmu.h \
  local_include\c10x\gd32c10x_rcu.h local_include\c10x\gd32c10x_rtc.h \
  local_include\c10x\gd32c10x_spi.h local_include\c10x\gd32c10x_timer.h \
  local_include\c10x\gd32c10x_usart.h \
  local_include\c10x\gd32c10x_wwdgt.h service\step_executor.h \
  service\voice_announce_service.h control\motor_feedback.h \
  service\event_collector.h
