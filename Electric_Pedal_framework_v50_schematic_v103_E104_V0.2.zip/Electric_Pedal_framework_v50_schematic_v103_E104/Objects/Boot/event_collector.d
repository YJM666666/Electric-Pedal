./objects/boot/event_collector.o: service\event_collector.c \
  service\event_collector.h service\event_flags.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h service\event.h \
  project_bool.h service\ble_if.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stddef.h service\can_if.h bsp_can.h \
  bsp\bsp_can.h service\param.h pedal_types.h service\u17_link.h \
  service\current_guard.h service\motor_pulse_latch.h \
  D:\Keil_v5\ARM\ARMCLANG\include\string.h
