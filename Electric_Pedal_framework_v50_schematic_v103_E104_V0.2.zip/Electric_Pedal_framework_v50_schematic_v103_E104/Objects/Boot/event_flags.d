./objects/boot/event_flags.o: service\event_flags.c service\event_flags.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h service\event.h \
  project_bool.h
