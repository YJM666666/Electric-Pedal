./objects/boot/bsp_adc.o: bsp\bsp_adc.c bsp\bsp_adc.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h bsp\bsp_build.h
