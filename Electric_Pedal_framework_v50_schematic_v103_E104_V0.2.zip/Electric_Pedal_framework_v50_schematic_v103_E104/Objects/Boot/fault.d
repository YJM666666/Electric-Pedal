./objects/boot/fault.o: service\fault.c service\fault.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h project_bool.h
