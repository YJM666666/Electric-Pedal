./objects/boot//boot_main_u12.o: boot\boot_main_u12.c boot\boot_info.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h project_bool.h \
  config\flash_layout.h boot\boot_image.h boot\boot_jump.h \
  boot\boot_crc32.h boot\boot_extflash.h bsp\bsp_iflash.h bsp_i2c.h \
  bsp\bsp_i2c.h D:\Keil_v5\ARM\ARMCLANG\include\stddef.h bsp_platform.h \
  bsp\bsp_platform.h bsp_wdg.h bsp\bsp_wdg.h bsp_board.h bsp\bsp_board.h \
  bsp\bsp_build.h config\board\board_profile_u12_gd32c103.h \
  config\board\board_profile_common.h local_include\c10x\gd32c10x.h \
  local_include\c10x\core_cm4.h local_include\c10x\core_cmInstr.h \
  local_include\c10x\core_cmFunc.h local_include\c10x\core_cm4_simd.h \
  local_include\c10x\system_gd32c10x.h \
  local_include\c10x\gd32c10x_libopt_local.h \
  local_include\c10x\RTE_Components_local.h \
  local_include\c10x\gd32c10x_adc.h local_include\c10x\gd32c10x_bkp.h \
  local_include\c10x\gd32c10x_can.h local_include\c10x\gd32c10x_crc.h \
  local_include\c10x\gd32c10x_ctc.h local_include\c10x\gd32c10x_dac.h \
  local_include\c10x\gd32c10x_dbg.h local_include\c10x\gd32c10x_dma.h \
  local_include\c10x\gd32c10x_exmc.h local_include\c10x\gd32c10x_exti.h \
  local_include\c10x\gd32c10x_fmc.h local_include\c10x\gd32c10x_fwdgt.h \
  local_include\c10x\gd32c10x_gpio.h local_include\c10x\gd32c10x_i2c.h \
  local_include\c10x\gd32c10x_misc.h local_include\c10x\gd32c10x_pmu.h \
  local_include\c10x\gd32c10x_rcu.h local_include\c10x\gd32c10x_rtc.h \
  local_include\c10x\gd32c10x_spi.h local_include\c10x\gd32c10x_timer.h \
  local_include\c10x\gd32c10x_usart.h \
  local_include\c10x\gd32c10x_wwdgt.h
