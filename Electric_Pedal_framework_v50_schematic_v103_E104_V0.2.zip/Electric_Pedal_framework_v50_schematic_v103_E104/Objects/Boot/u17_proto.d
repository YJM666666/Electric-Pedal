./objects/boot/u17_proto.o: service\u17_proto.c service\u17_proto.h \
  project_bool.h D:\Keil_v5\ARM\ARMCLANG\include\stdint.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stddef.h \
  D:\Keil_v5\ARM\ARMCLANG\include\string.h
