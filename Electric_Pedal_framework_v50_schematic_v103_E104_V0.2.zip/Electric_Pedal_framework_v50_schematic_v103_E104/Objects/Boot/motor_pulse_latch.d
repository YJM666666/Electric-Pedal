./objects/boot/motor_pulse_latch.o: service\motor_pulse_latch.c \
  service\motor_pulse_latch.h project_bool.h \
  D:\Keil_v5\ARM\ARMCLANG\include\stdint.h pedal_types.h \
  service\event_flags.h service\event.h \
  D:\Keil_v5\ARM\ARMCLANG\include\string.h
