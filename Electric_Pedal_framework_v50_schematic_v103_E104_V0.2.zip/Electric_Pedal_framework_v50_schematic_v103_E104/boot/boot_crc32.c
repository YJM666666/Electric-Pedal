#include "boot_crc32.h"

/*
 * 不带预计算表的 bit-wise CRC32, 与协议 13 章 image_crc32 / drv_nvm 中的算法一致。
 * bootloader 关心代码体积, 不预计算 1KB 表; 应用侧可在需要时改成查表加速。
 */

uint32_t boot_crc32_update(uint32_t state, const uint8_t *data, uint32_t len)
{
    uint32_t crc = state;
    uint32_t i;
    uint32_t j;
    uint32_t byte_val;

    if ((data == 0) || (len == 0U)) {
        return crc;
    }

    for (i = 0U; i < len; ++i) {
        byte_val = (uint32_t)data[i];
        crc ^= byte_val;
        for (j = 0U; j < 8U; ++j) {
            if ((crc & 1UL) != 0UL) {
                crc = (crc >> 1U) ^ 0xEDB88320UL;
            } else {
                crc >>= 1U;
            }
        }
    }

    return crc;
}

uint32_t boot_crc32_finalize(uint32_t state)
{
    return ~state;
}

uint32_t boot_crc32_calc(const uint8_t *data, uint32_t len)
{
    uint32_t state = 0xFFFFFFFFUL;
    state = boot_crc32_update(state, data, len);
    return boot_crc32_finalize(state);
}
