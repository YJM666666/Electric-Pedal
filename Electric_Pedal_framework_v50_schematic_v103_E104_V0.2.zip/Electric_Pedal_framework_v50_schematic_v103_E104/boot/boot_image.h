﻿#ifndef BOOT_BOOT_IMAGE_H
#define BOOT_BOOT_IMAGE_H

/*
 * 鏂囦欢: boot/boot_image.h
 * 鎻忚堪: OTA 闀滃儚澶翠笌闀滃儚瀹屾暣鎬ф牎楠屾帴鍙ｃ€?
 * 璐ｄ换: 鍗忚 0xC1/0xC3 鍐欏叆涓?bootloader 鍚姩鏍￠獙閮介€氳繃鏈ā鍧楄繘琛屻€?
 *
 * 闀滃儚鍐呭瓨甯冨眬:
 *   [boot_image_header_t][app payload (image_size 瀛楄妭)]
 * 鍏朵腑 app payload 鐨勯 8 瀛楄妭涓?Cortex-M 涓柇鍚戦噺琛ㄧ殑 SP / Reset_Handler;
 * bootloader 璺宠浆鍓嶄細鏍￠獙 SP 钀藉湪鍚堟硶 SRAM 鑼冨洿, Reset_Handler 鍦ㄥ悎娉?Flash 妲戒綅鍐呫€?
 */

#include <stdint.h>
#include "project_bool.h"
#include "flash_layout.h"

#define BOOT_IMAGE_MAGIC      0x4150503AUL  /* 'APP:' */
#define BOOT_IMAGE_VERSION    0x0001U

#define BOOT_IMAGE_TARGET_U12 0x12U
#define BOOT_IMAGE_TARGET_U17 0x17U

typedef struct
{
    uint32_t magic;          /* BOOT_IMAGE_MAGIC */
    uint16_t version;        /* BOOT_IMAGE_VERSION */
    uint8_t  target_mcu;     /* BOOT_IMAGE_TARGET_U12 / U17 */
    uint8_t  reserved0;

    uint32_t image_size;     /* payload 瀛楄妭鏁? 涓嶅惈鏈ご */
    uint32_t image_crc32;    /* 瀵?payload 鐨?CRC32 (涓庡崗璁?0xC3 涓€鑷? */
    uint32_t fw_version;     /* 鍗忚 0xC1 fw_ver, 渚嬪 0x00010203 = 1.2.3 */

    uint32_t entry_offset;   /* 搴旂敤澶嶄綅鍚戦噺鐩稿 payload 鐨勫亸绉? 閫氬父涓?0 */
    uint32_t reserved1[9];  /* 保留字段，确保镜像头固定为 64 字节 */

    uint32_t header_crc32;   /* 瀵瑰墠闈㈡墍鏈夊瓧娈电殑 CRC32 */
} boot_image_header_t;

#define BOOT_IMAGE_HEADER_LEN  ((uint32_t)sizeof(boot_image_header_t))

/* 鏍￠獙 payload 闀垮害涓?CRC 鏄惁鍖归厤 expected. */
bool boot_image_payload_is_valid(const uint8_t *payload,
                                 uint32_t payload_len,
                                 uint32_t expected_crc32);

/* 鏍￠獙闀滃儚澶达紙鍚?header_crc32锛夈€?*/
bool boot_image_header_is_valid(const boot_image_header_t *hdr);

/* 鏍￠獙 Cortex-M 澶嶄綅鍚戦噺: SP 鍦ㄥ悎娉?SRAM, Reset_Handler 鍦?[base, base+size) 鍐呫€?*/
bool boot_image_vectors_look_sane(uint32_t slot_base,
                                  uint32_t slot_size,
                                  uint32_t sram_base,
                                  uint32_t sram_size);

#endif /* BOOT_BOOT_IMAGE_H */

