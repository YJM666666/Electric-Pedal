#include "boot_extflash.h"
#include "bsp_build.h"
#include "bsp_board.h"
#include "bsp_spi.h"

/*
 * Bootloader 只用得到 W25 的读路径, 协议指令与 ota_service 中保持一致:
 *   0x03 = read data, 后跟 24bit 大端地址。
 * 写/擦除路径不需要, 由应用 ota_service 负责。
 */

#define W25_CMD_READ_DATA      0x03U

void boot_extflash_init(void)
{
#if BSP_PLATFORM_GD32 && BSP_HAS_FLASH
    bsp_spi_init();
#endif
}

bool boot_extflash_read(uint32_t addr, uint8_t *data, uint32_t len)
{
#if BSP_PLATFORM_GD32 && BSP_HAS_FLASH
    uint8_t cmd[4];

    if ((data == 0) || (len == 0U)) {
        return false;
    }

    cmd[0] = W25_CMD_READ_DATA;
    cmd[1] = (uint8_t)((addr >> 16U) & 0xFFU);
    cmd[2] = (uint8_t)((addr >> 8U) & 0xFFU);
    cmd[3] = (uint8_t)(addr & 0xFFU);

    bsp_spi_flash_select(true);
    if (!bsp_spi_flash_transfer(cmd, 0, sizeof(cmd))) {
        bsp_spi_flash_select(false);
        return false;
    }
    if (!bsp_spi_flash_transfer(0, data, len)) {
        bsp_spi_flash_select(false);
        return false;
    }
    bsp_spi_flash_select(false);
    return true;
#else
    (void)addr; (void)data; (void)len;
    return false;
#endif
}
