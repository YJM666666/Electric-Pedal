#ifndef BOOT_BOOT_CRC32_H
#define BOOT_BOOT_CRC32_H

/*
 * 文件: boot/boot_crc32.h
 * 描述: CRC-32/IEEE 802.3 (poly=0x04C11DB7, refIn/refOut, init=0xFFFFFFFF, xorOut=0xFFFFFFFF).
 * 责任: bootloader、boot_info、OTA 镜像校验、drv_nvm 共用同一份实现，避免多份 CRC 漂移。
 */

#include <stdint.h>

uint32_t boot_crc32_calc(const uint8_t *data, uint32_t len);

/* 用于流式校验：传入上一次返回值，分块累加；首次调用传 0xFFFFFFFFUL 作为 state。 */
uint32_t boot_crc32_update(uint32_t state, const uint8_t *data, uint32_t len);
uint32_t boot_crc32_finalize(uint32_t state);

#endif /* BOOT_BOOT_CRC32_H */
