﻿#include <stdint.h>

/*
 * U12 出厂烧录用 bootloader 镜像占位。
 * Build 前脚本会先编译 bootloader，再把 bin 转成 bootloader_blob.inc。
 * 链接脚本把本段固定放到 0x08000000，应用向量表仍固定在 0x08004040。
 */
__attribute__((used, aligned(4), section(".bootloader_blob")))
const uint8_t g_u12_bootloader_blob[] = {
#include "bootloader_blob.inc"
};
