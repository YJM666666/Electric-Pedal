#ifndef BOOT_BOOT_EXTFLASH_H
#define BOOT_BOOT_EXTFLASH_H

/*
 * 文件: boot/boot_extflash.h
 * 描述: bootloader 用的外部 W25 SPI Flash 只读接口。
 * 责任: 启动阶段把 ota_service 写入的镜像从外部 W25 读出来, 拷到内部 Flash。
 *      不复用 ota_service.c, 避免 bootloader 工程引入应用的依赖链;
 *      也不写外部 Flash, bootloader 只读不写。
 */

#include <stdint.h>
#include "project_bool.h"

void boot_extflash_init(void);

bool boot_extflash_read(uint32_t addr, uint8_t *data, uint32_t len);

#endif /* BOOT_BOOT_EXTFLASH_H */
