﻿#include "boot_info.h"
#include "boot_crc32.h"
#include "bsp_i2c.h"
#include <string.h>

/*
 * boot_info 放在 EEPROM 高地址保留区。
 * EEPROM 0~439 用作参数镜像，440~479 用作 boot_info，480~511 用作掉电恢复记录。
 */
#define BOOT_INFO_EEPROM_ADDR        440U
#define BOOT_INFO_PAYLOAD_LEN        ((uint32_t)(sizeof(boot_info_t) - sizeof(uint32_t)))

void boot_info_set_default(boot_info_t *info)
{
    if (info == 0) {
        return;
    }

    (void)memset(info, 0, sizeof(*info));
    info->magic = BOOT_INFO_MAGIC;
    info->version = BOOT_INFO_VERSION;
    info->active_slot = (uint8_t)BOOT_SLOT_A;
    info->pending_slot = (uint8_t)BOOT_SLOT_INVALID;
    info->pending_state = (uint8_t)BOOT_PENDING_NONE;
    info->last_error = 0U;
}

bool boot_info_load(boot_info_t *info)
{
    boot_info_t raw;
    uint32_t crc;

    if (info == 0) {
        return false;
    }

    if (!bsp_i2c_eeprom_read((uint16_t)BOOT_INFO_EEPROM_ADDR,
                             (uint8_t *)&raw, sizeof(raw))) {
        boot_info_set_default(info);
        return false;
    }

    if ((raw.magic != BOOT_INFO_MAGIC) || (raw.version != BOOT_INFO_VERSION)) {
        boot_info_set_default(info);
        return false;
    }

    crc = boot_crc32_calc((const uint8_t *)&raw, BOOT_INFO_PAYLOAD_LEN);
    if (crc != raw.crc32) {
        boot_info_set_default(info);
        return false;
    }

    *info = raw;
    return true;
}

bool boot_info_store(const boot_info_t *info)
{
    boot_info_t blob;

    if (info == 0) {
        return false;
    }

    blob = *info;
    blob.magic = BOOT_INFO_MAGIC;
    blob.version = BOOT_INFO_VERSION;
    blob.crc32 = boot_crc32_calc((const uint8_t *)&blob, BOOT_INFO_PAYLOAD_LEN);

    return bsp_i2c_eeprom_write((uint16_t)BOOT_INFO_EEPROM_ADDR,
                                (const uint8_t *)&blob, sizeof(blob));
}

bool boot_info_request_pending(uint8_t target_slot,
                               uint32_t size,
                               uint32_t crc32,
                               uint32_t version)
{
    boot_info_t info;

    if ((target_slot != (uint8_t)BOOT_SLOT_A) &&
        (target_slot != (uint8_t)BOOT_SLOT_B)) {
        return false;
    }

    (void)boot_info_load(&info);
    info.pending_slot = target_slot;
    info.pending_state = (uint8_t)BOOT_PENDING_PROMOTE;
    info.pending_size = size;
    info.pending_crc32 = crc32;
    info.pending_version = version;
    info.last_error = 0U;
    return boot_info_store(&info);
}

bool boot_info_mark_healthy(void)
{
    boot_info_t info;

    if (!boot_info_load(&info)) {
        return false;
    }
    if ((info.boot_count == 0U) && (info.boot_fail_count == 0U)) {
        return true;
    }
    info.boot_count = 0U;
    info.boot_fail_count = 0U;
    return boot_info_store(&info);
}

