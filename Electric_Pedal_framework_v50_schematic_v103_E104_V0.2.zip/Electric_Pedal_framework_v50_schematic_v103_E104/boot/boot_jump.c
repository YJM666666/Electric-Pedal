#include "boot_jump.h"
#include "boot_image.h"
#include "bsp_build.h"
#include "bsp_board.h"

#if BSP_PLATFORM_GD32
#if BSP_APP_IS_U17
#include "gd32f1x0.h"
#else
#include "gd32c10x.h"
#endif
#endif

/*
 * 应用镜像布局: [boot_image_header_t][app payload].
 * payload 起点即应用的中断向量表; vectors[0]=SP, vectors[1]=Reset_Handler.
 */

void boot_jump_to_app(uint32_t app_base_addr)
{
    uint32_t app_vectors;
    uint32_t app_sp;
    uint32_t app_reset;
    void (*app_entry)(void);

    app_vectors = app_base_addr + BOOT_IMAGE_HEADER_LEN;
    app_sp = *((volatile uint32_t *)(app_vectors + 0U));
    app_reset = *((volatile uint32_t *)(app_vectors + 4U));

#if BSP_PLATFORM_GD32
    /* 关闭所有可能在 bootloader 阶段打开的中断, 避免跳过去后立刻被打断 */
    __disable_irq();

    /* 复位主要外设时钟, 让 bootloader 留下的状态尽量干净 */
    RCU_AHBRST = 0xFFFFFFFFUL; RCU_AHBRST = 0x00000000UL;
    RCU_APB1RST = 0xFFFFFFFFUL; RCU_APB1RST = 0x00000000UL;
    RCU_APB2RST = 0xFFFFFFFFUL; RCU_APB2RST = 0x00000000UL;

    /* 重定位中断向量表到应用 */
    SCB->VTOR = app_vectors;

    __set_MSP(app_sp);
    __DSB();
    __ISB();
    __enable_irq();
#endif

    app_entry = (void (*)(void))app_reset;
    app_entry();

    /* 不应该到这里 */
    for (;;) {
    }
}
