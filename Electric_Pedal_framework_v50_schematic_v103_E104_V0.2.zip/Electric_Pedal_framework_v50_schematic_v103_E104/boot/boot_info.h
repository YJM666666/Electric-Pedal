﻿#ifndef BOOT_BOOT_INFO_H
#define BOOT_BOOT_INFO_H

/*
 * 文件: boot/boot_info.h
 * 描述: bootloader 与应用共享的启动信息块。
 * 责任: 记录当前活动槽位、OTA 待切换槽位、镜像校验值和启动健康计数。
 *
 * 存储位置: I2C EEPROM 440~479。
 * EEPROM 0~439 用作参数镜像，480~511 用作掉电恢复记录，三者互不重叠。
 */

#include <stdint.h>
#include "project_bool.h"
#include "flash_layout.h"

#define BOOT_INFO_MAGIC          0x424F4F31UL  /* 'BOO1' */
#define BOOT_INFO_VERSION        0x0001U

/*
 * Bootloader 瑙嗚鐨?pending 鍒囨崲鐘舵€佹満, 涓?ota_service 闃舵鐙珛銆?
 * - NONE       : 娌℃湁寰呭垏鎹㈤暅鍍?
 * - PROMOTE    : 搴旂敤宸叉牎楠岄€氳繃, 璇?bootloader 鍦ㄤ笅娆″惎鍔ㄦ椂鍒囨崲 active_slot
 * - PROMOTING  : bootloader 宸插紑濮嬪垏鎹?(鐢ㄤ簬鏂數鎭㈠鏃惰瘑鍒?"鍒囧埌涓€鍗? 鐨勬儏鍐?
 * - FAILED     : 鍒囨崲澶辫触, last_error 鍐欏叆鍘熷洜
 */
typedef enum
{
    BOOT_PENDING_NONE      = 0U,
    BOOT_PENDING_PROMOTE   = 1U,
    BOOT_PENDING_PROMOTING = 2U,
    BOOT_PENDING_FAILED    = 3U
} boot_pending_state_t;

typedef struct
{
    uint32_t magic;             /* BOOT_INFO_MAGIC */
    uint16_t version;           /* BOOT_INFO_VERSION */
    uint16_t reserved0;

    uint8_t  active_slot;       /* boot_slot_t: 褰撳墠姝ｅ湪鎵ц鐨勬Ы浣?*/
    uint8_t  pending_slot;      /* boot_slot_t: 鍒囨崲鐩爣; 0xFF=鏃?*/
    uint8_t  pending_state;     /* boot_pending_state_t */
    uint8_t  last_error;        /* 鏈€杩戜竴娆″垏鎹㈠け璐ュ師鍥? 涓庡崗璁?STATUS 鍏辩敤 */

    uint32_t pending_size;      /* 寰呭垏鎹㈤暅鍍忓瓧鑺傛暟 */
    uint32_t pending_crc32;     /* 寰呭垏鎹㈤暅鍍?CRC32 (涓庡崗璁?0xC3 涓€鑷? */
    uint32_t pending_version;   /* 寰呭垏鎹㈤暅鍍忕増鏈彿 */

    uint16_t boot_count;        /* 鑷笂娆″垏鎹互鏉ョ殑鍚姩娆℃暟, 鐢ㄤ簬鍥炴粴妫€娴?*/
    uint16_t boot_fail_count;   /* 鍚姩鍚庢湭纭鍋ュ悍鐨勬鏁?*/

    uint32_t reserved1[2];

    uint32_t crc32;             /* 瀵瑰墠闈㈡墍鏈夊瓧娈电殑 CRC32 */
} boot_info_t;

/* 璇诲彇 boot_info; 澶辫触鏃?*info 琚疆涓哄畨鍏ㄩ粯璁ゅ€煎苟杩斿洖 false銆?*/
bool boot_info_load(boot_info_t *info);

/* 鍐欏叆 boot_info; 鑷姩濉厖 magic / version / crc32銆?*/
bool boot_info_store(const boot_info_t *info);

/* 鎶?*info 閲嶇疆涓哄嚭鍘傞粯璁ゅ€?(active=A, pending=NONE)銆?*/
void boot_info_set_default(boot_info_t *info);

/*
 * 搴旂敤渚т究鎹锋帴鍙? ota_service 鏍￠獙閫氳繃鍚庤皟鐢? 璁╀笅娆″惎鍔ㄨ烦鐩爣妲姐€?
 * 鍐呴儴璇?>鏀?>鍐? 澶辫触杩斿洖 false銆?
 */
bool boot_info_request_pending(uint8_t target_slot,
                               uint32_t size,
                               uint32_t crc32,
                               uint32_t version);

/* 搴旂敤鍚姩鍚庤皟鐢? 鎶?boot_count / boot_fail_count 娓呴浂, 琛ㄧず鏂板浐浠跺仴搴枫€?*/
bool boot_info_mark_healthy(void);

#endif /* BOOT_BOOT_INFO_H */

