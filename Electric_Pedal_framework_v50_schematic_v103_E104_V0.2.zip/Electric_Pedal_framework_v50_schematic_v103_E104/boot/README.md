# Bootloader & OTA 集成指南 (U12 双 Bank)

## 模块清单

```
boot/
  boot_info.{h,c}        EEPROM 启动信息块 (active_slot / pending_*)
  boot_crc32.{h,c}       共享 CRC32 (与协议 0xC3 image_crc32 对齐)
  boot_image.{h,c}       OTA 镜像头格式与校验
  boot_jump.{h,c}        跳应用 (VTOR / MSP / Reset_Handler)
  boot_extflash.{h,c}    bootloader 用的 W25 SPI Flash 只读接口
  boot_main_u12.c        U12 双 Bank bootloader 入口

bsp/
  bsp_iflash.{h,c}       内部 Flash 编程薄封装 (FMC unlock/erase/program)

config/
  flash_layout.h         U12 / U17 Flash 与 EEPROM 地址布局

service/
  ota_service.{h,c}      应用侧 0x1A / 0xC1~0xC5 状态机 (写外部 W25 SPI Flash)

tools/
  boot_image_pack.py     固件打包工具 (在 .bin 前面加 boot_image_header_t)

链接脚本:
  Electric_Pedal_U12_boot.sct   bootloader: 0x08000000, 16KB
  Electric_Pedal_U12_app.sct    应用:        0x08004040 起 (slot 内含镜像头)
```

## U12 存储布局

```
内部 Flash 128KB
0x08000000 ─┬─ Bootloader        (16KB)
0x08004000 ─┼─ App Slot A        (56KB)   <- 出厂烧录, active_slot=A
0x08012000 ─┼─ App Slot B        (56KB)   <- bootloader OTA 拷贝目的地
0x08020000 ─┘

外部 W25 SPI Flash
BSP_FLASH_OTA_META_ADDR  : ota_service 的 meta sector
BSP_FLASH_OTA_IMAGE_ADDR : 应用 0xC2 写入的镜像 (含 boot_image_header_t)

EEPROM
448~?  : boot_info_t   (与 power_recovery@480 不重叠)
480~511: drv_nvm_power_recovery (已存在, 不动)
```

## OTA + Bootloader 协作流程

```
APP                 应用 (ota_service)               外部 W25       Bootloader (next boot)
 │                       │                               │                │
 │ 0xC1 begin            │                               │                │
 ├──────────────────────▶│ 擦 image 区, 写 meta=PREPARE  │                │
 │                       ├──────────────────────────────▶│                │
 │ 0xC2 write_block × N  │                               │                │
 ├──────────────────────▶│ 写 image, 维护 bitmap         │                │
 │                       ├──────────────────────────────▶│                │
 │ 0xC3 finish           │                               │                │
 ├──────────────────────▶│ 流式 CRC32, 写 meta=VERIFY    │                │
 │                       ├──────────────────────────────▶│                │
 │ 0xC4 reboot           │                               │                │
 ├──────────────────────▶│ 写 meta=SWITCH                │                │
 │                       │ ★ boot_info_request_pending() │                │
 │                       │   → EEPROM: pending_slot,     │                │
 │                       │              pending_size,    │                │
 │                       │              pending_crc32,   │                │
 │                       │              pending_state=PROMOTE             │
 │  ←-- 0xC4 ACK --------│                               │                │
 │                       │ ble_if 调 bsp_platform_system_reset()           │
 │                       │                                                │
 │                                                                        ▼
 │                                                              加载 boot_info
 │                                                              pending_state == PROMOTE
 │                                                                        │
 │                                                              copy_external_image_to_slot:
 │                                                                ① 擦内部 Flash slot_base
 │                                                                ② 256B 一段 W25 read
 │                                                                ③ FMC 写到内部 Flash
 │                                                                ④ 边写边累加 CRC32
 │                                                                ⑤ 与 pending_crc32 比对
 │                                                                        │
 │                                                              都通过 → active_slot=pending_slot
 │                                                                       boot_count=0
 │                                                                       pending_state=NONE
 │                                                                       boot_jump_to_app(slot)
 │                                                                        │
 │  ←-- 应用启动后 boot_info_mark_healthy() 清启动计数 ---------------------┘
```

## 关键时序与回滚

- bootloader 进 `promote_pending` 第一件事就把 `pending_state` 写成 `PROMOTING`,
  然后才动内部 Flash; 拷到一半掉电也能在下次启动识别 (PROMOTING 走同样路径)。
- bootloader 每次跳应用前 `boot_count++`; 应用进了主循环立即调
  `boot_info_mark_healthy()` 把计数清零。
- 若 `boot_count >= 3` 仍未被清零, 视为新固件无法稳定启动,
  bootloader 自动切回备份槽 (`rollback_if_needed`)。
- 应用 0xC5 查询能拿到的 `last_error` 字段是 `boot_info.last_error`,
  bootloader 拷贝/校验失败时会写入对应 STATUS (0x10/0x11/0x12)。

## 构建步骤

1. **新建 bootloader 工程** (Keil), 加入这些文件:
   ```
   boot/boot_main_u12.c
   boot/boot_info.c
   boot/boot_image.c
   boot/boot_crc32.c
   boot/boot_jump.c
   boot/boot_extflash.c
   bsp/bsp_iflash.c
   bsp/bsp_i2c.c
   bsp/bsp_spi.c
   bsp/bsp_platform.c
   bsp/bsp_wdg.c
   bsp/bsp_gpio.c (bsp_spi 选片用)
   startup_gd32c10x_ac6.c
   vendor/.../system_gd32c10x.c
   vendor/.../gd32c10x_fmc.c
   vendor/.../gd32c10x_spi.c
   vendor/.../gd32c10x_i2c.c
   vendor/.../gd32c10x_gpio.c
   vendor/.../gd32c10x_rcu.c
   ```
   链接脚本: `Electric_Pedal_U12_boot.sct`。
   工程预定义宏: `GD32C103, BSP_TARGET_GD32C103`, **不要**定义 `APP_ROLE_U17_SLAVE`,
   也**不要**包含应用层 (control/, service/, driver/)。

2. **应用工程** (`PowerStep_Controller_U12.uvprojx`) 把链接脚本切到
   `Electric_Pedal_U12_app.sct`, 把这些新文件加到工程:
   ```
   boot/boot_info.c
   boot/boot_image.c
   boot/boot_crc32.c
   bsp/bsp_iflash.c            (应用暂时用不到, 但 ota_service 不依赖它,
                                可不加; 留出来备 U17 路径)
   service/ota_service.c       (已有, 已经桥接了 boot_info)
   ```

3. **编译应用 → 打包**:
   ```
   python tools/boot_image_pack.py Objects/U12/Electric_Pedal_U12.bin \
       app_v1.0.0.bin --target u12 --version 1.0.0
   ```
   生成 `app_v1.0.0.bin` (前面带 64 字节 boot_image_header_t)。

4. **出厂烧录** (一次性):
   - bootloader.hex → 0x08000000
   - app_v1.0.0.bin  → 0x08004000
   - boot_info / OTA meta 区都留空 (CRC fail), 第一次启动会按默认值 (active=A)
     运行, 应用进入主循环后 `boot_info_mark_healthy()` 写一次完成初始化。

## OTA 升级实操 (上位机视角)

```
0xC1 begin(fw_size, fw_ver)         → 应用擦 W25 image 区
0xC2 write_block × N                → 应用顺序写 W25, 边写边记 bitmap
0xC3 finish(image_size, image_crc32, total_blocks)
                                    → 应用流式 CRC32 校验, 写 W25 meta=VERIFY
0xC4 reboot(0x01)                   → 应用写 boot_info pending=PROMOTE
                                       回完 ACK 后 ble_if 调 NVIC_SystemReset
                                    → bootloader 拷 W25→内部 Flash slot, 校验,
                                       切 active_slot, 跳新固件
0xC5 query progress                 → 任意时刻可查 stage / received_blocks /
                                       total_blocks / last_error
0x1A query status                   → 查 supported / upgrade_available / target_ver / stage
```

## 还没接通的事项

- **U17 路径**: 当前 bootloader / 双 Bank 只针对 U12 (128KB Flash)。U17 (64KB)
  装不下双 Bank, 后续要么单 Bank 直接覆盖、要么 ota_service 在 U17 上不允许;
  现阶段 `BSP_HAS_FLASH=0` 时 ota_service 自己会回报"不支持"。
- **bootloader 救援通道**: 内部 Flash 两槽都坏时停在 bootloader。后续可以在
  bootloader 内集成最小的 UART/CAN OTA 接收器, 复用本地 boot_info 流程。
