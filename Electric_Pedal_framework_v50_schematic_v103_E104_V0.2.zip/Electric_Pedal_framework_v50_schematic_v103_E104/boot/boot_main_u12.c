/* U12 (GD32C103) Bootloader */

#include "boot_info.h"
#include "boot_image.h"
#include "boot_jump.h"
#include "boot_crc32.h"
#include "boot_extflash.h"
#include "bsp_iflash.h"
#include "bsp_i2c.h"
#include "bsp_platform.h"
#include "bsp_wdg.h"
#include "bsp_board.h"
#include "flash_layout.h"

#define BOOT_HEALTH_FAIL_LIMIT     3U
#define BOOT_COPY_CHUNK_BYTES      256U
#define U12_SRAM_BASE              0x20000000UL
#define U12_SRAM_SIZE              0x00008000UL  /* 32KB */

/* OTA 镜像头部和 CRC 校验区大小；Keil 直接 Load AXF 时，镜像头区域保持擦除态，应用从 slot_base + 64 字节开始。 */
#define BOOT_ERR_NONE              0x00U
#define BOOT_ERR_PARAM             0x04U
#define BOOT_ERR_BLOCK_CRC         0x10U
#define BOOT_ERR_IMAGE_CRC         0x11U
#define BOOT_ERR_NO_SPACE          0x12U

static uint8_t s_copy_buf[BOOT_COPY_CHUNK_BYTES];

static bool boot_header_area_is_erased(const boot_image_header_t *hdr)
{
    const uint32_t *words = (const uint32_t *)hdr;
    uint32_t count = BOOT_IMAGE_HEADER_LEN / sizeof(uint32_t);
    uint32_t i;

    if (hdr == 0) {
        return false;
    }

    for (i = 0U; i < count; i++) {
        if (words[i] != 0xFFFFFFFFUL) {
            return false;
        }
    }

    return true;
}

static bool slot_app_vectors_are_valid(uint32_t slot_base)
{
    return boot_image_vectors_look_sane(slot_base,
                                        FL_U12_APP_A_SIZE,
                                        U12_SRAM_BASE, U12_SRAM_SIZE);
}

static bool slot_image_is_valid(boot_slot_t slot)
{
    uint32_t base;
    const boot_image_header_t *hdr;
    const uint8_t *payload;

    base = flash_layout_u12_slot_base(slot);
    hdr = (const boot_image_header_t *)base;

    if (!boot_image_header_is_valid(hdr)) {
        /*
         * Keil 调试或直接 Load AXF 时，应用从 0x08004040 开始下载，
         * 0x08004000 的 64 字节镜像头区域会保持擦除态。为了保留
         * 一键 Build + Load 的调试体验，只在镜像头全 FF 且应用向量表
         * 合法时接受 raw app。OTA 镜像仍然必须带合法 header 和 CRC。
         */
        if (boot_header_area_is_erased(hdr) && slot_app_vectors_are_valid(base)) {
            return true;
        }
        return false;
    }
    if (hdr->target_mcu != BOOT_IMAGE_TARGET_U12) {
        return false;
    }

    payload = (const uint8_t *)(base + BOOT_IMAGE_HEADER_LEN);
    if (!boot_image_payload_is_valid(payload, hdr->image_size, hdr->image_crc32)) {
        return false;
    }

    return slot_app_vectors_are_valid(base);
}
static bool copy_external_image_to_slot(boot_slot_t slot,
                                        uint32_t image_size,
                                        uint32_t expected_crc32)
{
    uint32_t slot_base = flash_layout_u12_slot_base(slot);
    uint32_t spi_addr = BSP_FLASH_OTA_IMAGE_ADDR;
    uint32_t remaining = image_size;
    uint32_t offset = 0U;
    uint32_t chunk;
    uint32_t crc_state = 0xFFFFFFFFUL;
    uint32_t final_crc;

    if (image_size == 0U) {
        return false;
    }
    if (image_size > FL_U12_APP_A_SIZE) {
        return false;
    }

    if (!bsp_iflash_erase_range(slot_base, image_size)) {
        return false;
    }

    while (remaining > 0U) {
        chunk = (remaining > BOOT_COPY_CHUNK_BYTES) ? BOOT_COPY_CHUNK_BYTES : remaining;

        if (!boot_extflash_read(spi_addr + offset, s_copy_buf, chunk)) {
            return false;
        }

        if (!bsp_iflash_program(slot_base + offset, s_copy_buf, chunk)) {
            return false;
        }

        crc_state = boot_crc32_update(crc_state, s_copy_buf, chunk);

        offset += chunk;
        remaining -= chunk;
        bsp_wdg_feed();
    }

    final_crc = boot_crc32_finalize(crc_state);
    if (final_crc != expected_crc32) {
        return false;
    }

    /* 镜像已经在 slot 中，后续的 slot_image_is_valid() 会再次验证 CRC 和向量表，这里直接返回成功。 */
    return true;
}

static void promote_pending(boot_info_t *info)
{
    boot_slot_t pending = (boot_slot_t)info->pending_slot;

    if ((pending != BOOT_SLOT_A) && (pending != BOOT_SLOT_B)) {
        return;
    }
    if ((info->pending_size == 0U) || (info->pending_size > FL_U12_APP_A_SIZE)) {
        info->pending_state = (uint8_t)BOOT_PENDING_FAILED;
        info->last_error = BOOT_ERR_NO_SPACE;
        info->pending_slot = (uint8_t)BOOT_SLOT_INVALID;
        (void)boot_info_store(info);
        return;
    }

    /* OTA 镜像到应用区 */
    info->pending_state = (uint8_t)BOOT_PENDING_PROMOTING;
    (void)boot_info_store(info);

    if (!copy_external_image_to_slot(pending, info->pending_size, info->pending_crc32)) {
        info->pending_state = (uint8_t)BOOT_PENDING_FAILED;
        info->last_error = BOOT_ERR_IMAGE_CRC;
        info->pending_slot = (uint8_t)BOOT_SLOT_INVALID;
        (void)boot_info_store(info);
        return;
    }

    if (!slot_image_is_valid(pending)) {
        info->pending_state = (uint8_t)BOOT_PENDING_FAILED;
        info->last_error = BOOT_ERR_IMAGE_CRC;
        info->pending_slot = (uint8_t)BOOT_SLOT_INVALID;
        (void)boot_info_store(info);
        return;
    }

    info->active_slot = (uint8_t)pending;
    info->pending_slot = (uint8_t)BOOT_SLOT_INVALID;
    info->pending_state = (uint8_t)BOOT_PENDING_NONE;
    info->last_error = BOOT_ERR_NONE;
    info->boot_count = 0U;
    info->boot_fail_count = 0U;
    (void)boot_info_store(info);
}

static void rollback_if_needed(boot_info_t *info)
{
    boot_slot_t active = (boot_slot_t)info->active_slot;
    boot_slot_t backup = (active == BOOT_SLOT_A) ? BOOT_SLOT_B : BOOT_SLOT_A;

    if (info->boot_fail_count < BOOT_HEALTH_FAIL_LIMIT) {
        return;
    }

    if (!slot_image_is_valid(backup)) {
        return;
    }

    info->active_slot = (uint8_t)backup;
    info->pending_state = (uint8_t)BOOT_PENDING_FAILED;
    info->last_error = BOOT_ERR_IMAGE_CRC;
    info->boot_count = 0U;
    info->boot_fail_count = 0U;
    (void)boot_info_store(info);
}

int main(void)
{
    boot_info_t info;
    boot_slot_t active;
    uint32_t base;

    bsp_platform_init();
    bsp_wdg_init();
    bsp_i2c_init();
    bsp_iflash_init();
    boot_extflash_init();

    (void)boot_info_load(&info);

    if ((info.pending_state == (uint8_t)BOOT_PENDING_PROMOTE) ||
        (info.pending_state == (uint8_t)BOOT_PENDING_PROMOTING)) {
        promote_pending(&info);
    }

    rollback_if_needed(&info);

    active = (boot_slot_t)info.active_slot;
    if ((active != BOOT_SLOT_A) && (active != BOOT_SLOT_B)) {
        active = BOOT_SLOT_A;
        info.active_slot = (uint8_t)active;
    }

    if (!slot_image_is_valid(active)) {
        boot_slot_t backup = (active == BOOT_SLOT_A) ? BOOT_SLOT_B : BOOT_SLOT_A;
        if (slot_image_is_valid(backup)) {
            info.active_slot = (uint8_t)backup;
            info.pending_state = (uint8_t)BOOT_PENDING_FAILED;
            info.last_error = BOOT_ERR_IMAGE_CRC;
            (void)boot_info_store(&info);
            active = backup;
        } else {
            /*
             * 娌℃湁浠讳綍鍙敤闀滃儚, 鍋滃湪 bootloader. 鐪熷疄宸ョ▼搴斿湪姝ゅ惎鍔?OTA 鏁戞彺
             * 閫氶亾 (UART / CAN / BLE 浠婚€?, 澶嶇敤搴旂敤灞傜幇鎴愮殑鍗忚甯цВ鏋愪笌
             * 0xC1~0xC4 娴佺▼. 褰撳墠妗嗘灦浠呬繚璇佸畨鍏ㄥ仠鏈?
             */
            for (;;) {
                bsp_wdg_feed();
            }
        }
    }

    /* 杩涘叆搴旂敤鍓嶇疮鍔犲惎鍔ㄨ鏁? 搴旂敤绋冲畾鍚庝細鑷娓呴浂 */
    if (info.boot_count < 0xFFFFU) {
        info.boot_count++;
    }
    if (info.boot_count >= BOOT_HEALTH_FAIL_LIMIT) {
        info.boot_fail_count = info.boot_count;
    }
    (void)boot_info_store(&info);

    base = flash_layout_u12_slot_base(active);
    boot_jump_to_app(base);

    /* 涓嶄細鍒拌繖閲?*/
    return 0;
}

