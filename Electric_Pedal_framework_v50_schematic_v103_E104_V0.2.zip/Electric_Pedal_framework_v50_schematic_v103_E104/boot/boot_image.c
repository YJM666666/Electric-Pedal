#include "boot_image.h"
#include "boot_crc32.h"

#define BOOT_IMAGE_HEADER_PAYLOAD_LEN \
    ((uint32_t)(sizeof(boot_image_header_t) - sizeof(uint32_t)))

bool boot_image_header_is_valid(const boot_image_header_t *hdr)
{
    uint32_t crc;

    if (hdr == 0) {
        return false;
    }

    if ((hdr->magic != BOOT_IMAGE_MAGIC) ||
        (hdr->version != BOOT_IMAGE_VERSION)) {
        return false;
    }

    if ((hdr->image_size == 0U) ||
        (hdr->image_size > FL_U12_APP_MAX_SIZE)) {
        return false;
    }

    crc = boot_crc32_calc((const uint8_t *)hdr, BOOT_IMAGE_HEADER_PAYLOAD_LEN);
    return (crc == hdr->header_crc32);
}

bool boot_image_payload_is_valid(const uint8_t *payload,
                                 uint32_t payload_len,
                                 uint32_t expected_crc32)
{
    uint32_t crc;

    if ((payload == 0) || (payload_len == 0U)) {
        return false;
    }

    crc = boot_crc32_calc(payload, payload_len);
    return (crc == expected_crc32);
}

bool boot_image_vectors_look_sane(uint32_t slot_base,
                                  uint32_t slot_size,
                                  uint32_t sram_base,
                                  uint32_t sram_size)
{
    uint32_t sp;
    uint32_t reset_handler;
    uint32_t slot_end;

    /* payload 紧跟在镜像头之后，向量表的前 8 字节即应用启动 SP / Reset_Handler */
    const uint32_t *vectors = (const uint32_t *)(slot_base + BOOT_IMAGE_HEADER_LEN);

    sp = vectors[0];
    reset_handler = vectors[1];

    if ((sp < sram_base) || (sp > (sram_base + sram_size))) {
        return false;
    }

    slot_end = slot_base + slot_size;
    if ((reset_handler < slot_base) || (reset_handler >= slot_end)) {
        return false;
    }

    /* Cortex-M 函数地址 LSB 必须为 1 (Thumb) */
    if ((reset_handler & 0x1UL) == 0U) {
        return false;
    }

    return true;
}
