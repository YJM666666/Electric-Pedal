#ifndef BOOT_BOOT_JUMP_H
#define BOOT_BOOT_JUMP_H

/*
 * 文件: boot/boot_jump.h
 * 描述: 从 bootloader 跳到应用的最后一步, 重定位 VTOR / MSP / Reset_Handler。
 * 责任: 仅在 bootloader 工程中链接; 应用工程不应该 include。
 */

#include <stdint.h>

void boot_jump_to_app(uint32_t app_base_addr) __attribute__((noreturn));

#endif /* BOOT_BOOT_JUMP_H */
