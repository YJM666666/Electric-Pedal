#include "bsp_build.h"
#if !defined(APP_ROLE_U17_SLAVE)
#include "event.h"
#include "sys_sm.h"
#include "policy.h"
#include "sw_timer.h"
#include "fault.h"
#include "drv_motor.h"
#include "drv_light.h"
#include "drv_nvm.h"
#include "param.h"
#include "current_guard.h"
#include "can_if.h"
#include "ble_if.h"
#include "u17_link.h"
#include "scheduler.h"
#include "bsp_gpio.h"
#include "bsp_motor_hall.h"
#include "bsp_adc.h"
#include "bsp_uart.h"
#include "bsp_can.h"
#include "bsp_wdg.h"
#include "bsp_timer.h"
#include "bsp_platform.h"
#include "ota_service.h"
#include "boot_info.h"
#if BSP_PLATFORM_GD32
#include "gd32c10x.h"
#endif

volatile uint32_t g_u12_main_loop_count = 0U;
/*
 * HardFault ���Լ�¼��
 * �ϰ����ʱ�����������쳣��Keil Watch ��ȡ��Щ������
 * ���Կ����쳣ԭ����쳣����ʱ�� PC/LR��
 */
volatile uint32_t g_fault_active = 0U;
volatile uint32_t g_fault_lr = 0U;
volatile uint32_t g_fault_stacked_r0 = 0U;
volatile uint32_t g_fault_stacked_r1 = 0U;
volatile uint32_t g_fault_stacked_r2 = 0U;
volatile uint32_t g_fault_stacked_r3 = 0U;
volatile uint32_t g_fault_stacked_r12 = 0U;
volatile uint32_t g_fault_stacked_lr = 0U;
volatile uint32_t g_fault_stacked_pc = 0U;
volatile uint32_t g_fault_stacked_xpsr = 0U;
volatile uint32_t g_fault_cfsr = 0U;
volatile uint32_t g_fault_hfsr = 0U;
volatile uint32_t g_fault_dfsr = 0U;
volatile uint32_t g_fault_afsr = 0U;
volatile uint32_t g_fault_mmfar = 0U;
volatile uint32_t g_fault_bfar = 0U;

void hardfault_capture(uint32_t *stack, uint32_t lr)
{
    g_fault_active = 1U;
    g_fault_lr = lr;
    if (stack != 0) {
        g_fault_stacked_r0 = stack[0];
        g_fault_stacked_r1 = stack[1];
        g_fault_stacked_r2 = stack[2];
        g_fault_stacked_r3 = stack[3];
        g_fault_stacked_r12 = stack[4];
        g_fault_stacked_lr = stack[5];
        g_fault_stacked_pc = stack[6];
        g_fault_stacked_xpsr = stack[7];
    }
    g_fault_cfsr = SCB->CFSR;
    g_fault_hfsr = SCB->HFSR;
    g_fault_dfsr = SCB->DFSR;
    g_fault_afsr = SCB->AFSR;
    g_fault_mmfar = SCB->MMFAR;
    g_fault_bfar = SCB->BFAR;

    while (1) {
    }
}

__attribute__((naked)) void HardFault_Handler(void)
{
    __asm volatile(
        "tst lr, #4\n"
        "ite eq\n"
        "mrseq r0, msp\n"
        "mrsne r0, psp\n"
        "mov r1, lr\n"
        "b hardfault_capture\n"
    );
}

/*
 * main.c (U12 / 主控)
 * ---------------------------------------------------------------
 * 这个文件只在“主控目标”里编译：U12_Brushed_Master�? *
 * 你可以把它理解成整机主循环入口：
 * 1. 初始化所有基础驱动和业务模块�? * 2. 发�?EV_BOOT，通知状态机开始工作�? * 3. �?while(1) 里不断做三件事：
 *    - 轮询外设输入（BLE / U17链路 / CAN�? *    - 消费事件队列（tick、故障、业务事件）
 *    - 喂狗
 *
 * 当前职责划分（按最新原理图�? * - U12：原有刷电机主控、参�?NVM、系统状态机、策略层
 * - U17：灯光、语音播放、以及可选外挂无刷接口的执行�? */

/*
 * 按顺序初始化所有模块�? * 顺序尽量不要随意打乱�? * - event/sw_timer 要最先起来，因为后续模块可能依赖事件和时间基�? * - platform/gpio/adc/uart/can/wdg/timer 属于 BSP �? * - fault/param/current_guard/drv_xxx 属于服务和驱动层
 * - sys_sm/policy 最后初始化，确保它们依赖的底层都已经可�? */
/*
 * 应用�?bootloader 跳过来时, 中断向量表已经被 bootloader 设到 slot A/B 的镜像头
 * 之后. 这里再次显式同步一�? 防止 SystemInit �?VTOR 改回 0x08000000.
 *
 * 应用镜像�?Flash 中的布局: [boot_image_header_t][vectors][code]
 * 因此向量表起�?= slot_base + BOOT_IMAGE_HEADER_LEN.
 * Slot A = 0x08004000, vectors = 0x08004040 (假设 header 长度 64)�? * 我们用链接器符号 Image$$ER_IROM1$$Base 拿到真实加载基址, 自动适应 A/B 槽�? */
extern uint32_t Image$$ER_IROM1$$Base;

static void relocate_vector_table(void)
{
#if BSP_PLATFORM_GD32
    uint32_t vectors = (uint32_t)&Image$$ER_IROM1$$Base;
    SCB->VTOR = vectors;
    __DSB();
    __ISB();
#endif
}

static void sys_init_all(void)
{
    event_init();
    sw_timer_init();

    bsp_platform_init(); 
    bsp_gpio_init();
    bsp_motor_hall_init();
    bsp_adc_init();
    bsp_uart_init();
    bsp_can_init();
    bsp_wdg_init();
    bsp_timer_init();

    fault_init();
    drv_nvm_init();
    param_init();
    current_guard_init();
    drv_motor_init();
    drv_light_init();
    can_if_init();
    ble_if_init();
    u17_link_init();
    sys_sm_init();
    policy_init();
    scheduler_init();
    ota_service_init();
}

/*
 * 上电后主动塞一�?BOOT 事件，让状态机完成“上电后的第一拍”�? * 这比在初始化函数里直接写业务逻辑更清晰，也便于以后扩展�? */
static void post_boot_event(void)
{
    event_t ev;

    ev.id = EV_BOOT;
    ev.source = EV_SRC_SYSTEM;
    ev.param_u32 = 0U;
    ev.param_ptr = 0;
    (void)event_push(&ev);
}

static bool has_pending_power_recovery(void)
{
    drv_nvm_power_recovery_t rec;

    /*
     * 正常启动不进入掉电恢复流程�?     * 只有 NVM 中存在“未完成动作”记录时，才投�?EV_POWER_RECOVERED�?     */
    if (!drv_nvm_read_power_recovery(&rec)) {
        return false;
    }

    return (rec.last_action != STEP_ACT_STOP) ? true : false;
}

static void post_power_recovered_event_if_needed(void)
{
    event_t ev;

    if (!has_pending_power_recovery()) {
        return;
    }

    ev.id = EV_POWER_RECOVERED;
    ev.source = EV_SRC_SYSTEM;
    ev.param_u32 = 0U;
    ev.param_ptr = 0;
    (void)event_push(&ev);
}

int main(void)
{
    relocate_vector_table();
    sys_init_all();
    scheduler_poll_inputs();
    post_boot_event();
    post_power_recovered_event_if_needed();

    /*
     * 标记当前应用启动健康. bootloader 在跳应用前已经把 boot_count �?1,
     * 应用进了主循环说明启动到这里没崩, 把计数清�? 防止下次启动被误回滚.
     * 真要�?应用功能可用"健康判定, 可以�?sys_sm �?SYS_NORMAL 时再调一�?
     */
    (void)boot_info_mark_healthy();

    while (1)
    {
        /*
         * 先轮询“会产生事件/状态变化”的外设�?         * 这里不直接做重逻辑，只负责把数据拿进来�?         */
        scheduler_poll_inputs();
        g_u12_main_loop_count++;

        /*
         * 统一在调度层里做�?         * 1) 服务维护与健康检�?         * 2) 系统状态机分发
         * 3) 策略层与踏板状态机分发
         */
        scheduler_run_all();

        bsp_wdg_feed();
    }

    /* 不会执行到此�?*/
    /* 返回 0; */
}

#endif /* !APP_ROLE_U17_SLAVE */




