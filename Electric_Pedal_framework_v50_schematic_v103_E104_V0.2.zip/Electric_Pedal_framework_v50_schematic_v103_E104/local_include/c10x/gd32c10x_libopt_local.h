#ifndef GD32C10X_LIBOPT_LOCAL_H
#define GD32C10X_LIBOPT_LOCAL_H

#include "RTE_Components_local.h"
#include "gd32c10x_adc.h"
#include "gd32c10x_bkp.h"
#include "gd32c10x_can.h"
#include "gd32c10x_crc.h"
#include "gd32c10x_ctc.h"
#include "gd32c10x_dac.h"
#include "gd32c10x_dbg.h"
#include "gd32c10x_dma.h"
#include "gd32c10x_exmc.h"
#include "gd32c10x_exti.h"
#include "gd32c10x_fmc.h"
#include "gd32c10x_fwdgt.h"
#include "gd32c10x_gpio.h"
#include "gd32c10x_i2c.h"
#include "gd32c10x_misc.h"
#include "gd32c10x_pmu.h"
#include "gd32c10x_rcu.h"
#include "gd32c10x_rtc.h"
#include "gd32c10x_spi.h"
#include "gd32c10x_timer.h"
#include "gd32c10x_usart.h"
#include "gd32c10x_wwdgt.h"

#endif
