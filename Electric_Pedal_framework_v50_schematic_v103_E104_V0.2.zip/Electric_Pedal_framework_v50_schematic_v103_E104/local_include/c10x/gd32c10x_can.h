/*!
    \file    gd32c10x_can.h
    \brief   definitions for the CAN
    
    \version 2026-01-30, V1.7.0, firmware for GD32C10x
*/

/*
    Copyright (c) 2026, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#ifndef GD32C10X_CAN_H
#define GD32C10X_CAN_H

#include "gd32c10x.h"

/* CAN definitions */
#define CAN0                               CAN_BASE                      /*!< CAN0 base address */
#define CAN1                               (CAN0 + 0x00000400U)          /*!< CAN1 base address */

/* registers definitions */
#define CAN_CTL(canx)                      REG32((canx) + 0x00U)         /*!< CAN control register */
#define CAN_STAT(canx)                     REG32((canx) + 0x04U)         /*!< CAN status register */
#define CAN_TSTAT(canx)                    REG32((canx) + 0x08U)         /*!< CAN transmit status register*/
#define CAN_RFIFO0(canx)                   REG32((canx) + 0x0CU)         /*!< CAN receive FIFO0 register */
#define CAN_RFIFO1(canx)                   REG32((canx) + 0x10U)         /*!< CAN receive FIFO1 register */
#define CAN_INTEN(canx)                    REG32((canx) + 0x14U)         /*!< CAN interrupt enable register */
#define CAN_ERR(canx)                      REG32((canx) + 0x18U)         /*!< CAN error register */
#define CAN_BT(canx)                       REG32((canx) + 0x1CU)         /*!< CAN bit timing register */
#define CAN_FDCTL(canx)                    REG32((canx) + 0x20U)         /*!< CAN FD control register */
#define CAN_FDSTAT(canx)                   REG32((canx) + 0x24U)         /*!< CAN FD status register */
#define CAN_FDTDC(canx)                    REG32((canx) + 0x28U)         /*!< CAN FD transmitter delay compensation register */
#define CAN_DBT(canx)                      REG32((canx) + 0x2CU)         /*!< CAN date bit timing register */
#define CAN_TMI0(canx)                     REG32((canx) + 0x180U)        /*!< CAN transmit mailbox0 identifier register */
#define CAN_TMP0(canx)                     REG32((canx) + 0x184U)        /*!< CAN transmit mailbox0 property register */
#define CAN_TMDATA00(canx)                 REG32((canx) + 0x188U)        /*!< CAN transmit mailbox0 data0 register */
#define CAN_TMDATA10(canx)                 REG32((canx) + 0x18CU)        /*!< CAN transmit mailbox0 data1 register */
#define CAN_TMI1(canx)                     REG32((canx) + 0x190U)        /*!< CAN transmit mailbox1 identifier register */
#define CAN_TMP1(canx)                     REG32((canx) + 0x194U)        /*!< CAN transmit mailbox1 property register */
#define CAN_TMDATA01(canx)                 REG32((canx) + 0x198U)        /*!< CAN transmit mailbox1 data0 register */
#define CAN_TMDATA11(canx)                 REG32((canx) + 0x19CU)        /*!< CAN transmit mailbox1 data1 register */
#define CAN_TMI2(canx)                     REG32((canx) + 0x1A0U)        /*!< CAN transmit mailbox2 identifier register */
#define CAN_TMP2(canx)                     REG32((canx) + 0x1A4U)        /*!< CAN transmit mailbox2 property register */
#define CAN_TMDATA02(canx)                 REG32((canx) + 0x1A8U)        /*!< CAN transmit mailbox2 data0 register */
#define CAN_TMDATA12(canx)                 REG32((canx) + 0x1ACU)        /*!< CAN transmit mailbox2 data1 register */
#define CAN_RFIFOMI0(canx)                 REG32((canx) + 0x1B0U)        /*!< CAN receive FIFO0 mailbox identifier register */
#define CAN_RFIFOMP0(canx)                 REG32((canx) + 0x1B4U)        /*!< CAN receive FIFO0 mailbox property register */
#define CAN_RFIFOMDATA00(canx)             REG32((canx) + 0x1B8U)        /*!< CAN receive FIFO0 mailbox data0 register */
#define CAN_RFIFOMDATA10(canx)             REG32((canx) + 0x1BCU)        /*!< CAN receive FIFO0 mailbox data1 register */
#define CAN_RFIFOMI1(canx)                 REG32((canx) + 0x1C0U)        /*!< CAN receive FIFO1 mailbox identifier register */
#define CAN_RFIFOMP1(canx)                 REG32((canx) + 0x1C4U)        /*!< CAN receive FIFO1 mailbox property register */
#define CAN_RFIFOMDATA01(canx)             REG32((canx) + 0x1C8U)        /*!< CAN receive FIFO1 mailbox data0 register */
#define CAN_RFIFOMDATA11(canx)             REG32((canx) + 0x1CCU)        /*!< CAN receive FIFO1 mailbox data1 register */
#define CAN_FCTL(canx)                     REG32((canx) + 0x200U)        /*!< CAN filter control register */
#define CAN_FMCFG(canx)                    REG32((canx) + 0x204U)        /*!< CAN filter mode register */
#define CAN_FSCFG(canx)                    REG32((canx) + 0x20CU)        /*!< CAN filter scale register */
#define CAN_FAFIFO(canx)                   REG32((canx) + 0x214U)        /*!< CAN filter associated FIFO register */
#define CAN_FW(canx)                       REG32((canx) + 0x21CU)        /*!< CAN filter working register */
#define CAN_F0DATA0(canx)                  REG32((canx) + 0x240U)        /*!< CAN filter 0 data 0 register */
#define CAN_F1DATA0(canx)                  REG32((canx) + 0x248U)        /*!< CAN filter 1 data 0 register */
#define CAN_F2DATA0(canx)                  REG32((canx) + 0x250U)        /*!< CAN filter 2 data 0 register */
#define CAN_F3DATA0(canx)                  REG32((canx) + 0x258U)        /*!< CAN filter 3 data 0 register */
#define CAN_F4DATA0(canx)                  REG32((canx) + 0x260U)        /*!< CAN filter 4 data 0 register */
#define CAN_F5DATA0(canx)                  REG32((canx) + 0x268U)        /*!< CAN filter 5 data 0 register */
#define CAN_F6DATA0(canx)                  REG32((canx) + 0x270U)        /*!< CAN filter 6 data 0 register */
#define CAN_F7DATA0(canx)                  REG32((canx) + 0x278U)        /*!< CAN filter 7 data 0 register */
#define CAN_F8DATA0(canx)                  REG32((canx) + 0x280U)        /*!< CAN filter 8 data 0 register */
#define CAN_F9DATA0(canx)                  REG32((canx) + 0x288U)        /*!< CAN filter 9 data 0 register */
#define CAN_F10DATA0(canx)                 REG32((canx) + 0x290U)        /*!< CAN filter 10 data 0 register */
#define CAN_F11DATA0(canx)                 REG32((canx) + 0x298U)        /*!< CAN filter 11 data 0 register */
#define CAN_F12DATA0(canx)                 REG32((canx) + 0x2A0U)        /*!< CAN filter 12 data 0 register */
#define CAN_F13DATA0(canx)                 REG32((canx) + 0x2A8U)        /*!< CAN filter 13 data 0 register */
#define CAN_F14DATA0(canx)                 REG32((canx) + 0x2B0U)        /*!< CAN filter 14 data 0 register */
#define CAN_F15DATA0(canx)                 REG32((canx) + 0x2B8U)        /*!< CAN filter 15 data 0 register */
#define CAN_F16DATA0(canx)                 REG32((canx) + 0x2C0U)        /*!< CAN filter 16 data 0 register */
#define CAN_F17DATA0(canx)                 REG32((canx) + 0x2C8U)        /*!< CAN filter 17 data 0 register */
#define CAN_F18DATA0(canx)                 REG32((canx) + 0x2D0U)        /*!< CAN filter 18 data 0 register */
#define CAN_F19DATA0(canx)                 REG32((canx) + 0x2D8U)        /*!< CAN filter 19 data 0 register */
#define CAN_F20DATA0(canx)                 REG32((canx) + 0x2E0U)        /*!< CAN filter 20 data 0 register */
#define CAN_F21DATA0(canx)                 REG32((canx) + 0x2E8U)        /*!< CAN filter 21 data 0 register */
#define CAN_F22DATA0(canx)                 REG32((canx) + 0x2F0U)        /*!< CAN filter 22 data 0 register */
#define CAN_F23DATA0(canx)                 REG32((canx) + 0x2F8U)        /*!< CAN filter 23 data 0 register */
#define CAN_F24DATA0(canx)                 REG32((canx) + 0x300U)        /*!< CAN filter 24 data 0 register */
#define CAN_F25DATA0(canx)                 REG32((canx) + 0x308U)        /*!< CAN filter 25 data 0 register */
#define CAN_F26DATA0(canx)                 REG32((canx) + 0x310U)        /*!< CAN filter 26 data 0 register */
#define CAN_F27DATA0(canx)                 REG32((canx) + 0x318U)        /*!< CAN filter 27 data 0 register */
#define CAN_F0DATA1(canx)                  REG32((canx) + 0x244U)        /*!< CAN filter 0 data 1 register */
#define CAN_F1DATA1(canx)                  REG32((canx) + 0x24CU)        /*!< CAN filter 1 data 1 register */
#define CAN_F2DATA1(canx)                  REG32((canx) + 0x254U)        /*!< CAN filter 2 data 1 register */
#define CAN_F3DATA1(canx)                  REG32((canx) + 0x25CU)        /*!< CAN filter 3 data 1 register */
#define CAN_F4DATA1(canx)                  REG32((canx) + 0x264U)        /*!< CAN filter 4 data 1 register */
#define CAN_F5DATA1(canx)                  REG32((canx) + 0x26CU)        /*!< CAN filter 5 data 1 register */
#define CAN_F6DATA1(canx)                  REG32((canx) + 0x274U)        /*!< CAN filter 6 data 1 register */
#define CAN_F7DATA1(canx)                  REG32((canx) + 0x27CU)        /*!< CAN filter 7 data 1 register */
#define CAN_F8DATA1(canx)                  REG32((canx) + 0x284U)        /*!< CAN filter 8 data 1 register */
#define CAN_F9DATA1(canx)                  REG32((canx) + 0x28CU)        /*!< CAN filter 9 data 1 register */
#define CAN_F10DATA1(canx)                 REG32((canx) + 0x294U)        /*!< CAN filter 10 data 1 register */
#define CAN_F11DATA1(canx)                 REG32((canx) + 0x29CU)        /*!< CAN filter 11 data 1 register */
#define CAN_F12DATA1(canx)                 REG32((canx) + 0x2A4U)        /*!< CAN filter 12 data 1 register */
#define CAN_F13DATA1(canx)                 REG32((canx) + 0x2ACU)        /*!< CAN filter 13 data 1 register */
#define CAN_F14DATA1(canx)                 REG32((canx) + 0x2B4U)        /*!< CAN filter 14 data 1 register */
#define CAN_F15DATA1(canx)                 REG32((canx) + 0x2BCU)        /*!< CAN filter 15 data 1 register */
#define CAN_F16DATA1(canx)                 REG32((canx) + 0x2C4U)        /*!< CAN filter 16 data 1 register */
#define CAN_F17DATA1(canx)                 REG32((canx) + 0x2CCU)        /*!< CAN filter 17 data 1 register */
#define CAN_F18DATA1(canx)                 REG32((canx) + 0x2D4U)        /*!< CAN filter 18 data 1 register */
#define CAN_F19DATA1(canx)                 REG32((canx) + 0x2DCU)        /*!< CAN filter 19 data 1 register */
#define CAN_F20DATA1(canx)                 REG32((canx) + 0x2E4U)        /*!< CAN filter 20 data 1 register */
#define CAN_F21DATA1(canx)                 REG32((canx) + 0x2ECU)        /*!< CAN filter 21 data 1 register */
#define CAN_F22DATA1(canx)                 REG32((canx) + 0x2F4U)        /*!< CAN filter 22 data 1 register */
#define CAN_F23DATA1(canx)                 REG32((canx) + 0x2FCU)        /*!< CAN filter 23 data 1 register */
#define CAN_F24DATA1(canx)                 REG32((canx) + 0x304U)        /*!< CAN filter 24 data 1 register */
#define CAN_F25DATA1(canx)                 REG32((canx) + 0x30CU)        /*!< CAN filter 25 data 1 register */
#define CAN_F26DATA1(canx)                 REG32((canx) + 0x314U)        /*!< CAN filter 26 data 1 register */
#define CAN_F27DATA1(canx)                 REG32((canx) + 0x31CU)        /*!< CAN filter 27 data 1 register */

/* CAN transmit mailbox bank */
#define CAN_TMI(canx, bank)                REG32((canx) + 0x180U + ((bank) * 0x10U))        /*!< CAN transmit mailbox identifier register */
#define CAN_TMP(canx, bank)                REG32((canx) + 0x184U + ((bank) * 0x10U))        /*!< CAN transmit mailbox property register */
#define CAN_TMDATA0(canx, bank)            REG32((canx) + 0x188U + ((bank) * 0x10U))        /*!< CAN transmit mailbox data0 register */
#define CAN_TMDATA1(canx, bank)            REG32((canx) + 0x18CU + ((bank) * 0x10U))        /*!< CAN transmit mailbox data1 register */

/* CAN filter bank */
#define CAN_FDATA0(canx, bank)             REG32((canx) + 0x240U + ((bank) * 0x8U) + 0x0U)  /*!< CAN filter data 0 register */
#define CAN_FDATA1(canx, bank)             REG32((canx) + 0x240U + ((bank) * 0x8U) + 0x4U)  /*!< CAN filter data 1 register */

/* CAN receive fifo mailbox bank */
#define CAN_RFIFOMI(canx, bank)            REG32((canx) + 0x1B0U + ((bank) * 0x10U))        /*!< CAN receive FIFO mailbox identifier register */
#define CAN_RFIFOMP(canx, bank)            REG32((canx) + 0x1B4U + ((bank) * 0x10U))        /*!< CAN receive FIFO mailbox property register */
#define CAN_RFIFOMDATA0(canx, bank)        REG32((canx) + 0x1B8U + ((bank) * 0x10U))        /*!< CAN receive FIFO mailbox data0 register */
#define CAN_RFIFOMDATA1(canx, bank)        REG32((canx) + 0x1BCU + ((bank) * 0x10U))        /*!< CAN receive FIFO mailbox data1 register */

/* bits definitions */
/* CAN_CTL */
#define CAN_CTL_IWMOD                      BIT(0)                       /*!< initial working mode */
#define CAN_CTL_SLPWMOD                    BIT(1)                       /*!< sleep working mode */
#define CAN_CTL_TFO                        BIT(2)                       /*!< transmit FIFO order */
#define CAN_CTL_RFOD                       BIT(3)                       /*!< receive FIFO overwrite disable */
#define CAN_CTL_ARD                        BIT(4)                       /*!< automatic retransmission disable */
#define CAN_CTL_AWU                        BIT(5)                       /*!< automatic wakeup */
#define CAN_CTL_ABOR                       BIT(6)                       /*!< automatic bus-off recovery */
#define CAN_CTL_TTC                        BIT(7)                       /*!< time triggered communication */
#define CAN_CTL_SWRST                      BIT(15)                      /*!< CAN software reset */
#define CAN_CTL_DFZ                        BIT(16)                      /*!< CAN debug freeze */

/* CAN_STAT */
#define CAN_STAT_IWS                       BIT(0)                       /*!< initial working state */
#define CAN_STAT_SLPWS                     BIT(1)                       /*!< sleep working state */
#define CAN_STAT_ERRIF                     BIT(2)                       /*!< error interrupt flag*/
#define CAN_STAT_WUIF                      BIT(3)                       /*!< status change interrupt flag of wakeup from sleep working mode */
#define CAN_STAT_SLPIF                     BIT(4)                       /*!< status change interrupt flag of sleep working mode entering */
#define CAN_STAT_TS                        BIT(8)                       /*!< transmitting state */
#define CAN_STAT_RS                        BIT(9)                       /*!< receiving state */
#define CAN_STAT_LASTRX                    BIT(10)                      /*!< last sample value of rx pin */
#define CAN_STAT_RXL                       BIT(11)                      /*!< CAN rx signal */

/* CAN_TSTAT */
#define CAN_TSTAT_MTF0                     BIT(0)                       /*!< mailbox0 transmit finished */
#define CAN_TSTAT_MTFNERR0                 BIT(1)                       /*!< mailbox0 transmit finished and no error */
#define CAN_TSTAT_MAL0                     BIT(2)                       /*!< mailbox0 arbitration lost */
#define CAN_TSTAT_MTE0                     BIT(3)                       /*!< mailbox0 transmit error */
#define CAN_TSTAT_MST0                     BIT(7)                       /*!< mailbox0 stop transmitting */
#define CAN_TSTAT_MTF1                     BIT(8)                       /*!< mailbox1 transmit finished */
#define CAN_TSTAT_MTFNERR1                 BIT(9)                       /*!< mailbox1 transmit finished and no error */
#define CAN_TSTAT_MAL1                     BIT(10)                      /*!< mailbox1 arbitration lost */
#define CAN_TSTAT_MTE1                     BIT(11)                      /*!< mailbox1 transmit error */
#define CAN_TSTAT_MST1                     BIT(15)                      /*!< mailbox1 stop transmitting */
#define CAN_TSTAT_MTF2                     BIT(16)                      /*!< mailbox2 transmit finished */
#define CAN_TSTAT_MTFNERR2                 BIT(17)                      /*!< mailbox2 transmit finished and no error */
#define CAN_TSTAT_MAL2                     BIT(18)                      /*!< mailbox2 arbitration lost */
#define CAN_TSTAT_MTE2                     BIT(19)                      /*!< mailbox2 transmit error */
#define CAN_TSTAT_MST2                     BIT(23)                      /*!< mailbox2 stop transmitting */
#define CAN_TSTAT_NUM                      BITS(24,25)                  /*!< mailbox number */
#define CAN_TSTAT_TME0                     BIT(26)                      /*!< transmit mailbox0 empty */
#define CAN_TSTAT_TME1                     BIT(27)                      /*!< transmit mailbox1 empty */
#define CAN_TSTAT_TME2                     BIT(28)                      /*!< transmit mailbox2 empty */
#define CAN_TSTAT_TMLS0                    BIT(29)                      /*!< last sending priority flag for mailbox0 */
#define CAN_TSTAT_TMLS1                    BIT(30)                      /*!< last sending priority flag for mailbox1 */
#define CAN_TSTAT_TMLS2                    BIT(31)                      /*!< last sending priority flag for mailbox2 */

/* CAN_RFIFO0 */
#define CAN_RFIFO0_RFL0                    BITS(0,1)                    /*!< receive FIFO0 length */
#define CAN_RFIFO0_RFF0                    BIT(3)                       /*!< receive FIFO0 full */
#define CAN_RFIFO0_RFO0                    BIT(4)                       /*!< receive FIFO0 overfull */
#define CAN_RFIFO0_RFD0                    BIT(5)                       /*!< receive FIFO0 dequeue */
#ifdef GD32C103XXA
#define CAN_RFIFO0_RFOVRN0                 BIT(8)                       /*!< receive FIFO0 overrun */
#endif /* GD32C103XXA */

/* CAN_RFIFO1 */
#define CAN_RFIFO1_RFL1                    BITS(0,1)                    /*!< receive FIFO1 length */
#define CAN_RFIFO1_RFF1                    BIT(3)                       /*!< receive FIFO1 full */
#define CAN_RFIFO1_RFO1                    BIT(4)                       /*!< receive FIFO1 overfull */
#define CAN_RFIFO1_RFD1                    BIT(5)                       /*!< receive FIFO1 dequeue */
#ifdef GD32C103XXA
#define CAN_RFIFO1_RFOVRN1                 BIT(8)                       /*!< receive FIFO1 overrun */
#endif /* GD32C103XXA */

/* CAN_INTEN */
#define CAN_INTEN_TMEIE                    BIT(0)                       /*!< transmit mailbox empty interrupt enable */
#define CAN_INTEN_RFNEIE0                  BIT(1)                       /*!< receive FIFO0 not empty interrupt enable */
#define CAN_INTEN_RFFIE0                   BIT(2)                       /*!< receive FIFO0 full interrupt enable */
#define CAN_INTEN_RFOIE0                   BIT(3)                       /*!< receive FIFO0 overfull interrupt enable */
#define CAN_INTEN_RFNEIE1                  BIT(4)                       /*!< receive FIFO1 not empty interrupt enable */
#define CAN_INTEN_RFFIE1                   BIT(5)                       /*!< receive FIFO1 full interrupt enable */
#define CAN_INTEN_RFOIE1                   BIT(6)                       /*!< receive FIFO1 overfull interrupt enable */
#define CAN_INTEN_WERRIE                   BIT(8)                       /*!< warning error interrupt enable */
#define CAN_INTEN_PERRIE                   BIT(9)                       /*!< passive error interrupt enable */
#define CAN_INTEN_BOIE                     BIT(10)                      /*!< bus-off interrupt enable */
#define CAN_INTEN_ERRNIE                   BIT(11)                      /*!< error number interrupt enable */
#define CAN_INTEN_ERRIE                    BIT(15)                      /*!< error interrupt enable */
#define CAN_INTEN_WIE                      BIT(16)                      /*!< wakeup interrupt enable */
#define CAN_INTEN_SLPWIE                   BIT(17)                      /*!< sleep working interrupt enable */

/* CAN_ERR */
#define CAN_ERR_WERR                       BIT(0)                       /*!< warning error */
#define CAN_ERR_PERR                       BIT(1)                       /*!< passive error */
#define CAN_ERR_BOERR                      BIT(2)                       /*!< bus-off error */
#define CAN_ERR_ERRN                       BITS(4,6)                    /*!< error number */
#define CAN_ERR_TECNT                      BITS(16,23)                  /*!< transmit error count */
#define CAN_ERR_RECNT                      BITS(24,31)                  /*!< receive error count */

/* CAN_BT */
#define CAN_BT_BAUDPSC                     BITS(0,9)                    /*!< baudrate prescaler */
#define CAN_BT_BS1_6_4                     BITS(10,12)                  /*!< bit segment 1 [6:4] */
#define CAN_BT_BS2_4_3                     BITS(13,14)                  /*!< bit segment 2 [4:3] */
#define CAN_BT_BS1_3_0                     BITS(16,19)                  /*!< bit segment 1 [3:0] */
#define CAN_BT_BS2_2_0                     BITS(20,22)                  /*!< bit segment 2 [2:0]*/
#define CAN_BT_SJW                         BITS(24,28)                  /*!< resynchronization jump width */
#define CAN_BT_LCMOD                       BIT(30)                      /*!< loopback communication mode */
#define CAN_BT_SCMOD                       BIT(31)                      /*!< silent communication mode */

/* CAN_FDCTL */
#define CAN_FDCTL_FDEN                     BIT(0)                       /*!< FD operation enable */
#define CAN_FDCTL_PRED                     BIT(2)                       /*!< protocol exception event detection disable */
#define CAN_FDCTL_NISO                     BIT(3)                       /*!< ISO/Bosch */
#define CAN_FDCTL_TDCEN                    BIT(4)                       /*!< transmitter delay compensation enable */
#define CAN_FDCTL_TDCMOD                   BIT(5)                       /*!< transmitter delay compensation mode */
#define CAN_FDCTL_ESIMOD                   BIT(6)                       /*!< error state indicator mode */

/* CAN_FDSTAT */
#define CAN_FDSTAT_TDCV                    BITS(0,6)                    /*!< transmitter delay compensation value */
#define CAN_FDSTAT_PRE                     BIT(16)                      /*!< protocol exception event */

/* CAN_FDTDC */
#define CAN_FDTDC_TDCF                     BITS(0,6)                    /*!< transmitter delay compensation filter */
#define CAN_FDTDC_TDCO                     BITS(8,14)                   /*!< transmitter delay compensation offset */

/* CAN_DBT */
#define CAN_DBT_DBAUDPSC                   BITS(0,9)                    /*!< baud rate prescaler */
#define CAN_DBT_DBS1                       BITS(16,19)                  /*!< bit segment 1 */
#define CAN_DBT_DBS2                       BITS(20,22)                  /*!< bit segment 2 */
#define CAN_DBT_DSJW                       BITS(24,26)                  /*!< resynchronization jump width */

/* CAN_TMIx */
#define CAN_TMI_TEN                        BIT(0)                       /*!< transmit enable */
#define CAN_TMI_FT                         BIT(1)                       /*!< frame type */
#define CAN_TMI_FF                         BIT(2)                       /*!< frame format */
#define CAN_TMI_EFID                       BITS(3,31)                   /*!< the frame identifier */
#define CAN_TMI_SFID                       BITS(21,31)                  /*!< the frame identifier */

/* CAN_TMPx */
#define CAN_TMP_DLENC                      BITS(0,3)                    /*!< data length code */
#define CAN_TMP_ESI                        BIT(4)                       /*!< error status indicator */
#define CAN_TMP_BRS                        BIT(5)                       /*!< bit rate of data switch */
#define CAN_TMP_FDF                        BIT(7)                       /*!< CAN FD frame flag */
#define CAN_TMP_TSEN                       BIT(8)                       /*!< time stamp enable */
#define CAN_TMP_TS                         BITS(16,31)                  /*!< time stamp */

/* CAN_TMDATA0x */
#define CAN_TMDATA0_DB0                    BITS(0,7)                    /*!< transmit data byte 0 */
#define CAN_TMDATA0_DB1                    BITS(8,15)                   /*!< transmit data byte 1 */
#define CAN_TMDATA0_DB2                    BITS(16,23)                  /*!< transmit data byte 2 */
#define CAN_TMDATA0_DB3                    BITS(24,31)                  /*!< transmit data byte 3 */

/* CAN_TMDATA1x */
#define CAN_TMDATA1_DB4                    BITS(0,7)                    /*!< transmit data byte 4 */
#define CAN_TMDATA1_DB5                    BITS(8,15)                   /*!< transmit data byte 5 */
#define CAN_TMDATA1_DB6                    BITS(16,23)                  /*!< transmit data byte 6 */
#define CAN_TMDATA1_DB7                    BITS(24,31)                  /*!< transmit data byte 7 */

/* CAN_RFIFOMIx */
#define CAN_RFIFOMI_FT                     BIT(1)                       /*!< frame type */
#define CAN_RFIFOMI_FF                     BIT(2)                       /*!< frame format */
#define CAN_RFIFOMI_EFID                   BITS(3,31)                   /*!< the frame identifier */
#define CAN_RFIFOMI_SFID                   BITS(21,31)                  /*!< the frame identifier */

/* CAN_RFIFOMPx */
#define CAN_RFIFOMP_DLENC                  BITS(0,3)                    /*!< receive data length code */
#define CAN_RFIFOMP_ESI                    BIT(4)                       /*!< error status indicator */
#define CAN_RFIFOMP_BRS                    BIT(5)                       /*!< bit rate of data switch */
#define CAN_RFIFOMP_FDF                    BIT(7)                       /*!< CAN FD frame flag */
#define CAN_RFIFOMP_FI                     BITS(8,15)                   /*!< filter index */
#define CAN_RFIFOMP_TS                     BITS(16,31)                  /*!< time stamp */

/* CAN_RFIFOMDATA0x */
#define CAN_RFIFOMDATA0_DB0                BITS(0,7)                    /*!< receive data byte 0 */
#define CAN_RFIFOMDATA0_DB1                BITS(8,15)                   /*!< receive data byte 1 */
#define CAN_RFIFOMDATA0_DB2                BITS(16,23)                  /*!< receive data byte 2 */
#define CAN_RFIFOMDATA0_DB3                BITS(24,31)                  /*!< receive data byte 3 */

/* CAN_RFIFOMDATA1x */
#define CAN_RFIFOMDATA1_DB4                BITS(0,7)                    /*!< receive data byte 4 */
#define CAN_RFIFOMDATA1_DB5                BITS(8,15)                   /*!< receive data byte 5 */
#define CAN_RFIFOMDATA1_DB6                BITS(16,23)                  /*!< receive data byte 6 */
#define CAN_RFIFOMDATA1_DB7                BITS(24,31)                  /*!< receive data byte 7 */

/* CAN_FCTL */
#define CAN_FCTL_FLD                       BIT(0)                       /*!< filter lock disable */
#define CAN_FCTL_HBC1F                     BITS(8,13)                   /*!< header bank of CAN1 filter */

/* CAN_FMCFG */
#define CAN_FMCFG_FMOD(regval)             BIT(regval)                  /*!< filter mode, list or mask*/

/* CAN_FSCFG */
#define CAN_FSCFG_FS(regval)               BIT(regval)                  /*!< filter scale, 32 bits or 16 bits*/

/* CAN_FAFIFO */
#define CAN_FAFIFOR_FAF(regval)            BIT(regval)                  /*!< filter associated with FIFO */

/* CAN_FW */
#define CAN_FW_FW(regval)                  BIT(regval)                  /*!< filter working */

/* CAN_FxDATAy */
#define CAN_FDATA_FD(regval)               BIT(regval)                  /*!< filter data */

/* consts definitions */
/* define the CAN bit position and its register index offset */
#define CAN_REGIDX_BIT(regidx, bitpos)              (((uint32_t)(regidx) << 6) | (uint32_t)(bitpos))
#define CAN_REG_VAL(canx, offset)                   (REG32((canx) + ((uint32_t)(offset) >> 6)))
#define CAN_BIT_POS(val)                            ((uint32_t)(val) & 0x1FU)

#define CAN_REGIDX_BITS(regidx, bitpos0, bitpos1)   (((uint32_t)(regidx) << 12) | ((uint32_t)(bitpos0) << 6) | (uint32_t)(bitpos1))
#define CAN_REG_VALS(canx, offset)                  (REG32((canx) + ((uint32_t)(offset) >> 12)))
#define CAN_BIT_POS0(val)                           (((uint32_t)(val) >> 6) & 0x1FU)
#define CAN_BIT_POS1(val)                           ((uint32_t)(val) & 0x1FU)

/* register offset */
#define STAT_REG_OFFSET                    ((uint8_t)0x04U)             /*!< STAT register offset */
#define TSTAT_REG_OFFSET                   ((uint8_t)0x08U)             /*!< TSTAT register offset */
#define RFIFO0_REG_OFFSET                  ((uint8_t)0x0CU)             /*!< RFIFO0 register offset */
#define RFIFO1_REG_OFFSET                  ((uint8_t)0x10U)             /*!< RFIFO1 register offset */
#define ERR_REG_OFFSET                     ((uint8_t)0x18U)             /*!< ERR register offset */

/* CAN flags */
typedef enum
{
    /* flags in STAT register */
    CAN_FLAG_RXL      = CAN_REGIDX_BIT(STAT_REG_OFFSET, 11U),           /*!< RX level */
    CAN_FLAG_LASTRX   = CAN_REGIDX_BIT(STAT_REG_OFFSET, 10U),           /*!< last sample value of RX pin */
    CAN_FLAG_RS       = CAN_REGIDX_BIT(STAT_REG_OFFSET, 9U),            /*!< receiving state */
    CAN_FLAG_TS       = CAN_REGIDX_BIT(STAT_REG_OFFSET, 8U),            /*!< transmitting state */
    CAN_FLAG_SLPIF    = CAN_REGIDX_BIT(STAT_REG_OFFSET, 4U),            /*!< status change flag of entering sleep working mode */
    CAN_FLAG_WUIF     = CAN_REGIDX_BIT(STAT_REG_OFFSET, 3U),            /*!< status change flag of wakeup from sleep working mode */
    CAN_FLAG_ERRIF    = CAN_REGIDX_BIT(STAT_REG_OFFSET, 2U),            /*!< error flag */
    CAN_FLAG_SLPWS    = CAN_REGIDX_BIT(STAT_REG_OFFSET, 1U),            /*!< sleep working state */
    CAN_FLAG_IWS      = CAN_REGIDX_BIT(STAT_REG_OFFSET, 0U),            /*!< initial working state */
    /* flags in TSTAT register */
    CAN_FLAG_TMLS2    = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 31U),          /*!< transmit mailbox 2 last sending in Tx FIFO */ 
    CAN_FLAG_TMLS1    = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 30U),          /*!< transmit mailbox 1 last sending in Tx FIFO */ 
    CAN_FLAG_TMLS0    = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 29U),          /*!< transmit mailbox 0 last sending in Tx FIFO */ 
    CAN_FLAG_TME2     = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 28U),          /*!< transmit mailbox 2 empty */
    CAN_FLAG_TME1     = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 27U),          /*!< transmit mailbox 1 empty */
    CAN_FLAG_TME0     = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 26U),          /*!< transmit mailbox 0 empty */
    CAN_FLAG_MTE2     = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 19U),          /*!< mailbox 2 transmit error */
    CAN_FLAG_MTE1     = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 11U),          /*!< mailbox 1 transmit error */
    CAN_FLAG_MTE0     = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 3U),           /*!< mailbox 0 transmit error */
    CAN_FLAG_MAL2     = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 18U),          /*!< mailbox 2 arbitration lost */
    CAN_FLAG_MAL1     = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 10U),          /*!< mailbox 1 arbitration lost */
    CAN_FLAG_MAL0     = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 2U),           /*!< mailbox 0 arbitration lost */
    CAN_FLAG_MTFNERR2 = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 17U),          /*!< mailbox 2 transmit finished with no error */
    CAN_FLAG_MTFNERR1 = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 9U),           /*!< mailbox 1 transmit finished with no error */
    CAN_FLAG_MTFNERR0 = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 1U),           /*!< mailbox 0 transmit finished with no error */
    CAN_FLAG_MTF2     = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 16U),          /*!< mailbox 2 transmit finished */
    CAN_FLAG_MTF1     = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 8U),           /*!< mailbox 1 transmit finished */
    CAN_FLAG_MTF0     = CAN_REGIDX_BIT(TSTAT_REG_OFFSET, 0U),           /*!< mailbox 0 transmit finished */
    /* flags in RFIFO0 register */
    CAN_FLAG_RFO0     = CAN_REGIDX_BIT(RFIFO0_REG_OFFSET, 4U),          /*!< receive FIFO0 overfull */ 
    CAN_FLAG_RFF0     = CAN_REGIDX_BIT(RFIFO0_REG_OFFSET, 3U),          /*!< receive FIFO0 full */ 
    /* flags in RFIFO1 register */
    CAN_FLAG_RFO1     = CAN_REGIDX_BIT(RFIFO1_REG_OFFSET, 4U),          /*!< receive FIFO1 overfull */ 
    CAN_FLAG_RFF1     = CAN_REGIDX_BIT(RFIFO1_REG_OFFSET, 3U),          /*!< receive FIFO1 full */ 
    /* flags in ERR register */
    CAN_FLAG_BOERR    = CAN_REGIDX_BIT(ERR_REG_OFFSET, 2U),             /*!< bus-off error */ 
    CAN_FLAG_PERR     = CAN_REGIDX_BIT(ERR_REG_OFFSET, 1U),             /*!< passive error */ 
    CAN_FLAG_WERR     = CAN_REGIDX_BIT(ERR_REG_OFFSET, 0U),             /*!< warning error */ 
}can_flag_enum;

/* CAN interrupt flags */
typedef enum
{
    /* interrupt flags in STAT register */
    CAN_INT_FLAG_SLPIF = CAN_REGIDX_BITS(STAT_REG_OFFSET, 4U, 17U),     /*!< status change interrupt flag of sleep working mode entering */
    CAN_INT_FLAG_WUIF  = CAN_REGIDX_BITS(STAT_REG_OFFSET, 3U, 16),      /*!< status change interrupt flag of wakeup from sleep working mode */
    CAN_INT_FLAG_ERRIF = CAN_REGIDX_BITS(STAT_REG_OFFSET, 2U, 15),      /*!< error interrupt flag */
    /* interrupt flags in TSTAT register */
    CAN_INT_FLAG_MTF2  = CAN_REGIDX_BITS(TSTAT_REG_OFFSET, 16U, 0U),    /*!< mailbox 2 transmit finished interrupt flag */
    CAN_INT_FLAG_MTF1  = CAN_REGIDX_BITS(TSTAT_REG_OFFSET, 8U, 0U),     /*!< mailbox 1 transmit finished interrupt flag */
    CAN_INT_FLAG_MTF0  = CAN_REGIDX_BITS(TSTAT_REG_OFFSET, 0U, 0U),     /*!< mailbox 0 transmit finished interrupt flag */
    /* interrupt flags in RFIFO0 register */
    CAN_INT_FLAG_RFO0  = CAN_REGIDX_BITS(RFIFO0_REG_OFFSET, 4U, 3U),    /*!< receive FIFO0 overfull interrupt flag */
    CAN_INT_FLAG_RFF0  = CAN_REGIDX_BITS(RFIFO0_REG_OFFSET, 3U, 2U),    /*!< receive FIFO0 full interrupt flag */
    CAN_INT_FLAG_RFL0  = CAN_REGIDX_BITS(RFIFO0_REG_OFFSET, 2U, 1U),    /*!< receive FIFO0 not empty interrupt flag */
    /* interrupt flags in RFIFO0 register */
    CAN_INT_FLAG_RFO1  = CAN_REGIDX_BITS(RFIFO1_REG_OFFSET, 4U, 6U),    /*!< receive FIFO1 overfull interrupt flag */
    CAN_INT_FLAG_RFF1  = CAN_REGIDX_BITS(RFIFO1_REG_OFFSET, 3U, 5U),    /*!< receive FIFO1 full interrupt flag */
    CAN_INT_FLAG_RFL1  = CAN_REGIDX_BITS(RFIFO1_REG_OFFSET, 2U, 4U),    /*!< receive FIFO1 not empty interrupt flag */
    /* interrupt flags in ERR register */
    CAN_INT_FLAG_ERRN  = CAN_REGIDX_BITS(ERR_REG_OFFSET, 3U, 11U),      /*!< error number interrupt flag */ 
    CAN_INT_FLAG_BOERR = CAN_REGIDX_BITS(ERR_REG_OFFSET, 2U, 10U),      /*!< bus-off error interrupt flag */ 
    CAN_INT_FLAG_PERR  = CAN_REGIDX_BITS(ERR_REG_OFFSET, 1U, 9U),       /*!< passive error interrupt flag */ 
    CAN_INT_FLAG_WERR  = CAN_REGIDX_BITS(ERR_REG_OFFSET, 0U, 8U),       /*!< warning error interrupt flag */ 
}can_interrupt_flag_enum;

/* CAN FD transmitter delay compensation parameters struct */
typedef struct 
{
    uint32_t tdc_mode;                                                  /*!< transmitter delay compensation mode */
    uint8_t tdc_filter;                                                 /*!< transmitter delay compensation filter */
    uint8_t tdc_offset;                                                 /*!< transmitter delay compensation offset */
}can_fd_tdc_struct;

/* CAN initiliaze FD frame parameters struct */
typedef struct 
{
    ControlStatus fd_frame;                                             /*!< FD operation function */              
    ControlStatus excp_event_detect;                                    /*!< protocol exception event detection function*/
    ControlStatus delay_compensation;                                   /*!< transmitter delay compensation mode */
    can_fd_tdc_struct *p_delay_compensation;                            /*!< pointer to the struct of the transmitter delay compensation */
    uint32_t iso_bosch;                                                 /*!< ISO/Bosch mode choice */
    uint32_t esi_mode;                                                  /*!< error state indicator mode */
    uint8_t data_resync_jump_width;                                     /*!< CAN resynchronization jump width */
    uint8_t data_time_segment_1;                                        /*!< time segment 1 */
    uint8_t data_time_segment_2;                                        /*!< time segment 2 */
    uint16_t data_prescaler;                                            /*!< baudrate prescaler */
}can_fdframe_struct;

/* CAN initiliaze parameters struct */
typedef struct
{
    uint8_t working_mode;                                               /*!< CAN working mode */ 
    uint8_t resync_jump_width;                                          /*!< CAN resynchronization jump width */
    uint8_t time_segment_1;                                             /*!< time segment 1 */
    uint8_t time_segment_2;                                             /*!< time segment 2 */
    ControlStatus time_triggered;                                       /*!< time triggered communication mode */
    ControlStatus auto_bus_off_recovery;                                /*!< automatic bus-off recovery */
    ControlStatus auto_wake_up;                                         /*!< automatic wake-up mode */
    ControlStatus auto_retrans;                                         /*!< automatic retransmission mode disable */
    ControlStatus rec_fifo_overwrite;                                   /*!< receive FIFO overwrite mode */
    ControlStatus trans_fifo_order;                                     /*!< transmit FIFO order */
    uint16_t prescaler;                                                 /*!< baudrate prescaler */
}can_parameter_struct;

/* CAN transmit message struct */
typedef struct
{
    uint32_t tx_sfid;                                                   /*!< standard format frame identifier */
    uint32_t tx_efid;                                                   /*!< extended format frame identifier */
    uint8_t tx_ff;                                                      /*!< format of frame, standard or extended format */
    uint8_t tx_ft;                                                      /*!< type of frame, data or remote */
    uint8_t tx_dlen;                                                    /*!< data length */
    uint8_t tx_data[64];                                                /*!< transmit data */
    uint8_t fd_flag;                                                    /*!< CAN FD frame flag */
    uint8_t fd_brs;                                                     /*!< bit rate of data switch */
    uint8_t fd_esi;                                                     /*!< error status indicator */
}can_trasnmit_message_struct;

/* CAN receive message struct */
typedef struct
{
    uint32_t rx_sfid;                                                   /*!< standard format frame identifier */
    uint32_t rx_efid;                                                   /*!< extended format frame identifier */
    uint8_t rx_ff;                                                      /*!< format of frame, standard or extended format */
    uint8_t rx_ft;                                                      /*!< type of frame, data or remote */
    uint8_t rx_dlen;                                                    /*!< data length */
    uint8_t rx_data[64];                                                /*!< receive data */
    uint8_t rx_fi;                                                      /*!< filtering index */
    uint8_t fd_flag;                                                    /*!< CAN FD frame flag */
    uint8_t fd_brs;                                                     /*!< bit rate of data switch */
    uint8_t fd_esi;                                                     /*!< error status indicator */
} can_receive_message_struct;

/* CAN filter parameters struct */
typedef struct
{
    uint16_t filter_list_high;                                          /*!< filter list number high bits*/
    uint16_t filter_list_low;                                           /*!< filter list number low bits */
    uint16_t filter_mask_high;                                          /*!< filter mask number high bits */
    uint16_t filter_mask_low;                                           /*!< filter mask number low bits */
    uint16_t filter_fifo_number;                                        /*!< receive FIFO associated with the filter */
    uint16_t filter_number;                                             /*!< filter number */
    uint16_t filter_mode;                                               /*!< filter mode, list or mask */
    uint16_t filter_bits;                                               /*!< filter scale */
    ControlStatus filter_enable;                                        /*!< filter work or not */
}can_filter_parameter_struct;

/* CAN errors */
typedef enum
{
    CAN_ERROR_NONE = 0,                                                 /*!< no error */
    CAN_ERROR_FILL,                                                     /*!< fill error */
    CAN_ERROR_FORMATE,                                                  /*!< format error */
    CAN_ERROR_ACK,                                                      /*!< ACK error */
    CAN_ERROR_BITRECESSIVE,                                             /*!< bit recessive error */
    CAN_ERROR_BITDOMINANTER,                                            /*!< bit dominant error */
    CAN_ERROR_CRC,                                                      /*!< CRC error */
    CAN_ERROR_SOFTWARECFG,                                              /*!< software configure */
}can_error_enum;

/* transmit states */
typedef enum
{
    CAN_TRANSMIT_FAILED = 0,                                            /*!< CAN transmitted failure */
    CAN_TRANSMIT_OK = 1,                                                /*!< CAN transmitted success */
    CAN_TRANSMIT_PENDING = 2,                                           /*!< CAN transmitted pending */
    CAN_TRANSMIT_NOMAILBOX = 4,                                         /*!< no empty mailbox to be used for CAN */
}can_transmit_state_enum;

/* format and fifo states */
typedef enum
{
    CAN_STANDARD_FIFO0 = 0,                                             /*!< standard frame and used FIFO0 */
    CAN_STANDARD_FIFO1,                                                 /*!< standard frame and used FIFO1 */
    CAN_EXTENDED_FIFO0,                                                 /*!< extended frame and used FIFO0 */
    CAN_EXTENDED_FIFO1,                                                 /*!< extended frame and used FIFO1 */
}can_format_fifo_enum;

typedef enum
{
    CAN_INIT_STRUCT = 0,                                                /* CAN initiliaze parameters struct */
    CAN_FILTER_STRUCT,                                                  /* CAN filter parameters struct */
    CAN_FD_FRAME_STRUCT,                                                /* CAN initiliaze FD frame parameters struct */
    CAN_TX_MESSAGE_STRUCT,                                              /* CAN transmit message struct */
    CAN_RX_MESSAGE_STRUCT,                                              /* CAN receive message struct */
}can_struct_type_enum;

/* CAN baudrate prescaler*/
#define BT_BAUDPSC(regval)                 (BITS(0,9) & ((uint32_t)(regval) << 0))

/* CAN bit segment 1*/
#define BT_BS1(regval)                     ((BITS(16,19) & ((uint32_t)(regval) << 16)) | (BITS(10,12) & ((uint32_t)(regval) << 6)))
#define BT_DBS1(regval)                    ((BITS(16,19) & ((uint32_t)(regval) << 16)))

/* CAN bit segment 2*/
#define BT_BS2(regval)                     ((BITS(20,22) & ((uint32_t)(regval) << 20)) | (BITS(13,14) & ((uint32_t)(regval) << 10)))
#define BT_DBS2(regval)                    ((BITS(20,22)) & ((uint32_t)(regval) << 20))

/* CAN resynchronization jump width*/
#define BT_SJW(regval)                     (BITS(24,28) & ((uint32_t)(regval) << 24))
#define BT_DSJW(regval)                    (BITS(24,26) & ((uint32_t)(regval) << 24))

#define FDTDC_TDCF(regval)                 (BITS(0,6) & ((uint32_t)(regval) << 0))
#define FDTDC_TDCO(regval)                 (BITS(8,14) & ((uint32_t)(regval) << 8))

/* CAN communication mode*/
#define BT_MODE(regval)                    (BITS(30,31) & ((uint32_t)(regval) << 30))

/* CAN FDATA high 16 bits */
#define FDATA_MASK_HIGH(regval)            (BITS(16,31) & ((uint32_t)(regval) << 16))

/* CAN FDATA low 16 bits */
#define FDATA_MASK_LOW(regval)             (BITS(0,15) & ((uint32_t)(regval) << 0))

/* CAN1 filter start bank_number*/
#define FCTL_HBC1F(regval)                 (BITS(8,13) & ((uint32_t)(regval) << 8))

/* CAN transmit mailbox extended identifier*/
#define TMI_EFID(regval)                   (BITS(3,31) & ((uint32_t)(regval) << 3))

/* CAN transmit mailbox standard identifier*/
#define TMI_SFID(regval)                   (BITS(21,31) & ((uint32_t)(regval) << 21))

/* transmit data byte 0 */
#define TMDATA0_DB0(regval)                (BITS(0,7) & ((uint32_t)(regval) << 0))

/* transmit data byte 1 */
#define TMDATA0_DB1(regval)                (BITS(8,15) & ((uint32_t)(regval) << 8))

/* transmit data byte 2 */
#define TMDATA0_DB2(regval)                (BITS(16,23) & ((uint32_t)(regval) << 16))

/* transmit data byte 3 */                 
#define TMDATA0_DB3(regval)                (BITS(24,31) & ((uint32_t)(regval) << 24))

/* transmit data byte 4 */                 
#define TMDATA1_DB4(regval)                (BITS(0,7) & ((uint32_t)(regval) << 0))

/* transmit data byte 5 */                 
#define TMDATA1_DB5(regval)                (BITS(8,15) & ((uint32_t)(regval) << 8))

/* transmit data byte 6 */                 
#define TMDATA1_DB6(regval)                (BITS(16,23) & ((uint32_t)(regval) << 16))

/* transmit data byte 7 */                 
#define TMDATA1_DB7(regval)                (BITS(24,31) & ((uint32_t)(regval) << 24))

/* receive mailbox extended identifier*/
#define GET_RFIFOMI_EFID(regval)           GET_BITS((uint32_t)(regval), 3, 31)

/* receive mailbox standrad identifier*/
#define GET_RFIFOMI_SFID(regval)           GET_BITS((uint32_t)(regval), 21, 31)

/* receive data length */
#define GET_RFIFOMP_DLENC(regval)          GET_BITS((uint32_t)(regval), 0, 3)

/* the index of the filter by which the frame is passed */
#define GET_RFIFOMP_FI(regval)             GET_BITS((uint32_t)(regval), 8, 15)

/* receive data byte 0 */
#define GET_RFIFOMDATA0_DB0(regval)        GET_BITS((uint32_t)(regval), 0, 7)

/* receive data byte 1 */
#define GET_RFIFOMDATA0_DB1(regval)        GET_BITS((uint32_t)(regval), 8, 15)

/* receive data byte 2 */
#define GET_RFIFOMDATA0_DB2(regval)        GET_BITS((uint32_t)(regval), 16, 23)

/* receive data byte 3 */
#define GET_RFIFOMDATA0_DB3(regval)        GET_BITS((uint32_t)(regval), 24, 31)

/* receive data byte 4 */
#define GET_RFIFOMDATA1_DB4(regval)        GET_BITS((uint32_t)(regval), 0, 7)

/* receive data byte 5 */
#define GET_RFIFOMDATA1_DB5(regval)        GET_BITS((uint32_t)(regval), 8, 15)

/* receive data byte 6 */
#define GET_RFIFOMDATA1_DB6(regval)        GET_BITS((uint32_t)(regval), 16, 23)

/* receive data byte 7 */
#define GET_RFIFOMDATA1_DB7(regval)        GET_BITS((uint32_t)(regval), 24, 31)

/* error number */        
#define GET_ERR_ERRN(regval)               GET_BITS((uint32_t)(regval), 4, 6)

/* transmit error count */        
#define GET_ERR_TECNT(regval)              GET_BITS((uint32_t)(regval), 16, 23)

/* receive  error count */        
#define GET_ERR_RECNT(regval)              GET_BITS((uint32_t)(regval), 24, 31)

/* CAN errors */
#define ERR_ERRN(regval)                   (BITS(4,6) & ((uint32_t)(regval) << 4))
#define CAN_ERRN_0                         ERR_ERRN(0)                  /* no error */
#define CAN_ERRN_1                         ERR_ERRN(1)                  /*!< fill error */
#define CAN_ERRN_2                         ERR_ERRN(2)                  /*!< format error */
#define CAN_ERRN_3                         ERR_ERRN(3)                  /*!< ACK error */
#define CAN_ERRN_4                         ERR_ERRN(4)                  /*!< bit recessive error */
#define CAN_ERRN_5                         ERR_ERRN(5)                  /*!< bit dominant error */
#define CAN_ERRN_6                         ERR_ERRN(6)                  /*!< CRC error */
#define CAN_ERRN_7                         ERR_ERRN(7)                  /*!< software error */

#define CAN_STATE_PENDING                  ((uint32_t)0x00000000U)      /*!< CAN pending */

/* CAN communication mode */
#define CAN_NORMAL_MODE                    ((uint8_t)0x00U)             /*!< normal communication mode */
#define CAN_LOOPBACK_MODE                  ((uint8_t)0x01U)             /*!< loopback communication mode */
#define CAN_SILENT_MODE                    ((uint8_t)0x02U)             /*!< silent communication mode */
#define CAN_SILENT_LOOPBACK_MODE           ((uint8_t)0x03U)             /*!< loopback and silent communication mode */

/* CAN resynchronisation jump width */
#define CAN_BT_SJW_1TQ                     ((uint8_t)0x00U)             /*!< 1 time quanta */
#define CAN_BT_SJW_2TQ                     ((uint8_t)0x01U)             /*!< 2 time quanta */
#define CAN_BT_SJW_3TQ                     ((uint8_t)0x02U)             /*!< 3 time quanta */
#define CAN_BT_SJW_4TQ                     ((uint8_t)0x03U)             /*!< 4 time quanta */
#define CAN_BT_SJW_5TQ                     ((uint8_t)0x04U)             /*!< 5 time quanta */
#define CAN_BT_SJW_6TQ                     ((uint8_t)0x05U)             /*!< 6 time quanta */
#define CAN_BT_SJW_7TQ                     ((uint8_t)0x06U)             /*!< 7 time quanta */
#define CAN_BT_SJW_8TQ                     ((uint8_t)0x07U)             /*!< 8 time quanta */
#define CAN_BT_SJW_9TQ                     ((uint8_t)0x08U)             /*!< 9 time quanta */
#define CAN_BT_SJW_10TQ                    ((uint8_t)0x09U)             /*!< 10 time quanta */
#define CAN_BT_SJW_11TQ                    ((uint8_t)0x0AU)             /*!< 11 time quanta */
#define CAN_BT_SJW_12TQ                    ((uint8_t)0x0BU)             /*!< 12 time quanta */
#define CAN_BT_SJW_13TQ                    ((uint8_t)0x0CU)             /*!< 13 time quanta */
#define CAN_BT_SJW_14TQ                    ((uint8_t)0x0DU)             /*!< 14 time quanta */
#define CAN_BT_SJW_15TQ                    ((uint8_t)0x0EU)             /*!< 15 time quanta */
#define CAN_BT_SJW_16TQ                    ((uint8_t)0x0FU)             /*!< 16 time quanta */
#define CAN_BT_SJW_17TQ                    ((uint8_t)0x10U)             /*!< 17 time quanta */
#define CAN_BT_SJW_18TQ                    ((uint8_t)0x11U)             /*!< 18 time quanta */
#define CAN_BT_SJW_19TQ                    ((uint8_t)0x12U)             /*!< 19 time quanta */
#define CAN_BT_SJW_20TQ                    ((uint8_t)0x13U)             /*!< 20 time quanta */
#define CAN_BT_SJW_21TQ                    ((uint8_t)0x14U)             /*!< 21 time quanta */
#define CAN_BT_SJW_22TQ                    ((uint8_t)0x15U)             /*!< 22 time quanta */
#define CAN_BT_SJW_23TQ                    ((uint8_t)0x16U)             /*!< 23 time quanta */
#define CAN_BT_SJW_24TQ                    ((uint8_t)0x17U)             /*!< 24 time quanta */
#define CAN_BT_SJW_25TQ                    ((uint8_t)0x18U)             /*!< 25 time quanta */
#define CAN_BT_SJW_26TQ                    ((uint8_t)0x19U)             /*!< 26 time quanta */
#define CAN_BT_SJW_27TQ                    ((uint8_t)0x1AU)             /*!< 27 time quanta */
#define CAN_BT_SJW_28TQ                    ((uint8_t)0x1BU)             /*!< 28 time quanta */
#define CAN_BT_SJW_29TQ                    ((uint8_t)0x1CU)             /*!< 29 time quanta */
#define CAN_BT_SJW_30TQ                    ((uint8_t)0x1DU)             /*!< 30 time quanta */
#define CAN_BT_SJW_31TQ                    ((uint8_t)0x1EU)             /*!< 31 time quanta */
#define CAN_BT_SJW_32TQ                    ((uint8_t)0x1FU)             /*!< 32 time quanta */

/* CAN time segment 1 */
#define CAN_BT_BS1_1TQ                     ((uint8_t)0x00U)             /*!< 1 time quanta */
#define CAN_BT_BS1_2TQ                     ((uint8_t)0x01U)             /*!< 2 time quanta */
#define CAN_BT_BS1_3TQ                     ((uint8_t)0x02U)             /*!< 3 time quanta */
#define CAN_BT_BS1_4TQ                     ((uint8_t)0x03U)             /*!< 4 time quanta */
#define CAN_BT_BS1_5TQ                     ((uint8_t)0x04U)             /*!< 5 time quanta */
#define CAN_BT_BS1_6TQ                     ((uint8_t)0x05U)             /*!< 6 time quanta */
#define CAN_BT_BS1_7TQ                     ((uint8_t)0x06U)             /*!< 7 time quanta */
#define CAN_BT_BS1_8TQ                     ((uint8_t)0x07U)             /*!< 8 time quanta */
#define CAN_BT_BS1_9TQ                     ((uint8_t)0x08U)             /*!< 9 time quanta */
#define CAN_BT_BS1_10TQ                    ((uint8_t)0x09U)             /*!< 10 time quanta */
#define CAN_BT_BS1_11TQ                    ((uint8_t)0x0AU)             /*!< 11 time quanta */
#define CAN_BT_BS1_12TQ                    ((uint8_t)0x0BU)             /*!< 12 time quanta */
#define CAN_BT_BS1_13TQ                    ((uint8_t)0x0CU)             /*!< 13 time quanta */
#define CAN_BT_BS1_14TQ                    ((uint8_t)0x0DU)             /*!< 14 time quanta */
#define CAN_BT_BS1_15TQ                    ((uint8_t)0x0EU)             /*!< 15 time quanta */
#define CAN_BT_BS1_16TQ                    ((uint8_t)0x0FU)             /*!< 16 time quanta */
#define CAN_BT_BS1_17TQ                    ((uint8_t)0x10U)             /*!< 17 time quanta */
#define CAN_BT_BS1_18TQ                    ((uint8_t)0x11U)             /*!< 18 time quanta */
#define CAN_BT_BS1_19TQ                    ((uint8_t)0x12U)             /*!< 19 time quanta */
#define CAN_BT_BS1_20TQ                    ((uint8_t)0x13U)             /*!< 20 time quanta */
#define CAN_BT_BS1_21TQ                    ((uint8_t)0x14U)             /*!< 21 time quanta */
#define CAN_BT_BS1_22TQ                    ((uint8_t)0x15U)             /*!< 22 time quanta */
#define CAN_BT_BS1_23TQ                    ((uint8_t)0x16U)             /*!< 23 time quanta */
#define CAN_BT_BS1_24TQ                    ((uint8_t)0x17U)             /*!< 24 time quanta */
#define CAN_BT_BS1_25TQ                    ((uint8_t)0x18U)             /*!< 25 time quanta */
#define CAN_BT_BS1_26TQ                    ((uint8_t)0x19U)             /*!< 26 time quanta */
#define CAN_BT_BS1_27TQ                    ((uint8_t)0x1AU)             /*!< 27 time quanta */
#define CAN_BT_BS1_28TQ                    ((uint8_t)0x1BU)             /*!< 28 time quanta */
#define CAN_BT_BS1_29TQ                    ((uint8_t)0x1CU)             /*!< 29 time quanta */
#define CAN_BT_BS1_30TQ                    ((uint8_t)0x1DU)             /*!< 30 time quanta */
#define CAN_BT_BS1_31TQ                    ((uint8_t)0x1EU)             /*!< 31 time quanta */
#define CAN_BT_BS1_32TQ                    ((uint8_t)0x1FU)             /*!< 32 time quanta */
#define CAN_BT_BS1_33TQ                    ((uint8_t)0x20U)             /*!< 33 time quanta */
#define CAN_BT_BS1_34TQ                    ((uint8_t)0x21U)             /*!< 34 time quanta */
#define CAN_BT_BS1_35TQ                    ((uint8_t)0x22U)             /*!< 35 time quanta */
#define CAN_BT_BS1_36TQ                    ((uint8_t)0x23U)             /*!< 36 time quanta */
#define CAN_BT_BS1_37TQ                    ((uint8_t)0x24U)             /*!< 37 time quanta */
#define CAN_BT_BS1_38TQ                    ((uint8_t)0x25U)             /*!< 38 time quanta */
#define CAN_BT_BS1_39TQ                    ((uint8_t)0x26U)             /*!< 39 time quanta */
#define CAN_BT_BS1_40TQ                    ((uint8_t)0x27U)             /*!< 40 time quanta */
#define CAN_BT_BS1_41TQ                    ((uint8_t)0x28U)             /*!< 41 time quanta */
#define CAN_BT_BS1_42TQ                    ((uint8_t)0x29U)             /*!< 42 time quanta */
#define CAN_BT_BS1_43TQ                    ((uint8_t)0x2AU)             /*!< 43 time quanta */
#define CAN_BT_BS1_44TQ                    ((uint8_t)0x2BU)             /*!< 44 time quanta */
#define CAN_BT_BS1_45TQ                    ((uint8_t)0x2CU)             /*!< 45 time quanta */
#define CAN_BT_BS1_46TQ                    ((uint8_t)0x2DU)             /*!< 46 time quanta */
#define CAN_BT_BS1_47TQ                    ((uint8_t)0x2EU)             /*!< 47 time quanta */
#define CAN_BT_BS1_48TQ                    ((uint8_t)0x2FU)             /*!< 48 time quanta */
#define CAN_BT_BS1_49TQ                    ((uint8_t)0x30U)             /*!< 49 time quanta */
#define CAN_BT_BS1_50TQ                    ((uint8_t)0x31U)             /*!< 50 time quanta */
#define CAN_BT_BS1_51TQ                    ((uint8_t)0x32U)             /*!< 51 time quanta */
#define CAN_BT_BS1_52TQ                    ((uint8_t)0x33U)             /*!< 52 time quanta */
#define CAN_BT_BS1_53TQ                    ((uint8_t)0x34U)             /*!< 53 time quanta */
#define CAN_BT_BS1_54TQ                    ((uint8_t)0x35U)             /*!< 54 time quanta */
#define CAN_BT_BS1_55TQ                    ((uint8_t)0x36U)             /*!< 55 time quanta */
#define CAN_BT_BS1_56TQ                    ((uint8_t)0x37U)             /*!< 56 time quanta */
#define CAN_BT_BS1_57TQ                    ((uint8_t)0x38U)             /*!< 57 time quanta */
#define CAN_BT_BS1_58TQ                    ((uint8_t)0x39U)             /*!< 58 time quanta */
#define CAN_BT_BS1_59TQ                    ((uint8_t)0x3AU)             /*!< 59 time quanta */
#define CAN_BT_BS1_60TQ                    ((uint8_t)0x3BU)             /*!< 60 time quanta */
#define CAN_BT_BS1_61TQ                    ((uint8_t)0x3CU)             /*!< 61 time quanta */
#define CAN_BT_BS1_62TQ                    ((uint8_t)0x3DU)             /*!< 62 time quanta */
#define CAN_BT_BS1_63TQ                    ((uint8_t)0x3EU)             /*!< 63 time quanta */
#define CAN_BT_BS1_64TQ                    ((uint8_t)0x3FU)             /*!< 64 time quanta */
#define CAN_BT_BS1_65TQ                    ((uint8_t)0x40U)             /*!< 65 time quanta */
#define CAN_BT_BS1_66TQ                    ((uint8_t)0x41U)             /*!< 66 time quanta */
#define CAN_BT_BS1_67TQ                    ((uint8_t)0x42U)             /*!< 67 time quanta */
#define CAN_BT_BS1_68TQ                    ((uint8_t)0x43U)             /*!< 68 time quanta */
#define CAN_BT_BS1_69TQ                    ((uint8_t)0x44U)             /*!< 69 time quanta */
#define CAN_BT_BS1_70TQ                    ((uint8_t)0x45U)             /*!< 70 time quanta */
#define CAN_BT_BS1_71TQ                    ((uint8_t)0x46U)             /*!< 71 time quanta */
#define CAN_BT_BS1_72TQ                    ((uint8_t)0x47U)             /*!< 72 time quanta */
#define CAN_BT_BS1_73TQ                    ((uint8_t)0x48U)             /*!< 73 time quanta */
#define CAN_BT_BS1_74TQ                    ((uint8_t)0x49U)             /*!< 74 time quanta */
#define CAN_BT_BS1_75TQ                    ((uint8_t)0x4AU)             /*!< 75 time quanta */
#define CAN_BT_BS1_76TQ                    ((uint8_t)0x4BU)             /*!< 76 time quanta */
#define CAN_BT_BS1_77TQ                    ((uint8_t)0x4CU)             /*!< 77 time quanta */
#define CAN_BT_BS1_78TQ                    ((uint8_t)0x4DU)             /*!< 78 time quanta */
#define CAN_BT_BS1_79TQ                    ((uint8_t)0x4EU)             /*!< 79 time quanta */
#define CAN_BT_BS1_80TQ                    ((uint8_t)0x4FU)             /*!< 80 time quanta */
#define CAN_BT_BS1_81TQ                    ((uint8_t)0x50U)             /*!< 81 time quanta */
#define CAN_BT_BS1_82TQ                    ((uint8_t)0x51U)             /*!< 82 time quanta */
#define CAN_BT_BS1_83TQ                    ((uint8_t)0x52U)             /*!< 83 time quanta */
#define CAN_BT_BS1_84TQ                    ((uint8_t)0x53U)             /*!< 84 time quanta */
#define CAN_BT_BS1_85TQ                    ((uint8_t)0x54U)             /*!< 85 time quanta */
#define CAN_BT_BS1_86TQ                    ((uint8_t)0x55U)             /*!< 86 time quanta */
#define CAN_BT_BS1_87TQ                    ((uint8_t)0x56U)             /*!< 87 time quanta */
#define CAN_BT_BS1_88TQ                    ((uint8_t)0x57U)             /*!< 88 time quanta */
#define CAN_BT_BS1_89TQ                    ((uint8_t)0x58U)             /*!< 89 time quanta */
#define CAN_BT_BS1_90TQ                    ((uint8_t)0x59U)             /*!< 90 time quanta */
#define CAN_BT_BS1_91TQ                    ((uint8_t)0x5AU)             /*!< 91 time quanta */
#define CAN_BT_BS1_92TQ                    ((uint8_t)0x5BU)             /*!< 92 time quanta */
#define CAN_BT_BS1_93TQ                    ((uint8_t)0x5CU)             /*!< 93 time quanta */
#define CAN_BT_BS1_94TQ                    ((uint8_t)0x5DU)             /*!< 94 time quanta */
#define CAN_BT_BS1_95TQ                    ((uint8_t)0x5EU)             /*!< 95 time quanta */
#define CAN_BT_BS1_96TQ                    ((uint8_t)0x5FU)             /*!< 96 time quanta */
#define CAN_BT_BS1_97TQ                    ((uint8_t)0x60U)             /*!< 97 time quanta */
#define CAN_BT_BS1_98TQ                    ((uint8_t)0x61U)             /*!< 98 time quanta */
#define CAN_BT_BS1_99TQ                    ((uint8_t)0x62U)             /*!< 99 time quanta */
#define CAN_BT_BS1_100TQ                   ((uint8_t)0x63U)             /*!< 100 time quanta */
#define CAN_BT_BS1_101TQ                   ((uint8_t)0x64U)             /*!< 101 time quanta */
#define CAN_BT_BS1_102TQ                   ((uint8_t)0x65U)             /*!< 102 time quanta */
#define CAN_BT_BS1_103TQ                   ((uint8_t)0x66U)             /*!< 103 time quanta */
#define CAN_BT_BS1_104TQ                   ((uint8_t)0x67U)             /*!< 104 time quanta */
#define CAN_BT_BS1_105TQ                   ((uint8_t)0x68U)             /*!< 105 time quanta */
#define CAN_BT_BS1_106TQ                   ((uint8_t)0x69U)             /*!< 106 time quanta */
#define CAN_BT_BS1_107TQ                   ((uint8_t)0x6AU)             /*!< 107 time quanta */
#define CAN_BT_BS1_108TQ                   ((uint8_t)0x6BU)             /*!< 108 time quanta */
#define CAN_BT_BS1_109TQ                   ((uint8_t)0x6CU)             /*!< 109 time quanta */
#define CAN_BT_BS1_110TQ                   ((uint8_t)0x6DU)             /*!< 110 time quanta */
#define CAN_BT_BS1_111TQ                   ((uint8_t)0x6EU)             /*!< 111 time quanta */
#define CAN_BT_BS1_112TQ                   ((uint8_t)0x6FU)             /*!< 112 time quanta */
#define CAN_BT_BS1_113TQ                   ((uint8_t)0x70U)             /*!< 113 time quanta */
#define CAN_BT_BS1_114TQ                   ((uint8_t)0x71U)             /*!< 114 time quanta */
#define CAN_BT_BS1_115TQ                   ((uint8_t)0x72U)             /*!< 115 time quanta */
#define CAN_BT_BS1_116TQ                   ((uint8_t)0x73U)             /*!< 116 time quanta */
#define CAN_BT_BS1_117TQ                   ((uint8_t)0x74U)             /*!< 117 time quanta */
#define CAN_BT_BS1_118TQ                   ((uint8_t)0x75U)             /*!< 118 time quanta */
#define CAN_BT_BS1_119TQ                   ((uint8_t)0x76U)             /*!< 119 time quanta */
#define CAN_BT_BS1_120TQ                   ((uint8_t)0x77U)             /*!< 120 time quanta */
#define CAN_BT_BS1_121TQ                   ((uint8_t)0x78U)             /*!< 121 time quanta */
#define CAN_BT_BS1_122TQ                   ((uint8_t)0x79U)             /*!< 122 time quanta */
#define CAN_BT_BS1_123TQ                   ((uint8_t)0x7AU)             /*!< 123 time quanta */
#define CAN_BT_BS1_124TQ                   ((uint8_t)0x7BU)             /*!< 124 time quanta */
#define CAN_BT_BS1_125TQ                   ((uint8_t)0x7CU)             /*!< 125 time quanta */
#define CAN_BT_BS1_126TQ                   ((uint8_t)0x7DU)             /*!< 126 time quanta */
#define CAN_BT_BS1_127TQ                   ((uint8_t)0x7EU)             /*!< 127 time quanta */
#define CAN_BT_BS1_128TQ                   ((uint8_t)0x7FU)             /*!< 128 time quanta */

/* CAN time segment 2 */
#define CAN_BT_BS2_1TQ                     ((uint8_t)0x00U)             /*!< 1 time quanta */
#define CAN_BT_BS2_2TQ                     ((uint8_t)0x01U)             /*!< 2 time quanta */
#define CAN_BT_BS2_3TQ                     ((uint8_t)0x02U)             /*!< 3 time quanta */
#define CAN_BT_BS2_4TQ                     ((uint8_t)0x03U)             /*!< 4 time quanta */
#define CAN_BT_BS2_5TQ                     ((uint8_t)0x04U)             /*!< 5 time quanta */
#define CAN_BT_BS2_6TQ                     ((uint8_t)0x05U)             /*!< 6 time quanta */
#define CAN_BT_BS2_7TQ                     ((uint8_t)0x06U)             /*!< 7 time quanta */
#define CAN_BT_BS2_8TQ                     ((uint8_t)0x07U)             /*!< 8 time quanta */
#define CAN_BT_BS2_9TQ                     ((uint8_t)0x08U)             /*!< 9 time quanta */
#define CAN_BT_BS2_10TQ                    ((uint8_t)0x09U)             /*!< 10 time quanta */
#define CAN_BT_BS2_11TQ                    ((uint8_t)0x0AU)             /*!< 11 time quanta */
#define CAN_BT_BS2_12TQ                    ((uint8_t)0x0BU)             /*!< 12 time quanta */
#define CAN_BT_BS2_13TQ                    ((uint8_t)0x0CU)             /*!< 13 time quanta */
#define CAN_BT_BS2_14TQ                    ((uint8_t)0x0DU)             /*!< 14 time quanta */
#define CAN_BT_BS2_15TQ                    ((uint8_t)0x0EU)             /*!< 15 time quanta */
#define CAN_BT_BS2_16TQ                    ((uint8_t)0x0FU)             /*!< 16 time quanta */
#define CAN_BT_BS2_17TQ                    ((uint8_t)0x10U)             /*!< 17 time quanta */
#define CAN_BT_BS2_18TQ                    ((uint8_t)0x11U)             /*!< 18 time quanta */
#define CAN_BT_BS2_19TQ                    ((uint8_t)0x12U)             /*!< 19 time quanta */
#define CAN_BT_BS2_20TQ                    ((uint8_t)0x13U)             /*!< 20 time quanta */
#define CAN_BT_BS2_21TQ                    ((uint8_t)0x14U)             /*!< 21 time quanta */
#define CAN_BT_BS2_22TQ                    ((uint8_t)0x15U)             /*!< 22 time quanta */
#define CAN_BT_BS2_23TQ                    ((uint8_t)0x16U)             /*!< 23 time quanta */
#define CAN_BT_BS2_24TQ                    ((uint8_t)0x17U)             /*!< 24 time quanta */
#define CAN_BT_BS2_25TQ                    ((uint8_t)0x18U)             /*!< 25 time quanta */
#define CAN_BT_BS2_26TQ                    ((uint8_t)0x19U)             /*!< 26 time quanta */
#define CAN_BT_BS2_27TQ                    ((uint8_t)0x1AU)             /*!< 27 time quanta */
#define CAN_BT_BS2_28TQ                    ((uint8_t)0x1BU)             /*!< 28 time quanta */
#define CAN_BT_BS2_29TQ                    ((uint8_t)0x1CU)             /*!< 29 time quanta */
#define CAN_BT_BS2_30TQ                    ((uint8_t)0x1DU)             /*!< 30 time quanta */
#define CAN_BT_BS2_31TQ                    ((uint8_t)0x1EU)             /*!< 31 time quanta */
#define CAN_BT_BS2_32TQ                    ((uint8_t)0x1FU)             /*!< 32 time quanta */

/* CAN  date bit resynchronisation jump width */
#define CAN_DBT_SWJ_1TQ                     ((uint8_t)0x00U)             /*!< 1 time quanta */
#define CAN_DBT_SWJ_2TQ                     ((uint8_t)0x01U)             /*!< 2 time quanta */
#define CAN_DBT_SWJ_3TQ                     ((uint8_t)0x02U)             /*!< 3 time quanta */
#define CAN_DBT_SWJ_4TQ                     ((uint8_t)0x03U)             /*!< 4 time quanta */
#define CAN_DBT_SWJ_5TQ                     ((uint8_t)0x04U)             /*!< 5 time quanta */
#define CAN_DBT_SWJ_6TQ                     ((uint8_t)0x05U)             /*!< 6 time quanta */
#define CAN_DBT_SWJ_7TQ                     ((uint8_t)0x06U)             /*!< 7 time quanta */
#define CAN_DBT_SWJ_8TQ                     ((uint8_t)0x07U)             /*!< 8 time quanta */

/* CAN date bit time segment 1 */
#define CAN_DBT_DBS1_1TQ                   ((uint8_t)0x00U)             /*!< 1 time quanta */
#define CAN_DBT_DBS1_2TQ                   ((uint8_t)0x01U)             /*!< 2 time quanta */
#define CAN_DBT_DBS1_3TQ                   ((uint8_t)0x02U)             /*!< 3 time quanta */
#define CAN_DBT_DBS1_4TQ                   ((uint8_t)0x03U)             /*!< 4 time quanta */
#define CAN_DBT_DBS1_5TQ                   ((uint8_t)0x04U)             /*!< 5 time quanta */
#define CAN_DBT_DBS1_6TQ                   ((uint8_t)0x05U)             /*!< 6 time quanta */
#define CAN_DBT_DBS1_7TQ                   ((uint8_t)0x06U)             /*!< 7 time quanta */
#define CAN_DBT_DBS1_8TQ                   ((uint8_t)0x07U)             /*!< 8 time quanta */
#define CAN_DBT_DBS1_9TQ                   ((uint8_t)0x08U)             /*!< 9 time quanta */
#define CAN_DBT_DBS1_10TQ                  ((uint8_t)0x09U)             /*!< 10 time quanta */
#define CAN_DBT_DBS1_11TQ                  ((uint8_t)0x0AU)             /*!< 11 time quanta */
#define CAN_DBT_DBS1_12TQ                  ((uint8_t)0x0BU)             /*!< 12 time quanta */
#define CAN_DBT_DBS1_13TQ                  ((uint8_t)0x0CU)             /*!< 13 time quanta */
#define CAN_DBT_DBS1_14TQ                  ((uint8_t)0x0DU)             /*!< 14 time quanta */
#define CAN_DBT_DBS1_15TQ                  ((uint8_t)0x0EU)             /*!< 15 time quanta */
#define CAN_DBT_DBS1_16TQ                  ((uint8_t)0x0FU)             /*!< 16 time quanta */

/* CAN date bit time segment 2 */
#define CAN_DBT_DBS2_1TQ                   ((uint8_t)0x00U)             /*!< 1 time quanta */
#define CAN_DBT_DBS2_2TQ                   ((uint8_t)0x01U)             /*!< 2 time quanta */
#define CAN_DBT_DBS2_3TQ                   ((uint8_t)0x02U)             /*!< 3 time quanta */
#define CAN_DBT_DBS2_4TQ                   ((uint8_t)0x03U)             /*!< 4 time quanta */
#define CAN_DBT_DBS2_5TQ                   ((uint8_t)0x04U)             /*!< 5 time quanta */
#define CAN_DBT_DBS2_6TQ                   ((uint8_t)0x05U)             /*!< 6 time quanta */
#define CAN_DBT_DBS2_7TQ                   ((uint8_t)0x06U)             /*!< 7 time quanta */
#define CAN_DBT_DBS2_8TQ                   ((uint8_t)0x07U)             /*!< 8 time quanta */

/* CAN mailbox number */
#define CAN_MAILBOX0                       ((uint8_t)0x00U)             /*!< mailbox0 */
#define CAN_MAILBOX1                       ((uint8_t)0x01U)             /*!< mailbox1 */
#define CAN_MAILBOX2                       ((uint8_t)0x02U)             /*!< mailbox2 */
#define CAN_NOMAILBOX                      ((uint8_t)0x03U)             /*!< no mailbox empty */

/* CAN frame format */
#define CAN_FF_STANDARD                    ((uint32_t)0x00000000U)      /*!< standard frame */
#define CAN_FF_EXTENDED                    ((uint32_t)0x00000004U)      /*!< extended frame */

/* CAN receive fifo */
#define CAN_FIFO0                          ((uint8_t)0x00U)             /*!< receive FIFO0 */
#define CAN_FIFO1                          ((uint8_t)0x01U)             /*!< receive FIFO1 */

/* frame number of receive fifo */
#define CAN_RFIF_RFL_MASK                  ((uint32_t)0x00000003U)      /*!< mask for frame number in receive FIFOx */

#define CAN_SFID_MASK                      ((uint32_t)0x000007FFU)      /*!< mask of standard identifier */
#define CAN_EFID_MASK                      ((uint32_t)0x1FFFFFFFU)      /*!< mask of extended identifier */

/* CAN working mode */
#define CAN_MODE_INITIALIZE                ((uint8_t)0x01U)             /*!< CAN initialize mode */
#define CAN_MODE_NORMAL                    ((uint8_t)0x02U)             /*!< CAN normal mode */
#define CAN_MODE_SLEEP                     ((uint8_t)0x04U)             /*!< CAN sleep mode */

/* filter bits */
#define CAN_FILTERBITS_16BIT               ((uint8_t)0x00U)             /*!< CAN filter 16 bits */
#define CAN_FILTERBITS_32BIT               ((uint8_t)0x01U)             /*!< CAN filter 32 bits */

/* filter mode */
#define CAN_FILTERMODE_MASK                ((uint8_t)0x00U)             /*!< mask mode */
#define CAN_FILTERMODE_LIST                ((uint8_t)0x01U)             /*!< list mode */

/* filter 16 bits mask */
#define CAN_FILTER_MASK_16BITS             ((uint32_t)0x0000FFFFU)      /*!< can filter 16 bits mask */

/* frame type */
#define CAN_FT_DATA                        ((uint32_t)0x00000000U)      /*!< data frame */
#define CAN_FT_REMOTE                      ((uint32_t)0x00000002U)      /*!< remote frame */

#define CAN_ESIMOD_HARDWARE                ((uint32_t)0x00000000U)      /*!< displays the node error state by hardware */
#define CAN_ESIMOD_SOFTWARE                CAN_FDCTL_ESIMOD             /*!< displays the node error state by software */

#define CAN_TDCMOD_CALC_AND_OFFSET         ((uint32_t)0x00000000U)      /*!< measurement and offset */
#define CAN_TDCMOD_OFFSET                  CAN_FDCTL_TDCMOD             /*!< only offset */

#define CAN_FDMOD_ISO                      ((uint32_t)0x00000000U)      /*!< ISO mode */
#define CAN_FDMOD_BOSCH                    CAN_FDCTL_NISO               /*!< BOSCH mode */


/* CAN FD frame flag */
#define CAN_FDF_CLASSIC                    (0U)                         /*!< classical frames */
#define CAN_FDF_FDFRAME                    (1U)                         /*!< FD frames */

/* bit rate of data switch */
#define CAN_BRS_DISABLE                    (0U)                         /*!< bit rate not switch */
#define CAN_BRS_ENABLE                     (1U)                         /*!< the bit rate shall be switched */

/* error status indicator */
#define CAN_ESI_DOMINANT                   (0U)                         /*!< transmit the dominant bit in ESI phase */
#define CAN_ESI_RECESSIVE                  (1U)                         /*!< transmit the recessive bit in ESI phase */

/* CAN timeout */
#define CAN_TIMEOUT                        ((uint32_t)0x0000FFFFU)      /*!< timeout value */

/* CAN maibox empty status mask */
#define CAN_ALL_MAILBOX_EMPTY              ((uint32_t)0x1C000000U)      /*!< CAN maibox empty status mask */

/* interrupt enable bits */
#define CAN_INT_TME                        CAN_INTEN_TMEIE              /*!< transmit mailbox empty interrupt enable */
#define CAN_INT_RFNE0                      CAN_INTEN_RFNEIE0            /*!< receive FIFO0 not empty interrupt enable */
#define CAN_INT_RFF0                       CAN_INTEN_RFFIE0             /*!< receive FIFO0 full interrupt enable */
#define CAN_INT_RFO0                       CAN_INTEN_RFOIE0             /*!< receive FIFO0 overfull interrupt enable */
#define CAN_INT_RFNE1                      CAN_INTEN_RFNEIE1            /*!< receive FIFO1 not empty interrupt enable */
#define CAN_INT_RFF1                       CAN_INTEN_RFFIE1             /*!< receive FIFO1 full interrupt enable */
#define CAN_INT_RFO1                       CAN_INTEN_RFOIE1             /*!< receive FIFO1 overfull interrupt enable */
#define CAN_INT_WERR                       CAN_INTEN_WERRIE             /*!< warning error interrupt enable */
#define CAN_INT_PERR                       CAN_INTEN_PERRIE             /*!< passive error interrupt enable */
#define CAN_INT_BO                         CAN_INTEN_BOIE               /*!< bus-off interrupt enable */
#define CAN_INT_ERRN                       CAN_INTEN_ERRNIE             /*!< error number interrupt enable */
#define CAN_INT_ERR                        CAN_INTEN_ERRIE              /*!< error interrupt enable */
#define CAN_INT_WAKEUP                     CAN_INTEN_WIE                /*!< wakeup interrupt enable */
#define CAN_INT_SLPW                       CAN_INTEN_SLPWIE             /*!< sleep working interrupt enable */

/* function declarations */
/* deinitialize CAN */
void can_deinit(uint32_t can_periph);
/* initialize CAN struct */
void can_struct_para_init(can_struct_type_enum type, void* p_struct);
/* initialize CAN */
ErrStatus can_init(uint32_t can_periph, can_parameter_struct* can_parameter_init);
/* initialize CAN FD function */
ErrStatus can_fd_init(uint32_t can_periph, can_fdframe_struct* can_fdframe_init);
/* CAN filter init */
void can_filter_init(can_filter_parameter_struct* can_filter_parameter_init);
/* CAN filter mask mode initialization */
void can_filter_mask_mode_init(uint32_t id, uint32_t mask, can_format_fifo_enum format_fifo, uint16_t filter_number);
/* CAN communication mode configure */
ErrStatus can_monitor_mode_set(uint32_t can_periph, uint8_t mode);
/* CAN FD frame function enable */
void can_fd_function_enable(uint32_t can_periph);
/* CAN FD frame function disable */
void can_fd_function_disable(uint32_t can_periph);

/* set can1 fliter start bank number */
void can1_filter_start_bank(uint8_t start_bank);
/* enable functions */
/* CAN debug freeze enable */
void can_debug_freeze_enable(uint32_t can_periph);
/* CAN debug freeze disable */
void can_debug_freeze_disable(uint32_t can_periph);
/* CAN time trigger mode enable */
void can_time_trigger_mode_enable(uint32_t can_periph);
/* CAN time trigger mode disable */
void can_time_trigger_mode_disable(uint32_t can_periph);

/* transmit CAN message */
uint8_t can_message_transmit(uint32_t can_periph, can_trasnmit_message_struct* transmit_message);
/* get CAN transmit state */
can_transmit_state_enum can_transmit_states(uint32_t can_periph, uint8_t mailbox_number);
/* stop CAN transmission */
ErrStatus can_transmission_stop(uint32_t can_periph, uint8_t mailbox_number);
/* CAN receive message */
void can_message_receive(uint32_t can_periph, uint8_t fifo_number, can_receive_message_struct* receive_message);
/* CAN release fifo */
void can_fifo_release(uint32_t can_periph, uint8_t fifo_number);
/* CAN receive message length */
uint8_t can_receive_message_length_get(uint32_t can_periph, uint8_t fifo_number);
/* CAN working mode */
ErrStatus can_working_mode_set(uint32_t can_periph, uint8_t working_mode);
/* CAN wakeup from sleep mode */
ErrStatus can_wakeup(uint32_t can_periph);

/* CAN get error */
can_error_enum can_error_get(uint32_t can_periph);
/* get CAN receive error number */
uint8_t can_receive_error_number_get(uint32_t can_periph);
/* get CAN transmit error number */
uint8_t can_transmit_error_number_get(uint32_t can_periph);

/* CAN interrupt enable */
void can_interrupt_enable(uint32_t can_periph, uint32_t interrupt);
/* CAN interrupt disable */
void can_interrupt_disable(uint32_t can_periph, uint32_t interrupt);
/* CAN get flag state */
FlagStatus can_flag_get(uint32_t can_periph, can_flag_enum flag);
/* CAN clear flag state */
void can_flag_clear(uint32_t can_periph, can_flag_enum flag);
/* CAN get interrupt flag state */
FlagStatus can_interrupt_flag_get(uint32_t can_periph, can_interrupt_flag_enum flag);
/* CAN clear interrupt flag state */
void can_interrupt_flag_clear(uint32_t can_periph, can_interrupt_flag_enum flag);
#ifdef GD32C103XXA
FlagStatus can_fifo_overrun_flag_get(uint32_t can_periph, uint8_t fifo_number);
#endif /* GD32C103XXA */

#endif /* GD32C10X_CAN_H */
