﻿param(
    [string]$Version = "1.0.0"
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

& ".\tools\check_u12_bootloader_fresh.ps1"

Write-Host "Generate combined factory hex..."
python ".\tools\make_u12_factory_image.py" --version $Version
if ($LASTEXITCODE -ne 0) {
    throw "Factory image generation failed: $LASTEXITCODE"
}

exit 0

