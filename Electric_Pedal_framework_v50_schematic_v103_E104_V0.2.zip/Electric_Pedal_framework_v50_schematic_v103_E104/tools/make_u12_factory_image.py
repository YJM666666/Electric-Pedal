﻿#!/usr/bin/env python3
"""
生成 U12 出厂整片烧录镜像。

输入:
  1. bootloader hex/bin, 地址从 0x08000000 开始
  2. app hex 或 app bin, 应用向量表链接地址为 0x08004040

输出:
  1. packed app bin: [64B boot_image_header_t][app payload]
  2. factory hex: bootloader + packed app, 可一次烧录到内部 Flash
"""

import argparse
import pathlib
import struct
import sys
import zlib

BOOT_IMAGE_MAGIC = 0x4150503A
BOOT_IMAGE_VERSION = 0x0001
BOOT_IMAGE_TARGET_U12 = 0x12
BOOT_IMAGE_HEADER_LEN = 64
U12_BOOT_BASE = 0x08000000
U12_APP_VECTOR_BASE = 0x08004040
U12_APP_SLOT_A_BASE = 0x08004000
U12_APP_SLOT_SIZE = 0x0000E000


def parse_version(text):
    parts = text.split(".")
    if len(parts) != 3:
        raise ValueError("版本号格式应为 major.minor.patch, 例如 1.0.0")
    major, minor, patch = (int(p) for p in parts)
    if not (0 <= major <= 255 and 0 <= minor <= 255 and 0 <= patch <= 65535):
        raise ValueError("版本号范围应为 major/minor 0~255, patch 0~65535")
    return (major << 24) | (minor << 16) | patch


def crc32(data):
    return zlib.crc32(data) & 0xFFFFFFFF


def pack_app_image(app_payload, fw_version):
    if not app_payload:
        raise ValueError("应用 payload 为空")
    total_size = BOOT_IMAGE_HEADER_LEN + len(app_payload)
    if total_size > U12_APP_SLOT_SIZE:
        raise ValueError(f"应用镜像超出 slot A: {total_size} > {U12_APP_SLOT_SIZE} bytes")

    image_crc = crc32(app_payload)
    header_no_crc = struct.pack(
        "<IHBB" + "I" * 13,
        BOOT_IMAGE_MAGIC,
        BOOT_IMAGE_VERSION,
        BOOT_IMAGE_TARGET_U12,
        0,
        len(app_payload),
        image_crc,
        fw_version,
        0,
        0, 0, 0, 0, 0, 0, 0, 0, 0,
    )
    if len(header_no_crc) != (BOOT_IMAGE_HEADER_LEN - 4):
        raise AssertionError(f"镜像头长度异常: {len(header_no_crc)}")
    return header_no_crc + struct.pack("<I", crc32(header_no_crc)) + app_payload


def parse_ihex(path):
    memory = {}
    upper = 0
    with open(path, "r", encoding="ascii", errors="strict") as f:
        for line_no, raw in enumerate(f, 1):
            line = raw.strip()
            if not line:
                continue
            if not line.startswith(":"):
                raise ValueError(f"{path}:{line_no}: HEX 行缺少 ':'")
            data = bytes.fromhex(line[1:])
            count = data[0]
            addr16 = (data[1] << 8) | data[2]
            rectype = data[3]
            payload = data[4:4 + count]
            checksum = data[4 + count]
            if ((sum(data[:-1]) + checksum) & 0xFF) != 0:
                raise ValueError(f"{path}:{line_no}: HEX 校验和错误")

            if rectype == 0x00:
                base = upper + addr16
                for i, b in enumerate(payload):
                    memory[base + i] = b
            elif rectype == 0x01:
                break
            elif rectype == 0x04:
                if count != 2:
                    raise ValueError(f"{path}:{line_no}: 扩展线性地址长度错误")
                upper = ((payload[0] << 8) | payload[1]) << 16
            elif rectype == 0x05:
                pass
            else:
                raise ValueError(f"{path}:{line_no}: 暂不支持 HEX 记录类型 {rectype}")
    return memory


def parse_bin(path, base_addr):
    data = pathlib.Path(path).read_bytes()
    if not data:
        raise ValueError(f"{path} 为空")
    return {base_addr + offset: value for offset, value in enumerate(data)}


def app_payload_from_hex(path, base_addr):
    memory = parse_ihex(path)
    app_addrs = [addr for addr in memory if addr >= base_addr]
    if not app_addrs:
        raise ValueError(f"HEX 中找不到应用区: 0x{base_addr:08X}")
    end_addr = max(app_addrs) + 1
    for addr in range(base_addr, end_addr):
        if addr not in memory:
            raise ValueError(f"应用 HEX 地址不连续，首个空洞: 0x{addr:08X}")
    return bytes(memory[addr] for addr in range(base_addr, end_addr))


def make_record(addr16, rectype, payload):
    count = len(payload)
    body = bytes([count, (addr16 >> 8) & 0xFF, addr16 & 0xFF, rectype]) + payload
    checksum = ((~sum(body) + 1) & 0xFF)
    return ":" + (body + bytes([checksum])).hex().upper()


def write_ihex(path, memory, start_addr=U12_BOOT_BASE, line_bytes=16):
    addresses = sorted(memory)
    current_upper = None
    lines = []
    i = 0
    while i < len(addresses):
        addr = addresses[i]
        upper = addr >> 16
        if upper != current_upper:
            current_upper = upper
            lines.append(make_record(0, 0x04, bytes([(upper >> 8) & 0xFF, upper & 0xFF])))

        chunk_addr = addr
        chunk = bytearray()
        while i < len(addresses):
            a = addresses[i]
            if a != chunk_addr + len(chunk):
                break
            if (a >> 16) != current_upper:
                break
            if len(chunk) >= line_bytes:
                break
            chunk.append(memory[a])
            i += 1
        lines.append(make_record(chunk_addr & 0xFFFF, 0x00, bytes(chunk)))

    lines.append(make_record(0, 0x05, struct.pack(">I", start_addr)))
    lines.append(make_record(0, 0x01, b""))
    pathlib.Path(path).write_text("\n".join(lines) + "\n", encoding="ascii")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--boot-hex", default="Objects/Boot/Electric_Pedal_U12_Bootloader.hex")
    ap.add_argument("--boot-bin", default="Objects/Boot/Electric_Pedal_U12_Bootloader.bin")
    ap.add_argument("--app-hex", default="Objects/U12/Electric_Pedal_U12.hex")
    ap.add_argument("--app-bin", default="Objects/U12/Electric_Pedal_U12.bin")
    ap.add_argument("--packed-bin", default="Objects/U12/Electric_Pedal_U12_packed.bin")
    ap.add_argument("--factory-hex", default="Objects/U12/Electric_Pedal_U12_factory.hex")
    ap.add_argument("--version", default="1.0.0")
    args = ap.parse_args()

    fw_version = parse_version(args.version)
    app_hex = pathlib.Path(args.app_hex)
    if app_hex.exists():
        app_payload = app_payload_from_hex(args.app_hex, U12_APP_VECTOR_BASE)
        app_source = args.app_hex
    else:
        app_payload = pathlib.Path(args.app_bin).read_bytes()
        app_source = args.app_bin
    packed = pack_app_image(app_payload, fw_version)
    pathlib.Path(args.packed_bin).write_bytes(packed)

    boot_hex = pathlib.Path(args.boot_hex)
    boot_bin = pathlib.Path(args.boot_bin)
    if boot_hex.exists():
        memory = parse_ihex(args.boot_hex)
        boot_source = args.boot_hex
    elif boot_bin.exists():
        memory = parse_bin(args.boot_bin, U12_BOOT_BASE)
        boot_source = f"{args.boot_bin} @ 0x{U12_BOOT_BASE:08X}"
    else:
        raise FileNotFoundError(f"找不到 bootloader 输出: {args.boot_hex} 或 {args.boot_bin}")

    for offset, value in enumerate(packed):
        addr = U12_APP_SLOT_A_BASE + offset
        if addr in memory:
            raise ValueError(f"地址重叠: 0x{addr:08X}")
        memory[addr] = value
    write_ihex(args.factory_hex, memory)

    print("U12 factory image generated")
    print(f"  boot source:  {boot_source}")
    print(f"  app source:   {app_source}")
    print(f"  packed bin:   {args.packed_bin}")
    print(f"  factory hex:  {args.factory_hex}")
    print(f"  version:      {args.version} (0x{fw_version:08X})")
    print(f"  app payload:  {len(app_payload)} bytes")
    print(f"  packed app:   {len(packed)} bytes @ 0x{U12_APP_SLOT_A_BASE:08X}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
