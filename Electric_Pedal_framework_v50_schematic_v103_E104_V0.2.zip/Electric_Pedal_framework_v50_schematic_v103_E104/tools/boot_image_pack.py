﻿#!/usr/bin/env python3
"""
boot_image_pack.py
------------------
鎶?Keil/IAR 缂栬瘧鍑烘潵鐨勫簲鐢?.bin 鍖呰鎴?bootloader 鍙瘑鍒殑 OTA 闀滃儚銆?

杈撳叆: 搴旂敤瑁?.bin (浠庝腑鏂悜閲忚〃寮€濮?
杈撳嚭: [boot_image_header_t (64B)][app payload]

Header 瀛楁蹇呴』涓?boot/boot_image.h 涓ユ牸涓€鑷?
    uint32_t magic         = 'APP:' = 0x4150503A   (LE)
    uint16_t version       = 0x0001
    uint8_t  target_mcu    = 0x12 (U12) / 0x17 (U17)
    uint8_t  reserved0     = 0
    uint32_t image_size    = len(payload)
    uint32_t image_crc32   = CRC32(payload)
    uint32_t fw_version    = e.g. 0x00010203
    uint32_t entry_offset  = 0
    uint32_t reserved1[9]  = {0}
    uint32_t header_crc32  = CRC32(鍓?60 瀛楄妭)

CRC32 = IEEE 802.3 (poly=0xEDB88320, init=0xFFFFFFFF, refIn/refOut, xorOut=0xFFFFFFFF).

鐢ㄦ硶:
    python boot_image_pack.py app.bin app_packed.bin --target u12 --version 1.2.3
"""

import argparse
import struct
import sys
import zlib

MAGIC = 0x4150503A
VERSION = 0x0001
TARGET_U12 = 0x12
TARGET_U17 = 0x17
HEADER_LEN = 64


def parse_version(text):
    parts = text.split(".")
    if len(parts) != 3:
        raise ValueError("version must be major.minor.patch")
    major, minor, patch = (int(p) for p in parts)
    if not (0 <= major <= 255 and 0 <= minor <= 255 and 0 <= patch <= 65535):
        raise ValueError("version components out of range")
    return (major << 24) | (minor << 16) | patch


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", help="application bin file")
    ap.add_argument("output", help="packed image output path")
    ap.add_argument("--target", choices=["u12", "u17"], default="u12")
    ap.add_argument("--version", required=True, help="firmware version, e.g. 1.2.3")
    args = ap.parse_args()

    with open(args.input, "rb") as f:
        payload = f.read()

    if not payload:
        print("ERROR: empty input", file=sys.stderr)
        sys.exit(1)

    target_mcu = TARGET_U12 if args.target == "u12" else TARGET_U17
    fw_version = parse_version(args.version)
    image_size = len(payload)
    image_crc32 = zlib.crc32(payload) & 0xFFFFFFFF

    # 鎵撳寘 header 鍓?60 瀛楄妭, 鏈熬 4 瀛楄妭鏄?header_crc32
    header_no_crc = struct.pack(
        "<IHBB" + "I" * 13,
        MAGIC,
        VERSION,
        target_mcu,
        0,            # reserved0
        image_size,
        image_crc32,
        fw_version,
        0,            # entry_offset
        0, 0, 0, 0, 0, 0, 0, 0, 0,  # reserved1[9]
    )
    assert len(header_no_crc) == HEADER_LEN - 4, f"unexpected header len {len(header_no_crc)}"
    header_crc32 = zlib.crc32(header_no_crc) & 0xFFFFFFFF

    header = header_no_crc + struct.pack("<I", header_crc32)
    assert len(header) == HEADER_LEN

    with open(args.output, "wb") as f:
        f.write(header)
        f.write(payload)

    print(f"packed image -> {args.output}")
    print(f"  target:        {args.target}")
    print(f"  version:       {args.version} (0x{fw_version:08X})")
    print(f"  payload size:  {image_size} bytes")
    print(f"  payload crc32: 0x{image_crc32:08X}")
    print(f"  header crc32:  0x{header_crc32:08X}")
    print(f"  total size:    {len(header) + len(payload)} bytes")


if __name__ == "__main__":
    main()

