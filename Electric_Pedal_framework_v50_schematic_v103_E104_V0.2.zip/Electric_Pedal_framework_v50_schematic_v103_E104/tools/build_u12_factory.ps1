﻿param(
    [string]$Version = "1.0.0",
    [string]$Keil = "D:\Keil_v5\UV4\UV4.exe"
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

Write-Host "Build U12 bootloader..."
& $Keil -b "PowerStep_Bootloader_U12.uvprojx"
if ($LASTEXITCODE -ne 0) {
    throw "Bootloader build failed: $LASTEXITCODE"
}

Write-Host "Build U12 application..."
& $Keil -b "PowerStep_Controller_U12.uvprojx"
if ($LASTEXITCODE -ne 0) {
    throw "Application build failed: $LASTEXITCODE"
}

Write-Host "Generate combined factory hex..."
python ".\tools\make_u12_factory_image.py" --version $Version
if ($LASTEXITCODE -ne 0) {
    throw "Factory image generation failed: $LASTEXITCODE"
}

Write-Host ""
Write-Host "Done."
Write-Host "Factory HEX: Objects\U12\Electric_Pedal_U12_factory.hex"
