@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File ".\tools\build_u12_bootloader_target.ps1"
if errorlevel 1 exit /b 1
exit /b 0
