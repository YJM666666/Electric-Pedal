﻿param(
    [switch]$AllowMissing
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

$bootOutputs = @(
    ".\Objects\Boot\Electric_Pedal_U12_Bootloader.hex",
    ".\Objects\Boot\Electric_Pedal_U12_Bootloader.bin"
)

$existingOutputs = @($bootOutputs | Where-Object { Test-Path -LiteralPath $_ })
if ($existingOutputs.Count -eq 0) {
    $msg = "U12 bootloader output not found. Build PowerStep_Bootloader_U12.uvprojx once before building the factory image."
    if ($AllowMissing) {
        Write-Warning $msg
        exit 0
    }
    throw $msg
}

$newestOutput = $existingOutputs |
    ForEach-Object { Get-Item -LiteralPath $_ } |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1

$sourceRoots = @(
    ".\boot",
    ".\bsp",
    ".\config",
    ".\local_include",
    ".\vendor\GD32C10x_Firmware_Library_V1.7.0\Firmware\CMSIS",
    ".\vendor\GD32C10x_Firmware_Library_V1.7.0\Firmware\GD32C10x_standard_peripheral"
)

$sourceFiles = @()
foreach ($dir in $sourceRoots) {
    if (Test-Path -LiteralPath $dir) {
        $sourceFiles += Get-ChildItem -LiteralPath $dir -Recurse -File -Include *.c,*.h,*.s,*.sct
    }
}

$extraFiles = @(".\startup_gd32c10x_ac6.c", ".\system_gd32c10x.c", ".\Electric_Pedal_U12_boot.sct", ".\PowerStep_Bootloader_U12.uvprojx")
foreach ($file in $extraFiles) {
    if (Test-Path -LiteralPath $file) {
        $sourceFiles += Get-Item -LiteralPath $file
    }
}

$generatedNames = @("bootloader_blob.c", "bootloader_blob.inc")
$newerSources = @($sourceFiles | Where-Object { ($generatedNames -notcontains $_.Name) -and ($_.LastWriteTime -gt $newestOutput.LastWriteTime) })
if ($newerSources.Count -gt 0) {
    $latest = $newerSources | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    throw "U12 bootloader is stale. Rebuild PowerStep_Bootloader_U12.uvprojx first. Newer file: $($latest.FullName)"
}

Write-Host "U12 bootloader is up to date: $($newestOutput.Name)"
exit 0
