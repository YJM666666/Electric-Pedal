@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File ".\tools\postbuild_u12_factory.ps1" -Version 1.0.0
if errorlevel 1 exit /b 1
exit /b 0
