﻿param(
    [string]$Project = ".\PowerStep_Bootloader_U12.uvprojx",
    [string]$Target = "U12_Bootloader"
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

function Update-BootloaderBlob {
    $bootBin = ".\Objects\Boot\Electric_Pedal_U12_Bootloader.bin"
    $blobInc = ".\boot\bootloader_blob.inc"
    if (-not (Test-Path -LiteralPath $bootBin)) {
        throw "Bootloader bin not found: $bootBin"
    }

    $bytes = [System.IO.File]::ReadAllBytes((Resolve-Path -LiteralPath $bootBin))
    if ($bytes.Length -gt 0x4000) {
        throw "Bootloader image is larger than 16KB: $($bytes.Length) bytes"
    }

    $needUpdate = -not (Test-Path -LiteralPath $blobInc)
    if (-not $needUpdate) {
        $blob = Get-Item -LiteralPath $blobInc
        $bin = Get-Item -LiteralPath $bootBin
        $needUpdate = $blob.LastWriteTime -lt $bin.LastWriteTime
    }

    if ($needUpdate) {
        $lines = New-Object System.Collections.Generic.List[string]
        for ($i = 0; $i -lt $bytes.Length; $i += 16) {
            $end = [Math]::Min($i + 15, $bytes.Length - 1)
            $chunk = for ($j = $i; $j -le $end; $j++) { "0x{0:X2}" -f $bytes[$j] }
            $lines.Add("    " + ($chunk -join ", ") + ",")
        }
        [System.IO.File]::WriteAllText((Join-Path $Root $blobInc), ($lines -join [Environment]::NewLine) + [Environment]::NewLine, [System.Text.Encoding]::ASCII)
        Write-Host "Generated bootloader blob include: $blobInc ($($bytes.Length) bytes)"
    } else {
        Write-Host "Bootloader blob include is up to date."
    }
}

$needsBuild = $false
try {
    & ".\tools\check_u12_bootloader_fresh.ps1"
} catch {
    $needsBuild = $true
    Write-Host $_.Exception.Message
}

if ($needsBuild) {
    $keilCandidates = @(
        "D:\Keil_v5\UV4\UV4.com",
        "C:\Keil_v5\UV4\UV4.com",
        "D:\Keil_v5\UV4\UV4.exe",
        "C:\Keil_v5\UV4\UV4.exe"
    )

    $keil = $keilCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    if (-not $keil) {
        throw "Keil UV4.com/UV4.exe not found. Please update tools\build_u12_bootloader_target.ps1."
    }

    if (-not (Test-Path -LiteralPath $Project)) {
        throw "Bootloader project not found: $Project"
    }

    $log = ".\Objects\Boot\U12_Bootloader_from_main.log"
    New-Item -ItemType Directory -Force -Path ".\Objects\Boot" | Out-Null

    Write-Host "Build U12_Bootloader first..."
    $args = @("-b", $Project, "-t", $Target, "-o", $log)
    $proc = Start-Process -FilePath $keil -ArgumentList $args -Wait -PassThru -WindowStyle Hidden
    if ($proc.ExitCode -ne 0) {
        if (Test-Path -LiteralPath $log) {
            Get-Content -LiteralPath $log | Select-Object -Last 120
        }
        throw "U12_Bootloader build failed: $($proc.ExitCode)"
    }

    & ".\tools\check_u12_bootloader_fresh.ps1"
} else {
    Write-Host "Skip U12_Bootloader build; existing output is fresh."
}

Update-BootloaderBlob
exit 0
