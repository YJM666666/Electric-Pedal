#include <assert.h>
#include "project_bool.h"
#include <stdint.h>
#include <stdio.h>

#include "event.h"
#include "sw_timer.h"
#include "fault.h"
#include "drv_motor.h"
#include "drv_light.h"
#include "drv_nvm.h"
#include "param.h"
#include "current_guard.h"
#include "can_if.h"
#include "ble_if.h"
#include "u17_link.h"
#include "bsp_gpio.h"
#include "bsp_adc.h"
#include "bsp_uart.h"
#include "bsp_can.h"
#include "bsp_wdg.h"
#include "bsp_timer.h"
#include "u17_slave/service/u12_u17_slave_link.h"

static void init_master(void)
{
    event_init();
    sw_timer_init();
    bsp_gpio_init();
    bsp_adc_init();
    bsp_uart_init();
    bsp_can_init();
    bsp_wdg_init();
    bsp_timer_init();
    fault_init();
    assert(drv_nvm_init());
    param_init();
    current_guard_init();
    drv_motor_init();
    drv_light_init();
    can_if_init();
    ble_if_init();
    u17_link_init();
}

static void bridge_master_to_slave(void)
{
    uint8_t buf[256];
    size_t len;

    len = bsp_uart_fetch_tx(BSP_UART_PORT_U17, buf, sizeof(buf));
    if (len > 0U) {
        u12_u17_slave_link_rx_bytes(buf, len);
    }
}

static void bridge_slave_to_master(void)
{
    uint8_t buf[256];
    size_t len;

    len = u12_u17_slave_link_fetch_tx(buf, sizeof(buf));
    if (len > 0U) {
        bsp_uart_rx_buf_isr(BSP_UART_PORT_U17, buf, len);
        u17_link_poll();
    }
}

static void service_link_once(void)
{
    bridge_master_to_slave();
    u12_u17_slave_link_tick_10ms();
    bridge_slave_to_master();
}

int main(void)
{
    u17_remote_status_t remote;
    u17_exec_status_t slave_st;

    init_master();
    u12_u17_slave_link_init();

    u17_link_tick_10ms();
    service_link_once();
    u17_link_get_remote_status(&remote);
    assert(remote.boot_seen == true);
    assert(remote.slave_ready == true);

    drv_motor_exec(STEP_SIDE_LEFT, STEP_ACT_EXTEND);
    assert(bsp_gpio_read_out(BSP_GPIO_OUT_L_MOTOR_A) == true);
    assert(bsp_gpio_read_out(BSP_GPIO_OUT_L_MOTOR_B) == false);

    /* 有刷电机的限位/电流信息不再由 U17 提供。 */

    drv_light_apply_scene(LIGHT_SCENE_WELCOME);
    service_link_once();
    u12_u17_slave_link_get_status(&slave_st);
    assert(slave_st.light_enabled == true);
    assert(slave_st.active_light_cfg.r == param_get()->light_welcome.r);

    assert(u17_link_request_voice(0U, 2U, false));
    service_link_once();
    u12_u17_slave_link_get_status(&slave_st);
    assert(slave_st.voice_busy == true);

    for (uint32_t i = 0U; i < 5U; ++i) {
        u12_u17_slave_link_tick_10ms();
    }
    bridge_slave_to_master();
    u12_u17_slave_link_get_status(&slave_st);

    drv_motor_exec(STEP_SIDE_LEFT, STEP_ACT_STOP);
    assert(bsp_gpio_read_out(BSP_GPIO_OUT_L_MOTOR_A) == false);
    assert(bsp_gpio_read_out(BSP_GPIO_OUT_L_MOTOR_B) == false);

    printf("[OK] dual MCU protocol regression passed\n");
    return 0;
}
