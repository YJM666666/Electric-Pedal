/*
 * 主机回归测试：在桌面环境模拟关键事件，覆盖策略、状态机和掉电恢复安全路径。
 */
#include <assert.h>
#include "project_bool.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "event.h"
#include "sys_sm.h"
#include "policy.h"
#include "sw_timer.h"
#include "fault.h"
#include "drv_motor.h"
#include "drv_light.h"
#include "drv_nvm.h"
#include "param.h"
#include "current_guard.h"
#include "can_if.h"
#include "ble_if.h"
#include "u17_link.h"
#include "scheduler.h"
#include "app_proto_v2.h"
#include "ota_service.h"
#include "u17_slave/service/u12_u17_slave_link.h"
#include "bsp_gpio.h"
#include "bsp_adc.h"
#include "bsp_uart.h"
#include "bsp_can.h"
#include "bsp_wdg.h"
#include "bsp_timer.h"

static void init_all(void)
{
    event_init();
    sw_timer_init();
    bsp_gpio_init();
    bsp_adc_init();
    bsp_uart_init();
    bsp_can_init();
    bsp_wdg_init();
    bsp_timer_init();
    fault_init();
    assert(drv_nvm_init());
    param_init();
    current_guard_init();
    drv_motor_init();
    drv_light_init();
    can_if_init();
    ble_if_init();
    u17_link_init();
    u12_u17_slave_link_init();
    sys_sm_init();
    policy_init();
    scheduler_init();
    policy_update_mode(SYS_NORMAL);
}

static void pump_queue(void)
{
    scheduler_run_all();
}

static void dispatch_event(event_id_t id, event_source_t src, uint32_t param)
{
    event_t ev;
    ev.id = id;
    ev.source = src;
    ev.param_u32 = param;
    ev.param_ptr = 0;
    scheduler_dispatch_event(&ev);
    pump_queue();
}

static void inject_can_speed_below_8(void)
{
    can_frame_t frm;

    memset(&frm, 0, sizeof(frm));
    frm.id = param_get()->speed_signal.module_id;
    frm.dlc = 8U;
    assert(can_if_rx_isr_push(&frm));
    scheduler_poll_inputs();
    pump_queue();
}

static void inject_can_fl_door_open(void)
{
    can_frame_t frm;
    const system_param_t *param = param_get();

    memset(&frm, 0, sizeof(frm));
    frm.id = param->door_signal[DOOR_POS_FL].module_id;
    frm.dlc = 8U;
    frm.data[param->door_signal[DOOR_POS_FL].group_no] =
        (uint8_t)(1U << param->door_signal[DOOR_POS_FL].bit_no);
    assert(can_if_rx_isr_push(&frm));
    scheduler_poll_inputs();
    pump_queue();
}

static void advance_recovery_can_stability(void)
{
    dispatch_event(EV_TICK_100MS, EV_SRC_TIMER, 0U);
    dispatch_event(EV_TICK_100MS, EV_SRC_TIMER, 0U);
}

static void bridge_master_to_slave(void)
{
    uint8_t buf[256];
    size_t len;

    len = bsp_uart_fetch_tx(BSP_UART_PORT_U17, buf, sizeof(buf));
    if (len > 0U) {
        u12_u17_slave_link_rx_bytes(buf, len);
    }
}

static void bridge_slave_to_master(void)
{
    uint8_t buf[256];
    size_t len;

    len = u12_u17_slave_link_fetch_tx(buf, sizeof(buf));
    if (len > 0U) {
        bsp_uart_rx_buf_isr(BSP_UART_PORT_U17, buf, len);
        u17_link_poll();
    }
}

static void service_link_once(void)
{
    bridge_master_to_slave();
    u12_u17_slave_link_tick_10ms();
    bridge_slave_to_master();
}

static bool ble_exchange(uint8_t cmd,
                         uint8_t seq,
                         const uint8_t *payload,
                         uint8_t len,
                         app_proto_v2_frame_t *reply)
{
    uint8_t frame[APP_PROTO_V2_MAX_FRAME];
    uint8_t rx[APP_PROTO_V2_MAX_FRAME];
    uint16_t frame_len = 0U;
    size_t rx_len;
    size_t i;
    app_proto_v2_parser_t parser;
    app_proto_v2_frame_t parsed;
    bool ready = false;

    assert(app_proto_v2_build(cmd, seq, 0x00U, payload, len, frame, &frame_len));
    bsp_uart_clear_tx(BSP_UART_PORT_BLE);
    ble_if_rx_buf_isr(frame, frame_len);
    ble_if_poll();
    rx_len = bsp_uart_fetch_tx(BSP_UART_PORT_BLE, rx, sizeof(rx));
    if (rx_len == 0U) {
        return false;
    }

    app_proto_v2_parser_init(&parser);
    for (i = 0U; i < rx_len; ++i) {
        assert(app_proto_v2_feed(&parser, rx[i], &parsed, &ready));
    }
    if (!ready) {
        return false;
    }
    if (reply != 0) {
        *reply = parsed;
    }
    return true;
}

static bool parse_ble_frame(const uint8_t *rx, size_t rx_len, app_proto_v2_frame_t *reply)
{
    app_proto_v2_parser_t parser;
    app_proto_v2_frame_t parsed;
    bool ready = false;
    size_t i;

    app_proto_v2_parser_init(&parser);
    for (i = 0U; i < rx_len; ++i) {
        assert(app_proto_v2_feed(&parser, rx[i], &parsed, &ready));
    }
    if (!ready) {
        return false;
    }
    if (reply != 0) {
        *reply = parsed;
    }
    return true;
}

static void ble_send_no_reply(uint8_t cmd, uint8_t seq, const uint8_t *payload, uint8_t len)
{
    uint8_t frame[APP_PROTO_V2_MAX_FRAME];
    uint16_t frame_len = 0U;

    assert(app_proto_v2_build(cmd, seq, 0x00U, payload, len, frame, &frame_len));
    bsp_uart_clear_tx(BSP_UART_PORT_BLE);
    ble_if_rx_buf_isr(frame, frame_len);
    ble_if_poll();
}

static bool ble_fetch_tx_frame(app_proto_v2_frame_t *reply)
{
    uint8_t rx[APP_PROTO_V2_MAX_FRAME];
    size_t rx_len;

    rx_len = bsp_uart_fetch_tx(BSP_UART_PORT_BLE, rx, sizeof(rx));
    if (rx_len == 0U) {
        return false;
    }
    return parse_ble_frame(rx, rx_len, reply);
}

static bool ble_tick_and_fetch_event(app_proto_v2_frame_t *reply)
{
    bsp_uart_clear_tx(BSP_UART_PORT_BLE);
    ble_if_tick_100ms();
    return ble_fetch_tx_frame(reply);
}

static void ble_ack_event(uint8_t event_id, uint8_t event_seq)
{
    uint8_t payload[3] = {event_id, event_seq, 0x00U};
    ble_send_no_reply(APP_CMD_EVT_ACK, 0xA0U, payload, sizeof(payload));
}

static uint16_t test_crc16_ibm(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFFU;
    uint16_t i;
    uint8_t bit;

    for (i = 0U; i < len; ++i) {
        crc ^= (uint16_t)data[i];
        for (bit = 0U; bit < 8U; ++bit) {
            if ((crc & 0x0001U) != 0U) {
                crc = (uint16_t)((crc >> 1U) ^ 0xA001U);
            } else {
                crc >>= 1U;
            }
        }
    }
    return crc;
}

static uint32_t test_crc32(const uint8_t *data, uint32_t len)
{
    uint32_t crc = 0xFFFFFFFFUL;
    uint32_t i;
    uint32_t j;

    for (i = 0U; i < len; ++i) {
        crc ^= (uint32_t)data[i];
        for (j = 0U; j < 8U; ++j) {
            if ((crc & 1UL) != 0UL) {
                crc = (crc >> 1U) ^ 0xEDB88320UL;
            } else {
                crc >>= 1U;
            }
        }
    }
    return ~crc;
}

static void test_ble_atomic_commit(void)
{
    uint8_t frame[APP_PROTO_V2_MAX_FRAME];
    uint8_t bad_frame[APP_PROTO_V2_MAX_FRAME];
    uint16_t frame_len = 0U;
    uint16_t bad_frame_len = 0U;
    uint8_t payload[13] = {1U, 15U, 1U, 2U, 0U, 1U, 0x01U, 0U, 0U, 0U, 1U, 0U, 0U};
    uint8_t bad_payload[13] = {1U, 15U, 1U, 9U, 0U, 1U, 0x01U, 0U, 0U, 0U, 1U, 0U, 0U};
    const system_param_t *param;

    assert(app_proto_v2_build(0x03U, 0x01U, 0x00U, payload, sizeof(payload), frame, &frame_len));
    ble_if_rx_buf_isr(frame, frame_len);
    ble_if_poll();
    param = param_get();
    assert(param->welcome_enable == true);
    assert(param->welcome_hold_seconds == 15U);
    assert(param->anti_pinch_level == 2U);
    assert(param->hand_drive == HAND_DRIVE_LEFT);

    assert(app_proto_v2_build(0x03U, 0x02U, 0x00U, bad_payload, sizeof(bad_payload), bad_frame, &bad_frame_len));
    ble_if_rx_buf_isr(bad_frame, bad_frame_len);
    ble_if_poll();
    param = param_get();
    assert(param->anti_pinch_level == 2U);
}

static void test_welcome_and_limit_flow(void)
{
    policy_status_t st;

    dispatch_event(EV_KEY_UNLOCK, EV_SRC_CAN, 0U);
    st = policy_get_status();
    assert(st.left_state == STEP_STATE_EXTENDING);
    assert(st.right_state == STEP_STATE_EXTENDING);

    bsp_gpio_mock_set_in(BSP_GPIO_IN_L_EXT_LIMIT, true);
    bsp_gpio_mock_set_in(BSP_GPIO_IN_R_EXT_LIMIT, true);
    dispatch_event(EV_TICK_1MS, EV_SRC_TIMER, 0U);
    dispatch_event(EV_L_DONE, EV_SRC_TIMER, 0U);
    dispatch_event(EV_R_DONE, EV_SRC_TIMER, 0U);
    st = policy_get_status();
    assert(st.left_state == STEP_STATE_EXTENDED);
    assert(st.right_state == STEP_STATE_EXTENDED);

    dispatch_event(EV_KEY_LOCK, EV_SRC_CAN, 0U);
    st = policy_get_status();
    assert(st.left_state == STEP_STATE_RETRACTING);
    assert(st.right_state == STEP_STATE_RETRACTING);

    bsp_gpio_mock_set_in(BSP_GPIO_IN_L_RET_LIMIT, true);
    bsp_gpio_mock_set_in(BSP_GPIO_IN_R_RET_LIMIT, true);
    dispatch_event(EV_TICK_1MS, EV_SRC_TIMER, 0U);
    dispatch_event(EV_L_DONE, EV_SRC_TIMER, 0U);
    dispatch_event(EV_R_DONE, EV_SRC_TIMER, 0U);
    st = policy_get_status();
    assert(st.left_state == STEP_STATE_RETRACTED);
    assert(st.right_state == STEP_STATE_RETRACTED);
}

static void test_nvm_reinit_persistence(void)
{
    system_param_t candidate = *param_get();
    candidate.vehicle_code = 0x12345678UL;
    assert(param_commit(&candidate));
    param_periodic_1s();
    param_periodic_1s();
    param_init();
    assert(param_get()->vehicle_code == 0x12345678UL);
}

static void test_power_recovery_policy(void)
{
    drv_nvm_power_recovery_t rec;
    policy_status_t st;

    rec.last_side = STEP_SIDE_LEFT;
    rec.last_state = (uint8_t)STEP_STATE_EXTENDING;
    rec.last_action = STEP_ACT_EXTEND;
    assert(drv_nvm_write_power_recovery(&rec));

    init_all();
    st = policy_get_status();
    assert(st.left_state == STEP_STATE_INIT);

    dispatch_event(EV_POWER_RECOVERED, EV_SRC_SYSTEM, 0U);
    st = policy_get_status();
    assert(st.left_state == STEP_STATE_INIT);
    inject_can_speed_below_8();
    advance_recovery_can_stability();
    st = policy_get_status();
    assert(st.left_state == STEP_STATE_RETRACTING);
    assert(st.left_owner == STEP_OWNER_POWER_RECOVERY);

    rec.last_side = STEP_SIDE_LEFT;
    rec.last_state = (uint8_t)STEP_STATE_RETRACTING;
    rec.last_action = STEP_ACT_RETRACT;
    assert(drv_nvm_write_power_recovery(&rec));

    init_all();
    dispatch_event(EV_POWER_RECOVERED, EV_SRC_SYSTEM, 0U);
    inject_can_fl_door_open();
    advance_recovery_can_stability();
    st = policy_get_status();
    assert(st.left_state == STEP_STATE_INIT);

    rec.last_side = STEP_SIDE_LEFT;
    rec.last_state = (uint8_t)STEP_STATE_RETRACTED;
    rec.last_action = STEP_ACT_STOP;
    assert(drv_nvm_write_power_recovery(&rec));
}

static void test_event_overflow_latch(void)
{
    event_t ev;
    uint32_t i;

    event_init();
    for (i = 0U; i < 300U; ++i) {
        ev.id = EV_TICK_1MS;
        ev.source = EV_SRC_TIMER;
        ev.param_u32 = 0U;
        ev.param_ptr = 0;
        (void)event_push(&ev);
    }

    assert(event_has_overflowed());
    event_clear_overflow();
    assert(!event_has_overflowed());
}


static void test_factory_protocol_and_status_query(void)
{
    app_proto_v2_frame_t reply;
    uint8_t b1[10] = {0x20U, 0x06U, 0x05U, 0x05U, 0x01U, 0x20U, 0x06U, 0x02U, 0x02U, 0x01U};
    uint8_t b2[10] = {0x20U, 0x06U, 0x04U, 0x04U, 0x01U, 0x20U, 0x06U, 0x03U, 0x03U, 0x01U};
    uint8_t b5[10] = {0x60U, 0x02U, 0x01U, 0x02U, 0x01U, 0x60U, 0x02U, 0x01U, 0x03U, 0x01U};
    uint8_t b6[13] = {0x80U, 0x05U, 0x06U, 0x00U, 0x01U, 0x06U, 0x01U, 0x01U, 0x80U, 0x05U, 0x01U, 0x01U, 0x01U};
    uint8_t b7[14] = {0x20U, 0x02U, 0x03U, 0x00U, 0x01U, 0x70U, 0x06U, 0x04U, 0x02U, 0x01U, 0x20U, 0x03U, 0x06U, 0x03U};
    uint8_t b8[12] = {0x00U, 0x00U, 0x02U, 0x00U, 30U, 0x05U, 25U, 0x00U, 0x01U, 0x00U, 0x01U, 0x03U};
    uint8_t b9[22] = {
        100U, 0x00U, 110U, 0x00U, 120U, 0x00U, 130U, 0x00U,
        140U, 0x00U, 150U, 0x00U, 160U, 0x00U, 170U, 0x00U,
        0x58U, 0x02U, 20U, 0x3CU, 0x00U, 0x01U
    };
    can_frame_t frm;
    policy_status_t st;

    assert(ble_exchange(APP_CMD_FACTORY_B1, 0x11U, b1, sizeof(b1), &reply));
    assert(reply.status == APP_ST_OK && reply.payload[0] == 0U);
    assert(param_get()->door_signal[DOOR_POS_FL].module_id == 0x0620U);
    assert(param_get()->door_signal[DOOR_POS_RL].bit_no == 2U);
    assert(param_get()->factory_cmd_len[0] == sizeof(b1));

    assert(ble_exchange(APP_CMD_FACTORY_B2, 0x12U, b2, sizeof(b2), &reply));
    assert(reply.status == APP_ST_OK && reply.payload[0] == 0U);
    assert(param_get()->door_signal[DOOR_POS_FR].bit_no == 4U);
    assert(param_get()->door_signal[DOOR_POS_RR].bit_no == 3U);

    assert(ble_exchange(APP_CMD_FACTORY_B5, 0x12U, b5, sizeof(b5), &reply));
    assert(reply.status == APP_ST_OK && reply.payload[0] == 0U);
    assert(param_get()->headlamp_signal.module_id == 0x0260U);
    assert(param_get()->ignition_signal.bit_no == 3U);

    assert(ble_exchange(APP_CMD_FACTORY_B6, 0x13U, b6, sizeof(b6), &reply));
    assert(reply.status == APP_ST_OK && reply.payload[0] == 0U);
    assert(param_get()->left_turn_signal.module_id == 0x0580U);
    assert(param_get()->right_turn_signal.bit_no == 1U);
    assert(param_get()->hazard_signal.module_id == 0x0580U);

    assert(ble_exchange(APP_CMD_FACTORY_B7, 0x16U, b7, sizeof(b7), &reply));
    assert(reply.status == APP_ST_OK && reply.payload[0] == 0U);
    assert(param_get()->unlock_signal.module_id == 0x0670U);
    assert(param_get()->speed_signal.module_id == 0x0320U);
    assert(param_get()->speed_signal.hi_group_no == 6U);
    assert(param_get()->speed_signal.lo_group_no == 3U);

    assert(ble_exchange(APP_CMD_FACTORY_B8, 0x17U, b8, sizeof(b8), &reply));
    assert(reply.status == APP_ST_OK && reply.payload[0] == 0U);
    assert(param_get()->can_baud_code == 0x05U);
    assert(param_get()->main_switch_enable == true);
    assert(param_get()->sound_enable == true);
    assert(param_get()->anti_pinch_enable == true);
    assert(param_get()->anti_pinch_level == 3U);
    assert(param_get()->install_manual_switch == 0U);
    assert(param_get()->wash_function_switch == 0U);

    assert(ble_exchange(APP_CMD_FACTORY_B9, 0x18U, b9, sizeof(b9), &reply));
    assert(reply.status == APP_ST_OK && reply.payload[0] == 0U);
    assert(param_get()->wash_hold_seconds == 600U);
    assert(param_get()->welcome_hold_seconds == 20U);
    assert(param_get()->welcome_start_interval_s == 60U);
    assert(param_get()->welcome_mode == WELCOME_BOTH_SIDES);
    assert(param_get()->adc_left_antipinch_th_lv1 == 1000U);
    assert(param_get()->adc_left_antipinch_th_lv8 == 1700U);
    assert(param_get()->factory_cmd_len[8] == sizeof(b9));

    memset(&frm, 0, sizeof(frm));
    frm.id = 0x0620U;
    frm.dlc = 8U;
    frm.data[5] = 0x20U;
    frm.data[2] = 0x04U;
    frm.data[4] = 0x10U;
    frm.data[3] = 0x08U;
    assert(can_if_rx_isr_push(&frm));
    scheduler_poll_inputs();
    pump_queue();
    st = policy_get_status();
    assert(st.door_open[DOOR_POS_FL] == true);
    assert(st.door_open[DOOR_POS_RL] == true);
    assert(st.door_open[DOOR_POS_FR] == true);
    assert(st.door_open[DOOR_POS_RR] == true);

    assert(ble_exchange(APP_CMD_Q_STATUS, 0x16U, 0, 0U, &reply));
    assert(reply.status == APP_ST_OK && reply.len == 7U);
    assert((reply.payload[0] & 0x0FU) == 0x0FU);
    assert((reply.payload[2] & 0x01U) != 0U);
    assert((reply.payload[2] & 0x02U) != 0U);
}

static void test_event_reporting_and_ack(void)
{
    app_proto_v2_frame_t reply;
    uint8_t feature_payload[13] = {1U, 15U, 1U, 2U, 0U, 1U, 0x01U, 0U, 0U, 0U, 1U, 0U, 0U};
    uint8_t light_payload[12] = {0U, 0x11U, 0x22U, 0x33U, 0x01U, 80U, 1U, 1U, 0U, 0U, 0U, 0U};

    assert(ble_exchange(APP_CMD_HANDSHAKE, 0x01U, (const uint8_t[]){0x01U, 0x00U}, 2U, &reply));
    assert(reply.status == APP_ST_OK);

    assert(ble_tick_and_fetch_event(&reply));
    assert(reply.cmd == APP_CMD_EVT_ACK);
    assert(reply.payload[0] == APP_EVENT_POWER_ON);
    ble_ack_event(reply.payload[0], reply.payload[1]);
    assert(ble_fetch_tx_frame(&reply));
    assert(reply.payload[0] == APP_EVENT_BLE_CONNECTED);
    ble_ack_event(reply.payload[0], reply.payload[1]);
    assert(!ble_fetch_tx_frame(&reply));

    dispatch_event(EV_DOOR_FL_OPEN, EV_SRC_CAN, 0U);
    assert(ble_tick_and_fetch_event(&reply));
    assert(reply.payload[0] == APP_EVENT_LF_DOOR_OPEN);
    assert(reply.payload[2] == 0U);

    bsp_uart_clear_tx(BSP_UART_PORT_BLE);
    ble_if_tick_100ms();
    assert(!ble_fetch_tx_frame(&reply));
    bsp_uart_clear_tx(BSP_UART_PORT_BLE);
    ble_if_tick_100ms();
    assert(!ble_fetch_tx_frame(&reply));
    assert(ble_tick_and_fetch_event(&reply));
    assert(reply.payload[0] == APP_EVENT_LF_DOOR_OPEN);

    ble_ack_event(reply.payload[0], reply.payload[1]);
    assert(!ble_fetch_tx_frame(&reply));

    assert(ble_exchange(APP_CMD_FEATURE, 0x02U, feature_payload, sizeof(feature_payload), &reply));
    assert(reply.status == APP_ST_OK);
    assert(ble_tick_and_fetch_event(&reply));
    assert(reply.payload[0] == APP_EVENT_SETUP_DONE);
    ble_ack_event(reply.payload[0], reply.payload[1]);
    assert(!ble_fetch_tx_frame(&reply));

    assert(ble_exchange(APP_CMD_LIGHT, 0x03U, light_payload, sizeof(light_payload), &reply));
    assert(reply.status == APP_ST_OK);
    assert(ble_tick_and_fetch_event(&reply));
    assert(reply.payload[0] == APP_EVENT_LIGHT_SET_OK);
    ble_ack_event(reply.payload[0], reply.payload[1]);
    assert(!ble_fetch_tx_frame(&reply));
}

static void test_ota_application_flow(void)
{
    app_proto_v2_frame_t reply;
    uint8_t image[16];
    uint8_t c1[9];
    uint8_t c2[26];
    uint8_t c3[10];
    uint8_t c4[1] = {0x01U};
    uint8_t c5[1] = {0x00U};
    uint16_t crc16;
    uint32_t crc32;
    uint32_t i;

    for (i = 0U; i < sizeof(image); ++i) {
        image[i] = (uint8_t)(0xA0U + i);
    }
    crc16 = test_crc16_ibm(image, (uint16_t)sizeof(image));
    crc32 = test_crc32(image, (uint32_t)sizeof(image));

    c1[0] = 0x01U;
    c1[1] = (uint8_t)sizeof(image); c1[2] = 0x00U; c1[3] = 0x00U; c1[4] = 0x00U;
    c1[5] = 0x04U; c1[6] = 0x03U; c1[7] = 0x02U; c1[8] = 0x01U;
    assert(ble_exchange(APP_CMD_OTA_C1, 0x31U, c1, sizeof(c1), &reply));
    assert(reply.status == APP_ST_OK && reply.payload[0] == 0U);
    pump_queue();

    assert(ble_exchange(APP_CMD_Q_OTA, 0x32U, 0, 0U, &reply));
    assert(reply.status == APP_ST_OK);
    assert(reply.payload[0] == 1U);
    assert(reply.payload[1] == 1U);
    assert(reply.payload[2] == 0x04U && reply.payload[3] == 0x03U && reply.payload[4] == 0x02U && reply.payload[5] == 0x01U);
    assert(reply.payload[6] == OTA_STAGE_PREPARE);

    c2[0] = 0x00U; c2[1] = 0x00U;
    c2[2] = 0x00U; c2[3] = 0x00U; c2[4] = 0x00U; c2[5] = 0x00U;
    c2[6] = (uint8_t)sizeof(image); c2[7] = 0x00U;
    c2[8] = (uint8_t)crc16; c2[9] = (uint8_t)(crc16 >> 8);
    memcpy(&c2[10], image, sizeof(image));
    assert(ble_exchange(APP_CMD_OTA_C2, 0x33U, c2, sizeof(c2), &reply));
    assert(reply.status == APP_ST_OK && reply.payload[2] == 0U);

    assert(ble_exchange(APP_CMD_OTA_C5, 0x34U, c5, sizeof(c5), &reply));
    assert(reply.status == APP_ST_OK);
    assert(reply.payload[0] == OTA_STAGE_RECEIVE);
    assert(reply.payload[1] == 0x01U && reply.payload[2] == 0x00U);

    c3[0] = (uint8_t)sizeof(image); c3[1] = 0x00U; c3[2] = 0x00U; c3[3] = 0x00U;
    c3[4] = (uint8_t)crc32; c3[5] = (uint8_t)(crc32 >> 8); c3[6] = (uint8_t)(crc32 >> 16); c3[7] = (uint8_t)(crc32 >> 24);
    c3[8] = 0x01U; c3[9] = 0x00U;
    assert(ble_exchange(APP_CMD_OTA_C3, 0x35U, c3, sizeof(c3), &reply));
    assert(reply.status == APP_ST_OK && reply.payload[0] == 0U && reply.payload[1] == 0U);

    assert(ble_exchange(APP_CMD_OTA_C5, 0x36U, c5, sizeof(c5), &reply));
    assert(reply.status == APP_ST_OK);
    assert(reply.payload[0] == OTA_STAGE_VERIFY);
    assert(reply.payload[1] == 0x01U && reply.payload[2] == 0x00U);
    assert(reply.payload[3] == 0x01U && reply.payload[4] == 0x00U);
    assert(reply.payload[5] == 0x00U);

    assert(ble_exchange(APP_CMD_OTA_C4, 0x37U, c4, sizeof(c4), &reply));
    assert(reply.status == APP_ST_OK && reply.payload[0] == 0U);
    pump_queue();

    assert(ble_exchange(APP_CMD_OTA_C5, 0x38U, c5, sizeof(c5), &reply));
    assert(reply.status == APP_ST_OK);
    assert(reply.payload[0] == OTA_STAGE_SWITCH);
}

static void test_u17_protocol_handshake_and_timeout(void)
{
    uint32_t i;
    u17_link_diag_t diag;
    u17_remote_status_t remote;

    bsp_uart_clear_tx(BSP_UART_PORT_U17);
    u17_link_tick_10ms();
    service_link_once();

    u17_link_get_diag(&diag);
    assert(diag.link_online == true);
    assert(diag.param_sync_pending == false);
    assert(diag.boot_seen == true);

    u17_link_get_remote_status(&remote);
    assert(remote.slave_ready == true);

    assert(u17_link_request_voice(0U, 2U, false));
    for (i = 0U; i < 21U; ++i) {
        u17_link_tick_10ms();
    }

    u17_link_get_diag(&diag);
    assert(diag.request_retry_count >= 3U);
    assert(diag.request_timeout_count >= 1U);
    assert(fault_has(FAULT_U17_LINK));

    for (i = 0U; i < 151U; ++i) {
        u17_link_tick_10ms();
    }
    assert(fault_has(FAULT_U17_LINK));
}

int main(void)
{
    init_all();
    test_ble_atomic_commit();
    init_all();
    test_welcome_and_limit_flow();
    init_all();
    test_nvm_reinit_persistence();
    test_power_recovery_policy();
    test_event_overflow_latch();
    init_all();
    test_factory_protocol_and_status_query();
    init_all();
    test_event_reporting_and_ack();
    init_all();
    test_ota_application_flow();
    init_all();
    test_u17_protocol_handshake_and_timeout();
    printf("[OK] host regression tests passed\n");
    return 0;
}
