#ifndef U17_SLAVE_SERVICE_U12_U17_SLAVE_LINK_H
#define U17_SLAVE_SERVICE_U12_U17_SLAVE_LINK_H

#include "project_bool.h"
#include <stddef.h>
#include <stdint.h>
#include "pedal_types.h"
#include "u17_slave/control/u17_exec.h"

/*
 * U17 从机协议层入口。
 *
 * 这个模块可以理解成：
 * - 收到 U12 发来的串口帧 -> 解析 -> 调用 u17_exec 执行
 * - 收集执行状态 -> 组装状态/故障/启动上报帧 -> 回给 U12
 * - 通过心跳/有效命令监测 U12 主控是否在线
 */
void u12_u17_slave_link_init(void);
void u12_u17_slave_link_rx_bytes(const uint8_t *data, size_t len);
size_t u12_u17_slave_link_fetch_tx(uint8_t *buf, size_t max_len);
void u12_u17_slave_link_tick_10ms(void);
void u12_u17_slave_link_set_limit(step_side_t side, bool ext_limit, bool ret_limit);
void u12_u17_slave_link_set_current(step_side_t side, uint16_t raw);
void u12_u17_slave_link_get_status(u17_exec_status_t *status);
bool u12_u17_slave_link_is_master_online(void);
uint32_t u12_u17_slave_link_master_timeout_count(void);

#endif
