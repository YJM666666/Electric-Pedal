#include "u12_u17_slave_link.h"
#include "service/u17_proto.h"
#include <string.h>

#define U17S_TX_BUF_SIZE 512U
#define U17S_STATUS_PERIOD_10MS 10U
#define U17S_MASTER_TIMEOUT_10MS 100U

typedef struct
{
    uint8_t tx_buf[U17S_TX_BUF_SIZE];
    size_t  tx_len;
    uint16_t tx_seq;
    uint16_t status_tick_10ms;
    uint16_t since_master_rx_10ms;
    uint32_t master_timeout_count;
    bool     master_online;
    bool     boot_report_pending;
    bool     status_dirty;
    u17_proto_parser_t parser;
} u17_slave_ctx_t;

static u17_slave_ctx_t s_ctx;

static bool queue_tx(uint8_t flags,
                     uint8_t cmd,
                     uint16_t ack_seq,
                     const uint8_t *payload,
                     uint8_t payload_len)
{
    uint8_t frame[U17_PROTO_MAX_FRAME];
    uint16_t frame_len;
    size_t room;

    s_ctx.tx_seq++;
    if (s_ctx.tx_seq == 0U) {
        s_ctx.tx_seq = 1U;
    }

    if (!u17_proto_build(flags, cmd, s_ctx.tx_seq, ack_seq, payload, payload_len, frame, &frame_len)) {
        return false;
    }

    room = U17S_TX_BUF_SIZE - s_ctx.tx_len;
    if (frame_len > room) {
        return false;
    }

    (void)memcpy(&s_ctx.tx_buf[s_ctx.tx_len], frame, frame_len);
    s_ctx.tx_len += frame_len;
    return true;
}

static void put_le16(uint8_t *dst, uint16_t value)
{
    dst[0] = (uint8_t)(value & 0xFFU);
    dst[1] = (uint8_t)((value >> 8U) & 0xFFU);
}

static void put_le32(uint8_t *dst, uint32_t value)
{
    dst[0] = (uint8_t)(value & 0xFFU);
    dst[1] = (uint8_t)((value >> 8U) & 0xFFU);
    dst[2] = (uint8_t)((value >> 16U) & 0xFFU);
    dst[3] = (uint8_t)((value >> 24U) & 0xFFU);
}

static void send_result(uint8_t cmd, uint16_t ack_seq, uint8_t result)
{
    uint8_t payload[1];
    payload[0] = result;
    (void)queue_tx(U17_PROTO_CLASS_RSP, cmd, ack_seq, payload, sizeof(payload));
}

static void send_boot_report(void)
{
    uint8_t payload[3];
    payload[0] = U17_PROTO_VERSION;
    payload[1] = (uint8_t)(U17_PROTO_BOOTF_READY | U17_PROTO_BOOTF_HAS_EE | U17_PROTO_BOOTF_HAS_FLASH);
    payload[2] = 0x01U;
    (void)queue_tx(U17_PROTO_CLASS_EVT, U17_CMD_BOOT_REPORT, 0U, payload, sizeof(payload));
}

static void send_status_report(void)
{
    uint8_t payload[13];
    u17_exec_status_t st;

    u17_exec_get_status(&st);
    payload[0] = 0U;
    if (st.left_ext_limit) {
        payload[0] |= U17_PROTO_STATUSF_L_EXT;
    }
    if (st.left_ret_limit) {
        payload[0] |= U17_PROTO_STATUSF_L_RET;
    }
    if (st.right_ext_limit) {
        payload[0] |= U17_PROTO_STATUSF_R_EXT;
    }
    if (st.right_ret_limit) {
        payload[0] |= U17_PROTO_STATUSF_R_RET;
    }
    if (st.light_enabled) {
        payload[0] |= U17_PROTO_STATUSF_LIGHT;
    }
    /* 当前 U17 无蜂鸣器硬件；BUZZER 状态位保留并置 0。 */
    if (st.ready) {
        payload[0] |= U17_PROTO_STATUSF_READY;
    }
    if (st.voice_busy) {
        payload[0] |= U17_PROTO_STATUSF_VOICE;
    }

    payload[1] = (uint8_t)st.left_action;
    payload[2] = (uint8_t)st.right_action;
    payload[3] = st.active_light_scene;
    payload[4] = st.active_light_cfg.r;
    payload[5] = st.active_light_cfg.g;
    payload[6] = st.active_light_cfg.b;
    payload[7] = st.active_light_cfg.mode;
    put_le16(&payload[8], st.left_current_raw);
    put_le16(&payload[10], st.right_current_raw);
    payload[12] = 0U;

    (void)queue_tx(U17_PROTO_CLASS_EVT, U17_CMD_STATUS_REPORT, 0U, payload, sizeof(payload));
}

static void send_fault_report(void)
{
    uint8_t payload[4];
    u17_exec_status_t st;

    u17_exec_get_status(&st);
    put_le32(payload, st.fault_mask);
    (void)queue_tx(U17_PROTO_CLASS_EVT, U17_CMD_FAULT_REPORT, 0U, payload, sizeof(payload));
}

static void mark_status_dirty(void)
{
    s_ctx.status_dirty = true;
}

static void note_master_rx_alive(void)
{
    bool was_online = s_ctx.master_online;
    s_ctx.since_master_rx_10ms = 0U;
    s_ctx.master_online = true;
    if (!was_online) {
        mark_status_dirty();
    }
}

static void handle_req(const u17_proto_frame_t *frame)
{
    light_scene_cfg_t cfg;
    bool ok;

    if (frame == 0) {
        return;
    }

    switch (frame->cmd)
    {
        case U17_CMD_HEARTBEAT:
            send_result(frame->cmd, frame->seq, U17_PROTO_RESULT_OK);
            mark_status_dirty();
            break;

        case U17_CMD_PARAM_SYNC:
            ok = u17_exec_apply_param_snapshot(frame->payload, frame->payload_len);
            send_result(frame->cmd, frame->seq, ok ? U17_PROTO_RESULT_OK : U17_PROTO_RESULT_INVALID);
            if (ok) {
                mark_status_dirty();
            }
            break;

        case U17_CMD_STEP_CTRL:
            ok = (frame->payload_len >= 2U) ?
                 u17_exec_apply_step((step_side_t)frame->payload[0], (step_action_t)frame->payload[1]) : false;
            send_result(frame->cmd, frame->seq, ok ? U17_PROTO_RESULT_OK : U17_PROTO_RESULT_INVALID);
            if (ok) {
                mark_status_dirty();
            }
            break;

        case U17_CMD_LIGHT_SCENE:
            if (frame->payload_len >= 6U) {
                cfg.r = frame->payload[1];
                cfg.g = frame->payload[2];
                cfg.b = frame->payload[3];
                cfg.mode = frame->payload[4];
                ok = u17_exec_apply_light(frame->payload[0], &cfg, (frame->payload[5] != 0U));
            } else {
                ok = false;
            }
            send_result(frame->cmd, frame->seq, ok ? U17_PROTO_RESULT_OK : U17_PROTO_RESULT_INVALID);
            if (ok) {
                mark_status_dirty();
            }
            break;

        case U17_CMD_BUZZER_CTRL:
                /* 当前 U17 原理图无独立蜂鸣器输出。 */
            send_result(frame->cmd, frame->seq, U17_PROTO_RESULT_UNSUP);
            break;

        case U17_CMD_VOICE_CTRL:
            ok = (frame->payload_len >= 4U) ?
                 u17_exec_apply_voice(frame->payload[0],
                                      (uint16_t)((uint16_t)frame->payload[1] | ((uint16_t)frame->payload[2] << 8U)),
                                      (frame->payload[3] != 0U)) : false;
            send_result(frame->cmd, frame->seq, ok ? U17_PROTO_RESULT_OK : U17_PROTO_RESULT_INVALID);
            if (ok) {
                mark_status_dirty();
            }
            break;

        default:
            send_result(frame->cmd, frame->seq, U17_PROTO_RESULT_UNSUP);
            break;
    }
}

void u12_u17_slave_link_init(void)
{
    (void)memset(&s_ctx, 0, sizeof(s_ctx));
    u17_proto_parser_init(&s_ctx.parser);
    u17_exec_init();
    s_ctx.boot_report_pending = true;
    s_ctx.status_dirty = true;
}

void u12_u17_slave_link_rx_bytes(const uint8_t *data, size_t len)
{
    size_t i;
    u17_proto_frame_t frame;
    bool frame_ready;

    if ((data == 0) || (len == 0U)) {
        return;
    }

    for (i = 0U; i < len; ++i) {
        if (!u17_proto_parser_feed(&s_ctx.parser, data[i], &frame, &frame_ready)) {
            continue;
        }
        if (frame_ready) {
            note_master_rx_alive();
            if ((frame.flags & U17_PROTO_FLAG_CLASS_MASK) == U17_PROTO_CLASS_REQ) {
                handle_req(&frame);
            }
        }
    }
}

size_t u12_u17_slave_link_fetch_tx(uint8_t *buf, size_t max_len)
{
    size_t copy_len;

    if ((buf == 0) || (max_len == 0U)) {
        return 0U;
    }

    copy_len = (s_ctx.tx_len <= max_len) ? s_ctx.tx_len : max_len;
    (void)memcpy(buf, s_ctx.tx_buf, copy_len);
    if (copy_len < s_ctx.tx_len) {
        (void)memmove(s_ctx.tx_buf, &s_ctx.tx_buf[copy_len], s_ctx.tx_len - copy_len);
    }
    s_ctx.tx_len -= copy_len;
    return copy_len;
}

void u12_u17_slave_link_tick_10ms(void)
{
    u17_exec_status_t st;

    u17_exec_tick_10ms();
    u17_exec_get_status(&st);

    if (s_ctx.since_master_rx_10ms < 0xFFFFU) {
        s_ctx.since_master_rx_10ms++;
    }
    if (s_ctx.master_online && (s_ctx.since_master_rx_10ms >= U17S_MASTER_TIMEOUT_10MS)) {
        s_ctx.master_online = false;
        s_ctx.master_timeout_count++;
        mark_status_dirty();
    }

    if (s_ctx.boot_report_pending) {
        send_boot_report();
        s_ctx.boot_report_pending = false;
    }

    if (s_ctx.status_tick_10ms < 0xFFFFU) {
        s_ctx.status_tick_10ms++;
    }

    if (s_ctx.status_dirty || (s_ctx.status_tick_10ms >= U17S_STATUS_PERIOD_10MS)) {
        send_status_report();
        s_ctx.status_tick_10ms = 0U;
        s_ctx.status_dirty = false;
    }

    if (st.fault_mask != 0U) {
        send_fault_report();
    }
}

void u12_u17_slave_link_set_limit(step_side_t side, bool ext_limit, bool ret_limit)
{
    u17_exec_set_limit(side, ext_limit, ret_limit);
    mark_status_dirty();
}

void u12_u17_slave_link_set_current(step_side_t side, uint16_t raw)
{
    u17_exec_set_current(side, raw);
    mark_status_dirty();
}

void u12_u17_slave_link_get_status(u17_exec_status_t *status)
{
    u17_exec_get_status(status);
}

bool u12_u17_slave_link_is_master_online(void)
{
    return s_ctx.master_online;
}

uint32_t u12_u17_slave_link_master_timeout_count(void)
{
    return s_ctx.master_timeout_count;
}
