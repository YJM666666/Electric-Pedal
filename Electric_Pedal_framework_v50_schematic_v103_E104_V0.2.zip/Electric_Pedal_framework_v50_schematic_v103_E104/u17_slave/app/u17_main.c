#include "bsp_build.h"
#if defined(APP_ROLE_U17_SLAVE)
#include "u17_slave/service/u12_u17_slave_link.h"
#include "bsp_platform.h"
#include "bsp_gpio.h"
#include "bsp_adc.h"
#include "bsp_uart.h"
#include "bsp_wdg.h"
#include "bsp_timer.h"
#include "bsp_i2c.h"
#include "bsp_voice.h"

/*
 * u17_main.c (U17 / 执行侧)
 * ---------------------------------------------------------------
 * 这个文件只在“执行侧目标”里编译：U17_Light_Voice。
 *
 * U17 当前职责：
 * - 接收 U12 下发的串口帧
 * - 执行灯光、语音等输出
 * - 当前硬件无蜂鸣器输出，不处理蜂鸣器命令
 * - 回传状态、限位、电流等执行侧信息
 *
 * 注意：
 * - 原有刷电机主链路已经回到 U12，不再由 U17 执行
 * - 本文件的主循环非常“薄”，多数业务都在 u12_u17_slave_link / u17_exec 里
 */

/*
 * 把 U17 本地采到的输入同步进“从机状态对象”。
 * 这样主控 U12 在读状态报告时，看到的是最新的限位和电流值。
 */
static void u17_sync_inputs(void)
{
    u12_u17_slave_link_set_limit(STEP_SIDE_LEFT,
                            bsp_gpio_read_in(BSP_GPIO_IN_L_EXT_LIMIT),
                            bsp_gpio_read_in(BSP_GPIO_IN_L_RET_LIMIT));
    u12_u17_slave_link_set_limit(STEP_SIDE_RIGHT,
                            bsp_gpio_read_in(BSP_GPIO_IN_R_EXT_LIMIT),
                            bsp_gpio_read_in(BSP_GPIO_IN_R_RET_LIMIT));
    u12_u17_slave_link_set_current(STEP_SIDE_LEFT, bsp_adc_get_left_current_raw());
    u12_u17_slave_link_set_current(STEP_SIDE_RIGHT, bsp_adc_get_right_current_raw());
}

int main(void)
{
    uint8_t rx_buf[64];
    uint8_t tx_buf[96];
    uint32_t last_10ms = 0U;
    uint32_t now_ms;
    size_t rx_len;
    size_t tx_len;

    /*
     * U17 侧初始化顺序和 U12 类似，但更偏执行：
     * voice/light 的基础资源要尽早准备好，
     * 然后再启动 slave 协议层。
     */
    bsp_platform_init();
    bsp_gpio_init();
    bsp_adc_init();
    bsp_uart_init();
    bsp_i2c_init();
    bsp_voice_init();
    bsp_wdg_init();
    bsp_timer_init();
    u12_u17_slave_link_init();

    while (1) {
        /* 收主控发来的数据帧。 */
        rx_len = bsp_uart_recv(BSP_UART_PORT_U17, rx_buf, sizeof(rx_buf));
        if (rx_len > 0U) {
            u12_u17_slave_link_rx_bytes(rx_buf, rx_len);
        }

        /* 周期性刷新本地输入快照。 */
        u17_sync_inputs();

        /*
         * U17 的内部状态机按 10ms 节拍跑：
         * - 语音 busy 采样
         * - 当前无蜂鸣器硬件，蜂鸣器状态不维护
         * - 周期状态上报等
         */
        now_ms = bsp_timer_now_ms();
        while ((now_ms - last_10ms) >= 10U) {
            last_10ms += 10U;
            u12_u17_slave_link_tick_10ms();
        }

        /* 如果协议层有待发数据，这里统一往 UART 发。 */
        tx_len = u12_u17_slave_link_fetch_tx(tx_buf, sizeof(tx_buf));
        if (tx_len > 0U) {
            (void)bsp_uart_send(BSP_UART_PORT_U17, tx_buf, tx_len);
        }

        bsp_wdg_feed();
    }
}

#endif /* APP_ROLE_U17_SLAVE */
