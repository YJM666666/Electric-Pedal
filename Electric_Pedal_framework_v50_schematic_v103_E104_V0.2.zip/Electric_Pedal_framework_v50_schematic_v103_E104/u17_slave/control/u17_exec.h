#ifndef U17_SLAVE_CONTROL_U17_EXEC_H
#define U17_SLAVE_CONTROL_U17_EXEC_H

#include "project_bool.h"
#include <stdint.h>
#include "pedal_types.h"
#include "param.h"

/*
 * U17 执行侧状态镜像。
 * 这个结构既用于本地管理，也会被协议层打包后回传给 U12。
 */
typedef struct
{
    bool          ready;
    bool          left_ext_limit;
    bool          left_ret_limit;
    bool          right_ext_limit;
    bool          right_ret_limit;
    bool          light_enabled;
    bool          voice_busy;
    uint8_t       active_light_scene;
    light_scene_cfg_t active_light_cfg;
    step_action_t left_action;
    step_action_t right_action;
    uint16_t      left_current_raw;
    uint16_t      right_current_raw;
    uint32_t      fault_mask;
    bool          left_out_a;
    bool          left_out_b;
    bool          right_out_a;
    bool          right_out_b;
} u17_exec_status_t;

void u17_exec_init(void);
bool u17_exec_apply_param_snapshot(const uint8_t *payload, uint8_t payload_len);
bool u17_exec_apply_step(step_side_t side, step_action_t action);
bool u17_exec_apply_light(uint8_t scene, const light_scene_cfg_t *cfg, bool enable);
bool u17_exec_apply_buzzer(bool enable, uint8_t pattern, uint16_t duration_10ms); /* 当前 U17 原理图无蜂鸣器硬件 */
bool u17_exec_apply_voice(uint8_t lang, uint16_t voice_id, bool stop);
void u17_exec_tick_10ms(void);
void u17_exec_set_limit(step_side_t side, bool ext_limit, bool ret_limit);
void u17_exec_set_current(step_side_t side, uint16_t raw);
void u17_exec_get_status(u17_exec_status_t *status);

#endif
