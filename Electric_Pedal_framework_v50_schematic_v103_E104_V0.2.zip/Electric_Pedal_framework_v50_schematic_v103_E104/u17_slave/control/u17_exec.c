#include "u17_exec.h"
#include "bsp_build.h"
#include "bsp_voice.h"
#include "service/voice_catalog.h"
#include <string.h>

#if BSP_PLATFORM_GD32
#include "bsp_gpio.h"
#endif

/*
 * U17 执行上下文。
 *
 * 这里保存执行侧需要长期记住的少量状态：
 * - 左右电机是否反相（目前仅参数占位）
 * - 当前状态镜像
 */
typedef struct
{
    bool left_reverse;
    bool right_reverse;
    u17_exec_status_t status;
} u17_exec_ctx_t;

static u17_exec_ctx_t s_exec;

void u17_exec_init(void)
{
    (void)memset(&s_exec, 0, sizeof(s_exec));
    s_exec.status.ready = true;
#if BSP_PLATFORM_GD32
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_L1, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_R1, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_L2, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_R2, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_L1, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_R1, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_L2, false);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_R2, false);
    bsp_gpio_write(BSP_GPIO_OUT_DRIVER_EN, false);
    bsp_gpio_write(BSP_GPIO_OUT_DRIVER_PWM, false);
#endif
}

bool u17_exec_apply_param_snapshot(const uint8_t *payload, uint8_t payload_len)
{
    if ((payload == 0) || (payload_len < 8U)) {
        return false;
    }

    /* 目前只取了左右方向反相两项，后续可以继续扩参数。 */
    s_exec.left_reverse = (payload[0] != 0U);
    s_exec.right_reverse = (payload[1] != 0U);
    return true;
}

bool u17_exec_apply_step(step_side_t side, step_action_t action)
{
    (void)side;
    (void)action;

    /*
     * 最新职责划分：传统有刷电机已经回到 U12。
     * 所以 U17 收到 STEP 命令时，明确返回 false，避免误执行。
     */
    return false;
}

bool u17_exec_apply_light(uint8_t scene, const light_scene_cfg_t *cfg, bool enable)
{
    if (cfg == 0) {
        return false;
    }

    s_exec.status.active_light_scene = scene;
    s_exec.status.active_light_cfg = *cfg;
    s_exec.status.light_enabled = enable;
#if BSP_PLATFORM_GD32
    /*
     * 当前先做最小硬件动作：使能/关闭左右灯输出。
     * 真正的灯效编码可在后续驱动里继续扩。
     */
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_L1, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_R1, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_L2, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_DATA_R2, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_L1, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_R1, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_L2, enable);
    bsp_gpio_write(BSP_GPIO_OUT_LIGHT_PWR_R2, enable);
    bsp_gpio_write(BSP_GPIO_OUT_DRIVER_EN, enable);
#endif
    return true;
}

bool u17_exec_apply_buzzer(bool enable, uint8_t pattern, uint16_t duration_10ms)
{
    (void)enable;
    (void)pattern;
    (void)duration_10ms;

    /* 当前 U17 原理图无独立蜂鸣器硬件；蜂鸣器命令明确不支持。 */
    return false;
}

bool u17_exec_apply_voice(uint8_t lang, uint16_t voice_id, bool stop)
{
    uint16_t slot = 0U;
    uint16_t duration_ms = 0U;
    bsp_voice_lang_t voice_lang = (lang == (uint8_t)BSP_VOICE_LANG_EN) ? BSP_VOICE_LANG_EN : BSP_VOICE_LANG_ZH;

    if (stop) {
        s_exec.status.voice_busy = false;
        return bsp_voice_stop();
    }

    if (!voice_catalog_resolve((voice_id_t)voice_id, voice_lang, &slot, &duration_ms)) {
        return false;
    }

    /* 先把状态置 busy，实际 10ms 维护里会再按硬件 BUSY 校准。 */
    s_exec.status.voice_busy = true;
    return bsp_voice_play_slot(slot, duration_ms);
}

void u17_exec_tick_10ms(void)
{
    /* 语音 busy 采样和兜底时长维护都在 BSP voice 层完成。 */
    bsp_voice_tick_10ms();
    s_exec.status.voice_busy = bsp_voice_is_busy();

    /* 有刷电机的限位处理现在保留在 MCU1/U12。 */
}

void u17_exec_set_limit(step_side_t side, bool ext_limit, bool ret_limit)
{
    if (side == STEP_SIDE_LEFT) {
        s_exec.status.left_ext_limit = ext_limit;
        s_exec.status.left_ret_limit = ret_limit;
    } else if (side == STEP_SIDE_RIGHT) {
        s_exec.status.right_ext_limit = ext_limit;
        s_exec.status.right_ret_limit = ret_limit;
    }
}

void u17_exec_set_current(step_side_t side, uint16_t raw)
{
    if (side == STEP_SIDE_LEFT) {
        s_exec.status.left_current_raw = raw;
    } else if (side == STEP_SIDE_RIGHT) {
        s_exec.status.right_current_raw = raw;
    }
}

void u17_exec_get_status(u17_exec_status_t *status)
{
    if (status == 0) {
        return;
    }

    *status = s_exec.status;
}
